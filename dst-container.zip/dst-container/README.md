DST Container
==============

DST Container (2.1.2 or above) is based on Spring Boot (2.0) embedded Tomcat container with custom Spring configurations that are common across SIG platform applications.

The main goals of  DST container are

* Make SIG applications run as Uber WAR or deploy them in standard container's
* Bundle all common configurations into container so that existing applications can run with minimal changes
* Extendable with additional configurations as needed (like ActiveMQ, Batch etc)
* Ease development of SaaS style multi-tenant applications. (3.0.0)
* Make existing SIG applications to run in multi-tenancy mode with minimal changes. (3.0.0)
* Easily deploy or on-board new tenant. (3.0.0)
* Separate configuration file per tenant. (3.0.0)
* Make container as true spring boot starter application. (3.0.0)
* Introduce a programming pattern for developing of multi-tenant applications. (3.0.0)

Project Setup

Main Modules

**container-multitenant-context** module has basic classes (like TenantScope, TenantRequestContext, TenantApplicationContext etc) needed for multi-tenant context. This module can be added as a dependency where you don't need to container-spring-boot-starter module but want to access Tenant related classes.

**container-spring-boot-starter** module has implementation of container configuration classes along with multi-tenancy implementation logic. This module is a true SpringBoot starter module and which brings only log4j as dependency. All configuration classes are loaded based on included dependencies.

Other Modules

**container-maven-plugin** module is implementation for creating distribution file for running container based applications outside pipeline VM's.

**container-multitenant-example** module is a sample application to showcase the multi-tenancy setup.

**container-example-2.1.x** module is a sample application which shows the how to use 2.1.x version of the container.

More details can be found on how to setup and customize container at https://confluence.ssnc.global/display/DSTHSSIG/DST+Container+-+Spring+Boot+Uber+WAR