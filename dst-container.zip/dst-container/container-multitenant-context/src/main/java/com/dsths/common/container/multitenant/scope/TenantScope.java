package com.dsths.common.container.multitenant.scope;

import org.springframework.beans.factory.config.Scope;

/**
 * Tenant Scope is custom spring scope which defines bean lifecycle in Spring Context per tenant.
 * <p/>
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
public interface TenantScope extends Scope {
}
