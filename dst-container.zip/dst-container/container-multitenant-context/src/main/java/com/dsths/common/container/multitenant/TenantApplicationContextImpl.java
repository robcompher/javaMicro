package com.dsths.common.container.multitenant;

import java.util.Set;

/**
 * Created by DT214743 on 12/30/2018.
 */
public class TenantApplicationContextImpl implements TenantApplicationContext {
  private final Set<String> allTenants;
  private final String primaryTenant;
  private final boolean tenanted;

  public TenantApplicationContextImpl(Set<String> tenantList, String primaryTenant, boolean tenanted) {
    this.allTenants = tenantList;
    this.tenanted = tenanted;
    this.primaryTenant = primaryTenant;
  }

  public Set<String> getAllTenants() {
    return allTenants;
  }

  public boolean isTenanted() {
    return tenanted;
  }

  public String getPrimaryTenant() {
    return primaryTenant;
  }
}
