package com.dsths.common.container.multitenant.support;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.core.env.Environment;

import java.nio.file.Paths;

/**
 * Created by DT214743 on 3/11/2019.
 */
public class TenantPathBuilder {
  private static Environment environment;
  private static TenantRequestContext tenantRequestContext;

  private TenantPathBuilder() {}

  static void init(Environment env, TenantRequestContext trc) {
    environment = env;
    tenantRequestContext = trc;
  }

  public static String getPath(String pathKey) {
    if (environment == null) {
      throw new IllegalStateException("TenantPathBuilder is not initialized");
    }
    String path = environment.getRequiredProperty(pathKey);
    return buildPath(path);
  }

  public static String buildPath(String path) {
    if (tenantRequestContext != null && tenantRequestContext.isTenanted()) {
      return Paths.get(path, tenantRequestContext.getCurrentTenant()).toString();
    }
    return path;
  }
}
