package com.dsths.common.container.multitenant;

import com.dsths.common.container.multitenant.exception.TenantNotFoundException;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

/**
 * Use this to manage tenant context per thread. Every time a new thread is invoked, make sure the context is reset
 * because a new thread would lose the current tenant's identifier information.
 * <p/>
 * Created by DT214743 on 12/25/2018.
 */
public class TenantRequestContextImpl implements TenantRequestContext {

  private static final Logger logger = LogManager.getLogger(TenantRequestContextImpl.class);

  private final TenantApplicationContext tenantApplicationContext;
  private String currentTenant;
  private int incrementer = 0;

  public TenantRequestContextImpl(TenantApplicationContext tenantApplicationContext) {
    this.tenantApplicationContext = tenantApplicationContext;
  }

  @Override
  public String getCurrentTenant() {
    return currentTenant;
  }

  @Override
  public void setCurrentTenant(String currentTenant) {
    if (this.currentTenant == null) {
      if (isTenanted() && !this.tenantApplicationContext.getAllTenants().contains(currentTenant)) {
        throw new TenantNotFoundException(currentTenant, String.format("Tenant \"%s\" is not valid.", currentTenant));
      }
      this.currentTenant = currentTenant;
    }
    ++incrementer;
  }

  @Override
  public boolean isTenanted() {
    return tenantApplicationContext.isTenanted();
  }

  @Override
  public void clear() {
    this.clear(false);
  }

  @Override
  public void clear(boolean force) {
    if (incrementer > 0) {--incrementer;}
    if (force || incrementer == 0) {
      if (incrementer != 0) {
        logger.warn("!!! TestRequestContext setCurrentTenant and clear calls are not matching. " +
            "Make sure every setCurrentTenant has matching clear call !!!!");
      }
      this.currentTenant = null;
      this.incrementer = 0;
    }
  }

  @Override
  public TenantApplicationContext getTenantApplicationContext() {
    return tenantApplicationContext;
  }
}
