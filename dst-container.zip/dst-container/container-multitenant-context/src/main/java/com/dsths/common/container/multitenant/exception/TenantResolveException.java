package com.dsths.common.container.multitenant.exception;

/**
 * Created by DT214743 on 12/27/2018.
 */
public class TenantResolveException extends TenantException {

  public TenantResolveException(String message) {
    super(message);
  }

  public TenantResolveException(String message, Throwable cause) {
    super(message, cause);
  }

}
