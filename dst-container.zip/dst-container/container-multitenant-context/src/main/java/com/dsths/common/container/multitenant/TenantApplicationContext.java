package com.dsths.common.container.multitenant;

import java.util.Set;

/**
 * Initialized when application started and maintains the list of initialized tenant's.
 * <p/>
 * Created by DT214743 on 12/30/2018.
 */
public interface TenantApplicationContext {
  Set<String> getAllTenants();

  boolean isTenanted();

  String getPrimaryTenant();
}
