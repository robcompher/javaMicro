package com.dsths.common.container.multitenant.scope;

import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 * Convenient/Shortcut annotation to mark a bean Tenant scope.
 * <p/>
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
@Scope(value = "tenant", proxyMode = ScopedProxyMode.TARGET_CLASS)
@Retention(RetentionPolicy.RUNTIME)
public @interface TenantScoped {
}
