package com.dsths.common.container.multitenant.scope;

import org.springframework.beans.factory.config.Scope;

/**
 * Created by DT214743 on 1/14/2019.
 */
public class DefaultDestructionCallback implements Runnable {
  private final Scope scope;
  private final String name;

  /**
   * Construct the Callback with the {@link Scope} and bean name
   *
   * @param scope The {@link Scope} the destruction callback runs under
   * @param name  The name of the bean
   */
  public DefaultDestructionCallback(Scope scope, String name) {
    this.scope = scope;
    this.name = name;
  }

  /**
   * Removes the bean from the scope
   */
  public void run() {
    scope.remove(name);
  }
}
