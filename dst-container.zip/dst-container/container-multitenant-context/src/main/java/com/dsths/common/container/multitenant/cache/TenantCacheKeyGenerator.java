package com.dsths.common.container.multitenant.cache;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.util.StringUtils;

import java.lang.reflect.Method;

/**
 * Generates the cache key per tenant if running in Tenanted mode.
 * <p/>
 * Simply appends Tenant from request to the key.
 * <p/>
 * Created by DT214743 on 3/9/2018.
 */
public class TenantCacheKeyGenerator implements KeyGenerator {

  @Autowired
  private TenantRequestContext tenantRequestContext;

  private static final String KEY_SEPARATOR = "_";

  @Override
  public Object generate(Object o, Method method, Object... params) {
    StringBuilder builder = new StringBuilder();
    builder.append(o.getClass().getSimpleName());
    builder.append(KEY_SEPARATOR);
    builder.append(method.getName());
    builder.append(KEY_SEPARATOR);
    builder.append(StringUtils.arrayToDelimitedString(params, KEY_SEPARATOR));
    //Add tenant
    if (tenantRequestContext.isTenanted()) {
      builder.append(KEY_SEPARATOR).append(tenantRequestContext.getCurrentTenant());
    }
    return builder.toString();
  }
}
