package com.dsths.common.container.multitenant.exception;

/**
 * Created by DT214743 on 12/27/2018.
 */
public class TenantNotFoundException extends TenantException {
  private final String missingTenant;

  public TenantNotFoundException(String tenant, String message) {
    super(message);
    this.missingTenant = tenant;
  }

  public TenantNotFoundException(String tenant, String message, Throwable cause) {
    super(message, cause);

    this.missingTenant = tenant;
  }

  public String getMissingTenant() {
    return missingTenant;
  }

}
