package com.dsths.common.container.multitenant.scope;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.ObjectFactory;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tenant Scope is custom spring scope which defines bean lifecycle in Spring Context per tenant.
 * <p/>
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
public class TenantScopeImpl implements TenantScope {
  private static final Logger logger = LogManager.getLogger(TenantScopeImpl.class);

  protected final TenantRequestContext tenantRequestContext;

  protected final Map<Object, Map<String, Object>> scopedBeans;
  protected final ObjectFactory mapFactory;

  protected final Map<Object, Map<String, Runnable>> destructionCallbacks;

  public TenantScopeImpl(TenantRequestContext tenantRequestContext) {
    this.scopedBeans = new ConcurrentHashMap<>();
    this.mapFactory = ConcurrentHashMap<String, Object>::new;
    this.destructionCallbacks = new ConcurrentHashMap<>();
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public Object get(String name, ObjectFactory<?> objectFactory) {
    String conversationId = getConversationId();
    logger.trace("Retrieving {} scope bean {}", conversationId, name);

    Map<String, Object> beans = (Map) getBean(scopedBeans, conversationId, mapFactory, false);
    return getBean(beans, name, objectFactory, true);
  }

  @Override
  public Object remove(String name) {
    String conversationId = getConversationId();
    logger.trace("Removing {} scope bean {}", conversationId, name);

    Map<String, Object> beans = (Map) getBean(scopedBeans, conversationId, mapFactory, false);
    return beans.remove(name);
  }

  @Override
  public void registerDestructionCallback(String name, Runnable callback) {
    String conversationId = getConversationId();
    logger.trace("Registering destruction callback to {} scope bean {}", conversationId, name);
    Map<String, Runnable> callbacks = (Map) getBean(destructionCallbacks, conversationId, mapFactory, false);

    callbacks.computeIfAbsent(name, k -> callback);
  }

  @Override
  public Object resolveContextualObject(String s) {
    return null;
  }

  @Override
  public String getConversationId() {
    if (!tenantRequestContext.isTenanted()) {
      logger.trace("non-tenanted mode, returning default");
      return "default";
    } else if (tenantRequestContext.getCurrentTenant() == null) {
      throw new IllegalStateException("Tenant not found in request context.");
    }
    logger.trace("tenanted mode, returning current tenant");
    return tenantRequestContext.getCurrentTenant();
  }

  protected Object getBean(Map map, String name, ObjectFactory factory, boolean registerCb) {
    Object o = map.computeIfAbsent(name, k -> factory.getObject());

    if (registerCb) {
      registerDefaultDestructionCallback(name);
    }

    return o;
  }

  protected void registerDefaultDestructionCallback(String name) {
    String conversationId = getConversationId();

    Map<String, Runnable> callbacks = (Map) getBean(destructionCallbacks, conversationId, mapFactory, false);
    if (!callbacks.containsKey(name)) {
      logger.trace("Registering default destruction callback to bean {}", name);
      registerDestructionCallback(name, new DefaultDestructionCallback(this, name));
    }
  }
}
