package com.dsths.common.container.multitenant.support;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.env.Environment;

import javax.annotation.PostConstruct;

/**
 * Created by DT214743 on 11/12/2019.
 */
public class TenantPathBuilderInitializer implements EnvironmentAware {
  private Environment environment;
  private TenantRequestContext tenantRequestContext;

  public void setTenantRequestContext(TenantRequestContext requestContext) {
    this.tenantRequestContext = requestContext;
  }

  @Override
  public void setEnvironment(Environment env) {
    this.environment = env;
  }

  @PostConstruct
  public void init() {
    TenantPathBuilder.init(environment, tenantRequestContext);
  }
}
