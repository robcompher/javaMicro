package com.dsths.common.container.multitenant;

/**
 * Use this to manage tenant context per thread. Every time a new thread is invoked, make sure the context is reset
 * because a new thread would lose the current tenant's identifier information.
 * <p/>
 * Created by DT214743 on 12/25/2018.
 */
public interface TenantRequestContext {

  String getCurrentTenant();

  void setCurrentTenant(String currentTenant);

  boolean isTenanted();

  void clear();

  void clear(boolean force);

  TenantApplicationContext getTenantApplicationContext();
}
