package com.dsths.common;

import org.apache.commons.configuration.Configuration;
import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.configuration.XMLConfiguration;
import org.apache.maven.model.FileSet;
import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugin.MojoExecution;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugins.annotations.Component;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;
import org.apache.maven.project.MavenProject;
import org.apache.maven.project.MavenProjectHelper;
import org.codehaus.plexus.archiver.Archiver;
import org.codehaus.plexus.archiver.manager.ArchiverManager;
import org.codehaus.plexus.archiver.manager.NoSuchArchiverException;
import org.codehaus.plexus.util.DirectoryScanner;

import java.io.File;
import java.io.IOException;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/*
 * Copyright 2001-2005 The Apache Software Foundation.
 *
 * Licensed under the Apache License, Version 2.0 (the "License")
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Maven Plugin responsible for generating application.properties file to be used in Spring boot enabled DSTContainer.
 * A set of Application properties file, each one per environment by assembling all the properties and values defined.
 * For example, if the appConfig module contains pom.xml with multiple execution targets (dev-localhost-tomcat.jar, vcloud-vcloud-tomcat.jar)
 * then the plugin generates two files named app-dev-localhost.properties, app-vcloud-vcloud.properties file.
 * Spring Boot allows us to define the ${application name}_${profile}.properties where the application name and
 * profile can be bootstrapped at runtime.
 *
 * @author Kamal Ramakrishnan (dt78836)
 *
 */
@Mojo(name = "config", inheritByDefault = false, requiresDependencyResolution = ResolutionScope.COMPILE,
    threadSafe = true)
public class ConfigMojo extends AbstractMojo {

  @Parameter(property = "applicationName", required = true)
  private String applicationName;

  @Parameter(property = "outputDirectory", required = true)
  private String outputDirectory;

  @Parameter(required = true)
  private FileSet[] filesets;

  @Parameter(defaultValue = "${mojoExecution}", readonly = true)
  private MojoExecution execution;

  private static final String[] STRINGS_ARRAY = new String[0];

  private static final String DATASOURCE_PREFIX = "container.dataSources";

  private static final Pattern DATASOURCE_FILE_PATTERN = Pattern.compile("dataSource-(.*)\\.xml");

  private static final String LOCAL_SETTINGS_FILE_PATTERN = "local-settings.xml";

  /**
   * The character encoding scheme to be applied when filtering resources.
   */
  @Parameter(property = "encoding", defaultValue = "${project.build.sourceEncoding}", required = false)
  protected String encoding;

  /**
   */
  @Parameter(defaultValue = "${project}", readonly = true)
  private MavenProject project;

  @Parameter(defaultValue = "${project.build.directory}", readonly = true)
  private File target;

  /**
   * Maven ProjectHelper.
   */
  @Component
  private MavenProjectHelper projectHelper;

  /**
   * To look up Archiver/UnArchiver implementations
   */
  @Component
  private ArchiverManager archiverManager;

  private PropertiesConfiguration propertiesConfiguration = new PropertiesConfiguration();

  private String outputType = "jar";

  @Override
  public void execute() throws MojoExecutionException, MojoFailureException {
    if (encoding == null) {
      encoding = "UTF-8";
    }

    Collection<File> filesList = doScan(filesets);
    String targetFileName = "application.properties";

    try {

      propertiesConfiguration.getLayout().setHeaderComment("Auto-generated " + targetFileName + " file. \n" +
                  String.format("Generated on %1$tb %1$te, %1$tY %1$tT %1$tZ.", Calendar.getInstance()));
      filesList.stream().forEach(e -> buildConfigProps(e.getAbsolutePath(),e.getName()));

      getLog().info("Generating application configuration -- "+ Paths.get(outputDirectory, targetFileName).toFile());

      PropertiesConfiguration targetConfiguration = new PropertiesConfiguration(Paths.get(outputDirectory, targetFileName).toFile());
      targetConfiguration.append(propertiesConfiguration);
      targetConfiguration.save();

      buildConfigJarArchive();
    } catch (ConfigurationException | NoSuchArchiverException  | IOException ex) {
      getLog().error("Exception occurred generating properties file", ex);
    }
  }

  private void buildConfigJarArchive() throws NoSuchArchiverException,IOException {

    Archiver archiver = archiverManager.getArchiver(outputType);

    // duplicates are skipped - first copy added to archive wins
    archiver.setDuplicateBehavior(Archiver.DUPLICATES_SKIP);
    File targetFile = new File(outputDirectory + "." + outputType);
    getLog().info("Building " + targetFile.getName());

    archiver.addDirectory(new File(outputDirectory));
    archiver.setDestFile(targetFile);
    archiver.createArchive();
    projectHelper.attachArtifact(project,outputType, null, targetFile);
  }

  private void buildConfigProps(final String configFilePath, final String fileName) {
    getLog().info("Extracting properties from file - " + fileName);
    Matcher matcher = DATASOURCE_FILE_PATTERN.matcher(fileName);
    try {
      if (matcher.matches()) {
        addFromDataSourceConfig(configFilePath, matcher.group(1));
      }
      else if (fileName.equalsIgnoreCase(LOCAL_SETTINGS_FILE_PATTERN)) {
        addFromLocalSettingsConfig(configFilePath);
      }
      else if (fileName.endsWith(".properties")) {
        addFromAppPropertiesFile(configFilePath);
      }
    } catch (ConfigurationException ce) {
      getLog().error("Exception occurred while generating properties file", ce);
    }

  }

  private void addFromDataSourceConfig(final String configFile, final String dataSourceName) throws ConfigurationException {
    Configuration xmlConfiguration = new XMLConfiguration(configFile);
    xmlConfiguration.getKeys().forEachRemaining(key ->
      propertiesConfiguration.addProperty(DATASOURCE_PREFIX + "." + dataSourceName + "." + key, xmlConfiguration.getProperty(key))
    );
  }

  private void addFromLocalSettingsConfig(final String configFile) throws ConfigurationException {
    Configuration xmlConfiguration = new XMLConfiguration(configFile);
    xmlConfiguration.getKeys().forEachRemaining(key ->
      propertiesConfiguration.addProperty(key, xmlConfiguration.getProperty(key))
    );
  }

  private void addFromAppPropertiesFile(final String configFile) throws ConfigurationException {
    Configuration configuration  = new PropertiesConfiguration(configFile);
    configuration.getKeys().forEachRemaining(key ->
      propertiesConfiguration.addProperty(key, configuration.getProperty(key))
    );
  }

  private File resolveRelativePath(File file) {
    File result = file;
    if (!result.isAbsolute()) {
      result = new File(project.getBasedir(), result.getPath());
    }

    return result;
  }

  /**
   * Scans the source directory specified and selects the list of configuration files.
   *
   * @param includes - Include file patterns
   * @param excludes - Exclude file patterns
   * @param rootFolder - Source Directory
   * @return String[] - list of files qualified
   * @throws MojoExecutionException
   */
  protected String[] doScan(String[] includes, String[] excludes, File rootFolder) throws MojoExecutionException {

    try {

      DirectoryScanner directoryScanner = new DirectoryScanner();

      directoryScanner.setFollowSymlinks(true);
      directoryScanner.setBasedir(rootFolder);
      directoryScanner.setExcludes(excludes);
      directoryScanner.setIncludes(includes);
      directoryScanner.addDefaultExcludes();
      directoryScanner.scan();

      return directoryScanner.getIncludedFiles();
    } catch (IllegalStateException e) {
      throw new MojoExecutionException("Error scanning source root: \'" + rootFolder + "\'", e);
    }

  }

  /**
   * Scan the filesets defined under resources.
   *
   * @param filesets
   * @return
   * @throws MojoExecutionException
   */
  @SuppressWarnings("unchecked")
  protected Collection<File> doScan(FileSet[] filesets) throws MojoExecutionException {
    List<File> files = new ArrayList<>();

    if (null != filesets) {

      for (FileSet fileSet : filesets) {

        String[] includes = fileSet.getIncludes().toArray(STRINGS_ARRAY);
        String[] excludes = fileSet.getExcludes().toArray(STRINGS_ARRAY);

        File fileSetDirectory = resolveRelativePath(new File(fileSet.getDirectory()));
        String[] scan = doScan(includes, excludes, fileSetDirectory);

        for (String filename : scan) {
          files.add(resolveRelativePath(new File(fileSetDirectory, filename)));
        }
      }
    }

    return files;
  }
}
