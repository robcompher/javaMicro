package com.dsths.example.test.service;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.Future;

/**
 * Created by DT214743 on 3/6/2019.
 */
@Component
public class AsyncServices {
  private static final Logger log = LogManager.getLogger(AsyncServices.class);
  @Async
  public Future<String> process() throws InterruptedException {
    log.info("###Start Processing with Thread id: " + Thread.currentThread().getId());

    // Sleep 3s for simulating the processing
    Thread.sleep(3000);

    String processInfo = String.format("Processing is Done with Thread id= %d", Thread.currentThread().getId());
    return new AsyncResult<>(processInfo);
  }
}
