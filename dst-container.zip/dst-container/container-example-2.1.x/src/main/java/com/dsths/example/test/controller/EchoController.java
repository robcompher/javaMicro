package com.dsths.example.test.controller;

import com.dsths.example.test.service.AsyncServices;
import com.dsths.example.test.service.SingletonService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;


@RestController
public class EchoController {

  @Autowired
  private SingletonService singletonService;

  @Autowired
  private AsyncServices asyncServices;

  @RequestMapping("/echo")
  public Map echo(@RequestParam String arg) throws Exception {
    Map<String, Object> result = new HashMap<>();
    result.put("echo", arg);
    result.put("singleton-identity", singletonService.identity());
    return result;
  }

  @RequestMapping("/asyncCall")
  public String asyncCall() throws Exception {
    return asyncServices.process().get();
  }
}
