package com.dsths.example.test.spring;

import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;


@Configuration
public class MvcConfig implements WebMvcConfigurer {

  public MvcConfig() {
    super();
  }

  @Override
  public void addViewControllers(final ViewControllerRegistry registry) {
    registry.addViewController("/anonymous.html");
    registry.addViewController("/login.html");
    registry.addViewController("/homepage.html");
    registry.addViewController("/sessionExpired.html");
    registry.addViewController("/invalidExpired.html");
    registry.addViewController("/console.html");
  }

  @Override
  public void configureViewResolvers(ViewResolverRegistry registry) {
    registry.jsp("/views/", ".jsp");
  }
}