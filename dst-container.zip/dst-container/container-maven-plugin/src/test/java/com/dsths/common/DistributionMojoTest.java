package com.dsths.common;

import org.apache.maven.artifact.InvalidRepositoryException;
import org.apache.maven.artifact.repository.ArtifactRepository;
import org.apache.maven.artifact.repository.ArtifactRepositoryPolicy;
import org.apache.maven.artifact.repository.MavenArtifactRepository;
import org.apache.maven.artifact.repository.layout.DefaultRepositoryLayout;
import org.apache.maven.execution.*;
import org.apache.maven.model.Plugin;
import org.apache.maven.plugin.*;
import org.apache.maven.plugin.descriptor.PluginDescriptor;
import org.apache.maven.plugin.testing.MojoRule;
import org.apache.maven.project.MavenProject;
import org.apache.maven.project.ProjectBuilder;
import org.apache.maven.project.ProjectBuildingRequest;
import org.apache.maven.repository.internal.MavenRepositorySystemUtils;
import org.codehaus.plexus.PlexusTestCase;
import org.eclipse.aether.DefaultRepositorySystemSession;
import org.eclipse.aether.RepositorySystem;
import org.eclipse.aether.RepositorySystemSession;
import org.eclipse.aether.connector.basic.BasicRepositoryConnectorFactory;
import org.eclipse.aether.impl.DefaultServiceLocator;
import org.eclipse.aether.repository.LocalRepository;
import org.eclipse.aether.spi.connector.RepositoryConnectorFactory;
import org.eclipse.aether.spi.connector.transport.TransporterFactory;
import org.eclipse.aether.transport.file.FileTransporterFactory;
import org.eclipse.aether.transport.http.HttpTransporterFactory;
import org.junit.Rule;
import org.junit.Test;

import java.io.File;
import java.util.Arrays;

import static junit.framework.TestCase.assertNotNull;
import static junit.framework.TestCase.assertTrue;

/**
 * Created by DT214743 on 12/11/2018.
 */
public class DistributionMojoTest {

  public static final String LOCAL_REPO = "target/local-repo";
  @Rule
  public MojoRule mojoRule = new MojoRule();

  @Test
  public void shouldGenerateArtifacts() throws Exception {
    File testPom = new File("target/test-classes/distribution-mojo");
    File outDir = new File(getBasedir(), "target/test-run/distribution-mojo");

    MavenProject project = mojoRule.readMavenProject(testPom);
    MavenSession session = newMavenSession(project);

    MojoExecution mojoExecution = mojoRule.newMojoExecution("single");
    AbstractMojo distMojo = (AbstractMojo) mojoRule.lookupConfiguredMojo(session, mojoExecution);
    assertNotNull(distMojo);

    mojoRule.setVariableValueToObject(distMojo, "outputDirectory", outDir);
    PluginDescriptor pluginDescriptor = (PluginDescriptor) mojoRule.getVariableValueFromObject(distMojo, "plugin");
    Plugin plugin = project.getPlugin(pluginDescriptor.getPluginLookupKey());
    pluginDescriptor.setPlugin(plugin);

    distMojo.execute();

    assertTrue(new File(outDir, "container/scripts/container.sh").exists());
    assertTrue(new File(outDir, "container-maven-plugin-test-1.0-SNAPSHOT-linux.tar.gz").exists());
  }

  @Test(expected = MojoFailureException.class)
  public void testArtifactIdError() throws Exception {
    File testPom = new File(getBasedir(), "src/test/resources/distribution-mojo/pom-artifactId-error.xml");
    assertNotNull(testPom);
    assertTrue(testPom.exists());

    ProjectBuildingRequest buildingRequest = newMavenSession().getProjectBuildingRequest();
    ProjectBuilder projectBuilder = mojoRule.lookup(ProjectBuilder.class);
    MavenProject mavenProject = projectBuilder.build(testPom, buildingRequest).getProject();

    AbstractMojo distMojo = (AbstractMojo) mojoRule.lookupConfiguredMojo(mavenProject, "single");

    assertNotNull(distMojo);

    distMojo.execute();
  }

  private String getBasedir() {
    return PlexusTestCase.getBasedir();
  }

  protected MavenSession newMavenSession() {
    try {
      MavenExecutionRequest request = new DefaultMavenExecutionRequest();
      MavenExecutionResult result = new DefaultMavenExecutionResult();

      // populate sensible defaults, including repository basedir and remote repos
      MavenExecutionRequestPopulator populator = mojoRule.getContainer().lookup(MavenExecutionRequestPopulator.class);
      populator.populateDefaults(request);
      // this is needed to allow java profiles to get resolved; i.e. avoid during project builds:
      // [ERROR] Failed to determine Java version for profile java-1.5-detected @ org.apache.commons:commons-parent:22,
      // /Users/user_home/.m2/repository/org/apache/commons/commons-parent/22/commons-parent-22.pom, line 909, column 14
      request.setSystemProperties(System.getProperties());
      ArtifactRepository artifactRepository = new MavenArtifactRepository("local", "file://"+new File(getBasedir(), LOCAL_REPO).getAbsolutePath(),
          new DefaultRepositoryLayout(),
          new ArtifactRepositoryPolicy(true, ArtifactRepositoryPolicy.UPDATE_POLICY_ALWAYS, ArtifactRepositoryPolicy.CHECKSUM_POLICY_IGNORE),
          new ArtifactRepositoryPolicy(true, ArtifactRepositoryPolicy.UPDATE_POLICY_ALWAYS, ArtifactRepositoryPolicy.CHECKSUM_POLICY_IGNORE)
      );
      request.setLocalRepository(artifactRepository);
      RepositorySystem repoSystem = newRepositorySystem();
      RepositorySystemSession repoSession = newRepoSession(repoSystem);
      MavenSession mavenSession = new MavenSession(mojoRule.getContainer(), repoSession, request, result);

      LegacySupport legacySupport = mojoRule.lookup(LegacySupport.class);
      legacySupport.setSession(mavenSession);
      return mavenSession;
    } catch (Exception e) {
      throw new RuntimeException(e);
    }
  }

  /**
   * Extends the super to use the new {@link #newMavenSession()} introduced here
   * which sets the defaults one expects from maven; the standard test case leaves a lot of things blank
   */
  protected MavenSession newMavenSession(MavenProject project) {
    MavenSession session = newMavenSession();
    session.setCurrentProject(project);
    session.setProjects(Arrays.asList(project));
    return session;
  }

  private RepositorySystem newRepositorySystem() {
    DefaultServiceLocator locator = MavenRepositorySystemUtils.newServiceLocator();
    locator.addService(RepositoryConnectorFactory.class, BasicRepositoryConnectorFactory.class);
    locator.addService(TransporterFactory.class, FileTransporterFactory.class);
    locator.addService(TransporterFactory.class, HttpTransporterFactory.class);

    return locator.getService(RepositorySystem.class);
  }

  private RepositorySystemSession newRepoSession(RepositorySystem system) throws InvalidRepositoryException {
    DefaultRepositorySystemSession session = MavenRepositorySystemUtils.newSession();

    LocalRepository localRepo = new LocalRepository(new File(getBasedir(), LOCAL_REPO));

    session.setLocalRepositoryManager(system.newLocalRepositoryManager(session, localRepo));

    return session;
  }
}
