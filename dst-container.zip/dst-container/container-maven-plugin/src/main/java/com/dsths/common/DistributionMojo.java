package com.dsths.common;

import org.apache.maven.plugin.BuildPluginManager;
import org.apache.maven.plugin.MojoExecutionException;
import org.apache.maven.plugin.MojoFailureException;
import org.apache.maven.plugin.logging.Log;
import org.apache.maven.plugins.annotations.Component;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.maven.plugins.annotations.ResolutionScope;
import org.apache.maven.plugins.assembly.mojos.SingleAssemblyMojo;
import org.apache.maven.project.MavenProject;
import org.apache.maven.shared.utils.io.FileUtils;
import org.codehaus.plexus.util.xml.Xpp3Dom;
import org.springframework.boot.loader.tools.DefaultLaunchScript;
import org.springframework.boot.loader.tools.LaunchScript;

import java.io.*;
import java.net.URL;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static org.twdata.maven.mojoexecutor.MojoExecutor.artifactId;
import static org.twdata.maven.mojoexecutor.MojoExecutor.configuration;
import static org.twdata.maven.mojoexecutor.MojoExecutor.element;
import static org.twdata.maven.mojoexecutor.MojoExecutor.executeMojo;
import static org.twdata.maven.mojoexecutor.MojoExecutor.executionEnvironment;
import static org.twdata.maven.mojoexecutor.MojoExecutor.goal;
import static org.twdata.maven.mojoexecutor.MojoExecutor.groupId;
import static org.twdata.maven.mojoexecutor.MojoExecutor.name;
import static org.twdata.maven.mojoexecutor.MojoExecutor.plugin;
import static org.twdata.maven.mojoexecutor.MojoExecutor.version;

@Mojo(
    name = "single",
    inheritByDefault = false,
    requiresDependencyResolution = ResolutionScope.COMPILE,
    threadSafe = true
)
public class DistributionMojo extends SingleAssemblyMojo {
  public static final String CONTAINER_SCRIPTS_DIRECTORY = "container/scripts/";
  public static final String CONTAINER_CONF_DIRECTORY = "container/conf/";
  public static final String RUN_ARGS = "RUN_ARGS";
  public static final String JAVA_OPTS = "JAVA_OPTS";
  public static final String APPLICATION_NAME = "application.name";
  public static final String WAR_ARTIFACT_ID = "war.artifactId";
  public static final String INCLUDES = "includes";
  public static final String EXCLUDES = "excludes";
  public static final String OS_LINUX = "linux";
  public static final String OS_WINDOWS = "windows";
  public static final String LAUNCHER_BAT_SCRIPT = "launcher.bat.script";

  @Component
  private BuildPluginManager pluginManager;

  /**
   * The SCM connection URL.
   */
  @Parameter(property = "configScmConnectionUrl")
  private String configScmConnectionUrl;

  /**
   * Comma separated list of includes file pattern.
   */
  @Parameter(property = "configIncludes", defaultValue = "**")
  private String configIncludes;

  /**
   * Comma separated list of excludes file pattern.
   */
  @Parameter(property = "configExcludes")
  private String configExcludes;

  /**
   * Artifact Type
   */
  @Parameter(property = "artifactType", defaultValue = "war")
  private String artifactType;

  /**
   * Artifact Id
   */
  private String artifactId;

  /**
   * config environment
   */
  @Parameter(property = "configDirectory")
  private String configDirectory;

  /**
   * The embedded launch script to prepend to the front of the jar if it is fully
   * executable. If not specified the 'Spring Boot' default script will be used.
   *
   * @since 1.3
   */
  @Parameter
  private File embeddedLaunchScript;

  /**
   * Properties that should be expanded in the embedded launch script.
   *
   * See https://docs.spring.io/spring-boot/docs/current/reference/html/deployment-install.html#deployment-script-customization-when-it-written
   *
   * @since 1.3
   */
  @Parameter
  private Properties embeddedLaunchScriptProperties;

  /**
   * Properties Customizing a Script When It Runs.
   *
   * See https://docs.spring.io/spring-boot/docs/current/reference/html/deployment-install.html#deployment-script-customization-when-it-runs
   *
   * @since 1.3
   */
  @Parameter
  private Properties embeddedLaunchScriptRuntimeProperties;

  @Parameter(defaultValue = "app.pid")
  private String pidFilename;

  @Parameter(defaultValue = "${project.build.directory}")
  private String projectBuildDir;

  @Parameter(defaultValue = OS_LINUX)
  private String os;

  private boolean isAppendAssemblyIdSet = false;

  @Override
  public void setAppendAssemblyId(final boolean appendAssemblyId) {
    this.isAppendAssemblyIdSet = true;
    super.setAppendAssemblyId(appendAssemblyId);
  }

  @Override
  public void execute() throws MojoExecutionException, MojoFailureException {
    getLog().info("--> DistributionMojo execute");
    if(!this.os.equals(OS_LINUX) && !this.os.equals(OS_WINDOWS)) {
      throw new MojoFailureException(String.format("Invalid OS parameter specified for execution. " +
          "Allowed only [%1$s,%2$s]", OS_LINUX,OS_WINDOWS));
    }
    if(this.getDescriptorReferences() == null && this.getDescriptors() == null) {
      if(this.os.equals(OS_LINUX)) {
        this.setDescriptorRefs(new String[] {"dist-linux"});
      } else if(this.os.equals(OS_WINDOWS)) {
        this.setDescriptorRefs(new String[] {"dist-windows"});
      }
    }

    //set properties
    initProperties();

    //Copy config files
    copyConfigFilesToTargetDir();

    //write startup scripts
    try {
      writeLaunchScript();
      writeLaunchScriptRuntimeConfig();
    } catch (IOException e) {
      throw new MojoFailureException("Failed to write launch scripts", e);
    }
    //call assembly
    super.execute();

    getLog().info("<-- DistributionMojo execute");
  }

  private void initProperties() throws MojoFailureException {
    if(!this.isAppendAssemblyIdSet) {
      this.setAppendAssemblyId(false);
    }
    Properties properties = getProject().getProperties();
    if (properties.getProperty(WAR_ARTIFACT_ID) != null && !properties.getProperty(WAR_ARTIFACT_ID).trim().isEmpty()) {
      artifactId = properties.getProperty(WAR_ARTIFACT_ID);
    } else {
      getProject().getDependencies().forEach(dependency -> {
        if (dependency.getType().equalsIgnoreCase(artifactType)) {
          artifactId = dependency.getArtifactId();
        }
      });
    }

    if (artifactId == null || artifactId.trim().isEmpty()) {
      throw new MojoFailureException("unable derive artifactId");
    }

    if (properties.getProperty(APPLICATION_NAME) == null || properties.getProperty(APPLICATION_NAME).trim().isEmpty()) {
      if (getProject().getParent() != null) {
        properties.setProperty(APPLICATION_NAME, getProject().getParent().getArtifactId());
      } else {
        properties.setProperty(APPLICATION_NAME, artifactId);
      }
    }
  }

  private void writeLaunchScriptRuntimeConfig() throws IOException {
    File confDir = new File(getOutputDirectory(), CONTAINER_CONF_DIRECTORY);
    FileUtils.forceMkdir(confDir);
    File configFile = new File(confDir, artifactId+"-"+getProject().getVersion()+".conf");
    try (
      BufferedWriter bw = new BufferedWriter(new OutputStreamWriter(new FileOutputStream(configFile)));
    ) {
      Properties properties = new Properties();
      if(this.embeddedLaunchScriptRuntimeProperties != null) {
        properties.putAll(this.embeddedLaunchScriptRuntimeProperties);
      }
      if(this.os.equals(OS_LINUX)) {
        properties.put(JAVA_OPTS, "\"" + (properties.getProperty(JAVA_OPTS) == null ? "" : properties.getProperty(JAVA_OPTS)) +
            " -Dapplication.conf.directory=${CONF_FOLDER} -Dserver.tomcat.basedir=${WORKING_DIR} -Dlogging.path=${WORKING_DIR}/logs\"");
      } else if(this.os.equals(OS_WINDOWS)) {
        properties.put(JAVA_OPTS, "\"" + (properties.getProperty(JAVA_OPTS) == null ? "" : properties.getProperty(JAVA_OPTS)) +
            " -Dapplication.conf.directory=!CONF_FOLDER! -Dserver.tomcat.basedir=!WORKING_DIR! -Dlogging.path=!WORKING_DIR!\\logs\"");
      }
      //wrap quotes around run args
      if(properties.getProperty(RUN_ARGS) != null) {
        properties.put(RUN_ARGS, "\"" + properties.getProperty(RUN_ARGS) + "\"");
      }
      bw.write("#" + new Date().toString() + "\n");
      for (Enumeration e = properties.propertyNames(); e.hasMoreElements();) {
        String key = (String) e.nextElement();
        bw.write(key + "=" + properties.getProperty(key)+"\n");
      }
    }
  }

  private void writeLaunchScript() throws IOException {
    if(this.os.equals(OS_LINUX)) {
      writeLinuxScript();
    } else if(this.os.equals(OS_WINDOWS)) {
      writeWindowsScript();
    }
  }

  private void writeWindowsScript() throws IOException {
    File scriptsDir = new File(getOutputDirectory(), CONTAINER_SCRIPTS_DIRECTORY);
    FileUtils.forceMkdir(scriptsDir);
    if (this.embeddedLaunchScript == null) {
      URL url = Thread.currentThread().getContextClassLoader().getResource(CONTAINER_SCRIPTS_DIRECTORY+ LAUNCHER_BAT_SCRIPT);
      this.embeddedLaunchScript = new File(scriptsDir, LAUNCHER_BAT_SCRIPT);
      FileUtils.copyURLToFile(url, this.embeddedLaunchScript);
    }
    Properties launchScriptProps = buildLaunchScriptProperties();
    LaunchScript launchScript = new DefaultLaunchScript(this.embeddedLaunchScript, launchScriptProps);
    String containerScript = new String(launchScript.toByteArray());
    try (FileOutputStream fileOutputStream = new FileOutputStream(new File(scriptsDir, "container.bat"));) {
      fileOutputStream.write(containerScript.getBytes());
      FileUtils.delete(new File(scriptsDir, LAUNCHER_BAT_SCRIPT));
    }

    writeEncryptionScript("encrypt.bat", scriptsDir, launchScriptProps);
  }

  private void writeLinuxScript() throws IOException {
    File scriptsDir = new File(getOutputDirectory(), CONTAINER_SCRIPTS_DIRECTORY);
    FileUtils.forceMkdir(scriptsDir);
    if (this.embeddedLaunchScript == null) {
      URL url = Thread.currentThread().getContextClassLoader().getResource("org/springframework/boot/loader/tools/launch.script");
      this.embeddedLaunchScript = new File(scriptsDir, "launcher.script");
      FileUtils.copyURLToFile(url, this.embeddedLaunchScript);
    }
    String workingDir = String.format("SOURCE=\"${BASH_SOURCE[0]}\"\nwhile [ -h \"$SOURCE\" ] ; do SOURCE=\"$(readlink \"$SOURCE\")\"; " +
                    "done\nWORKING_DIR=\"$( cd -P \"$( dirname \"$SOURCE\" )/../\" && pwd )\"\n[[ -z \"$APP_NAME\" ]] && identity=\"%1$s\"\n",
            getProject().getProperties().getProperty(APPLICATION_NAME));
    String artifactFile = String.format("[[ -z \"$jarfile\" ]] && jarfile=\"%1$s-%2$s.%3$s\"", artifactId, getProject().getVersion(), artifactType);

    Properties launchScriptProps = buildLaunchScriptProperties();
    LaunchScript launchScript = new DefaultLaunchScript(this.embeddedLaunchScript, launchScriptProps);

    String containerScript = new String(launchScript.toByteArray());
    containerScript = containerScript.replaceFirst(Pattern.quote("WORKING_DIR=\"$(pwd)\""), Matcher.quoteReplacement(workingDir))
            .replaceFirst(Pattern.quote("[[ -z \"$jarfile\" ]] && jarfile=$(pwd)/$(basename \"$0\")"), Matcher.quoteReplacement(artifactFile))
            .replaceFirst(Pattern.quote("PID_FOLDER=\"$PID_FOLDER/${identity}\""), Matcher.quoteReplacement("#PID_FOLDER=\"$PID_FOLDER/${identity}\""));
    try (FileOutputStream fileOutputStream = new FileOutputStream(new File(scriptsDir, "container.sh"));) {
      fileOutputStream.write(containerScript.getBytes());
      FileUtils.delete(new File(scriptsDir, "launcher.script"));
    }

    writeEncryptionScript("encrypt.sh", scriptsDir, launchScriptProps);
  }

  private void writeEncryptionScript(String scriptFileName, File scriptsDir, Properties launchScriptProps) throws IOException {
    String scriptResourceName = scriptFileName+".script";
    URL url = Thread.currentThread().getContextClassLoader().getResource(CONTAINER_SCRIPTS_DIRECTORY+scriptResourceName);
    File encryptionScript = new File(scriptsDir, scriptResourceName);
    FileUtils.copyURLToFile(url, encryptionScript);

    LaunchScript encScript = new DefaultLaunchScript(encryptionScript, launchScriptProps);

    String encScriptStr = new String(encScript.toByteArray());
    try (FileOutputStream fileOutputStream = new FileOutputStream(new File(scriptsDir, scriptFileName));) {
      fileOutputStream.write(encScriptStr.getBytes());
      FileUtils.delete(new File(scriptsDir, scriptResourceName));
    }
  }

  private Properties buildLaunchScriptProperties() {
    Properties properties = new Properties();

    if (this.embeddedLaunchScriptProperties != null) {
      properties.putAll(this.embeddedLaunchScriptProperties);
    }

    MavenProject project = getProject();
    if (getProject().getParent() != null) {
      project = getProject().getParent();
    }
    String workDirectory = "$WORKING_DIR";
    if(this.os.equals(OS_WINDOWS)) {
      workDirectory = "!WORKING_DIR!";
    }
    putIfMissing(properties, "initInfoProvides", project.getArtifactId());
    putIfMissing(properties, "initInfoShortDescription", project.getName(), project.getArtifactId());
    putIfMissing(properties, "initInfoDescription", removeLineBreaks(project.getDescription()), project.getName(), project.getArtifactId());
    putIfMissing(properties, "mode", "service");
    putIfMissing(properties, "applicationName", getProject().getProperties().getProperty(APPLICATION_NAME));
    putIfMissing(properties, "projectVersion", getProject().getVersion());
    if(this.os.equals(OS_LINUX)) {
      putIfMissing(properties, "confFolder", workDirectory.concat("/conf"));
    } else if(this.os.equals(OS_WINDOWS)) {
      putIfMissing(properties, "confFolder", workDirectory.concat("\\\\conf"));
    }
    putIfMissing(properties, "confFile", String.format("%1$s-%2$s.%3$s", artifactId, getProject().getVersion(), "conf"));
    putIfMissing(properties, "pidFolder", workDirectory);
    if(this.os.equals(OS_LINUX)) {
      putIfMissing(properties, "logFolder", workDirectory.concat("/logs"));
    } else if(this.os.equals(OS_WINDOWS)) {
      putIfMissing(properties, "logFolder", workDirectory.concat("\\\\logs"));
    }
    putIfMissing(properties, "logFilename", artifactId + "-console.log");
    putIfMissing(properties, "pidFilename", pidFilename);
    putIfMissing(properties, "jarFile", String.format("%1$s-%2$s.%3$s", artifactId, getProject().getVersion(), artifactType));

    return properties;
  }

  private String removeLineBreaks(String description) {
    return (description != null ? description.replaceAll("\\s+", " ") : null);
  }

  private void putIfMissing(Properties properties, String key, String... valueCandidates) {
    if (!properties.containsKey(key)) {
      for (String candidate : valueCandidates) {
        if (candidate != null && !candidate.isEmpty()) {
          properties.put(key, candidate);
          return;
        }
      }
    }
  }

  private void copyConfigFilesToTargetDir() throws MojoExecutionException, MojoFailureException {
    if (configScmConnectionUrl != null && !configScmConnectionUrl.trim().isEmpty()) {
      executeMojo(
          plugin(
              groupId("org.apache.maven.plugins"),
              artifactId("maven-scm-plugin"),
              version("1.9.5")
          ),
          goal("checkout"),
          configuration(
              element(name("connectionUrl"), configScmConnectionUrl),
              element(name("pushChanges"), "false"),
              element(name("checkoutDirectory"), "${project.build.directory}/container/conf-repo"),
              element(name(INCLUDES), "**/"+configDirectory+"/**")
          ),
          executionEnvironment(
              getProject(),
              getMavenSession(),
              pluginManager
          )
      );
      try {
        executeMojo(
            plugin(
                groupId("org.apache.maven.plugins"),
                artifactId("maven-resources-plugin"),
                version("3.1.0")
            ),
            goal("copy-resources"),
            buildResourcesPluginConfig(),
            executionEnvironment(
                getProject(),
                getMavenSession(),
                pluginManager
            )
        );
      } catch (IOException e) {
        throw new MojoFailureException("Failed to copy conf from git", e);
      }
    }
  }

  private Xpp3Dom buildResourcesPluginConfig() throws IOException {
    Xpp3Dom config = null;
    if(configExcludes != null) {
      config = configuration(
          element(name("outputDirectory"), "${project.build.directory}/container/conf"),
          element(name("resources"), element(name("resource"),
              element(name("directory"), getEnvConfDirectory()),
              element(name(INCLUDES), element(name("include"), configIncludes)),
              element(name(EXCLUDES), element(name("exclude"), configExcludes)))));
    } else {
      config = configuration(
          element(name("outputDirectory"), "${project.build.directory}/container/conf"),
          element(name("resources"), element(name("resource"),
              element(name("directory"), getEnvConfDirectory()),
              element(name(INCLUDES), element(name("include"), configIncludes)))));
    }

    return config;
  }

  private String getEnvConfDirectory() throws IOException {
    File repoDir = new File(projectBuildDir, "container/conf-repo");
    String parentPath = repoDir.getAbsolutePath();
    Log log = getLog();
    log.info("");
    log.info("Project repoDir: " + repoDir );
    log.info("");
    PathMatcher matcher = FileSystems.getDefault().getPathMatcher("glob:**/"+configDirectory+"/**");
    final List<String> result = new ArrayList<>();
    Files.walkFileTree(Paths.get(parentPath), new SimpleFileVisitor<Path>() {
      @Override
      public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
        if (matcher.matches(file)) {
          String filePath = file.toAbsolutePath().toString();
          log.info("File: " + filePath);
          result.add(filePath.substring(0, filePath.lastIndexOf(File.separator+configDirectory+File.separator) + configDirectory.length() +2));
          log.info("Parent "+ result.get(0));
          return FileVisitResult.TERMINATE;
        }
        return FileVisitResult.CONTINUE;
      }
    });

    if(!result.isEmpty()) {
      return result.get(0);
    }
    return parentPath;
  }
}