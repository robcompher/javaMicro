package com.dsths.common.container.support.test;

import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.Core;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.PatternLayout;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by DT214743 on 12/12/2018.
 */
@Plugin(name = "ListAppender",
    category = Core.CATEGORY_NAME,
    elementType = Appender.ELEMENT_TYPE)
public class ListAppender extends AbstractAppender {

  private final List<String> messages = new ArrayList<String>();

  protected ListAppender(String name, Filter filter, Layout<? extends Serializable> layout) {
    super(name, filter, layout);
  }

  @Override
  public void append(LogEvent event) {
    synchronized (this.messages) {
      getMessages().add(event.getMessage().getFormattedMessage());
    }
  }

  @PluginFactory
  public static ListAppender createAppender(@PluginAttribute("name") String name,
                                            @PluginElement("Layout") Layout<? extends Serializable> layout,
                                            @PluginElement("Filter") final Filter filter,
                                            @PluginAttribute("otherAttribute") String otherAttribute) {
    if (name == null) {
      LOGGER.error("No name provided for ListAppender");
      return null;
    }
    if (layout == null) {
      layout = PatternLayout.createDefaultLayout();
    }
    return new ListAppender(name, filter, layout);
  }

  public List<String> getMessages() {
    return this.messages;
  }

  public void clear() {
    synchronized (this.messages) {
      getMessages().clear();
    }
  }
}
