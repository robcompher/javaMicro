package com.dsths.common.container.support.test;

/**
 * Created by DT214743 on 2/12/2019.
 */
public class MockMessage {
  private int id;

  public int getId() {
    return id;
  }

  public void setId(int id) {
    this.id = id;
  }
}
