package com.dsths.common.container.multitenant.resolver;

import com.dsths.common.container.multitenant.TenantPathData;
import com.dsths.common.container.multitenant.exception.TenantResolveException;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by DT214743 on 1/16/2019.
 */
public class DomainTenantResolverTest {

  @Test
  public void testDomainResolver() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getServerName()).thenReturn("client1.dstcrop.net");
    Mockito.when(request.getServletPath()).thenReturn("/echo");

    TenantResolver tenantResolver = new DomainTenantResolver();
    TenantPathData pathData = tenantResolver.resolve(request);

    Assert.assertEquals("client1", pathData.getCurrentTenant());
  }

  @Test(expected = TenantResolveException.class)
  public void testDomainResolverError() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getServerName()).thenReturn("client1dstcropnet");
    Mockito.when(request.getServletPath()).thenReturn("/echo");

    TenantResolver tenantResolver = new DomainTenantResolver();
    tenantResolver.resolve(request);
  }
}
