package com.dsths.common.container.support.test;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.scheduling.annotation.EnableAsync;

/**
 * Created by DT214743 on 12/20/2018.
 */
@ComponentScan(basePackages = "com.dsths.common.container.support.test")
@EnableAsync
public class AppStartConfig {

}
