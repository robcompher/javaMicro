package com.dsths.common.container.multitenant.session;

import com.dsths.common.container.DeployableLauncher;
import com.dsths.common.container.multitenant.TenantApplicationContext;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.support.SystemPropertiesHelper;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.ClassRule;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.ExpectedException;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.session.web.http.CookieSerializer;
import org.springframework.test.annotation.DirtiesContext;
import org.springframework.test.context.junit4.rules.SpringClassRule;
import org.springframework.test.context.junit4.rules.SpringMethodRule;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.util.StringUtils;

import javax.servlet.http.Cookie;
import java.io.File;
import java.util.Base64;
import java.util.HashSet;
import java.util.Set;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Created by DT214743 on 1/16/2019.
 */
@RunWith(Parameterized.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {DeployableLauncher.class})
@DirtiesContext(classMode = DirtiesContext.ClassMode.AFTER_CLASS)
public class TenantCookieSerializerTest {
  @Parameters(name = "useBase64Encoding={0}")
  public static Object[] parameters() {
    return new Object[]{false, true};
  }

  @ClassRule
  public static final SpringClassRule SPRING_CLASS_RULE = new SpringClassRule();

  @Rule
  public final SpringMethodRule springMethodRule = new SpringMethodRule();

  @Rule
  public ExpectedException thrown = ExpectedException.none();

  private boolean useBase64Encoding;

  private String cookieName;

  private MockHttpServletRequest request;

  private MockHttpServletResponse response;

  @Autowired
  private TenantRequestContext requestContext;
  @Autowired
  private TenantApplicationContext appContext;

  private TenantCookieSerializer serializer;

  private String sessionId;

  public TenantCookieSerializerTest(boolean useBase64Encoding) {
    this.useBase64Encoding = useBase64Encoding;
  }

  @BeforeClass
  public static void init() {
    System.setProperty("server.tomcat.basedir", new File("target/CookieTests/container").getAbsolutePath());
    System.setProperty("logging.path", "${server.tomcat.basedir}/logs");
    SystemPropertiesHelper.setDefaults();
  }

  @Before
  public void setup() {
    this.cookieName = "SESSION";
    this.request = new MockHttpServletRequest();
    this.response = new MockHttpServletResponse();
    this.sessionId = "sessionId";
    this.requestContext.clear();
    this.serializer = new TenantCookieSerializer();
    ReflectionTestUtils.setField(appContext, "tenanted", true);
    Set<String> tenantList = new HashSet();
    tenantList.add("client1");
    ReflectionTestUtils.setField(appContext, "allTenants", tenantList);
    ReflectionTestUtils.setField(serializer, "requestContext", requestContext);
    this.serializer.setUseBase64Encoding(this.useBase64Encoding);
  }

  // --- readCookieValues ---

  @Test
  public void readCookieValuesNull() {
    assertThat(this.serializer.readCookieValues(this.request)).isEmpty();
  }

  @Test
  public void readCookieValuesSingle() {
    this.request.setCookies(createCookie(this.cookieName, this.sessionId));

    assertThat(this.serializer.readCookieValues(this.request))
        .containsOnly(this.sessionId);
  }

  @Test
  public void readCookieSerializerUseBase64EncodingTrueValuesNotBase64() {
    this.sessionId = "&^%$*";
    this.serializer.setUseBase64Encoding(true);
    this.request.setCookies(new Cookie(this.cookieName, this.sessionId));

    assertThat(this.serializer.readCookieValues(this.request)).isEmpty();
  }

  @Test
  public void readCookieValuesSingleAndInvalidName() {
    this.request.setCookies(createCookie(this.cookieName, this.sessionId),
        createCookie(this.cookieName + "INVALID", this.sessionId + "INVALID"));

    assertThat(this.serializer.readCookieValues(this.request))
        .containsOnly(this.sessionId);
  }

  @Test
  public void readCookieValuesMulti() {
    String secondSession = "secondSessionId";
    this.request.setCookies(createCookie(this.cookieName, this.sessionId),
        createCookie(this.cookieName, secondSession));

    assertThat(this.serializer.readCookieValues(this.request))
        .containsExactly(this.sessionId, secondSession);
  }

  @Test
  public void readCookieValuesMultiCustomSessionCookieName() {
    setCookieName("JSESSIONID");
    String secondSession = "secondSessionId";
    this.request.setCookies(createCookie(this.cookieName, this.sessionId),
        createCookie(this.cookieName, secondSession));

    assertThat(this.serializer.readCookieValues(this.request))
        .containsExactly(this.sessionId, secondSession);
  }

  // gh-392
  @Test
  public void readCookieValuesNullCookieValue() {
    this.request.setCookies(createCookie(this.cookieName, null));

    assertThat(this.serializer.readCookieValues(this.request)).isEmpty();
  }

  @Test
  public void readCookieValuesNullCookieValueAndJvmRoute() {
    this.serializer.setJvmRoute("123");
    this.request.setCookies(createCookie(this.cookieName, null));

    assertThat(this.serializer.readCookieValues(this.request)).isEmpty();
  }

  @Test
  public void readCookieValuesNullCookieValueAndNotNullCookie() {
    this.serializer.setJvmRoute("123");
    this.request.setCookies(createCookie(this.cookieName, null),
        createCookie(this.cookieName, this.sessionId));

    assertThat(this.serializer.readCookieValues(this.request))
        .containsOnly(this.sessionId);
  }

  // --- writeCookie ---

  @Test
  public void writeCookie() {
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookieValue()).isEqualTo(this.sessionId);
  }

  // --- httpOnly ---

  @Test
  public void writeCookieHttpOnlyDefault() {
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().isHttpOnly()).isTrue();
  }

  @Test
  public void writeCookieHttpOnlySetTrue() {
    this.serializer.setUseHttpOnlyCookie(true);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().isHttpOnly()).isTrue();
  }

  @Test
  public void writeCookieHttpOnlySetFalse() {
    this.serializer.setUseHttpOnlyCookie(false);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().isHttpOnly()).isFalse();
  }

  // --- domainName ---

  @Test
  public void writeCookieDomainNameDefault() {
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getDomain()).isNull();
  }

  @Test
  public void writeCookieDomainNameCustom() {
    String domainName = "example.com";
    this.serializer.setDomainName(domainName);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getDomain()).isEqualTo(domainName);
  }

  @Test(expected = IllegalStateException.class)
  public void setDomainNameAndDomainNamePatternThrows() {
    this.serializer.setDomainName("example.com");
    this.serializer.setDomainNamePattern(".*");
  }

  // --- domainNamePattern ---

  @Test
  public void writeCookieDomainNamePattern() {
    String domainNamePattern = "^.+?\\.(\\w+\\.[a-z]+)$";
    this.serializer.setDomainNamePattern(domainNamePattern);

    String[] matchingDomains = {"child.sub.example.com", "www.example.com"};
    for (String domain : matchingDomains) {
      this.request.setServerName(domain);
      this.serializer.writeCookieValue(cookieValue(this.sessionId));
      assertThat(getCookie().getDomain()).isEqualTo("example.com");

      this.response = new MockHttpServletResponse();
    }

    String[] notMatchingDomains = {"example.com", "localhost", "127.0.0.1"};
    for (String domain : notMatchingDomains) {
      this.request.setServerName(domain);
      this.serializer.writeCookieValue(cookieValue(this.sessionId));
      assertThat(getCookie().getDomain()).isNull();

      this.response = new MockHttpServletResponse();
    }
  }

  @Test(expected = IllegalStateException.class)
  public void setDomainNamePatternAndDomainNameThrows() {
    this.serializer.setDomainNamePattern(".*");
    this.serializer.setDomainName("example.com");
  }

  // --- cookieName ---

  @Test
  public void writeCookieCookieNameDefault() {
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getName()).isEqualTo("SESSION");
  }

  @Test
  public void writeCookieCookieNameCustom() {
    String cookieName = "JSESSIONID";
    setCookieName(cookieName);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getName()).isEqualTo(cookieName);
  }

  @Test
  public void writeCookieCookieNameTenant() {
    String cookieName = "JSESSIONID";
    setCookieName(cookieName);
    this.cookieName = "client1_" + cookieName;
    this.requestContext.setCurrentTenant("client1");
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getName()).isEqualTo("client1_" + cookieName);
  }

  @Test(expected = IllegalArgumentException.class)
  public void setCookieNameNullThrows() {
    this.serializer.setCookieName(null);
  }

  // --- cookiePath ---

  @Test
  public void writeCookieCookiePathDefaultEmptyContextPathUsed() {
    this.request.setContextPath("");

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getPath()).isEqualTo("/");
  }

  @Test
  public void writeCookieCookiePathDefaultContextPathUsed() {
    this.request.setContextPath("/context");

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getPath()).isEqualTo("/context/");
  }

  @Test
  public void writeCookieCookiePathExplicitNullCookiePathContextPathUsed() {
    this.request.setContextPath("/context");
    this.serializer.setCookiePath(null);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getPath()).isEqualTo("/context/");
  }

  @Test
  public void writeCookieCookiePathExplicitCookiePath() {
    this.request.setContextPath("/context");
    this.serializer.setCookiePath("/");

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getPath()).isEqualTo("/");
  }

  // --- cookieMaxAge ---

  @Test
  public void writeCookieCookieMaxAgeDefault() {
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getMaxAge()).isEqualTo(-1);
  }

  @Test
  public void writeCookieCookieMaxAgeExplicit() {
    this.serializer.setCookieMaxAge(100);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getMaxAge()).isEqualTo(100);
  }

  @Test
  public void writeCookieCookieMaxAgeExplicitEmptyCookie() {
    this.serializer.setCookieMaxAge(100);

    this.serializer.writeCookieValue(cookieValue(""));

    assertThat(getCookie().getMaxAge()).isEqualTo(0);
  }

  // --- secure ---

  @Test
  public void writeCookieDefaultInsecureRequest() {
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getSecure()).isFalse();
  }

  @Test
  public void writeCookieSecureSecureRequest() {
    this.request.setSecure(true);
    this.serializer.setUseSecureCookie(true);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getSecure()).isTrue();
  }

  @Test
  public void writeCookieSecureInsecureRequest() {
    this.serializer.setUseSecureCookie(true);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getSecure()).isTrue();
  }

  @Test
  public void writeCookieInsecureSecureRequest() {
    this.request.setSecure(true);
    this.serializer.setUseSecureCookie(false);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getSecure()).isFalse();
  }

  @Test
  public void writeCookieInecureInsecureRequest() {
    this.serializer.setUseSecureCookie(false);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getSecure()).isFalse();
  }

  // --- jvmRoute ---

  @Test
  public void writeCookieJvmRoute() {
    String jvmRoute = "route";
    this.serializer.setJvmRoute(jvmRoute);

    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookieValue()).isEqualTo(this.sessionId + "." + jvmRoute);
  }

  @Test
  public void readCookieJvmRoute() {
    String jvmRoute = "route";
    this.serializer.setJvmRoute(jvmRoute);
    this.request.setCookies(
        createCookie(this.cookieName, this.sessionId + "." + jvmRoute));

    assertThat(this.serializer.readCookieValues(this.request))
        .containsOnly(this.sessionId);
  }

  @Test
  public void readCookieJvmRouteRouteMissing() {
    String jvmRoute = "route";
    this.serializer.setJvmRoute(jvmRoute);
    this.request.setCookies(createCookie(this.cookieName, this.sessionId));

    assertThat(this.serializer.readCookieValues(this.request)).containsOnly(this.sessionId);
  }

  @Test
  public void readCookieJvmRouteOnlyRoute() {
    String jvmRoute = "route";
    this.serializer.setJvmRoute(jvmRoute);
    this.request.setCookies(createCookie(this.cookieName, "." + jvmRoute));

    assertThat(this.serializer.readCookieValues(this.request)).containsOnly("");
  }

  // --- rememberMe ---

  @Test
  public void writeCookieRememberMeCookieMaxAgeDefault() {
    this.request.setAttribute("rememberMe", true);
    this.serializer.setRememberMeRequestAttribute("rememberMe");
    this.serializer.writeCookieValue(cookieValue(this.sessionId));

    assertThat(getCookie().getMaxAge()).isEqualTo(Integer.MAX_VALUE);
  }

  public void setCookieName(String cookieName) {
    this.cookieName = cookieName;
    this.serializer.setCookieName(cookieName);
  }

  private Cookie createCookie(String name, String value) {
    if (this.useBase64Encoding && StringUtils.hasLength(value)) {
      value = new String(Base64.getEncoder().encode(value.getBytes()));
    }
    return new Cookie(name, value);
  }

  private Cookie getCookie() {
    return this.response.getCookie(this.cookieName);
  }

  private String getCookieValue() {
    String value = getCookie().getValue();
    if (!this.useBase64Encoding) {
      return value;
    }
    if (value == null) {
      return null;
    }
    return new String(Base64.getDecoder().decode(value));
  }

  private CookieSerializer.CookieValue cookieValue(String cookieValue) {
    return new CookieSerializer.CookieValue(this.request, this.response, cookieValue);
  }
}
