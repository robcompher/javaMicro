package com.dsths.common.container;

import com.dsths.common.container.log4j2.SpringBootLookup;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.property.TenantMapPropertySource;
import com.dsths.common.container.multitenant.support.TenantPathBuilder;
import com.dsths.common.container.support.SystemPropertiesHelper;
import com.dsths.common.container.support.test.AsyncServices;
import com.dsths.common.container.support.test.ContainerSoapWS;
import com.dsths.common.container.support.test.MockMessage;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.io.File;
import java.net.URL;
import java.nio.file.Paths;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Future;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;

/**
 * Created by DT214743 on 12/5/2018.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {DeployableLauncher.class})
public class LauncherMultiTenantTests extends BaseSpringBootTest {
  @LocalServerPort
  private int port;

  @Autowired
  private TestRestTemplate restTemplate;

  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Autowired
  private AsyncServices asyncServices;

  @Autowired
  private JobLauncher jobLauncher;

  @Autowired
  @Qualifier("testJob")
  private Job job;

  @Autowired
  private Environment environment;

  @Autowired
  @Qualifier("loggingQueueChannel")
  private MessageChannel queueChannel;

  @BeforeClass
  public static void init() {
    System.setProperty("server.tomcat.basedir", new File("target/LauncherMultiTenantTests/container").getAbsolutePath());
    System.setProperty("logging.path", "${server.tomcat.basedir}/logs");
    File configDirectory = new File("src/test/app-conf/multi-tenant");
    System.setProperty("application.conf.directory", configDirectory.getAbsolutePath());
    SystemPropertiesHelper.setDefaults();
  }

  @Test
  public void contextLoads() {
    assertEquals("DSTContainerMultiTenantTest", new SpringBootLookup().lookup("spring.application.name"));
  }

  @Test
  public void test404Call() {
    String serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client1/container/error/", port);
    ResponseEntity<String> response = restTemplate.getForEntity(serviceUrl, String.class);
    assertEquals(404, response.getStatusCode().value());

    serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client1/container/css/", port);
    response = restTemplate.getForEntity(serviceUrl, String.class);
    assertEquals(404, response.getStatusCode().value());

    serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client1/container/js/", port);
    response = restTemplate.getForEntity(serviceUrl, String.class);
    assertEquals(404, response.getStatusCode().value());

    serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client1/container/images/", port);
    response = restTemplate.getForEntity(serviceUrl, String.class);
    assertEquals(404, response.getStatusCode().value());

    serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client1/container/fonts/", port);
    response = restTemplate.getForEntity(serviceUrl, String.class);
    assertEquals(404, response.getStatusCode().value());
  }

  @Test
  public void testRestCall() {
    String serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client1/rest/mock", port);
    assertEquals("DSTContainer Rest Test", this.restTemplate.getForObject(serviceUrl, String.class));

    serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client2/rest/mock", port);
    assertEquals("DSTContainer Rest Test", this.restTemplate.getForObject(serviceUrl, String.class));

    serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client1/rest/mock/pwd", port);
    assertEquals("passwordsa", this.restTemplate.getForObject(serviceUrl, String.class));

    serviceUrl = String.format("http://localhost:%1$s/dstcontainer/client2/rest/mock/pwd", port);
    assertEquals("sasa", this.restTemplate.getForObject(serviceUrl, String.class));
  }

  @Test
  public void testSoapCall() {
    try {
      URL url = new URL(String.format("http://localhost:%1$s/dstcontainer/client1/soap/mock?wsdl", port));

      QName qname = new QName("http://test.support.container.common.dsths.com/", "ContainerSoapWSImplService");

      Service service = Service.create(url, qname);

      ContainerSoapWS hello = service.getPort(ContainerSoapWS.class);

      assertEquals("DSTContainer SOAP Test", hello.getTestSoapCall());

      url = new URL(String.format("http://localhost:%1$s/dstcontainer/client2/soap/mock?wsdl", port));

      service = Service.create(url, qname);

      hello = service.getPort(ContainerSoapWS.class);

      assertEquals("DSTContainer SOAP Test", hello.getTestSoapCall());
    } catch (Exception e) {
      fail(e.getMessage());
    }
  }

  @Test
  public void testQueue() {
    int i = 0;
    while (i < 3) {
      tenantRequestContext.setCurrentTenant((i % 2 == 0) ? "client1" : "client2");
      MockMessage mockMessage = new MockMessage();
      mockMessage.setId(i);
      Message<MockMessage> message = MessageBuilder.withPayload(mockMessage).build();

      boolean result = queueChannel.send(message);
      assertTrue(result);
      i++;
      try {
        Thread.sleep(500);
      } catch (InterruptedException e) {
        //
      }
      tenantRequestContext.clear();
    }

    assertEquals(3, i);

    try {
      Thread.sleep(1000);
    } catch (InterruptedException e) {
      //
    }
  }

  @Test
  public void testAsync() throws Exception {
    Logger log = LogManager.getLogger(LauncherMultiTenantTests.class);
    Future<String> process1;
    try {
      tenantRequestContext.setCurrentTenant("client1");
      process1 = asyncServices.process();
    } finally {
      tenantRequestContext.clear();
    }
    Future<String> process2;
    try {
      tenantRequestContext.setCurrentTenant("client2");
      process2 = asyncServices.process();
    } finally {
      tenantRequestContext.clear();
    }

    // Wait until They are all Done
    // If all are not Done. Pause 2s for next re-check
    while(!(process1.isDone() && process2.isDone())){
      Thread.sleep(2000);
    }
    log.info("All Processes are DONE!");
    String p1result = process1.get();
    String p2result = process2.get();
    // Log results
    log.info("Process 1: " + p1result);
    log.info("Process 2: " + p2result);

    assertTrue(p1result.contains("tenant= client1"));
    assertTrue(p2result.contains("tenant= client2"));
  }

  @Test
  public void testBatchJavaConfig() throws Exception {
    try {
      tenantRequestContext.setCurrentTenant("client1");
      JobParameters params = new JobParametersBuilder()
          .addString("JobID", String.valueOf(System.currentTimeMillis()))
          .toJobParameters();
      JobExecution jobExecution = jobLauncher.run(job, params);
      assertEquals(ExitStatus.COMPLETED.getExitCode(), jobExecution.getExitStatus().getExitCode());
      assertEquals("client1", jobExecution.getExecutionContext().getString("TestTenant"));
    } finally {
      tenantRequestContext.clear();
    }
    try {
      tenantRequestContext.setCurrentTenant("client2");
      JobParameters params = new JobParametersBuilder()
          .addString("JobID", String.valueOf(System.currentTimeMillis()))
          .toJobParameters();
      JobExecution jobExecution = jobLauncher.run(job, params);
      assertEquals(ExitStatus.COMPLETED.getExitCode(), jobExecution.getExitStatus().getExitCode());
      assertEquals("client2", jobExecution.getExecutionContext().getString("TestTenant"));
    } finally {
      tenantRequestContext.clear();
    }
  }

  @Test
  public void testTenantMapPropertySource() {
    Map<String, Object> map1 = new HashMap<String, Object>() {{
      put("a", "b");
    }};
    try {
      assertEquals(new TenantMapPropertySource("x", map1), new TenantMapPropertySource("x", map1));
      assertFalse(new TenantMapPropertySource("x", map1).equals(new TenantMapPropertySource("y", map1)));

      TenantMapPropertySource mps = new TenantMapPropertySource("mps", map1);
      mps.setTenantRequestContext(tenantRequestContext);
      tenantRequestContext.setCurrentTenant("client1");
      assertTrue(mps.containsProperty("a"));
      assertFalse(mps.containsProperty("abc"));

      assertEquals("b", mps.getProperty("a"));

      assertEquals("password", environment.getProperty("container.server.test.password"));
    } finally {
      tenantRequestContext.clear();
    }
  }

  @Test
  public void testTenantPathBuilder() throws Exception {
    try {
      tenantRequestContext.setCurrentTenant("client1");
      //app.file.path=/apps/test/file/path
      assertEquals(Paths.get("/apps/test/file/path/client1").toString(), TenantPathBuilder.getPath("app.file.path"));
    } finally {
      tenantRequestContext.clear();
    }
    try {
      tenantRequestContext.setCurrentTenant("client2");
      assertEquals(Paths.get("/apps/test/file/path/client2").toString(), TenantPathBuilder.getPath("app.file.path"));
    } finally {
      tenantRequestContext.clear();
    }
  }

}
