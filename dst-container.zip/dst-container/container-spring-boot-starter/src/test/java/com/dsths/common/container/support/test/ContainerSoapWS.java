package com.dsths.common.container.support.test;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Created by DT214743 on 12/10/2018.
 */
@WebService
//@SOAPBinding(style = SOAPBinding.Style.RPC)
public interface ContainerSoapWS {
  @WebMethod
  String getTestSoapCall();
}
