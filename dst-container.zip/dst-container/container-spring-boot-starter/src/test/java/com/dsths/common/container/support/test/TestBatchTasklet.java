package com.dsths.common.container.support.test;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by DT214743 on 11/5/2019.
 */
@Component
public class TestBatchTasklet implements Tasklet {
  private static final Logger log = LogManager.getLogger(TestBatchTasklet.class);
  @Autowired
  private TenantRequestContext tenantRequestContext;

  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
    log.info("Tenant " + tenantRequestContext.getCurrentTenant());
    chunkContext
        .getStepContext()
        .getStepExecution()
        .getJobExecution()
        .getExecutionContext().put("TestTenant", tenantRequestContext.getCurrentTenant());
    return RepeatStatus.FINISHED;
  }
}
