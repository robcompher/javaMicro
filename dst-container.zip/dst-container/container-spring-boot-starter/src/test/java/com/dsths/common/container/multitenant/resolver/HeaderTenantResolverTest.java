package com.dsths.common.container.multitenant.resolver;

import com.dsths.common.container.multitenant.TenantPathData;
import com.dsths.common.container.multitenant.exception.TenantResolveException;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by DT214743 on 1/16/2019.
 */
public class HeaderTenantResolverTest {

  @Test
  public void testHeaderResolver() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getHeader("X-TENANT")).thenReturn("client1");
    Mockito.when(request.getServletPath()).thenReturn("/echo");

    TenantResolver tenantResolver = new HeaderTenantResolver();
    TenantPathData pathData = tenantResolver.resolve(request);

    Assert.assertEquals("client1", pathData.getCurrentTenant());
  }

  @Test(expected = TenantResolveException.class)
  public void testHeaderResolverError() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getHeader("X-TENANT")).thenReturn(null);
    Mockito.when(request.getServletPath()).thenReturn("/echo");

    TenantResolver tenantResolver = new HeaderTenantResolver();
    tenantResolver.resolve(request);
  }
}
