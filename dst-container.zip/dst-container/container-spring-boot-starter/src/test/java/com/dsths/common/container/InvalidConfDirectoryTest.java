package com.dsths.common.container;

import com.dsths.common.container.log4j2.SpringBootLookup;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

import java.io.File;

import static junit.framework.TestCase.assertEquals;

/**
 * Created by DT214743 on 12/5/2018.
 */
@SpringBootTest(classes = {CommandLineLauncher.class})
public class InvalidConfDirectoryTest extends BaseSpringBootTest {
  @BeforeClass
  public static void init() {
    System.setProperty("server.tomcat.basedir", new File("target/InvalidConfDirectoryTests/container").getAbsolutePath());
    System.setProperty("logging.path", "${server.tomcat.basedir}/logs");
    File configDirectory = new File("src/test/app-conf1");
    System.setProperty("application.conf.directory", configDirectory.getAbsolutePath());
  }

  @Test
  public void contextLoadsInvalidConf() {
    assertEquals("application", new SpringBootLookup().lookup("spring.application.name"));
  }
}
