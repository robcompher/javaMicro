package com.dsths.common.container.multitenant.resolver;

import com.dsths.common.container.multitenant.TenantPathData;
import com.dsths.common.container.multitenant.exception.TenantResolveException;
import org.junit.Assert;
import org.junit.Test;
import org.mockito.Mockito;

import javax.servlet.http.HttpServletRequest;

/**
 * Created by DT214743 on 1/16/2019.
 */
public class ServletPathTenantResolverTest {

  @Test
  public void testServletPathResolver() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getServletPath()).thenReturn("/client1/echo");

    TenantResolver tenantResolver = new ServletPathTenantResolver();
    TenantPathData pathData = tenantResolver.resolve(request);

    Assert.assertEquals("client1", pathData.getCurrentTenant());
  }

  @Test(expected = TenantResolveException.class)
  public void testServletPathResolverError() {
    HttpServletRequest request = Mockito.mock(HttpServletRequest.class);
    Mockito.when(request.getServletPath()).thenReturn("echo");

    TenantResolver tenantResolver = new ServletPathTenantResolver();
    tenantResolver.resolve(request);
  }
}
