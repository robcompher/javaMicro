package com.dsths.common.container;

import com.dsths.common.container.log4j2.SpringBootLookup;
import com.dsths.common.container.multitenant.property.TenantMapPropertySource;
import com.dsths.common.container.support.SystemPropertiesHelper;
import com.dsths.common.container.support.test.ContainerSoapWS;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.ResponseEntity;

import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import java.io.File;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static junit.framework.Assert.assertFalse;
import static junit.framework.Assert.assertTrue;
import static junit.framework.TestCase.assertEquals;
import static junit.framework.TestCase.fail;

/**
 * Created by DT214743 on 12/5/2018.
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, classes = {DeployableLauncher.class})
public class LauncherTests extends BaseSpringBootTest {
  @LocalServerPort
  private int port;

  @Autowired
  private TestRestTemplate restTemplate;

  @BeforeClass
  public static void init() {
    System.setProperty("server.tomcat.basedir", new File("target/LauncherTests/container").getAbsolutePath());
    System.setProperty("logging.path", "${server.tomcat.basedir}/logs");
    File configDirectory = new File("src/test/app-conf/single-tenant");
    System.setProperty("application.conf.directory", configDirectory.getAbsolutePath());
    SystemPropertiesHelper.setDefaults();
  }

  @Test
  public void contextLoads() {
    assertEquals("DSTContainerTest", new SpringBootLookup().lookup("spring.application.name"));
  }

  @Test
  public void testRestCall() {
    String serviceUrl = String.format("http://localhost:%1$s/dstcontainer/rest/mock", port);
    assertEquals("DSTContainer Rest Test", this.restTemplate.getForObject(serviceUrl, String.class));
  }

  @Test
  public void test404Call() {
    String serviceUrl = String.format("http://localhost:%1$s/dstcontainer/container/error/", port);
    ResponseEntity<String> response = restTemplate.getForEntity(serviceUrl, String.class);
    assertEquals(404, response.getStatusCode().value());
  }

  @Test
  public void testTenantMapPropertySource() {
    Map<String, Object> map1 = new HashMap<String, Object>() {{
      put("a", "b");
    }};

    assertEquals(new TenantMapPropertySource("x", map1), new TenantMapPropertySource("x", map1));
    assertFalse(new TenantMapPropertySource("x", map1).equals(new TenantMapPropertySource("y", map1)));

    TenantMapPropertySource mps = new TenantMapPropertySource("mps", map1);
    assertTrue(mps.containsProperty("a"));
    assertFalse(mps.containsProperty("abc"));

    assertEquals("b", mps.getProperty("a"));
  }

  @Test
  public void testSoapCall() {
    try {
      URL url = new URL(String.format("http://localhost:%1$s/dstcontainer/soap/mock?wsdl", port));

      QName qname = new QName("http://test.support.container.common.dsths.com/", "ContainerSoapWSImplService");

      Service service = Service.create(url, qname);

      ContainerSoapWS hello = service.getPort(ContainerSoapWS.class);

      assertEquals("DSTContainer SOAP Test", hello.getTestSoapCall());
    } catch (Exception e) {
      fail(e.getMessage());
    }
  }
}
