package com.dsths.common.container.support.test;

import javax.jws.WebService;

/**
 * Created by DT214743 on 12/10/2018.
 */
@WebService(endpointInterface = "com.dsths.common.container.support.test.ContainerSoapWS")
public class ContainerSoapWSImpl implements ContainerSoapWS {
  @Override
  public String getTestSoapCall() {
    return "DSTContainer SOAP Test";
  }
}
