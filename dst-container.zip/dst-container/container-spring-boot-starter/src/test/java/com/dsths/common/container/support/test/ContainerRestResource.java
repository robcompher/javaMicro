package com.dsths.common.container.support.test;

import com.dsths.common.container.multitenant.scope.TenantScoped;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

/**
 * Created by DT214743 on 12/5/2018.
 */
@Component
@TenantScoped
@Path("/mock")
public class ContainerRestResource {
  @Autowired
  @Qualifier("datasource_2")
  private DataSource dataSource2;

  @Value("${container.server.test.password}")
  private String testPwd;

  @Value("${server.ssl.key-store-password}")
  private String sslPwd;

  @GET
  public String test() {
    try (Connection conn = dataSource2.getConnection()) {
      DatabaseMetaData metaData = conn.getMetaData();
    } catch (SQLException e) {
      //
    }
    return "DSTContainer Rest Test";
  }

  @GET
  @Path("/pwd")
  public String getPwd() {
    return testPwd+sslPwd;
  }
}
