package com.dsths.common.container.support.test;

import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.batch.TenantJob;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by DT214743 on 11/5/2019.
 */
@Configuration
public class TestBatchConfig {
  @Autowired
  private JobBuilderFactory jobs;

  @Autowired
  private StepBuilderFactory steps;

  @Bean
  public Step stepOne(TestBatchTasklet testBatchTasklet){
    return steps.get("stepOne")
        .tasklet(testBatchTasklet)
        .build();
  }

  @Bean
  public Job testJob(TestBatchTasklet testBatchTasklet){
    return jobs.get("testJob")
        .incrementer(new RunIdIncrementer())
        .start(stepOne(testBatchTasklet))
        .build();
  }

  @Bean
  public Job testTenantJob(TestBatchTasklet testBatchTasklet,
                           TenantRequestContext tenantRequestContext){
    return new TenantJob(jobs.get("testTenantJob")
        .incrementer(new RunIdIncrementer())
        .start(stepOne(testBatchTasklet))
        .build(), tenantRequestContext);
  }
}
