package com.dsths.common.container.support.test;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by DT214743 on 2/12/2019.
 */
public class QueueMockService {
  private static final Logger log = LogManager.getLogger(QueueMockService.class);
  @Autowired
  private TenantRequestContext tenantRequestContext;

  public void processMessage(MockMessage message) {
    log.debug("processMessage1: " + tenantRequestContext.getCurrentTenant());
    log.debug("processMessage2: " + message.getId());
  }
}
