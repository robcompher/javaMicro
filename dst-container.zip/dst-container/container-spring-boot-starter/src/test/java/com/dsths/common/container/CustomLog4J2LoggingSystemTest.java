package com.dsths.common.container;

import com.dsths.common.container.log4j2.CustomLog4J2LoggingSystem;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.appender.RollingFileAppender;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.boot.logging.LoggingInitializationContext;
import org.springframework.core.env.ConfigurableEnvironment;

import java.io.File;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * Created by DT214743 on 12/11/2018.
 */
public class CustomLog4J2LoggingSystemTest {
  @BeforeClass
  public static void init() {
    System.setProperty("LOG_PATH", new File("target/Log4J2Tests/logs/").getAbsolutePath());
  }

  @Test
  public void testLoadConfigurationClasspath() {
    CustomLog4J2LoggingSystem loggingSystem = new CustomLog4J2LoggingSystem(Thread.currentThread().getContextClassLoader());
    LoggingInitializationContext lic = new LoggingInitializationContext(Mockito.mock(ConfigurableEnvironment.class));
    loggingSystem.initialize(lic, "classpath:config/test-log4j2.xml", null);

    LoggerContext logContext = (LoggerContext) LogManager.getContext(false);
    Configuration config = logContext.getConfiguration();

    assertEquals(4, config.getAppenders().size());
    assertTrue(((RollingFileAppender) config.getAppender("ServerFile")).getFileName().contains("server.log"));
    assertTrue(((RollingFileAppender) config.getAppender("rolling-file-appender")).getFileName().contains("test-app.log"));

    LoggerConfig loggerConfig = config.getLoggerConfig("com.dsths.rolling.appender");
    assertEquals(1, loggerConfig.getAppenderRefs().size());
    assertEquals(Level.WARN, loggerConfig.getLevel());
  }

  @Test
  public void testLoadConfigurationLocation() {
    CustomLog4J2LoggingSystem loggingSystem = new CustomLog4J2LoggingSystem(Thread.currentThread().getContextClassLoader());
    LoggingInitializationContext lic = new LoggingInitializationContext(Mockito.mock(ConfigurableEnvironment.class));
    loggingSystem.initialize(lic, new File("src/test/resources/config/test-log4j2.xml").toURI().getPath(), null);

    LoggerContext logContext = (LoggerContext) LogManager.getContext(false);
    Configuration config = logContext.getConfiguration();

    assertEquals(4, config.getAppenders().size());
    assertTrue(((RollingFileAppender) config.getAppender("ServerFile")).getFileName().contains("server.log"));
    assertTrue(((RollingFileAppender) config.getAppender("rolling-file-appender")).getFileName().contains("test-app.log"));

    LoggerConfig loggerConfig = config.getLoggerConfig("com.dsths.rolling.appender");

    assertEquals(1, loggerConfig.getAppenderRefs().size());
    assertEquals(Level.WARN, loggerConfig.getLevel());
  }

  @Test(expected = IllegalStateException.class)
  public void testLoadConfigurationInvalidLocation() {
    CustomLog4J2LoggingSystem loggingSystem = new CustomLog4J2LoggingSystem(Thread.currentThread().getContextClassLoader());
    LoggingInitializationContext lic = new LoggingInitializationContext(Mockito.mock(ConfigurableEnvironment.class));
    loggingSystem.initialize(lic, new File("src/test/app-conf/app-lg4j2.xml").toURI().getPath(), null);
  }
}
