package com.dsths.common.container;

import com.dsths.common.container.listeners.ContainerClasspathListener;
import com.dsths.common.container.listeners.PropertiesLoggerListener;
import com.dsths.common.container.support.test.ListAppender;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.ConfigurableApplicationContext;

import java.io.File;

import static junit.framework.Assert.assertTrue;
import static org.junit.Assert.assertEquals;

/**
 * Created by DT214743 on 12/11/2018.
 */
@SpringBootTest(classes = {CommandLineLauncher.class})
public class ListenerTests extends BaseSpringBootTest {
  @Autowired
  private ConfigurableApplicationContext applicationContext;

  private ListAppender listAppender;

  @BeforeClass
  public static void init() {
    File configDirectory = new File("src/test/app-conf/single-tenant");
    System.setProperty("application.conf.directory", configDirectory.getAbsolutePath());
    System.setProperty("server.tomcat.basedir", new File("target/ListenerTests/container").getAbsolutePath());
    System.setProperty("logging.path", "${server.tomcat.basedir}/logs");
    System.setProperty("logging.config", "classpath:config/listener-log4j2.xml");
    System.setProperty("app.password1", "test1");
  }

  @Before
  public void setUp() {
    if (listAppender == null) {
      LoggerContext logContext = (LoggerContext) LogManager.getContext(false);
      Configuration config = logContext.getConfiguration();
      LoggerConfig loggerConfig = config.getLoggerConfig("com.dsths.common.container.listeners");
      listAppender = (ListAppender) loggerConfig.getAppenders().get("list-appender");
    }
    listAppender.clear();
  }

  @Test
  public void testPropertiesLoggerListener() {
    ApplicationPreparedEvent event = Mockito.mock(ApplicationPreparedEvent.class);
    Mockito.when(event.getApplicationContext()).thenReturn(applicationContext);

    PropertiesLoggerListener listener = new PropertiesLoggerListener();
    listener.onApplicationEvent(event);

    assertTrue(listAppender.getMessages().contains("server.tomcat.basedir=" + new File("target/ListenerTests/container").getAbsolutePath()));
    assertTrue(listAppender.getMessages().contains("logging.config=classpath:config/listener-log4j2.xml"));
    assertTrue(listAppender.getMessages().contains("additional.property.two=2"));
    assertTrue(listAppender.getMessages().contains("additional.property.one.set2=2"));
    assertTrue(listAppender.getMessages().contains("additional.property.one.set=1"));
    assertTrue(listAppender.getMessages().contains("app.password1=***** OVERRIDDEN to *****"));
    assertTrue(listAppender.getMessages().contains("app.password=*****"));
  }

  @Test
  public void testContainerClasspathListenerStartedEvent() {
    ContainerClasspathListener listener = new ContainerClasspathListener();
    listener.onApplicationEvent(Mockito.mock(ApplicationPreparedEvent.class));
    assertEquals(1, listAppender.getMessages().parallelStream().filter(msg -> msg.startsWith("Application starting with classpath:")).count());
  }

  @Test
  public void testContainerClasspathListenerFailedEvent() {
    ContainerClasspathListener listener = new ContainerClasspathListener();
    listener.onApplicationEvent(Mockito.mock(ApplicationFailedEvent.class));
    assertEquals(1, listAppender.getMessages().parallelStream().filter(msg -> msg.startsWith("Application failed to start with classpath:")).count());
  }
}
