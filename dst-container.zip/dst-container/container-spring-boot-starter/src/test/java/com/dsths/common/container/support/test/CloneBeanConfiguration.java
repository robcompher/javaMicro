package com.dsths.common.container.support.test;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by DT214743 on 2/23/2019.
 */
@Configuration
public class CloneBeanConfiguration {
  @Bean
  public List<String> cloneList() {
    return new ArrayList<>();
  }
}
