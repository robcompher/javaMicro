package com.dsths.common.container.tomcat;

import org.junit.Before;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.doThrow;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.spy;
import static org.mockito.Mockito.when;

/**
 * Created by DT214743 on 1/18/2019.
 */
public class RootRedirectServletTest {
  private RootRedirectServlet servlet;
  private MockHttpServletRequest request;
  private MockHttpServletResponse response;
  private String contextParh;

  @Before
  public void setUp() {
    contextParh = "/dstcontainer";
    servlet = new RootRedirectServlet(contextParh);
    request = new MockHttpServletRequest();
    response = new MockHttpServletResponse();
  }

  @Test
  public void testRedirectSuccess() throws ServletException, IOException {
    servlet.doGet(new MockHttpServletRequest(), response);

    assertEquals(HttpServletResponse.SC_MOVED_TEMPORARILY, response.getStatus());
    assertEquals(contextParh, response.getHeader("Location"));
  }

  @Test
  public void testRedirectError() throws ServletException, IOException {
    IOException ex = new IOException("Testing");
    HttpServletRequest spyRequest = spy(request);
    HttpServletResponse spyResponse = spy(response);
    when(spyRequest.getServletContext()).thenReturn(mock(ServletContext.class));

    doThrow(ex).when(spyResponse).sendRedirect(contextParh);

    servlet.doGet(spyRequest, spyResponse);

    assertEquals(HttpServletResponse.SC_NOT_FOUND, spyResponse.getStatus());
  }
}
