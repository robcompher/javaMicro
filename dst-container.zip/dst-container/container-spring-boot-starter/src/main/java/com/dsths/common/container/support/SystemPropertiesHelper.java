package com.dsths.common.container.support;

/**
 * Used for setting defaults on server startup.
 * <p/>
 * Created by DT214743 on 12/17/2018.
 */
public class SystemPropertiesHelper {
  private SystemPropertiesHelper() {
  }

  public static void setDefaults() {
    //To bridge JUL to log4j
    System.setProperty("java.util.logging.manager", "org.apache.logging.log4j.jul.LogManager");
    System.setProperty("org.springframework.boot.logging.LoggingSystem", "com.dsths.common.container.log4j2.CustomLog4J2LoggingSystem");
  }
}
