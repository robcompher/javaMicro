package com.dsths.common.container.multitenant.concurrent;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.util.StringUtils;

import java.util.concurrent.Callable;

/**
 * Created by DT214743 on 2/7/2019.
 */
public class TenantCallable<V> implements Callable<V> {
  private final TenantRequestContext tenantRequestContext;
  private final Callable<V> delegate;

  public TenantCallable(TenantRequestContext tenantRequestContext, Callable<V> delegate) {
    this.tenantRequestContext = tenantRequestContext;
    this.delegate = associateTenant(delegate);
  }

  @Override
  public V call() throws Exception {
    return this.delegate.call();
  }

  protected <V> Callable<V> associateTenant(Callable<V> task) {
    if (tenantRequestContext.isTenanted() && tenantRequestContext.getCurrentTenant() != null) {
      String originalTenant = tenantRequestContext.getCurrentTenant();
      return () -> {
        if (!StringUtils.isEmpty(originalTenant)) {
          tenantRequestContext.setCurrentTenant(originalTenant);
          try {
            return task.call();
          } finally {
            tenantRequestContext.clear();
          }
        } else {
          return task.call();
        }
      };
    }

    return task;
  }
}
