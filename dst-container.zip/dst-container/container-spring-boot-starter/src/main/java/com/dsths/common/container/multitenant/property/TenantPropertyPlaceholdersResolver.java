package com.dsths.common.container.multitenant.property;

import org.springframework.boot.context.properties.bind.PlaceholdersResolver;
import org.springframework.boot.env.OriginTrackedMapPropertySource;
import org.springframework.boot.origin.OriginTrackedValue;
import org.springframework.util.PropertyPlaceholderHelper;
import org.springframework.util.SystemPropertyUtils;

/**
 * Created by DT214743 on 1/9/2019.
 */
public class TenantPropertyPlaceholdersResolver implements PlaceholdersResolver {
  private final PropertyPlaceholderHelper helper;
  private final OriginTrackedMapPropertySource propertySource;

  public TenantPropertyPlaceholdersResolver(OriginTrackedMapPropertySource propertySource) {
    this.propertySource = propertySource;
    this.helper = new PropertyPlaceholderHelper(SystemPropertyUtils.PLACEHOLDER_PREFIX,
        SystemPropertyUtils.PLACEHOLDER_SUFFIX,
        SystemPropertyUtils.VALUE_SEPARATOR, false);
  }

  @Override
  public Object resolvePlaceholders(Object value) {
    if (value instanceof OriginTrackedValue) {
      OriginTrackedValue originTrackedValue = (OriginTrackedValue) value;
      String originalValue = (String) originTrackedValue.getValue();
      String resolvedValue = this.helper.replacePlaceholders(originalValue, this::resolvePlaceholder);
      if (resolvedValue.equals(originalValue)) {
        return originTrackedValue;
      } else {
        return OriginTrackedValue.of(resolvedValue, originTrackedValue.getOrigin());
      }
    }
    return value;
  }

  protected String resolvePlaceholder(String placeholder) {
    if (propertySource != null) {
      Object value = propertySource.getProperty(placeholder);
      if (value != null) {
        return String.valueOf(value);
      }
    }
    return null;
  }
}
