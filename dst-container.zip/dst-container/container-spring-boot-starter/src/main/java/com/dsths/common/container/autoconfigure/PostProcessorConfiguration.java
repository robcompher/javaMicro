package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.postprocessors.DataSourcePostProcessor;
import com.dsths.common.container.postprocessors.ExecutorBeanPostProcessor;
import com.dsths.common.container.postprocessors.ModifyBeanDefinitionPostProcessor;
import com.dsths.common.container.postprocessors.OverrideBeanScopePostProcessor;
import com.dsths.common.container.postprocessors.TenantAsyncConfigurerBeanPostProcessor;
import com.dsths.common.container.postprocessors.TenantAwareProxyBeanPostProcessor;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Created by DT214743 on 1/28/2019.
 */
@Configuration
public class PostProcessorConfiguration {
  @Bean
  @ConditionalOnClass(name = {"javax.sql.DataSource"})
  public static BeanFactoryPostProcessor customDataSourceConfiguration() {
    return new DataSourcePostProcessor();
  }

  @Bean
  @ConditionalOnProperty({Constants.OVERRIDE_BEAN_SCOPE_TO_TENANT_SCOPE_PROPERTY, Constants.CONTAINER_TENANTS_PROPERTY_KEY})
  public static BeanDefinitionRegistryPostProcessor overrideBeanScopePostProcessor(Environment environment) {
    String[] beanNames = StringUtils.trimArrayElements(StringUtils.commaDelimitedListToStringArray(
        environment.getRequiredProperty(Constants.OVERRIDE_BEAN_SCOPE_TO_TENANT_SCOPE_PROPERTY)));
    return new OverrideBeanScopePostProcessor(Constants.TENANT_SCOPE_NAME, beanNames);
  }

  @Bean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public static BeanDefinitionRegistryPostProcessor modifyBeanDefinitionPostProcessor(Environment environment) {
    List<String> beanNames = new ArrayList<>();
    if (environment.containsProperty(Constants.CLONE_BEAN_DEFINITION_PER_TENANT_PROPERTY)) {
      beanNames.addAll(Arrays.asList(StringUtils.trimArrayElements(StringUtils.commaDelimitedListToStringArray(
          environment.getRequiredProperty(Constants.CLONE_BEAN_DEFINITION_PER_TENANT_PROPERTY)))));
    }

    String[] tenants = StringUtils.trimArrayElements(StringUtils.commaDelimitedListToStringArray(
        environment.getProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)));

    return new ModifyBeanDefinitionPostProcessor(Arrays.asList(tenants), beanNames);
  }

  @Bean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public static ExecutorBeanPostProcessor executorBeanPostProcessor() {
    return new ExecutorBeanPostProcessor();
  }

  @Bean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public static TenantAsyncConfigurerBeanPostProcessor tenantAsyncConfigurerBeanPostProcessor() {
    return new TenantAsyncConfigurerBeanPostProcessor();
  }

  @Bean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public BeanPostProcessor tenantAwareProxyBeanPostProcessor() {
    return new TenantAwareProxyBeanPostProcessor();
  }
}
