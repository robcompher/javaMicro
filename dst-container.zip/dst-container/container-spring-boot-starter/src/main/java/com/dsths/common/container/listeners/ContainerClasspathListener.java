package com.dsths.common.container.listeners;

import com.dsths.common.container.support.ClassLoaderHelper;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.context.config.ConfigFileApplicationListener;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.boot.context.event.ApplicationStartingEvent;
import org.springframework.boot.system.SystemProperties;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.ContextClosedEvent;
import org.springframework.context.event.GenericApplicationListener;
import org.springframework.core.ResolvableType;

import java.net.URLClassLoader;
import java.util.Arrays;

/**
 * Container classpath listener does
 * 1. Add application.conf.directory to classpath
 * 2. Logs classpath including parent classloader
 * <p/>
 * Created by DT214743 on 4/13/2018.
 */
public class ContainerClasspathListener implements GenericApplicationListener {
  private static final Logger LOGGER = LogManager.getLogger(ContainerClasspathListener.class);
  //load before ConfigFileApplicationListener
  private static final int ORDER = ConfigFileApplicationListener.DEFAULT_ORDER - 1;

  //Set as default SB_CONFIG: CDP-132. Used if no JVM/Env param application.conf.directory
  private static final String DEFAULT_CONF_DIR = "/apps/middleware/config";
  public static final String APPLICATION_CONF_DIRECTORY = "application.conf.directory";

  @Override
  public void onApplicationEvent(ApplicationEvent event) {
    if (event instanceof ApplicationStartingEvent) {
      String confDir = StringUtils.isNotEmpty(SystemProperties.get(APPLICATION_CONF_DIRECTORY)) ?
          SystemProperties.get(APPLICATION_CONF_DIRECTORY) : DEFAULT_CONF_DIR;
      LOGGER.info("Adding conf directory to classpath: " + confDir);
      ClassLoaderHelper.addPathToClasspath(confDir);
    } else if (event instanceof ApplicationPreparedEvent) {
      LOGGER.debug("Application starting with classpath: " + getClasspath());
    } else if (event instanceof ApplicationFailedEvent) {
      LOGGER.debug("Application failed to start with classpath: " + getClasspath());
    } else if (event instanceof ContextClosedEvent) {
      LOGGER.debug("Context closing - reset ClassLoader");
      String confDir = StringUtils.isNotEmpty(SystemProperties.get(APPLICATION_CONF_DIRECTORY)) ?
          SystemProperties.get(APPLICATION_CONF_DIRECTORY) : DEFAULT_CONF_DIR;
      ClassLoaderHelper.resetClassLoader(confDir);
    }
  }

  @Override
  public int getOrder() {
    return ORDER;
  }

  @Override
  public boolean supportsEventType(ResolvableType resolvableType) {
    Class<?> type = resolvableType.getRawClass();

    return ApplicationStartingEvent.class.isAssignableFrom(type)
        || ApplicationPreparedEvent.class.isAssignableFrom(type)
        || ApplicationFailedEvent.class.isAssignableFrom(type)
        || ContextClosedEvent.class.isAssignableFrom(type);
  }

  @Override
  public boolean supportsSourceType(Class<?> sourceType) {
    return true;
  }

  private String getClasspath() {
    StringBuilder classpath = new StringBuilder();
    ClassLoader classLoader = Thread.currentThread().getContextClassLoader();
    classpath.append("current ");
    if (classLoader instanceof URLClassLoader) {
      classpath.append(Arrays.toString(((URLClassLoader) classLoader).getURLs()));
    } else {
      classpath.append("[unknown]");
    }
    classpath.append(" ");
    while (classLoader.getParent() != null) {
      classLoader = classLoader.getParent();
      classpath.append(", parent ");
      if (classLoader instanceof URLClassLoader) {
        classpath.append(Arrays.toString(((URLClassLoader) classLoader).getURLs()));
      } else {
        classpath.append("[unknown]");
      }
      classpath.append("");
    }
    return classpath.toString();
  }
}
