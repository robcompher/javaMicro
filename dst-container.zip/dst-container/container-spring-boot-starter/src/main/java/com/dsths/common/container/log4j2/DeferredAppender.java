package com.dsths.common.container.log4j2;

import org.apache.logging.log4j.core.Appender;
import org.apache.logging.log4j.core.Core;
import org.apache.logging.log4j.core.Filter;
import org.apache.logging.log4j.core.Layout;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.appender.AbstractAppender;
import org.apache.logging.log4j.core.config.AppenderControl;
import org.apache.logging.log4j.core.config.AppenderRef;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.config.plugins.PluginAttribute;
import org.apache.logging.log4j.core.config.plugins.PluginConfiguration;
import org.apache.logging.log4j.core.config.plugins.PluginElement;
import org.apache.logging.log4j.core.config.plugins.PluginFactory;
import org.apache.logging.log4j.core.layout.PatternLayout;

import java.io.Serializable;
import java.util.List;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;
import java.util.concurrent.CopyOnWriteArrayList;

/**
 * Created by DT214743 on 1/11/2019.
 */
@Plugin(name = "DeferredAppender",
    category = Core.CATEGORY_NAME,
    elementType = Appender.ELEMENT_TYPE)
public class DeferredAppender extends AbstractAppender {
  private final List<LogEvent> messages = new CopyOnWriteArrayList<>();
  private final Configuration config;
  private final ConcurrentMap<String, AppenderControl> appenders = new ConcurrentHashMap<>();
  private final AppenderRef[] appenderRefs;

  protected DeferredAppender(String name, Filter filter, Layout<? extends Serializable> layout,
                             final AppenderRef[] appenderRefs, final Configuration config) {
    super(name, filter, layout);
    this.config = config;
    this.appenderRefs = appenderRefs;
  }

  @Override
  public void append(LogEvent event) {
    this.messages.add(event);
  }

  @PluginFactory
  public static DeferredAppender createAppender(@PluginAttribute("name") String name,
                                                @PluginElement("Layout") Layout<? extends Serializable> layout,
                                                @PluginElement("Filter") final Filter filter,
                                                @PluginElement("AppenderRef") final AppenderRef[] appenderRefs,
                                                @PluginConfiguration final Configuration config,
                                                @PluginAttribute("otherAttribute") String otherAttribute) {
    if (name == null) {
      LOGGER.error("No name provided for ListAppender");
      return null;
    }
    if (layout == null) {
      layout = PatternLayout.createDefaultLayout();
    }
    return new DeferredAppender(name, filter, layout, appenderRefs, config);
  }

  public List<LogEvent> getMessages() {
    return messages;
  }

  public void clear() {
    this.messages.clear();
  }

  public void replayTo() {
    populateAppenders();

    if (!this.appenders.isEmpty()) {
      this.messages.stream().forEach(event -> this.appenders.values().forEach(control -> control.callAppender(event)));
      this.clear();
    }
  }

  private void populateAppenders() {
    if (this.appenders.isEmpty()) {
      for (final AppenderRef ref : appenderRefs) {
        final String name = ref.getRef();
        final Appender appender = config.getAppender(name);
        if (appender != null) {
          final Filter filter = appender instanceof AbstractAppender ? ((AbstractAppender) appender).getFilter() : null;
          this.appenders.put(name, new AppenderControl(appender, ref.getLevel(), filter));
        } else {
          LOGGER.error("Appender " + ref + " cannot be located. Reference ignored");
        }
      }
    }
  }
}
