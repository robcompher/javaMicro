package com.dsths.common.container.multitenant.property;

import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.property.PropertyTransformer;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.lang.Nullable;
import org.springframework.util.ObjectUtils;

import java.util.HashMap;
import java.util.Map;
import java.util.Set;

/**
 * Created by DT214743 on 12/28/2018.
 */
public class TenantMapPropertySource extends MapPropertySource {
  private Map<String, PropertyTransformer> propertyTransformers = new HashMap<>();
  private TenantRequestContext tenantRequestContext;

  public TenantMapPropertySource(String name, Map<String, Object> source) {
    super(name, source);
  }

  @Override
  public boolean containsProperty(String name) {
    boolean exists = false;
    if (tenantRequestContext != null && tenantRequestContext.getCurrentTenant() != null
        && propertyTransformers.containsKey(tenantRequestContext.getCurrentTenant())) {
      exists = getSource().containsKey(propertyTransformers.get(tenantRequestContext.getCurrentTenant()).transform(name));
    }

    return exists ? exists: super.containsProperty(name);
  }

  @Override
  public Object getProperty(String name) {
    Object value = null;
    if (tenantRequestContext != null && tenantRequestContext.getCurrentTenant() != null
        && propertyTransformers.containsKey(tenantRequestContext.getCurrentTenant())) {
      value = getSource().get(propertyTransformers.get(tenantRequestContext.getCurrentTenant()).transform(name));
    }

    return value == null ? super.getProperty(name): value;
  }

  /**
   * This bean will be set from TenantPropertyEnvironmentListener on ApplicationPreparedEvent
   *
   * @param tenantRequestContext
   */
  public void setTenantRequestContext(TenantRequestContext tenantRequestContext) {
    this.tenantRequestContext = tenantRequestContext;

    //init transformers
    if(tenantRequestContext.isTenanted()) {
      Set<String> tenants = tenantRequestContext.getTenantApplicationContext().getAllTenants();
      tenants.stream().forEach(tenant -> propertyTransformers.put(tenant, PrefixPropertyTransformer.forTenant(tenant)));
    }
  }

  @Override
  public boolean equals(@Nullable Object other) {
    return this == other || other instanceof PropertySource && ObjectUtils.nullSafeEquals(this.name, ((PropertySource) other).getName());
  }

  @Override
  public int hashCode() {
    return ObjectUtils.nullSafeHashCode(this.name);
  }
}
