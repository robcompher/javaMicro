package com.dsths.common.container.support;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.EnvironmentAware;
import org.springframework.context.annotation.DeferredImportSelector;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;
import org.springframework.core.type.AnnotationMetadata;
import org.springframework.util.StringUtils;

/**
 * The AdditionalImportSelector is to import additional configuration classes from application.
 * <p/>
 * This is to include additional packages for component scan.
 * <p/>
 * Created by DT214743 on 12/20/2018.
 */
public class AdditionalImportSelector implements DeferredImportSelector, EnvironmentAware, Ordered {

  private Environment environment;

  @Override
  public String[] selectImports(AnnotationMetadata metadata) {
    return StringUtils.tokenizeToStringArray(getEnvironment().getProperty("container.import.config.classes"),
        ConfigurableApplicationContext.CONFIG_LOCATION_DELIMITERS);
  }

  @Override
  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  protected final Environment getEnvironment() {
    return this.environment;
  }

  @Override
  public int getOrder() {
    return Ordered.LOWEST_PRECEDENCE - 1;
  }
}
