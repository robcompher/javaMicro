package com.dsths.common.container.multitenant.property;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.property.PropertyTransformer;
import org.springframework.boot.env.OriginTrackedMapPropertySource;
import org.springframework.boot.origin.Origin;
import org.springframework.boot.origin.OriginLookup;
import org.springframework.boot.origin.OriginTrackedValue;
import org.springframework.core.env.MapPropertySource;
import org.springframework.util.ObjectUtils;

import java.util.ArrayDeque;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by DT214743 on 12/28/2018.
 */
public class TenantOriginTrackedMapPropertySource extends MapPropertySource implements OriginLookup<String> {
  private final String propertySourceName;
  private final Map<String, PropertyTransformer> propertyTransformers;
  private final Set<String> allTenants;
  private TenantRequestContext tenantRequestContext;

  protected TenantOriginTrackedMapPropertySource(Map<String, ArrayDeque<OriginTrackedMapPropertySource>> propertySources) {
    super("TenantOriginTrackedMapPropertySource", new HashMap<>());
    Map<String, String> tenantMapping = populateAllTenants(propertySources);
    this.allTenants = tenantMapping.keySet();
    this.propertySourceName = generateName(propertySources);
    this.propertyTransformers = initPropertyTransformers(this.allTenants);
    super.getSource().putAll(transformAndMerge(tenantMapping, propertySources));
  }

  protected Map<String, String> populateAllTenants(Map<String, ArrayDeque<OriginTrackedMapPropertySource>> propertySources) {
    Map<String, String> tenantMapping = new HashMap<>();
    propertySources.forEach((fileName, psList) -> psList.stream()
        .map(propertySource -> propertySource.getProperty(Constants.TENANT_NAME))
        .filter(Objects::nonNull).findFirst()
        .ifPresent(tenantName -> tenantMapping.put((String) tenantName, fileName)));

    return tenantMapping;
  }

  protected Map<String, PropertyTransformer> initPropertyTransformers(Set<String> tenants) {
    Map<String, PropertyTransformer> propertyTransformerMap = new HashMap<>();

    tenants.forEach(tenant -> propertyTransformerMap.put(tenant, PrefixPropertyTransformer.forTenant(tenant)));

    return propertyTransformerMap;
  }

  protected String generateName(Map<String, ArrayDeque<OriginTrackedMapPropertySource>> realPropertySources) {
    String sourceName = realPropertySources.values().stream().flatMap(ArrayDeque::stream)
        .map(OriginTrackedMapPropertySource::getName).collect(Collectors.joining(", "));

    return new StringBuilder("TenantOriginTrackedMapPropertySource [").append(sourceName).append("]").toString();
  }

  protected Map<String, Object> transformAndMerge(Map<String, String> tenantMapping,
                                                  Map<String, ArrayDeque<OriginTrackedMapPropertySource>> propertySources) {
    Map<String, Object> sourceMap = new HashMap<>();

    tenantMapping.forEach((tenant, fileName) -> propertySources.get(fileName).stream()
        .forEach(propertySource -> propertySource.getSource()
            .forEach((propKey, propValue) -> sourceMap.put(propertyTransformers.get(tenant).transform(propKey),
                new TenantPropertyPlaceholdersResolver(propertySource).resolvePlaceholders(propValue)))));

    return sourceMap;
  }

  @Override
  public boolean containsProperty(String name) {
    if (tenantRequestContext != null && tenantRequestContext.getCurrentTenant() != null) {
      return getSource().containsKey(propertyTransformers.get(tenantRequestContext.getCurrentTenant()).transform(name));
    }
    return super.containsProperty(name);
  }

  @Override
  public Object getProperty(String name) {
    Object value;
    if (tenantRequestContext != null && tenantRequestContext.getCurrentTenant() != null) {
      value = getSource().get(propertyTransformers.get(tenantRequestContext.getCurrentTenant()).transform(name));
    } else {
      value = super.getProperty(name);
    }
    return value instanceof OriginTrackedValue ? ((OriginTrackedValue) value).getValue() : value;
  }

  @Override
  public Origin getOrigin(String name) {
    Object value;
    if (tenantRequestContext != null && tenantRequestContext.getCurrentTenant() != null) {
      value = getSource().get(propertyTransformers.get(tenantRequestContext.getCurrentTenant()).transform(name));
    } else {
      value = super.getProperty(name);
    }
    return value instanceof OriginTrackedValue ? ((OriginTrackedValue) value).getOrigin() : null;
  }

  @Override
  public String[] getPropertyNames() {
    List<String> names = getSource().keySet().stream().collect(Collectors.toList());
    return names.toArray(new String[0]);
  }

  @Override
  public String getName() {
    return propertySourceName;
  }

  public Set<String> getAllTenants() {
    return allTenants;
  }

  /**
   * This bean will be set from TenantPropertyEnvironmentListener on ApplicationPreparedEvent
   *
   * @param tenantRequestContext
   */
  public void setTenantRequestContext(TenantRequestContext tenantRequestContext) {
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public boolean equals(Object other) {
    return this == other || (other instanceof TenantOriginTrackedMapPropertySource
        && ObjectUtils.nullSafeEquals(this.propertySourceName,
        ((TenantOriginTrackedMapPropertySource) other).propertySourceName));
  }

  @Override
  public int hashCode() {
    return ObjectUtils.nullSafeHashCode(this.propertySourceName);
  }

  @Override
  public String toString() {
    return this.logger.isDebugEnabled() ? this.getClass().getSimpleName() + "@" + System.identityHashCode(this)
        + " {name=\'" + this.propertySourceName + "\', properties=" + this.source + "}"
        : this.getClass().getSimpleName() + " {name=\'" + this.propertySourceName + "\'}";
  }
}
