package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.web.ResourceProperties;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.autoconfigure.web.servlet.WebMvcAutoConfiguration;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.http.CacheControl;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import java.time.Duration;

import static org.springframework.util.StringUtils.tokenizeToStringArray;

/**
 * Custom WebMVC configuration class to register additional static resource patterns.
 * <p/>
 * This configuration loaded only if container.static.content.enabled is set and loaded after WebMvcAutoConfiguration
 * <p/>
 * Created by DT214743 on 4/4/2018.
 */
@Configuration
@AutoConfigureAfter(WebMvcAutoConfiguration.class)
@EnableConfigurationProperties({ServerProperties.class, ResourceProperties.class})
@ConditionalOnProperty(name = Constants.CONTAINER_STATIC_CONTENT_ENABLED)
public class CustomWebMvcConfiguration implements WebMvcConfigurer {

  @Autowired
  private ResourceProperties resourceProperties;

  @Autowired
  private Environment environment;

  @Override
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
    String[] paths = getResourcePaths();
    Duration cachePeriod = this.resourceProperties.getCache().getPeriod();
    CacheControl cacheControl = this.resourceProperties.getCache().getCachecontrol().toHttpCacheControl();

    registry.addResourceHandler(paths)
        .addResourceLocations(this.resourceProperties.getStaticLocations())
        .setCachePeriod(this.getSeconds(cachePeriod)).setCacheControl(cacheControl);
  }

  private String[] getResourcePaths() {
    String path = environment.getProperty(Constants.CONTAINER_SPRING_MVC_ADDITIONAL_STATIC_PATH_PATTERNS);
    if (StringUtils.isNotEmpty(path)) {
      String[] paths = tokenizeToStringArray(path, ConfigurableApplicationContext.CONFIG_LOCATION_DELIMITERS);
      for (int i = 0; i < paths.length; i++) {
        paths[i] = paths[i].trim();
      }

      return paths;
    }
    return new String[0];
  }

  private Integer getSeconds(Duration cachePeriod) {
    return cachePeriod == null ? 60 : Integer.valueOf((int) cachePeriod.getSeconds());
  }

  @Override
  public void addViewControllers(ViewControllerRegistry registry) {
    String path = environment.getProperty(Constants.CONTAINER_APPLICATION_INDEX_PAGE);
    if (StringUtils.isNotEmpty(path)) {
      registry.addViewController("/").setViewName(path);
    }
  }
}
