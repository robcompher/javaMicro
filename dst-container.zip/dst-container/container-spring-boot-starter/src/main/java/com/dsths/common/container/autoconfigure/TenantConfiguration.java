package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantApplicationContext;
import com.dsths.common.container.multitenant.TenantApplicationContextImpl;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.TenantRequestContextImpl;
import com.dsths.common.container.multitenant.TenantServletFilter;
import com.dsths.common.container.multitenant.resolver.ServletPathTenantResolver;
import com.dsths.common.container.multitenant.resolver.TenantResolver;
import com.dsths.common.container.multitenant.scope.TenantScope;
import com.dsths.common.container.multitenant.scope.TenantScopeImpl;
import com.dsths.common.container.multitenant.support.TenantPathBuilderInitializer;
import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.aop.target.ThreadLocalTargetSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.CustomScopeConfigurer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.security.SecurityProperties;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.Scope;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Created by DT214743 on 12/25/2018.
 */
@Configuration
public class TenantConfiguration {

  @Bean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  @ConditionalOnWebApplication
  public static FilterRegistrationBean tenantFilter(TenantRequestContext tenantRequestContext,
                                                    TenantResolver tenantResolver,
                                                    SecurityProperties securityProperties) {
    FilterRegistrationBean filter = new FilterRegistrationBean(new TenantServletFilter(tenantRequestContext,
        tenantResolver));
    filter.addUrlPatterns("/*");
    if (securityProperties != null) {
      filter.setOrder(securityProperties.getFilter().getOrder() - 1);
    } else {
      filter.setOrder(SecurityProperties.DEFAULT_FILTER_ORDER - 1);
    }
    return filter;
  }

  @Bean
  public static CustomScopeConfigurer customScopeConfigurer(final TenantScope tenantScope) {
    final CustomScopeConfigurer configurer = new CustomScopeConfigurer();

    configurer.addScope("tenant", tenantScope);
    return configurer;
  }

  @Bean
  public static TenantScope tenantScope(TenantRequestContext tenantRequestContext) {
    return new TenantScopeImpl(tenantRequestContext);
  }

  @Primary
  @Bean(name = "proxiedThreadLocalTargetSource")
  public static ProxyFactoryBean proxiedThreadLocalTargetSource(@Qualifier("tenantThreadLocalTargetStore") ThreadLocalTargetSource tenantThreadLocalTargetStore) {
    ProxyFactoryBean result = new ProxyFactoryBean();
    result.setTargetSource(tenantThreadLocalTargetStore);

    return result;
  }

  @Bean(destroyMethod = "destroy")
  public static ThreadLocalTargetSource tenantThreadLocalTargetStore() {
    ThreadLocalTargetSource result = new ThreadLocalTargetSource();
    result.setTargetBeanName("tenantRequestContext");
    return result;
  }

  @Bean(name = "tenantRequestContext")
  @Scope(scopeName = "prototype")
  public static TenantRequestContext tenantRequestContext(@Lazy TenantApplicationContext tenantApplicationContext) {
    return new TenantRequestContextImpl(tenantApplicationContext);
  }

  @Bean(name = "tenantApplicationContext")
  public static TenantApplicationContext tenantApplicationContext(Environment environment) {
    String primaryTenant = null;
    if (environment.getProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY) != null) {
      String[] tenants = StringUtils.trimArrayElements(StringUtils.commaDelimitedListToStringArray(
          environment.getProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)));
      Set<String> allTenants = Collections.unmodifiableSet(Arrays.stream(tenants).collect(Collectors.toSet()));
      Optional<String> pTenant = allTenants.stream()
          .filter(tenant -> Boolean.valueOf(environment.getProperty(Constants.getKeyPrefix(tenant)
              + Constants.CONTAINER_TENANT_PRIMARY)))
          .findFirst();

      //Primary tenant is required so that the entity manager factory and other components in the application
      //can pick up the correct settings for the query generator JPA uses.
      if (pTenant.isPresent()) {
        primaryTenant = pTenant.get();
      } else {
        primaryTenant = tenants[0];
      }

      return new TenantApplicationContextImpl(allTenants, primaryTenant, true);
    }
    return new TenantApplicationContextImpl(new HashSet<>(), primaryTenant, false);
  }

  @Bean(name = "tenantResolver")
  @ConditionalOnMissingBean
  @Order(Ordered.LOWEST_PRECEDENCE - 10)
  public static TenantResolver tenantResolver() {
    return new ServletPathTenantResolver();
  }

  @Bean(name = "tenantAwareProxyBeanNames")
  public List<String> tenantAwareProxyBeanNames() {
    return new ArrayList<>();
  }

  @Bean
  @ConditionalOnMissingBean
  public static TenantPathBuilderInitializer tenantPathBuilderInitializer(TenantRequestContext tenantRequestContext) {
    TenantPathBuilderInitializer tenantPathBuilder = new TenantPathBuilderInitializer();
    tenantPathBuilder.setTenantRequestContext(tenantRequestContext);
    return tenantPathBuilder;
  }
}
