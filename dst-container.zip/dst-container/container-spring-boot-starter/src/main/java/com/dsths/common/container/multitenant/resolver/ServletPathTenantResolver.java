package com.dsths.common.container.multitenant.resolver;

import com.dsths.common.container.multitenant.TenantPathData;
import com.dsths.common.container.multitenant.exception.TenantResolveException;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tries to resolve Tenant from request path/url
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
public class ServletPathTenantResolver implements TenantResolver {
  protected final Pattern pattern;

  public ServletPathTenantResolver() {
    this.pattern = Pattern.compile("^/(?<tenant>\\w+)(?<servletPath>.*)$");
  }

  @Override
  public TenantPathData resolve(HttpServletRequest request) {
    Matcher matcher = pattern.matcher(request.getServletPath());

    if (!matcher.matches()) {
      throw new TenantResolveException(String.format("Unable to resolve the tenant from Servlet Path: \"%s\"",
          request.getServletPath()));
    }

    return new TenantPathData(matcher.group("tenant"), String.format("/%s", matcher.group("tenant")),
        matcher.group("servletPath"));
  }
}
