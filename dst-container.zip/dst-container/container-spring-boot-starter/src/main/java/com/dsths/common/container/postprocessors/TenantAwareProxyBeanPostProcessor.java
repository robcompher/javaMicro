package com.dsths.common.container.postprocessors;

import com.dsths.common.container.multitenant.TenantApplicationContext;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.concurrent.TenantAwareMethodInterceptor;
import org.springframework.aop.framework.Advised;
import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.config.BeanPostProcessor;

import java.util.List;
import java.util.Optional;

/**
 * Created by DT214743 on 2/1/2019.
 */
public class TenantAwareProxyBeanPostProcessor implements BeanPostProcessor {
  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Autowired
  private TenantApplicationContext tenantApplicationContext;

  @Autowired
  @Qualifier("tenantAwareProxyBeanNames")
  private List<String> beanNames;

  @Override
  public Object postProcessBeforeInitialization(final Object bean, final String beanName) {
    if (beanNames != null && beanNames.contains(beanName)) {
      String tenant = extractTenant(beanName);
      if (tenant != null) {
        TenantAwareMethodInterceptor advice = new TenantAwareMethodInterceptor(bean, tenant, tenantRequestContext);
        if (bean instanceof Advised) {
          ((Advised) bean).addAdvice(advice);
        } else {
          ProxyFactoryBean factory = new ProxyFactoryBean();
          factory.setProxyTargetClass(true);
          factory.addAdvice(advice);
          factory.setTarget(bean);
          return factory.getObject();
        }
      }
    }
    return bean;
  }

  @Override
  public Object postProcessAfterInitialization(final Object bean, final String beanName) {
    return bean;
  }

  private String extractTenant(final String beanName) {
    if (tenantApplicationContext.isTenanted()) {
      Optional<String> tenant = tenantApplicationContext.getAllTenants().stream().filter(beanName::startsWith).findFirst();
      if (tenant.isPresent())
        return tenant.get();
    }
    return null;
  }
}
