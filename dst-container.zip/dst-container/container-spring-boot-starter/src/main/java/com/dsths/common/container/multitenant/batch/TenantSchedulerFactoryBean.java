package com.dsths.common.container.multitenant.batch;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import org.quartz.Scheduler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.lang.Nullable;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

/**
 * Created by DT214743 on 2/24/2019.
 */
public class TenantSchedulerFactoryBean extends SchedulerFactoryBean {
  @Autowired
  private TenantRequestContext tenantRequestContext;
  private ApplicationContext applicationContext;
  private String beanNameSuffix;

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) {
    super.setApplicationContext(applicationContext);
    this.applicationContext = applicationContext;
  }

  public void setBeanNameSuffix(String name) {
    this.beanNameSuffix = name;
  }

  @Override
  public Scheduler getScheduler() {
    if (tenantRequestContext.isTenanted() && tenantRequestContext.getCurrentTenant() == null) {
      throw new IllegalStateException("Unable to resolve scheduler. Tenant is not associated with request context.");
    }
    String tenant = tenantRequestContext.getCurrentTenant();

    return (Scheduler) applicationContext.getBean(Constants.getKeyPrefix(tenant) + beanNameSuffix);
  }

  @Nullable
  @Override
  public Scheduler getObject() {
    return getScheduler();
  }

  @Override
  public void afterPropertiesSet() throws Exception {
    //no op
  }

  @Override
  public boolean isSingleton() {
    return false;
  }
}
