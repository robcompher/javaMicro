package com.dsths.common.container;

import com.dsths.common.container.support.SystemPropertiesHelper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;

/**
 * App Launcher for running application's in command line and can't be used for deploying war inside web container.
 * <p/>
 * Container initialization class which does below
 * 1. Custom Logging System
 * 2. JUL bridge
 * 3. Spring Boot config
 *
 * @author Arun Kommineni (DT214743) on 12/27/2018.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class CommandLineLauncher {
  static {
    SystemPropertiesHelper.setDefaults();
  }

  public static void main(String[] args) {
    SpringApplication.run(CommandLineLauncher.class, args);
  }
}
