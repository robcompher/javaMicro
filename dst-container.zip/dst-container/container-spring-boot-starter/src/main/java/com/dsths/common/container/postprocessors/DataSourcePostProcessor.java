package com.dsths.common.container.postprocessors;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantApplicationContext;
import com.dsths.common.container.multitenant.ds.TenantDelegatingDataSource;
import com.dsths.common.container.property.ContainerProperties;
import com.dsths.common.container.support.JndiObjectTargetSource;
import org.apache.commons.lang.StringUtils;
import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.config.BeanFactoryPostProcessor;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.Ordered;
import org.springframework.core.ResolvableType;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.Environment;
import org.springframework.util.ClassUtils;

import javax.sql.DataSource;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.sql.Driver;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * Created by DT214743 on 10/9/2018.
 */
public class DataSourcePostProcessor implements EnvironmentAware, BeanFactoryPostProcessor, Ordered {
  private Environment environment;

  @Override
  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }

  @Override
  public void postProcessBeanFactory(ConfigurableListableBeanFactory beanFactory) {
    DefaultListableBeanFactory defaultListableBeanFactory = ((DefaultListableBeanFactory) beanFactory);
    Map<String, List<String>> dataSourceNames = new HashMap<>();
    dataSourceNames.put("nonJndiDataSources", new ArrayList<>());
    dataSourceNames.put("jndiDataSources", new ArrayList<>());

    //register default datasource's
    registerDataSource(defaultListableBeanFactory, null, dataSourceNames);

    //register tenant datasource's
    TenantApplicationContext tenantApplicationContext = beanFactory.getBean(TenantApplicationContext.class);
    if (tenantApplicationContext.isTenanted()) {
      tenantApplicationContext.getAllTenants().forEach(tenant ->
              registerDataSource(defaultListableBeanFactory, tenant, dataSourceNames)
      );
    }

    beanFactory.registerSingleton("allDataSourceBeanNames", dataSourceNames);
  }

  private void registerDataSource(DefaultListableBeanFactory beanFactory, String tenant,
                                  Map<String, List<String>> dataSourceNames) {
    try {
      String tenantPrefix = tenant == null ? "" : Constants.getKeyPrefix(tenant);
      Binder binder = Binder.get(environment);
      ContainerProperties containerProperties = binder.bind(tenantPrefix + "container", ContainerProperties.class).get();
      containerProperties.getDataSources().forEach((key, dsProps) -> {
        String dataSourceName = StringUtils.isNotEmpty(dsProps.getName()) ? dsProps.getName() : key;
        String tenantDataSourceName = (tenantPrefix.equals("") ? Constants.DEFAULT_KEY_PREFIX : tenantPrefix)
            + dataSourceName;

        if (StringUtils.isEmpty(dsProps.getJndiName())) {
          registerNonJndiDataSource(beanFactory, key, dsProps, tenantDataSourceName, tenantPrefix, binder);

          dataSourceNames.get("nonJndiDataSources").add(tenantDataSourceName);
        } else {
          registerJndiTargetSource(beanFactory, dsProps, tenantDataSourceName);

          dataSourceNames.get("jndiDataSources").add(tenantDataSourceName);
        }

        registerDataSourceBeanDefinition(beanFactory, dataSourceName);
      });
    } catch (NoSuchElementException e) {
      //Ignore
    }
  }

  private void registerNonJndiDataSource(DefaultListableBeanFactory beanFactory, String key,
                                         DataSourceProperties dsProps, String tenantDataSourceName,
                                         String tenantPrefix, Binder binder) {
    String leakDetectionThresholdKey = String.format("%1$scontainer.data-sources.%2$s.hikari.%3$s", tenantPrefix, key,
        "leakDetectionThreshold");
    if (!environment.containsProperty(leakDetectionThresholdKey)) {
      ((ConfigurableEnvironment) environment).getSystemProperties().put(leakDetectionThresholdKey,
          environment.getProperty("container.hikari.leakDetectionThreshold"));
    }

    DataSource dataSource = dsProps.initializeDataSourceBuilder().build();
    ResolvableType type = ResolvableType.forClass(dataSource.getClass());
    binder.bind(String.format("%1$scontainer.data-sources.%2$s.hikari", tenantPrefix, key),
        Bindable.of(type).withExistingValue(dataSource));

    String credentialsAdaptorKey = String.format("%1$scontainer.data-sources.%2$s.credentials.adapter", tenantPrefix, key);
    String credentialsAdaptor = environment.getProperty(credentialsAdaptorKey);

    if (StringUtils.isNotEmpty(credentialsAdaptor)) {
      setDriverClassAndRegisterBean(beanFactory, dsProps, tenantDataSourceName, dataSource);

      setTargetDataSourceAndRegisterBean(beanFactory, tenantDataSourceName, credentialsAdaptor);
    } else {
      beanFactory.registerSingleton(tenantDataSourceName, dataSource);
    }
  }

  private void registerJndiTargetSource(DefaultListableBeanFactory beanFactory, DataSourceProperties dsProps, String tenantDataSourceName) {
    GenericBeanDefinition bd = new GenericBeanDefinition();
    bd.setBeanClass(JndiObjectTargetSource.class);
    bd.getPropertyValues().add("jndiName", JndiObjectTargetSource.CONTAINER_PREFIX + dsProps.getJndiName());
    bd.getPropertyValues().add("resourceRef", true);
    bd.getPropertyValues().add("lookupOnStartup", false);
    beanFactory.registerBeanDefinition(tenantDataSourceName + "Target", bd);

    bd = new GenericBeanDefinition();
    bd.setBeanClass(ProxyFactoryBean.class);
    bd.getPropertyValues().add("targetSource", beanFactory.getBean(tenantDataSourceName + "Target"));
    bd.getPropertyValues().add("proxyInterfaces", DataSource.class);

    beanFactory.registerBeanDefinition(tenantDataSourceName, bd);
  }

  private void registerDataSourceBeanDefinition(DefaultListableBeanFactory beanFactory, String dataSourceName) {
    if (!beanFactory.containsBeanDefinition(dataSourceName) && !beanFactory.containsBean(dataSourceName)) {
      BeanDefinitionBuilder bd = BeanDefinitionBuilder.genericBeanDefinition(TenantDelegatingDataSource.class);
      bd.addPropertyValue("dataSourceName", dataSourceName);
      bd.setLazyInit(true);

      beanFactory.registerBeanDefinition(dataSourceName, bd.getBeanDefinition());
    }
  }

  private void setTargetDataSourceAndRegisterBean(ConfigurableListableBeanFactory beanFactory, String beanName,
                                                  String credentialsAdaptor) {
    try {
      Class<?> adapterClazz = ClassUtils.forName(credentialsAdaptor, null);

      Method method = BeanUtils.findDeclaredMethod(adapterClazz, "setTargetDataSource", DataSource.class);
      DataSource dataSourceAdapter = (DataSource) BeanUtils.instantiateClass(adapterClazz);

      method.invoke(dataSourceAdapter, beanFactory.getBean(beanName + "-DS"));

      beanFactory.registerSingleton(beanName, dataSourceAdapter);
    } catch (ClassNotFoundException e) {
      throw new IllegalStateException("Not able to find defined CredentialsAdaptor class :" + credentialsAdaptor);
    } catch (IllegalAccessException | InvocationTargetException e) {
      throw new IllegalStateException("Failed to set TargetDataSource on CredentialsAdaptor class:" + credentialsAdaptor);
    }
  }

  private void setDriverClassAndRegisterBean(ConfigurableListableBeanFactory beanFactory, DataSourceProperties dsProps, String beanName, DataSource dataSource) {
    try {
      Method driverMethod = BeanUtils.findMethod(dataSource.getClass(), "setDriverClass", Driver.class.getClass());
      if (driverMethod != null)
        driverMethod.invoke(dataSource, ClassUtils.forName(dsProps.getDriverClassName(), null));

      beanFactory.registerSingleton(beanName + "-DS", dataSource);
    } catch (ClassNotFoundException e) {
      throw new IllegalStateException("Not able to find defined Driver class :" + dsProps.getDriverClassName());
    } catch (IllegalAccessException | InvocationTargetException e) {
      throw new IllegalStateException("Failed to set DriverClass on datasource:" + dsProps.getDriverClassName());
    }
  }

  @Override
  public int getOrder() {
    return Ordered.HIGHEST_PRECEDENCE;
  }
}
