package com.dsths.common.container;

import com.dsths.common.container.support.SystemPropertiesHelper;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.properties.ConfigurationPropertiesScan;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;

/**
 * Launcher for web applications that can run both outside & inside Web Container.
 * Utility class for starting and stopping the container built using Spring Boot based Tomcat.
 * <p/>
 * Container initialization class which does below
 * 1. Custom Logging System
 * 2. JUL bridge
 * 3. Spring Boot config
 *
 * @author Kamal Ramakrishnan (dt78836)
 * @since 09/2017
 * <p/>
 * Modified by Arun Kommineni (DT214743) on 3/27/2018.
 */
@SpringBootApplication
@ConfigurationPropertiesScan
public class DeployableLauncher extends SpringBootServletInitializer {
  static {
    SystemPropertiesHelper.setDefaults();
  }

  @Override
  protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) {
    return build(builder);
  }

  public static void main(String[] args) {
    build(new SpringApplicationBuilder()).run(args);
  }

  /**
   * Method starts the container initializing the container configuration
   */
  public static SpringApplicationBuilder build(SpringApplicationBuilder builder) {
    return builder.sources(DeployableLauncher.class);
  }
}
