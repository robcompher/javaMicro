package com.dsths.common.container.multitenant.concurrent;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.support.ScheduledMethodRunnable;

import java.lang.reflect.Method;

/**
 * Created by DT214743 on 2/5/2019.
 */
public class TenantAwareScheduledMethodRunnable extends ScheduledMethodRunnable {
  private final String tenant;

  @Autowired
  private TenantRequestContext tenantRequestContext;

  public TenantAwareScheduledMethodRunnable(Object target, Method method, String tenant) {
    super(target, method);
    this.tenant = tenant;
  }

  public TenantAwareScheduledMethodRunnable(Object target, String methodName, String tenant) throws NoSuchMethodException {
    super(target, methodName);
    this.tenant = tenant;
  }

  @Override
  public void run() {
    try {
      tenantRequestContext.setCurrentTenant(tenant);
      super.run();
    } finally {
      tenantRequestContext.clear();
    }
  }
}
