package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.integration.TenantChannelInterceptor;
import com.dsths.common.container.multitenant.integration.TenantRequestHandlerAdvice;
import com.dsths.common.container.postprocessors.TenantServiceActivatorFactoryBeanPostProcessor;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.integration.config.GlobalChannelInterceptor;

/**
 * Created by DT214743 on 2/18/2019.
 */
@Configuration
@ConditionalOnClass(name = {"org.springframework.messaging.support.ChannelInterceptor"})
@AutoConfigureAfter(TenantConfiguration.class)
public class TenantIntegrationConfiguration {

  @Bean(name = "tenantChannelInterceptor")
  @Order(Ordered.LOWEST_PRECEDENCE - 10)
  @GlobalChannelInterceptor(order = -1)
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public static TenantChannelInterceptor tenantChannelInterceptor() {
    return new TenantChannelInterceptor();
  }

  @Bean(name = "tenantRequestHandlerAdvice")
  @Order(Ordered.LOWEST_PRECEDENCE - 10)
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public static TenantRequestHandlerAdvice tenantRequestHandlerAdvice() {
    return new TenantRequestHandlerAdvice();
  }

  @Bean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public BeanPostProcessor tenantServiceActivatorFactoryBeanPostProcessor() {
    return new TenantServiceActivatorFactoryBeanPostProcessor();
  }
}
