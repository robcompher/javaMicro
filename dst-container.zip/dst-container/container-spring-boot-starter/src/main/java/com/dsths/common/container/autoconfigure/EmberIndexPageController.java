package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

/**
 * Custom configuration for ember applications to load index page.
 * <p/>
 * This configuration loaded only if container.is.ember.application is set
 * <p/>
 * Created by DT214743 on 4/4/2018.
 */
@Controller
@ConditionalOnProperty(name = Constants.CONTAINER_IS_EMBER_APPLICATION)
@RequestMapping(path = "${container.ember.index.page.path}")
public class EmberIndexPageController {

  @Value("${container.ember.index.page.path}")
  private String indexPagePath;

  @Value("${container.ember.index.page}")
  private String indexPage;

  @GetMapping("")
  public ModelAndView redirectToSlashPath() {
    return new ModelAndView("redirect:" + indexPagePath + "/");
  }

  @GetMapping("/")
  public ModelAndView indexPage() {
    return new ModelAndView(indexPage);
  }
}
