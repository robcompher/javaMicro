package com.dsths.common.container.support;

import org.springframework.core.env.Environment;

/**
 * Created by DT214743 on 11/8/2018.
 */
public class SpringEnvironmentHelper {
  private static Environment env;

  private SpringEnvironmentHelper(){}

  public static String getProperty(String key) {
    return env.getProperty(key);
  }

  public static void setEnvironment(Environment environment) {
    env = environment;
  }
}