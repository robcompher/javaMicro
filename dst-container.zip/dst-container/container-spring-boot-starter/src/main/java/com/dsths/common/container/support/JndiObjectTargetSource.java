package com.dsths.common.container.support;

import org.springframework.aop.TargetSource;
import org.springframework.jndi.JndiLookupFailureException;
import org.springframework.jndi.JndiObjectLocator;
import org.springframework.lang.Nullable;

import javax.naming.NamingException;

/**
 * Added logic to release cached datasource object to fix issue SIGFCONTAINER-238 on shutdown.
 * <p>
 * <p/>
 * AOP {@link org.springframework.aop.TargetSource} that provides
 * configurable JNDI lookups for {@code getTarget()} calls.
 * <p>
 * <p>Can be used as alternative to {@link org.springframework.jndi.JndiObjectFactoryBean}, to allow for
 * relocating a JNDI object lazily or for each operation (see "lookupOnStartup"
 * and "cache" properties). This is particularly useful during development, as it
 * allows for hot restarting of the JNDI server (for example, a remote JMS server).
 * <p>
 * </p><p>Example:
 * <p>
 * </p><pre class="code"> * <bean id="queueConnectionFactoryTarget" class="org.springframework.jndi.JndiObjectTargetSource">
 * <property name="jndiName" value="JmsQueueConnectionFactory"/>
 * <property name="lookupOnStartup" value="false"/>
 * </bean>
 * <p/>
 * <bean id="queueConnectionFactory" class="org.springframework.aop.framework.ProxyFactoryBean">
 * <property name="proxyInterfaces" value="javax.jms.QueueConnectionFactory"/>
 * <property name="targetSource" ref="queueConnectionFactoryTarget"/>
 * </bean></pre>
 * <p/>
 * A {@code createQueueConnection} call on the "queueConnectionFactory" proxy will
 * cause a lazy JNDI lookup for "JmsQueueConnectionFactory" and a subsequent delegating
 * call to the retrieved QueueConnectionFactory's {@code createQueueConnection}.
 * <p/>
 * <p><b>Alternatively, use a {@link org.springframework.jndi.JndiObjectFactoryBean} with a "proxyInterface".</b>
 * "lookupOnStartup" and "cache" can then be specified on the JndiObjectFactoryBean,
 * creating a JndiObjectTargetSource underneath (instead of defining separate
 * ProxyFactoryBean and JndiObjectTargetSource beans).
 *
 * @author Juergen Hoeller
 * @see #setLookupOnStartup
 * @see #setCache
 * @see org.springframework.aop.framework.ProxyFactoryBean#setTargetSource
 * @see org.springframework.jndi.JndiObjectFactoryBean#setProxyInterface
 * @since 1.1
 * <p/>
 * Modified by DT214743 on 01/02/2019
 */
public class JndiObjectTargetSource extends JndiObjectLocator implements TargetSource {

  private boolean lookupOnStartup = true;

  private boolean cache = true;

  @Nullable
  private Object cachedObject;

  @Nullable
  private Class<?> targetClass;


  /**
   * Set whether to look up the JNDI object on startup. Default is "true".
   * </p><p>Can be turned off to allow for late availability of the JNDI object.
   * In this case, the JNDI object will be fetched on first access.
   *
   * @see #setCache
   */
  public void setLookupOnStartup(boolean lookupOnStartup) {
    this.lookupOnStartup = lookupOnStartup;
  }

  /**
   * Set whether to cache the JNDI object once it has been located.
   * Default is "true".
   * </p><p>Can be turned off to allow for hot redeployment of JNDI objects.
   * In this case, the JNDI object will be fetched for each invocation.
   *
   * @see #setLookupOnStartup
   */
  public void setCache(boolean cache) {
    this.cache = cache;
  }

  @Override
  public void afterPropertiesSet() throws NamingException {
    super.afterPropertiesSet();
    if (this.lookupOnStartup) {
      Object object = lookup();
      if (this.cache) {
        this.cachedObject = object;
      } else {
        this.targetClass = object.getClass();
      }
    }
  }


  @Override
  @Nullable
  public Class<?> getTargetClass() {
    if (this.cachedObject != null) {
      return this.cachedObject.getClass();
    } else if (this.targetClass != null) {
      return this.targetClass;
    } else {
      return getExpectedType();
    }
  }

  @Override
  public boolean isStatic() {
    return (this.cachedObject != null);
  }

  @Override
  @Nullable
  public Object getTarget() {
    try {
      if (this.lookupOnStartup || !this.cache) {
        return (this.cachedObject != null ? this.cachedObject : lookup());
      } else {
        synchronized (this) {
          if (this.cachedObject == null) {
            this.cachedObject = lookup();
          }
          return this.cachedObject;
        }
      }
    } catch (NamingException ex) {
      throw new JndiLookupFailureException("JndiObjectTargetSource failed to obtain new target object", ex);
    }
  }

  @Override
  public void releaseTarget(Object target) {
    this.cachedObject = null;
  }

}
