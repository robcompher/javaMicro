package com.dsths.common.container.multitenant.concurrent;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.util.StringUtils;

/**
 * Created by DT214743 on 2/7/2019.
 */
public class TenantRunnable implements Runnable {
  private final TenantRequestContext tenantRequestContext;
  private final Runnable delegate;

  public TenantRunnable(TenantRequestContext tenantRequestContext, Runnable delegate) {
    this.tenantRequestContext = tenantRequestContext;
    this.delegate = associateTenant(delegate);
  }

  @Override
  public void run() {
    this.delegate.run();
  }

  protected Runnable associateTenant(Runnable task) {
    if (tenantRequestContext.isTenanted() && tenantRequestContext.getCurrentTenant() != null) {
      String originalTenant = tenantRequestContext.getCurrentTenant();
      return () -> {
        if (!StringUtils.isEmpty(originalTenant)) {
          tenantRequestContext.setCurrentTenant(originalTenant);
          try {
            task.run();
          } finally {
            tenantRequestContext.clear();
          }
        } else {
          task.run();
        }
      };
    }

    return task;
  }
}
