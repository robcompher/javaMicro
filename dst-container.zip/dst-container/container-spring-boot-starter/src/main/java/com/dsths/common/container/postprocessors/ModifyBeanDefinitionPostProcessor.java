package com.dsths.common.container.postprocessors;

import com.dsths.common.container.Constants;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.aop.scope.ScopedProxyUtils;
import org.springframework.beans.factory.annotation.AnnotatedBeanDefinition;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.config.ConstructorArgumentValues;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.beans.factory.support.GenericBeanDefinition;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.core.Ordered;
import org.springframework.core.type.MethodMetadata;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Optional;
import java.util.Set;

/**
 * Created by DT214743 on 1/31/2019.
 */
public class ModifyBeanDefinitionPostProcessor implements BeanDefinitionRegistryPostProcessor, Ordered {
  public static final int DEFAULT_ORDER = Ordered.LOWEST_PRECEDENCE + 1;

  private static final Logger logger = LogManager.getLogger(ModifyBeanDefinitionPostProcessor.class);

  private final List<String> beanNames;
  private final List<String> keys;
  private final List<String> clonedBeanNames;

  public ModifyBeanDefinitionPostProcessor(List<String> keys, List<String> beanNames) {
    Assert.notNull(beanNames, "bean names are required");
    Assert.notNull(keys, "keys are required");

    clonedBeanNames = new ArrayList<>();
    this.beanNames = beanNames;
    this.keys = keys;
  }

  @Override
  public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry beanDefinitionRegistry) {
    copyBeanDefinitions(beanDefinitionRegistry);
    processBeanDefinition(beanDefinitionRegistry);
  }

  @Override
  public void postProcessBeanFactory(final ConfigurableListableBeanFactory beanFactory) {
    List<String> tenantAwareProxyBeanNames = (List<String>) beanFactory.getBean("tenantAwareProxyBeanNames");
    tenantAwareProxyBeanNames.addAll(clonedBeanNames);
  }

  private void processBeanDefinition(BeanDefinitionRegistry beanDefinitionRegistry) {
    Set<String> removeDefs = new HashSet<>();
    Arrays.stream(beanDefinitionRegistry.getBeanDefinitionNames())
        .filter(beanName -> (beanDefinitionRegistry.getBeanDefinition(beanName).getBeanClassName() != null))
        .forEach(beanName -> {
          BeanDefinition beanDefinition = beanDefinitionRegistry.getBeanDefinition(beanName);
          if (beanDefinition.getBeanClassName().equals(
              "org.springframework.scheduling.config.ContextLifecycleScheduledTaskRegistrar")) {
            copyScheduledBeanDefinition(beanDefinitionRegistry, removeDefs, beanName, beanDefinition);
          }
          if(beanDefinition.getDependsOn() != null) {
            List<String> dependsOnNames = new ArrayList<>();
            dependsOnNames.addAll(Arrays.asList(beanDefinition.getDependsOn()));
            Arrays.stream(beanDefinition.getDependsOn()).forEach(dependsOnName -> {
              if (beanNames.contains(dependsOnName)) {
                Optional<String> tenantBeanName = clonedBeanNames.stream()
                    .filter(clonedBeanName -> clonedBeanName.contains(dependsOnName))
                    .findFirst();
                if (tenantBeanName.isPresent()) {
                  dependsOnNames.add(tenantBeanName.get());
                  dependsOnNames.remove(dependsOnName);
                }
              }
            });
            beanDefinition.setDependsOn(dependsOnNames.toArray(new String[0]));
          }
        });
    removeDefs.stream().forEach(beanDefinitionRegistry::removeBeanDefinition);
  }

  private void copyScheduledBeanDefinition(BeanDefinitionRegistry beanDefinitionRegistry,
                                           Set<String> removeDefs, String beanName, BeanDefinition beanDefinition) {
    logger.debug("taskRegistrarBeanName: " + beanName);
    //copy scheduled tasks
    List<String> taskListMethods = Arrays.asList("cronTasksList", "fixedDelayTasksList",
        "fixedRateTasksList", "triggerTasksList");

    taskListMethods.forEach(methodName -> {
      ManagedList existingTaskList = (ManagedList) beanDefinition.getPropertyValues().get(methodName);
      ManagedList newTaskList = new ManagedList();

      existingTaskList.forEach(managedTaskBean -> {
        String taskBeanName = ((RuntimeBeanReference) managedTaskBean).getBeanName();
        BeanDefinition taskBeanDef = beanDefinitionRegistry.getBeanDefinition(taskBeanName);
        logger.debug("taskBeanName: " + taskBeanName);
        ConstructorArgumentValues.ValueHolder rbf = taskBeanDef.getConstructorArgumentValues()
            .getIndexedArgumentValue(0, RuntimeBeanReference.class);

        String scheduledBeanName = ((RuntimeBeanReference) rbf.getValue()).getBeanName();
        logger.debug("scheduledBeanName: " + scheduledBeanName);

        BeanDefinition scheduledBeanDef = beanDefinitionRegistry.getBeanDefinition(scheduledBeanName);
        rbf = scheduledBeanDef.getConstructorArgumentValues().getIndexedArgumentValue(0, RuntimeBeanReference.class);

        String targetBeanName = ((RuntimeBeanReference) rbf.getValue()).getBeanName();
        logger.debug("targetBeanName: " + targetBeanName);
        if (beanNames.contains(targetBeanName)) {
          keys.stream().forEach(key -> {
            String newTargetBeanName = generateBeanName(key, targetBeanName);
            String newScheduledBeanName = generateBeanName(key, scheduledBeanName);
            logger.debug("Replicated scheduled bean name {}", newScheduledBeanName);
            BeanDefinition newScheduledBeanDef = ((GenericBeanDefinition) scheduledBeanDef).cloneBeanDefinition();
            newScheduledBeanDef.setBeanClassName(
                "com.dsths.common.container.multitenant.concurrent.TenantAwareScheduledMethodRunnable");
            newScheduledBeanDef.getConstructorArgumentValues()
                .addIndexedArgumentValue(0, new RuntimeBeanReference(newTargetBeanName));
            newScheduledBeanDef.getConstructorArgumentValues().addIndexedArgumentValue(2, key);

            beanDefinitionRegistry.registerBeanDefinition(newScheduledBeanName, newScheduledBeanDef);

            String newTaskBeanName = generateBeanName(key, taskBeanName);
            logger.debug("Replicated task bean name {}", newTaskBeanName);

            BeanDefinition newTaskBeanDef = ((GenericBeanDefinition) taskBeanDef).cloneBeanDefinition();
            newTaskBeanDef.getConstructorArgumentValues()
                .addIndexedArgumentValue(0, new RuntimeBeanReference(newScheduledBeanName));
            beanDefinitionRegistry.registerBeanDefinition(newTaskBeanName, newTaskBeanDef);
            newTaskList.add(new RuntimeBeanReference(newTaskBeanName));

            removeDefs.add(scheduledBeanName);
            removeDefs.add(taskBeanName);
            clonedBeanNames.remove(newTargetBeanName);
          });
        }
      });
      if (!newTaskList.isEmpty()) {
        beanDefinition.getPropertyValues().addPropertyValue(methodName, newTaskList);
      }
    });
  }

  private List<String> copyBeanDefinitions(final BeanDefinitionRegistry beanDefinitionRegistry) {
    if (!keys.isEmpty()) {
      //copy bean definition
      beanNames.stream()
          .filter(beanName -> {
            if (beanDefinitionRegistry.containsBeanDefinition(beanName)) {
              return true;
            } else {
              logger.warn("Ignoring for replication!!! Bean name {} is not found in configuration", beanName);
              return false;
            }
          })
          .map(beanName -> new BeanDefinitionHolder(beanDefinitionRegistry.getBeanDefinition(beanName), beanName))
          .forEach(targetDefinitionHolder -> {
            final BeanDefinition beanDefinition = targetDefinitionHolder.getBeanDefinition();
            keys.stream().forEach(key -> {
              BeanDefinition newBeanDefinition = new GenericBeanDefinition(beanDefinition);
              String newBeanName = generateBeanName(key, targetDefinitionHolder.getBeanName());
              logger.debug("Replicated bean name {}", newBeanName);
              beanDefinitionRegistry.registerBeanDefinition(newBeanName, newBeanDefinition);
              clonedBeanNames.add(newBeanName);
            });

            if (isSchedulerFactoryBean(beanDefinition, beanDefinitionRegistry)) {
              BeanDefinitionBuilder bd = BeanDefinitionBuilder.genericBeanDefinition(
                  "com.dsths.common.container.multitenant.batch.TenantSchedulerFactoryBean");
              bd.setScope("prototype"); //Changed scope tenant to prototype to fix error on startup with Spring 5.2.0 version or above
              bd.addPropertyValue("beanNameSuffix", targetDefinitionHolder.getBeanName());
              BeanDefinitionHolder proxyHolder = ScopedProxyUtils.createScopedProxy(
                  new BeanDefinitionHolder(bd.getBeanDefinition(), targetDefinitionHolder.getBeanName()),
                  beanDefinitionRegistry, true);

              beanDefinitionRegistry.removeBeanDefinition(proxyHolder.getBeanName());
              beanDefinitionRegistry.registerBeanDefinition(proxyHolder.getBeanName(), proxyHolder.getBeanDefinition());
            } else {
              //remove original bean definition
              beanDefinitionRegistry.removeBeanDefinition(targetDefinitionHolder.getBeanName());
            }
          });
    }
    return clonedBeanNames;
  }

  private boolean isSchedulerFactoryBean(BeanDefinition beanDefinition, BeanDefinitionRegistry beanDefinitionRegistry) {
    String beanClassName = getBeanClassName(beanDefinition, beanDefinitionRegistry);
    if (beanClassName != null
        && beanClassName.equals("org.springframework.scheduling.quartz.SchedulerFactoryBean")) {
      return true;
    }
    return false;
  }

  private String getBeanClassName(BeanDefinition beanDefinition, BeanDefinitionRegistry beanDefinitionRegistry) {
    String beanClassName = null;
    if (beanDefinition instanceof AnnotatedBeanDefinition) {
      MethodMetadata factoryMethodMetadata = ((AnnotatedBeanDefinition) beanDefinition).getFactoryMethodMetadata();
      if (factoryMethodMetadata != null) {
        beanClassName = factoryMethodMetadata.getReturnTypeName();
      }
    } else {
      beanClassName = beanDefinition.getBeanClassName();
      String parentName = beanDefinition.getParentName();
      while (beanClassName == null && parentName != null) {
        BeanDefinition parentBeanDefinition = beanDefinitionRegistry.getBeanDefinition(parentName);
        beanClassName = parentBeanDefinition.getBeanClassName();
        parentName = parentBeanDefinition.getParentName();
      }
    }
    return beanClassName;
  }

  private String generateBeanName(String key, String beanName) {
    return Constants.getKeyPrefix(key) + beanName;
  }

  @Override
  public int getOrder() {
    return DEFAULT_ORDER;
  }

}
