package com.dsths.common.container.multitenant.property;

import com.dsths.common.container.Constants;
import com.dsths.common.container.property.PropertyTransformer;

/**
 * Created by DT214743 on 12/28/2018.
 */
public class PrefixPropertyTransformer implements PropertyTransformer {

  private final String prefix;

  private PrefixPropertyTransformer(String prefix) {
    this.prefix = prefix;
  }

  public static PropertyTransformer forTenant(String prefix) {
    return new PrefixPropertyTransformer(prefix);
  }

  @Override
  public String transform(String key) {
    String keyPrefix = Constants.getKeyPrefix(this.prefix);
    String returnKey = key;
    if (returnKey != null && !returnKey.startsWith(keyPrefix)) {
      returnKey = keyPrefix + returnKey;
    }
    return returnKey;
  }

  @Override
  public String untransform(String key) {
    String keyPrefix = Constants.getKeyPrefix(this.prefix);
    String returnKey = key;
    if (returnKey != null && returnKey.startsWith(keyPrefix)) {
      returnKey = returnKey.replaceFirst(keyPrefix, "");
    }
    return returnKey;
  }
}
