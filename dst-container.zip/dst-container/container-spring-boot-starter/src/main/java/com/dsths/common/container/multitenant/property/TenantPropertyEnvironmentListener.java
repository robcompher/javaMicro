package com.dsths.common.container.multitenant.property;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertySource;

/**
 * Set's the TenantRequestContext to property source on ApplicationPreparedEvent.
 * Created by DT214743 on 12/29/2018.
 */
public class TenantPropertyEnvironmentListener implements ApplicationListener<ApplicationPreparedEvent> {
  @Override
  public void onApplicationEvent(ApplicationPreparedEvent event) {
    ConfigurableEnvironment environment = event.getApplicationContext().getEnvironment();

    for (PropertySource<?> propertySource : environment.getPropertySources()) {
      if (propertySource instanceof TenantOriginTrackedMapPropertySource) {
        event.getApplicationContext().addBeanFactoryPostProcessor(
            beanFactory -> {
              if(beanFactory.containsBean("tenantRequestContext")) {
                ((TenantOriginTrackedMapPropertySource) propertySource).setTenantRequestContext(
                    beanFactory.getBean(TenantRequestContext.class));
              }
            }
        );
      } else if (propertySource instanceof TenantMapPropertySource) {
        event.getApplicationContext().addBeanFactoryPostProcessor(
            beanFactory -> {
              if (beanFactory.containsBean("tenantRequestContext")) {
                ((TenantMapPropertySource) propertySource).setTenantRequestContext(
                    beanFactory.getBean(TenantRequestContext.class));
              }
            }
        );
      }
    }
  }
}
