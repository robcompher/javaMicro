package com.dsths.common.container.listeners;

import com.dsths.common.container.support.JndiObjectTargetSource;
import com.zaxxer.hikari.HikariDataSource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.aop.framework.Advised;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.sql.DataSource;
import java.util.List;

/**
 * Added listener to TO FIX below issue logged while shutting down the container with JNDI Hikari DataSource
 * <p/>
 * The web application [dstcontainer] appears to have started a thread named [XXXXX housekeeper] but has failed to stop it.
 * This is very likely to create a memory leak.
 * Stack trace of thread: sun.misc.Unsafe.park(Native Method)
 * java.util.concurrent.locks.LockSupport.parkNanos(LockSupport.java:215)
 * <p/>
 * Created by DT214743 on 12/10/2018.
 */
public class HikariServletListener implements ServletContextListener {
  private static final Logger logger = LogManager.getLogger(HikariServletListener.class);

  @Value("#{allDataSourceBeanNames['jndiDataSources']}")
  private List<String> allDataSourceBeanNames;

  @Autowired
  private BeanFactory beanFactory;

  @Override
  public void contextInitialized(ServletContextEvent sce) {
    logger.info(String.format("ServletContext [%1$s] initialized", sce.getServletContext().getContextPath()));
  }

  @Override
  public void contextDestroyed(ServletContextEvent sce) {
    logger.info(String.format("ServletContext [%1$s] closing Data Source's", sce.getServletContext().getContextPath()));
    if (allDataSourceBeanNames != null) {
      DefaultListableBeanFactory configurableBeanFactory = (DefaultListableBeanFactory) beanFactory;
      //close jndi datasource's
      allDataSourceBeanNames.stream().forEach(dataSourceName -> {
        try {
          DataSource ds = (DataSource) configurableBeanFactory.getBean(dataSourceName);
          JndiObjectTargetSource ts = ((JndiObjectTargetSource) ((Advised) ds).getTargetSource());
          if (ts.getTarget() instanceof HikariDataSource) {
            HikariDataSource hikariDataSource = (HikariDataSource) ts.getTarget();
            ts.releaseTarget(hikariDataSource);
            hikariDataSource.close();
          }
        } catch (Exception e) {
          logger.warn("Failed to close Hikari JNDI datasource", e);
        }
      });
    }
    logger.info(String.format("ServletContext [%1$s] destroyed", sce.getServletContext().getContextPath()));
  }
}
