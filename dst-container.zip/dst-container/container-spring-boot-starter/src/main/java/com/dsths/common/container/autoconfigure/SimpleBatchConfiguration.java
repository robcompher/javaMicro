package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.batch.CustomDefaultBatchConfigurer;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.ProxyFactory;
import org.springframework.aop.target.AbstractLazyCreationTargetSource;
import org.springframework.batch.core.configuration.JobRegistry;
import org.springframework.batch.core.configuration.ListableJobLocator;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.configuration.support.MapJobRegistry;
import org.springframework.batch.core.explore.JobExplorer;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.batch.core.launch.JobOperator;
import org.springframework.batch.core.launch.support.SimpleJobOperator;
import org.springframework.batch.core.repository.JobRepository;
import org.springframework.batch.core.scope.JobScope;
import org.springframework.batch.core.scope.StepScope;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.batch.BatchAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.util.Collection;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Created by DT214743 on 10/31/2019.
 *
 * Most of the code is copied from Spring batch
 * org.springframework.batch.core.configuration.annotation.SimpleBatchConfiguration class
 *
 * This is to avoid https://jira.spring.io/browse/BATCH-2819 when multiple datasources are defined.
 */
@Configuration
@ConditionalOnClass({JobLauncher.class, DataSource.class})
@AutoConfigureAfter({BatchAutoConfiguration.class})
public class SimpleBatchConfiguration {
  @Autowired
  private ApplicationContext context;
  private boolean initialized = false;
  private AtomicReference<JobRepository> jobRepository = new AtomicReference<>();
  private AtomicReference<JobLauncher> jobLauncher = new AtomicReference<>();
  private AtomicReference<JobRegistry> jobRegistry = new AtomicReference<>();
  private AtomicReference<PlatformTransactionManager> transactionManager = new AtomicReference<>();
  private AtomicReference<JobExplorer> jobExplorer = new AtomicReference<>();

  @Bean
  @ConditionalOnMissingBean(JobRepository.class)
  public JobRepository jobRepository() {
    return createLazyProxy(jobRepository, JobRepository.class);
  }

  @Bean
  @ConditionalOnMissingBean(JobLauncher.class)
  public JobLauncher jobLauncher() {
    return createLazyProxy(jobLauncher, JobLauncher.class);
  }

  @Bean
  @ConditionalOnMissingBean(JobRegistry.class)
  public JobRegistry jobRegistry() {
    return createLazyProxy(jobRegistry, JobRegistry.class);
  }

  @Bean
  @ConditionalOnMissingBean(JobExplorer.class)
  public JobExplorer jobExplorer() {
    return createLazyProxy(jobExplorer, JobExplorer.class);
  }

  @Bean
  @ConditionalOnMissingBean(PlatformTransactionManager.class)
  public PlatformTransactionManager transactionManager() {
    return createLazyProxy(transactionManager, PlatformTransactionManager.class);
  }

  @Bean
  @ConditionalOnMissingBean(JobOperator.class)
  public JobOperator jobOperator(JobExplorer jobExplorer, JobLauncher jobLauncher, ListableJobLocator jobRegistry, JobRepository jobRepository) {
    SimpleJobOperator jobOperator = new SimpleJobOperator();
    jobOperator.setJobExplorer(jobExplorer);
    jobOperator.setJobLauncher(jobLauncher);
    jobOperator.setJobRegistry(jobRegistry);
    jobOperator.setJobRepository(jobRepository);
    return jobOperator;
  }

  @Bean
  @ConditionalOnMissingBean(JobBuilderFactory.class)
  public JobBuilderFactory jobBuilderFactory(JobRepository jobRepository) {
    return new JobBuilderFactory(jobRepository);
  }

  @Bean
  @ConditionalOnMissingBean(StepBuilderFactory.class)
  public StepBuilderFactory stepBuilderFactory(JobRepository jobRepository, PlatformTransactionManager transactionManager) {
    return new StepBuilderFactory(jobRepository, transactionManager);
  }

  @Bean
  @ConditionalOnMissingBean(StepScope.class)
  public static StepScope stepScope() {
    StepScope stepScope = new StepScope();
    stepScope.setAutoProxy(false);
    return stepScope;
  }

  @Bean
  @ConditionalOnMissingBean(JobScope.class)
  public static JobScope jobScope() {
    JobScope jobScope = new JobScope();
    jobScope.setAutoProxy(false);
    return jobScope;
  }

  private <T> T createLazyProxy(AtomicReference<T> reference, Class<T> type) {
    ProxyFactory factory = new ProxyFactory();
    factory.setTargetSource(new ReferenceTargetSource<>(reference));
    factory.addAdvice(new PassthruAdvice());
    factory.setInterfaces(type);
    @SuppressWarnings("unchecked")
    T proxy = (T) factory.getProxy();
    return proxy;
  }

  /**
   * Sets up the basic components by extracting them from the {@link BatchConfigurer configurer}, defaulting to some
   * sensible values as long as a unique DataSource is available.
   *
   * @throws Exception if there is a problem in the configurer
   */
  @PostConstruct
  protected void initialize() throws Exception {
    if (initialized) {
      return;
    }
    BatchConfigurer configurer = getConfigurer(context.getBeansOfType(BatchConfigurer.class).values());
    jobRepository.set(configurer.getJobRepository());
    jobLauncher.set(configurer.getJobLauncher());
    transactionManager.set(configurer.getTransactionManager());
    jobRegistry.set(new MapJobRegistry());
    jobExplorer.set(configurer.getJobExplorer());
    initialized = true;
  }

  protected BatchConfigurer getConfigurer(Collection<BatchConfigurer> configurers) {
    if(configurers != null && !configurers.isEmpty()) {
      if (configurers.size() > 1) {
        throw new IllegalStateException(
            "To use a custom BatchConfigurer the context must contain precisely one, found "
                + configurers.size());
      }
      return configurers.iterator().next();
    } else {
      DefaultBatchConfigurer configurer = new CustomDefaultBatchConfigurer();
      configurer.initialize();
      return configurer;
    }
  }

  private class PassthruAdvice implements MethodInterceptor {
    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
      return invocation.proceed();
    }
  }

  private class ReferenceTargetSource<T> extends AbstractLazyCreationTargetSource {
    private AtomicReference<T> reference;

    public ReferenceTargetSource(AtomicReference<T> reference) {
      this.reference = reference;
    }

    @Override
    protected Object createObject() throws Exception {
      initialize();
      return reference.get();
    }
  }
}
