package com.dsths.common.container.postprocessors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.aop.scope.ScopedProxyUtils;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.core.Ordered;
import org.springframework.util.Assert;

import java.util.Arrays;
import java.util.List;

/**
 * Created by DT214743 on 1/24/2019.
 */
public class OverrideBeanScopePostProcessor implements BeanDefinitionRegistryPostProcessor, Ordered {
  public static final int DEFAULT_ORDER = ModifyBeanDefinitionPostProcessor.DEFAULT_ORDER - 2;
  private static final Logger logger = LogManager.getLogger(OverrideBeanScopePostProcessor.class);

  private final List<String> beanNames;
  private final String scope;

  public OverrideBeanScopePostProcessor(String scope, String... beanNames) {
    Assert.notNull(beanNames, "bean names are required");
    Assert.notNull(scope, "scope is required");
    this.beanNames = Arrays.asList(beanNames);
    this.scope = scope;
  }

  @Override
  public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry beanDefinitionRegistry) {
    //set tenant scope
    beanNames.stream()
        .filter(beanName -> {
          if (beanDefinitionRegistry.containsBeanDefinition(beanName)) {
            return true;
          } else {
            logger.warn("Ignoring for scope overriding!!! Bean name {} is not found in configuration", beanName);
            return false;
          }
        })
        .map(beanName -> new BeanDefinitionHolder(beanDefinitionRegistry.getBeanDefinition(beanName), beanName))
        .forEach(targetDefinitionHolder -> {
          targetDefinitionHolder.getBeanDefinition().setScope(scope);
          if (!isProxyFactoryBeanDefinition(targetDefinitionHolder.getBeanDefinition())) {
            logger.debug("Creating scoped proxy for bean name {}", targetDefinitionHolder.getBeanName());
            BeanDefinitionHolder proxyHolder = ScopedProxyUtils.createScopedProxy(targetDefinitionHolder,
                beanDefinitionRegistry, true);

            beanDefinitionRegistry.removeBeanDefinition(proxyHolder.getBeanName());
            beanDefinitionRegistry.registerBeanDefinition(proxyHolder.getBeanName(), proxyHolder.getBeanDefinition());
          } else {
            logger.warn("Scoped Proxy is not created. Given bean name {} is already a proxy factory bean.",
                targetDefinitionHolder.getBeanName());
          }
        });
  }

  @Override
  public void postProcessBeanFactory(final ConfigurableListableBeanFactory beanFactory) {
    //no op
  }

  @Override
  public int getOrder() {
    return DEFAULT_ORDER;
  }

  private boolean isProxyFactoryBeanDefinition(BeanDefinition existingDefinition) {
    return ProxyFactoryBean.class.getName().equals(existingDefinition.getBeanClassName());
  }
}
