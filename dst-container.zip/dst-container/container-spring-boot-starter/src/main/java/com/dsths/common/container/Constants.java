package com.dsths.common.container;

/**
 * Created by DT214743 on 2/7/2019.
 */
public class Constants {

  private Constants() {}
  public static final String CONTAINER_APPLICATION_INDEX_PAGE = "container.application.index.page";
  public static final String CONTAINER_TENANTS_PROPERTY_KEY = "__container__tenant__list__";
  public static final String DEFAULT_KEY_PREFIX = Constants.getKeyPrefix("default");
  public static final String OVERRIDE_BEAN_SCOPE_TO_TENANT_SCOPE_PROPERTY = "container.tenant.override.bean.scope.to.tenant.scope";
  public static final String CLONE_BEAN_DEFINITION_PER_TENANT_PROPERTY = "container.tenant.clone.bean.per.tenant";
  public static final String TENANT_SCOPE_NAME = "tenant";
  public static final String CONTAINER_SPRING_MVC_ADDITIONAL_STATIC_PATH_PATTERNS = "container.spring.mvc.additional.static-path-patterns";
  public static final String CONTAINER_STATIC_CONTENT_ENABLED = "container.static.content.enabled";
  public static final String CONTAINER_IS_EMBER_APPLICATION = "container.is.ember.application";
  public static final String CONTAINER_JERSEY_ENABLED = "container.jersey.enabled";
  public static final String SPRING_JERSEY_APPLICATION_PATH = "spring.jersey.application-path";
  public static final String CONTAINER_SOAP_ENABLED = "container.soap.enabled";
  public static final String CONTAINER_SOAP_APPLICATION_PATH = "container.soap.application-path";
  public static final String CONTAINER_TENANT_PRIMARY = "container.tenant.primary";
  public static final String CONTAINER_TENANT_ACTIVE = "container.tenant.active";
  public static final String TENANT_CONFIG_LOCATION = "container.tenant.config.location";
  public static final String TENANT_CONFIG_TENANT_NAME_PATTERN = "container.tenant.config.tenant.name.pattern";
  public static final String TENANT_NAME = "container.tenant.name";
  public static final String ENCRYPTED_PD_KEY = "encryptedPassword";
  public static final String PD_DECRYPTION_ERROR = "Password could not be decrypted using encryptedPassword (%s) and encryptionKeyFile (%s)";
  public static final String ENCRYPTION_KEY_FILE = "encryptionKeyFile";

  public static final String TENANT_KEY = "tenant.key";
  public static final String JOB_FACTORY = "jobFactory";
  public static final String DATASOURCE = "dataSource";
  public static final String ADVICE_CHAIN = "adviceChain";
  public static final String PERSISTENCE_PROVIDER = "persistenceProvider";
  public static final String PERSISTENCE_PROVIDER_CLAZZ = "persistenceProviderClass";

  public static final String getKeyPrefix(String keyPrefix) {
    return keyPrefix + '.';
  }
}
