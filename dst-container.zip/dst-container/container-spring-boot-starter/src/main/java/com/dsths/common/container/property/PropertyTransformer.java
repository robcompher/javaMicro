package com.dsths.common.container.property;

public interface PropertyTransformer {

  String transform(String key);

  String untransform(String key);
}
