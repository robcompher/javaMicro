package com.dsths.common.container.tomcat;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantApplicationContext;
import com.dsths.common.container.multitenant.exception.TenantException;
import com.dsths.common.container.property.ContainerProperties;
import org.apache.catalina.Context;
import org.apache.catalina.startup.Tomcat;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tomcat.util.descriptor.web.ContextResource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.boot.web.embedded.tomcat.TomcatServletWebServerFactory;
import org.springframework.boot.web.embedded.tomcat.TomcatWebServer;
import org.springframework.boot.web.server.ErrorPage;
import org.springframework.boot.web.server.WebServer;
import org.springframework.boot.web.servlet.ServletContextInitializer;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;

import java.util.Arrays;
import java.util.NoSuchElementException;

/**
 * Custom Embedded container configuration
 * 1. JNDI based Datasource registration
 * 2. SSL config
 *
 * @author Kamal Ramakrishnan (dt78836)
 *         Modified by Arun Kommineni (DT214743) on 3/23/2018.
 */
public class CustomTomcatWebServerFactory extends TomcatServletWebServerFactory {
  private static final Logger LOGGER = LogManager.getLogger(CustomTomcatWebServerFactory.class);

  private static final String[] HIKARI_POOL_PROPERTIES = new String[]{"connectionTimeout", "validationTimeout",
      "idleTimeout", "maxLifetime", "maximumPoolSize", "minimumIdle", "initializationFailTimeout", "catalog",
      "connectionInitSql", "connectionTestQuery", "schema", "transactionIsolationName", "autoCommit",
      "readOnly", "isolateInternalQueries", "allowPoolSuspension"};

  @Autowired
  private TenantApplicationContext tenantApplicationContext;

  @Autowired
  private Environment environment;

  @Override
  public WebServer getWebServer(ServletContextInitializer... initializers) {
    LOGGER.trace("getWebServer: Initialize Error pages");
    this.addErrorPages(new ErrorPage(HttpStatus.UNAUTHORIZED, "/container/error/401.jsp"));
    this.addErrorPages(new ErrorPage(HttpStatus.FORBIDDEN, "/container/error/403.jsp"));
    this.addErrorPages(new ErrorPage(HttpStatus.NOT_FOUND, "/container/error/404.jsp"));
    this.addErrorPages(new ErrorPage(TenantException.class, "/container/error/tenantError.jsp"));
    this.addErrorPages(new ErrorPage(Exception.class, "/container/error/500.jsp"));

    return super.getWebServer(initializers);
  }

  @Override
  protected TomcatWebServer getTomcatWebServer(Tomcat tomcat) {
    LOGGER.trace("getWebServer: enableNaming");
    tomcat.enableNaming();

    //Register default servlet to redirect to contextpath url
    if (StringUtils.isNotEmpty(this.getContextPath())) {
      LOGGER.trace("getWebServer: register RootRedirectServlet");
      Context ctx = tomcat.addContext("", null);
      Tomcat.addServlet(ctx, "default", new RootRedirectServlet(this.getContextPath()));
      ctx.addServletMappingDecoded("/", "default");
    }

    return super.getTomcatWebServer(tomcat);
  }

  @Override
  protected void postProcessContext(final Context serverContext) {
    LOGGER.trace("postProcessContext: DataSource");
    //register default datasource's
    registerDataSource(serverContext, "");

    //register tenant datasource's
    if (tenantApplicationContext.isTenanted()) {
      tenantApplicationContext.getAllTenants().forEach(tenant ->
              registerDataSource(serverContext, Constants.getKeyPrefix(tenant))
      );
    }
  }

  /**
   * Initialize Tomcat ContextResource
   * <p/>
   * Note: lookupOnStartup to false, when datasource is defined in applicationContext.xml
   *
   * @param serverContext
   */
  private void registerDataSource(final Context serverContext, String keyPrefix) {
    try {
      Binder binder = Binder.get(environment);
      ContainerProperties containerProperties = binder.bind(keyPrefix + "container", ContainerProperties.class).get();
      containerProperties.getDataSources().forEach((key, dataSource) -> {
        if (StringUtils.isNotEmpty(dataSource.getJndiName())) {
          LOGGER.debug("initializeDataSource: " + dataSource.getJndiName());
          if (serverContext.getNamingResources().findResource(dataSource.getJndiName()) != null) {
            throw new IllegalStateException("JNDI name must be unique. Duplicate datasource JNDI name: " + dataSource.getJndiName());
          }
          ContextResource resource = new ContextResource();

          resource.setName(dataSource.getJndiName());
          resource.setType(javax.sql.DataSource.class.getName());
          setResourceProperty(resource, "factory", "com.zaxxer.hikari.HikariJNDIFactory");
          setResourceProperty(resource, "poolName", dataSource.getJndiName());
          setResourceProperty(resource, "driverClassName", dataSource.getDriverClassName());
          setResourceProperty(resource, "jdbcUrl", dataSource.getUrl());
          setResourceProperty(resource, "username", dataSource.getUsername());
          setResourceProperty(resource, "password", dataSource.getPassword());
          setResourceProperty(resource, "dataSource.implicitCachingEnabled", "true");
          setResourceProperty(resource, "closeMethod", "close");
          setHikariPoolProperties(resource, key, keyPrefix);
          serverContext.getNamingResources().addResource(resource);
        }
      });
    } catch (NoSuchElementException e) {
      //Ignore
    }
  }

  private void setHikariPoolProperties(ContextResource resource, final String key, final String keyPrefix) {
    Arrays.stream(HIKARI_POOL_PROPERTIES).forEach(prop -> setResourceProperty(resource, prop,
        environment.getProperty(String.format("%1$scontainer.data-sources.%2$s.hikari.%3$s", keyPrefix, key, prop))));

    if (!environment.containsProperty(String.format("%1$scontainer.data-sources.%2$s.hikari.%3$s", keyPrefix, key,
        "leakDetectionThreshold"))) {
      setResourceProperty(resource, "leakDetectionThreshold", environment.getProperty("container.hikari.leakDetectionThreshold"));
    }
  }

  private void setResourceProperty(ContextResource resource, String key, String value) {
    if (StringUtils.isNotEmpty(value) && !value.equals("null")) {
      resource.setProperty(key, value);
    }
  }
}