package com.dsths.common.container.jersey;

import com.sun.jersey.api.core.PackagesResourceConfig;
import com.sun.jersey.core.reflection.ReflectionHelper;
import com.sun.jersey.core.spi.scanning.Scanner;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.context.ApplicationContextException;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.core.type.filter.AnnotationTypeFilter;

import javax.ws.rs.Path;
import javax.ws.rs.ext.Provider;
import java.security.AccessController;
import java.security.PrivilegedActionException;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class JerseyResourcesConfig extends PackagesResourceConfig {

  private static final Logger LOGGER = LogManager.getLogger(JerseyResourcesConfig.class);

  public JerseyResourcesConfig(String... packages) {
    super(packages);
  }

  // this constructor needs to be here,
  // do not delete it or else the com.sun.jersey.config.property.packages param can't be passed in.
  public JerseyResourcesConfig(Map<String, Object> props) {
    super(props);

    this.scanAndRegisterClasses(getPackages(props.get(PackagesResourceConfig.PROPERTY_PACKAGES)));
  }

  /**
   * Initialize and scan for root resource and provider classes
   * using a scanner.
   *
   * @param scanner the scanner.
   */
  @Override
  public void init(final Scanner scanner) {
    //do not implement..package property is not available yet
  }

  protected void scanAndRegisterClasses(String... packages) {
    ClassPathScanningCandidateComponentProvider cpScanner =
        new ClassPathScanningCandidateComponentProvider(false);

    cpScanner.addIncludeFilter(new AnnotationTypeFilter(Path.class));
    cpScanner.addIncludeFilter(new AnnotationTypeFilter(Provider.class));

    for (String resourcePkg : packages) {
      for (BeanDefinition bd : cpScanner.findCandidateComponents(resourcePkg)) {
        this.getClasses().add(getClassForName(bd.getBeanClassName()));
      }
    }

    if (LOGGER.isInfoEnabled()) {
      Set rootResourceClasses = this.getRootResourceClasses();
      if (rootResourceClasses.isEmpty()) {
        LOGGER.info("No root resource classes found.");
      } else {
        this.logClasses("Root resource classes found:", rootResourceClasses);
      }

      Set providerClasses = this.getProviderClasses();
      if (providerClasses.isEmpty()) {
        LOGGER.info("No provider classes found.");
      } else {
        this.logClasses("Provider classes found:", providerClasses);
      }
    }
  }

  //Copied from Jersey AnnotationScannerListener
  private Class getClassForName(String className) {
    try {
      ClassLoader classLoader = AccessController.doPrivileged(ReflectionHelper.getContextClassLoaderPA());
      return AccessController.doPrivileged(ReflectionHelper.classForNameWithExceptionPEA(className, classLoader));
    } catch (ClassNotFoundException | PrivilegedActionException ex) {
      throw new ApplicationContextException(String.format("A class file of the class name, %s is identified but the class could not be found", className), ex);
    }
  }

  //Copied from super class
  private static String[] getPackages(Object param) {
    if (param instanceof String) {
      return getElements(new String[]{(String) param}, PackagesResourceConfig.COMMON_DELIMITERS);
    } else if (param instanceof String[]) {
      return getElements((String[]) param, PackagesResourceConfig.COMMON_DELIMITERS);
    } else {
      throw new IllegalArgumentException(PackagesResourceConfig.PROPERTY_PACKAGES + " must have a property value of type String or String[]");
    }
  }

  //Copied from super class
  private void logClasses(String s, Set<Class> classes) {
    StringBuilder b = new StringBuilder();
    b.append(s);
    Iterator it = classes.iterator();

    while (it.hasNext()) {
      Class c = (Class) it.next();
      b.append('\n').append("  ").append(c);
    }

    LOGGER.info(b.toString());
  }
}
