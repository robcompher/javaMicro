package com.dsths.common.container.property.visitors;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Set;

/**
 * Created by DT214743 on 12/27/2018.
 */
public class AdditionalPropertyLocationsVisitor extends AbstractPropertyVisitor {

  private static final Logger logger = LogManager.getLogger(AdditionalPropertyLocationsVisitor.class);

  public static final int ORDER = 0;

  @Override
  public void visit(ConfigurableEnvironment environment) {
    String additionalLocations = environment.getProperty("container.additional.property.locations");
    logger.debug("additionalLocations :"+additionalLocations);
    try {
      if (!StringUtils.isEmpty(additionalLocations)) {
        Set<String> locations = getSearchLocations(additionalLocations, environment);
        for (String location : locations) {
          Resource[] resources = ResourcePatternUtils.getResourcePatternResolver(null).getResources(location);
          if (resources != null) {
            addResources(environment, resources);
          }
        }
      }
    } catch (IOException e) {
      logger.error(additionalLocations + " not found in classpath", e);
    }
  }

  @Override
  public int getOrder() {
    return ORDER;
  }
}
