package com.dsths.common.container.multitenant.batch;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParametersIncrementer;
import org.springframework.batch.core.JobParametersValidator;
import org.springframework.lang.Nullable;
import org.springframework.util.ClassUtils;

/**
 * Created by DT214743 on 2/22/2019.
 */
public class TenantJob implements Job {
  private final Job delegate;

  private final TenantRequestContext tenantRequestContext;


  /**
   * Create a new {@link Job} with the given group name and delegate.
   *
   * @param delegate a delegate for the features of a regular Job
   */
  public TenantJob(Job delegate, TenantRequestContext tenantRequestContext) {
    super();
    this.delegate = delegate;
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public void execute(JobExecution execution) {
    if (tenantRequestContext.isTenanted()) {
      String tenant = execution.getJobParameters().getString(Constants.TENANT_KEY);
      tenantRequestContext.setCurrentTenant(tenant);
    }
    try {
      delegate.execute(execution);
    } finally {
      tenantRequestContext.clear();
    }
  }

  /**
   * Concatenates the group name and the delegate job name (joining with a
   * ".").
   *
   * @see org.springframework.batch.core.Job#getName()
   */
  @Override
  public String getName() {
    return delegate.getName();
  }

  @Override
  public boolean isRestartable() {
    return delegate.isRestartable();
  }

  @Override
  @Nullable
  public JobParametersIncrementer getJobParametersIncrementer() {
    return delegate.getJobParametersIncrementer();
  }

  @Override
  public JobParametersValidator getJobParametersValidator() {
    return delegate.getJobParametersValidator();
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#equals(java.lang.Object)
   */
  @Override
  public boolean equals(Object obj) {
    if (obj instanceof TenantJob) {
      return ((TenantJob) obj).delegate.equals(delegate);
    }
    return false;
  }

  /*
   * (non-Javadoc)
   *
   * @see java.lang.Object#hashCode()
   */
  @Override
  public int hashCode() {
    return delegate.hashCode();
  }

  @Override
  public String toString() {
    return ClassUtils.getShortName(delegate.getClass()) + ": [name=" + getName() + "]";
  }
}
