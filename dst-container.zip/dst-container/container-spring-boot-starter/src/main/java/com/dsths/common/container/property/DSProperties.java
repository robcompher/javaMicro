package com.dsths.common.container.property;

import org.springframework.boot.autoconfigure.jdbc.DataSourceProperties;

/**
 * Created by DT214743 on 4/2/2019.
 */
public class DSProperties extends DataSourceProperties {

  /**
   * @deprecated (since="3.0.0", use springboot default property "username")
   */
  @Deprecated
  public void setUser(String user) {
    setUsername(user);
  }
}
