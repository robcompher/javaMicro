package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.postprocessors.TenantEntityManagerFactoryBeanPostProcessor;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Configuration to add custom Persistence Provider and EMF bean post processor in Tenanted environment
 *
 * Created by DT214743 on 7/12/2019.
 */
@Configuration
@ConditionalOnClass(name = {"org.eclipse.persistence.jpa.PersistenceProvider"})
public class TenantJpaConfiguration {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public TenantEntityManagerFactoryBeanPostProcessor tenantEntityManagerFactoryBeanPostProcessor(DefaultListableBeanFactory beanFactory,
                                                                                                 TenantRequestContext tenantRequestContext) {
    return new TenantEntityManagerFactoryBeanPostProcessor(beanFactory, tenantRequestContext);
  }
}
