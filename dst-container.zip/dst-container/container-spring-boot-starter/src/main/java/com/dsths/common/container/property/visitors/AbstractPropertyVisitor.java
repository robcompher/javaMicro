package com.dsths.common.container.property.visitors;

import com.dsths.common.container.multitenant.property.TenantMapPropertySource;
import com.dsths.common.container.property.CustomEnvironmentPostProcessor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.env.PropertiesPropertySourceLoader;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.util.ResourceUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.StreamSupport;

/**
 * Created by DT214743 on 12/27/2018.
 */
public abstract class AbstractPropertyVisitor implements PropertyVisitor {
  private static final Logger logger = LogManager.getLogger(AbstractPropertyVisitor.class);

  protected void addResources(ConfigurableEnvironment environment, Resource[] resources) throws IOException {

    for (Resource resource : resources) {
      logger.debug("addResources:  " +resource.getURI().toString());
      List<PropertySource<?>> properties = new PropertiesPropertySourceLoader().load(resource.getURI().toString(), resource);

      if (!properties.isEmpty()) {
        addLastPropertySource(environment, properties.get(0));
      }
    }
  }

  protected void addLastPropertySource(ConfigurableEnvironment environment, PropertySource<?> propertySource) {
    if (propertySource != null) {
      MutablePropertySources propertySources = environment.getPropertySources();
      propertySources.addLast(propertySource);
    }
  }

  protected Set<String> getSearchLocations(String value, ConfigurableEnvironment environment) {
    Set<String> locations = new LinkedHashSet<>();

    for (String path : asResolvedSet(value, null, environment)) {
      if (!path.contains("$")) {
        path = StringUtils.cleanPath(path);
        if (!ResourceUtils.isUrl(path)) {
          path = ResourceUtils.FILE_URL_PREFIX + path;
        }
      }
      locations.add(path);
    }
    return locations;
  }

  protected Set<String> asResolvedSet(String value, String fallback, ConfigurableEnvironment environment) {
    List<String> list = Arrays.asList(
        StringUtils.trimArrayElements(
            StringUtils.tokenizeToStringArray((value != null) ? environment.resolvePlaceholders(value) : fallback,
                ConfigurableApplicationContext.CONFIG_LOCATION_DELIMITERS)));
    Collections.reverse(list);
    return new LinkedHashSet<>(list);
  }

  protected TenantMapPropertySource getContainerEnvironmentPropertySource(ConfigurableEnvironment environment) {
    MutablePropertySources propertySources = environment.getPropertySources();
    Optional<PropertySource<?>> propertySource = StreamSupport.stream(propertySources.spliterator(), false)
        .filter(ps -> ps instanceof TenantMapPropertySource)
        .filter(ps -> ps.getName().equals(CustomEnvironmentPostProcessor.CONTAINER_ENVIRONMENT_SOURCE_NAME))
        .findFirst();

    if (!propertySource.isPresent()) {
      throw new IllegalStateException(CustomEnvironmentPostProcessor.CONTAINER_ENVIRONMENT_SOURCE_NAME
          + " not found in Environment.");
    }
    return (TenantMapPropertySource) propertySource.get();
  }

  @Override
  public int getOrder() {
    return 0;
  }

  @Override
  public boolean equals(Object o) {
    if (this == o) return true;
    if (o == null || getClass() != o.getClass()) return false;
    return false;
  }

  @Override
  public int hashCode() {
    return Objects.hash(17, getOrder(), getClass());
  }

  @Override
  public String toString() {
    return "PropertyVisitor{order=" + getOrder() + ", name='" + getClass().getName() + "'}";
  }
}
