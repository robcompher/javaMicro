package com.dsths.common.container.multitenant.batch;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.Scheduler;
import org.quartz.SchedulerContext;
import org.quartz.SchedulerException;
import org.quartz.spi.JobFactory;
import org.quartz.spi.TriggerFiredBundle;
import org.springframework.beans.factory.config.AutowireCapableBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.scheduling.quartz.SpringBeanJobFactory;

/**
 * Created by DT214743 on 2/25/2019.
 */
public class TenantAwareQuartzJobFactory extends SpringBeanJobFactory implements ApplicationContextAware {

  private AutowireCapableBeanFactory beanFactory;
  private String tenant;
  private JobFactory delegate;

  public void setJobFactory(JobFactory delegate) {
    this.delegate = delegate;
  }

  public void setTenant(String tenant) {
    this.tenant = tenant;
  }

  @Override
  public void setIgnoredUnknownProperties(String... ignoredUnknownProperties) {
    if (delegate instanceof SpringBeanJobFactory) {
      ((SpringBeanJobFactory) delegate).setIgnoredUnknownProperties(ignoredUnknownProperties);
    } else {
      super.setIgnoredUnknownProperties(ignoredUnknownProperties);
    }
  }

  @Override
  public void setSchedulerContext(SchedulerContext schedulerContext) {
    if (delegate instanceof SpringBeanJobFactory) {
      ((SpringBeanJobFactory) delegate).setSchedulerContext(schedulerContext);
    } else {
      super.setSchedulerContext(schedulerContext);
    }
  }

  @Override
  public void setApplicationContext(final ApplicationContext context) {
    beanFactory = context.getAutowireCapableBeanFactory();
  }

  @Override
  public Job newJob(TriggerFiredBundle bundle, Scheduler scheduler) throws SchedulerException {
    Job job;
    if (delegate != null) {
      job = delegate.newJob(bundle, scheduler);
    } else {
      job = super.newJob(bundle, scheduler);
    }

    TenantRequestContext tenantRequestContext = beanFactory.getBean(TenantRequestContext.class);
    return new TenantAwareQuartzJob(job, tenant, tenantRequestContext);
  }

  /**
   * Autowire job
   *
   * @param bundle
   * @return
   * @throws Exception
   */
  @Override
  protected Object createJobInstance(final TriggerFiredBundle bundle) throws Exception {
    final Object job = super.createJobInstance(bundle);
    beanFactory.autowireBean(job);
    return job;
  }

  static class TenantAwareQuartzJob implements Job {
    private final Job delegate;
    private final String tenant;
    private final TenantRequestContext tenantRequestContext;

    public TenantAwareQuartzJob(final Job delegate, final String tenant,
                                final TenantRequestContext tenantRequestContext) {
      this.delegate = delegate;
      this.tenant = tenant;
      this.tenantRequestContext = tenantRequestContext;
    }

    @Override
    public void execute(JobExecutionContext jobExecutionContext) throws JobExecutionException {
      tenantRequestContext.setCurrentTenant(tenant);
      try {
        delegate.execute(jobExecutionContext);
      } finally {
        tenantRequestContext.clear();
      }
    }
  }
}