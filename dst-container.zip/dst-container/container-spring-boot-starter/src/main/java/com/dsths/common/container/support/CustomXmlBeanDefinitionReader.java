package com.dsths.common.container.support;

import org.springframework.beans.factory.config.BeanDefinition;
import org.springframework.beans.factory.config.PlaceholderConfigurerSupport;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.xml.XmlBeanDefinitionReader;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.util.StringUtils;

import java.util.Arrays;

/**
 * The CustomXmlBeanDefinitionReader is to resolve multiple context files specified in contextConfig
 * <p/>
 * Created by DT214743 on 4/18/2018.
 */
public class CustomXmlBeanDefinitionReader extends XmlBeanDefinitionReader {

  public CustomXmlBeanDefinitionReader(BeanDefinitionRegistry registry) {
    super(registry);
  }

  @Override
  public int loadBeanDefinitions(String location) {
    String[] locations = StringUtils.tokenizeToStringArray(location, ConfigurableApplicationContext.CONFIG_LOCATION_DELIMITERS);
    int counter = 0;
    int total = locations.length;

    for (int index = 0; index < total; ++index) {
      counter += super.loadBeanDefinitions(locations[index]);
    }

    resolveBeanClassName();

    return counter;
  }

  /**
   * Resolve dynamic bean class name using property defined in properties
   * Example: <bean id="dynamicBean" class="${dynamic.beanClassName}"/>
   */
  private void resolveBeanClassName() {
    String[] beanNames = this.getRegistry().getBeanDefinitionNames();
    Arrays.stream(beanNames).forEach(beanName -> {
      BeanDefinition bd = this.getRegistry().getBeanDefinition(beanName);
      if (bd.getBeanClassName() != null &&
          bd.getBeanClassName().contains(PlaceholderConfigurerSupport.DEFAULT_PLACEHOLDER_PREFIX)) {
        String resolvedBeanClassName = this.getEnvironment().resolveRequiredPlaceholders(bd.getBeanClassName());
        bd.setBeanClassName(resolvedBeanClassName);
        //replace original definition
        this.getRegistry().removeBeanDefinition(beanName);
        this.getRegistry().registerBeanDefinition(beanName, bd);
      }
    });
  }
}
