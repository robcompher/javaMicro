package com.dsths.common.container.multitenant.concurrent;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.beans.factory.BeanFactory;

import java.util.concurrent.Executor;

/**
 * Created by DT214743 on 2/6/2019.
 */
public class TenantExecutor implements Executor {
  private final TenantRequestContext tenantRequestContext;
  private final Executor delegate;

  public TenantExecutor(BeanFactory beanFactory, Executor delegate) {
    this.delegate = delegate;

    this.tenantRequestContext = beanFactory.getBean(TenantRequestContext.class);
  }

  @Override
  public void execute(Runnable command) {
    this.delegate.execute(new TenantRunnable(tenantRequestContext, command));
  }
}
