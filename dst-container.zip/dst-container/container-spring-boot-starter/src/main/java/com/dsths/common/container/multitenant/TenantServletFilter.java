package com.dsths.common.container.multitenant;

import com.dsths.common.container.multitenant.resolver.TenantResolver;
import org.springframework.web.filter.GenericFilterBean;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import java.io.IOException;

/**
 * This filter is responsible for intercepting all requests, resolve Tenant based on defined Tenant Resolver
 * and set's Tenant in Tenant Request Context.
 * <p/>
 * This must be the first filter in filter chain for application.
 * <p/>
 * Created by DT214743 on 12/25/2018.
 */
public class TenantServletFilter extends GenericFilterBean {
  protected final TenantRequestContext tenantRequestContext;
  protected final TenantResolver tenantResolver;

  public TenantServletFilter(TenantRequestContext tenantRequestContext, TenantResolver tenantResolver) {
    this.tenantRequestContext = tenantRequestContext;
    this.tenantResolver = tenantResolver;
  }

  public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
      throws IOException, ServletException {
    HttpServletRequest httpServletRequest = (HttpServletRequest) request;
    String servletPath = httpServletRequest.getServletPath();
    if (!this.tenantRequestContext.isTenanted() || servletPath.contains("/container/css/")
        || servletPath.contains("/container/error/")
        || servletPath.contains("/container/fonts/")
        || servletPath.contains("/container/js/")
        || servletPath.contains("/container/images/")) {
      chain.doFilter(request, response);
    } else {
      try {
        TenantPathData tenantPathData = this.tenantResolver.resolve(httpServletRequest);
        this.tenantRequestContext.setCurrentTenant(tenantPathData.getCurrentTenant());
        chain.doFilter(new TenantServletRequest(httpServletRequest, tenantPathData), response);
      } finally {
        this.tenantRequestContext.clear(true);
      }
    }
  }

  protected static class TenantServletRequest extends HttpServletRequestWrapper {
    private final String servletPath;
    private final String tenantPath;

    public TenantServletRequest(HttpServletRequest request, TenantPathData tenantPathData) {
      super(request);

      this.servletPath = tenantPathData.getServletPath();
      this.tenantPath = tenantPathData.getTenantPath();
    }

    @Override
    public String getServletPath() {
      String actualServletPath = super.getServletPath();
      if (!"".equals(tenantPath) && actualServletPath.startsWith(tenantPath)) {
        actualServletPath = servletPath;
      }
      return actualServletPath;
    }

    @Override
    public String getContextPath() {
      return super.getContextPath() + tenantPath;
    }
  }
}
