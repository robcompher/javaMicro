package com.dsths.common.container.multitenant.resolver;

import com.dsths.common.container.multitenant.TenantPathData;
import com.dsths.common.container.multitenant.exception.TenantResolveException;

import javax.servlet.http.HttpServletRequest;

/**
 * The Tenant Resolver will detect which tenant will deal the current request.
 * Most multi-tenant applications would define tenant based on the Domain, URL Path, or Header attribute
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
public interface TenantResolver {
  /**
   * Get Tenant Information from request
   *
   * @param request
   * @return
   * @throws TenantResolveException
   */
  TenantPathData resolve(HttpServletRequest request);
}
