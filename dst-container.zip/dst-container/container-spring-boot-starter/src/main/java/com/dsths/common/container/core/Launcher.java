package com.dsths.common.container.core;

import com.dsths.common.container.DeployableLauncher;
import org.springframework.boot.builder.SpringApplicationBuilder;

/**
 * Created by DT214743 on 1/10/2019.
 * <p/>
 * Use DeployableLauncher instead of Launcher
 *
 * @deprecated use DeployableLauncher
 */
@Deprecated
public class Launcher extends DeployableLauncher {
  public static void main(String[] args) {
    build(new SpringApplicationBuilder()).run(args);
  }
}
