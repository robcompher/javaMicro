package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.multitenant.cache.TenantCacheKeyGenerator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.cache.interceptor.KeyGenerator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;

/**
 * Created by DT214743 on 12/31/2018.
 */
@Configuration
@ConditionalOnClass(name = {"org.springframework.cache.interceptor.KeyGenerator"})
@Order(Ordered.LOWEST_PRECEDENCE)
public class CacheKeyConfiguration {

  @Bean
  @ConditionalOnMissingBean
  public KeyGenerator keyGenerator() {
    return new TenantCacheKeyGenerator();
  }
}
