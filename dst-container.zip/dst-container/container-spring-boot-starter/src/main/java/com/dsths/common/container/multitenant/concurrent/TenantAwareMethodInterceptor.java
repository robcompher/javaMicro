package com.dsths.common.container.multitenant.concurrent;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;

/**
 * Created by DT214743 on 2/7/2019.
 */
public class TenantAwareMethodInterceptor implements MethodInterceptor {
  private final Object delegate;
  private final String tenant;
  private final TenantRequestContext tenantRequestContext;

  public TenantAwareMethodInterceptor(final Object delegate, final String tenant,
                                      final TenantRequestContext tenantRequestContext) {
    this.delegate = delegate;
    this.tenant = tenant;
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public Object invoke(final MethodInvocation invocation) throws Throwable {
    Method proxyMethod = getMethod(invocation, delegate);
    if(proxyMethod == null || (delegate instanceof FactoryBean && invocation.getMethod().getName().equals("getObjectType"))) {
      return invocation.proceed();
    }
    proxyMethod.setAccessible(true);
    try {
      tenantRequestContext.setCurrentTenant(tenant);
      return proxyMethod.invoke(delegate, invocation.getArguments());
    } finally {
      tenantRequestContext.clear();
    }
  }

  private Method getMethod(MethodInvocation invocation, Object object) {
    Method method = invocation.getMethod();
    return ReflectionUtils.findMethod(object.getClass(), method.getName(), method.getParameterTypes());
  }
}
