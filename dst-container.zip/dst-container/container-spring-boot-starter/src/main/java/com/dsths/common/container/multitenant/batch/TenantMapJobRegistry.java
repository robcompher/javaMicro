package com.dsths.common.container.multitenant.batch;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.configuration.DuplicateJobException;
import org.springframework.batch.core.configuration.JobFactory;
import org.springframework.batch.core.configuration.support.MapJobRegistry;
import org.springframework.batch.core.launch.NoSuchJobException;

import java.util.Set;

/**
 * Created by DT214743 on 2/22/2019.
 */
public class TenantMapJobRegistry extends MapJobRegistry {

  private final TenantRequestContext tenantRequestContext;
  private final MapJobRegistry delegate;

  public TenantMapJobRegistry(MapJobRegistry delegate, TenantRequestContext tenantRequestContext) {
    this.delegate = delegate;
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public Job getJob(String name) throws NoSuchJobException {
    return new TenantJob(delegate.getJob(name), tenantRequestContext);
  }

  @Override
  public void register(JobFactory jobFactory) throws DuplicateJobException {
    delegate.register(jobFactory);
  }

  @Override
  public void unregister(String name) {
    delegate.unregister(name);
  }

  @Override
  public Set<String> getJobNames() {
    return delegate.getJobNames();
  }
}
