package com.dsths.common.container.property;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.HashMap;
import java.util.Map;

/**
 * @author Kamal Ramakrishnan (dt78836)
 */
@ConfigurationProperties("container")
public class ContainerProperties {

  private Map<String, DSProperties> dataSources = new HashMap<>();

  public Map<String, DSProperties> getDataSources() {
    return dataSources;
  }

  public void setDataSources(Map<String, DSProperties> dataSources) {
    this.dataSources = dataSources;
  }
}
