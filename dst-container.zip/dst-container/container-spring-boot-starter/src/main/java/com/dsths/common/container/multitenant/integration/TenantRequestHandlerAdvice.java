package com.dsths.common.container.multitenant.integration;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.handler.advice.AbstractRequestHandlerAdvice;
import org.springframework.messaging.Message;

/**
 * Created by DT214743 on 2/13/2019.
 */
public class TenantRequestHandlerAdvice extends AbstractRequestHandlerAdvice {

  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Override
  protected Object doInvoke(ExecutionCallback executionCallback, Object o, Message<?> message) {
    String tenant = (String) message.getHeaders().get(Constants.TENANT_KEY);
    if (tenantRequestContext.isTenanted() && tenant != null) {
      try {
        tenantRequestContext.setCurrentTenant(tenant);
        return executionCallback.execute();
      } finally {
        tenantRequestContext.clear();
      }
    } else {
      return executionCallback.execute();
    }
  }
}
