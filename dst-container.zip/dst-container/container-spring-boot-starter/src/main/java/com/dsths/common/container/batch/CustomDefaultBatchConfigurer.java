package com.dsths.common.container.batch;

import javax.sql.DataSource;

/**
 * Created by DT214743 on 11/5/2019.
 */
public class CustomDefaultBatchConfigurer extends org.springframework.batch.core.configuration.annotation.DefaultBatchConfigurer {

  public CustomDefaultBatchConfigurer() {
    super();
  }

  public CustomDefaultBatchConfigurer(DataSource dataSource) {
    super(dataSource);
  }

  /**
   * Override to avoid @Autowire annotation from super class
   *
   * @param dataSource
   */
  @Override
  public void setDataSource(DataSource dataSource) {
    super.setDataSource(dataSource);
  }
}
