package com.dsths.common.container.property.visitors;

import com.dsths.common.container.multitenant.property.TenantMapPropertySource;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.MapPropertySource;
import org.springframework.core.env.MutablePropertySources;
import org.springframework.core.env.PropertySource;

import java.util.Iterator;

/**
 * Created by DT214743 on 12/27/2018.
 */
public class EmberIndexPageVisitor extends AbstractPropertyVisitor {
  public static final int ORDER = ContainerPropertiesVisitor.ORDER + 1;

  public void visit(ConfigurableEnvironment environment) {
    MutablePropertySources propertySources = environment.getPropertySources();
    if (environment.containsProperty("container.is.ember.application") && environment.getProperty("container.is.ember.application").equalsIgnoreCase("true")) {
      final TenantMapPropertySource containerEnvSource = getContainerEnvironmentPropertySource(environment);
      Iterator<PropertySource<?>> iterator = propertySources.iterator();
      while (iterator.hasNext()) {
        PropertySource<?> propertySource = iterator.next();
        if (propertySource instanceof MapPropertySource
            && propertySource.containsProperty("container.ember.index.page")
            && !environment.containsProperty("container.ember.index.page.path")) {
          String indexPage = environment.getProperty("container.ember.index.page");
          containerEnvSource.getSource().put("container.ember.index.page.path", indexPage.substring(0, indexPage.lastIndexOf('/')));
        }
      }
    }
  }

  @Override
  public int getOrder() {
    return ORDER;
  }
}
