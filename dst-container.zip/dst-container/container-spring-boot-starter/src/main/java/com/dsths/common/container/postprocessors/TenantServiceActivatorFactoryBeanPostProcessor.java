package com.dsths.common.container.postprocessors;

import com.dsths.common.container.Constants;
import org.springframework.beans.BeansException;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.ManagedList;
import org.springframework.integration.config.ServiceActivatorFactoryBean;

import java.util.Optional;

/**
 * Created by DT214743 on 3/29/2019.
 */
public class TenantServiceActivatorFactoryBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter {

  @Override
  public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName) throws BeansException {
    if(bean instanceof ServiceActivatorFactoryBean) {
      PropertyValue pv = pvs.getPropertyValue(Constants.ADVICE_CHAIN);
      ManagedList advices = new ManagedList();
      if(pv != null && pv.getValue() != null) {
        advices.addAll((ManagedList) pv.getValue());
      }
      Optional<Object> adviceExists = advices.stream().filter(v -> v instanceof RuntimeBeanReference
          && ((RuntimeBeanReference) v).getBeanName().equals("tenantRequestHandlerAdvice")).findFirst();
      if (!adviceExists.isPresent()) {
        advices.add(new RuntimeBeanReference("tenantRequestHandlerAdvice"));
        ((MutablePropertyValues) pvs).add(Constants.ADVICE_CHAIN, advices);
      }
    }
    return pvs;
  }
}
