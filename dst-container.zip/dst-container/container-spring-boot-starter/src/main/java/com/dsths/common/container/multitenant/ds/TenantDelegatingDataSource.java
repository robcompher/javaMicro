package com.dsths.common.container.multitenant.ds;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantApplicationContext;
import com.dsths.common.container.multitenant.TenantRequestContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.jdbc.datasource.DelegatingDataSource;
import org.springframework.lang.Nullable;

import javax.sql.DataSource;


/**
 * This class dynamically resolves the DataSource based on Tenant in request context for the given dataSourceName.
 * <p/>
 * If there is no tenant in request context it simply returns the DataSource defined in
 * application.properties with given dataSourceName.
 * <p/>
 * Created by DT214743 on 12/31/2018.
 */
public class TenantDelegatingDataSource extends DelegatingDataSource implements ApplicationListener<ApplicationStartedEvent> {
  private static final Logger logger = LogManager.getLogger(TenantDelegatingDataSource.class);
  @Autowired
  private TenantApplicationContext tenantApplicationContext;

  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Autowired
  private ApplicationContext applicationContext;

  private String defaultDataSourceKey;
  private String dataSourceName;

  private boolean started = false;

  /**
   * Return the target DataSource that this DataSource should delegate to.
   */
  @Nullable
  @Override
  public DataSource getTargetDataSource() {
    if (tenantRequestContext.isTenanted() && tenantRequestContext.getCurrentTenant() != null) {
      String tenantDataSource = Constants.getKeyPrefix(tenantRequestContext.getCurrentTenant())
          + dataSourceName;
      logger.trace("looking up datasource with tenant name {}", tenantDataSource);
      return (DataSource) applicationContext.getBean(tenantDataSource);
    }

    try {
      logger.trace("looking up datasource with default name {}", defaultDataSourceKey);
      return (DataSource) applicationContext.getBean(defaultDataSourceKey);
    } catch (NoSuchBeanDefinitionException e) {
      //not started & use primary tenant so that the entity manager factory and other components in the application
      //can pick up the correct settings for the query generator JPA uses.
      if (!started && tenantApplicationContext.getPrimaryTenant() != null) {
        String tenantDataSource = Constants.getKeyPrefix(tenantApplicationContext.getPrimaryTenant())
            + dataSourceName;
        logger.trace("looking up datasource with primary tenant name {}", tenantDataSource);
        return (DataSource) applicationContext.getBean(tenantDataSource);
      }
      throw e;
    }
  }

  @Override
  public void afterPropertiesSet() {
    if (dataSourceName == null) {
      throw new IllegalArgumentException("Property 'dataSourceName' is required");
    }
    defaultDataSourceKey = Constants.DEFAULT_KEY_PREFIX + dataSourceName;
  }

  public void setDataSourceName(String dataSourceName) {
    this.dataSourceName = dataSourceName;
  }

  @Override
  public void onApplicationEvent(ApplicationStartedEvent applicationStartedEvent) {
    started = true;
  }
}
