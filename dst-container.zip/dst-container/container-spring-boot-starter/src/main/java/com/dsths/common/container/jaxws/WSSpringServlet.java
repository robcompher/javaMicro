package com.dsths.common.container.jaxws;

import com.sun.xml.ws.transport.http.servlet.ServletAdapterList;
import com.sun.xml.ws.transport.http.servlet.SpringBinding;
import com.sun.xml.ws.transport.http.servlet.SpringBindingList;
import com.sun.xml.ws.transport.http.servlet.WSServletDelegate;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

/**
 * Server stop is hanging as WSSpringServlet is trying to close Spring Context in SpringBoot environment.
 * So changed the logic to close context only if this servlet is loaded outside Spring Boot Embedded container.
 * <p/>
 * All code is copied from below location but changed to work for SpringBoot Environment
 * <p/>
 * https://github.com/javaee/metro-jaxws-commons/blob/master/spring/spring-core/src/main/java/com/sun/xml/ws/transport/http/servlet/WSSpringServlet.java
 * <p/>
 * Created by DT214743 on 12/7/2018.
 */
public class WSSpringServlet extends HttpServlet implements ApplicationContextAware {
  private static final Logger logger = LogManager.getLogger(WSSpringServlet.class);
  private static final long serialVersionUID = -2786178909818639147L;

  private WSServletDelegate delegate;
  private WebApplicationContext wac;

  private static boolean wacInjected = false;

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) {
    if (wac == null && applicationContext instanceof WebApplicationContext) {
      wac = (WebApplicationContext) applicationContext;
      WSSpringServlet.wacInjected = true;
    }
  }

  protected WebApplicationContext getWebApplicationContext() {
    if (wac != null) {
      return wac;
    } else {
      return WebApplicationContextUtils.getRequiredWebApplicationContext(getServletContext());
    }
  }

  @Override
  public void init(ServletConfig servletConfig) throws ServletException {
    super.init(servletConfig);

    // get the configured adapters from Spring
    wac = getWebApplicationContext();

    Set<SpringBinding> bindings = new LinkedHashSet<>();

    // backward compatibility. recognize all bindings
    Map<String, SpringBindingList> m = wac.getBeansOfType(SpringBindingList.class);
    for (SpringBindingList sbl : m.values())
      bindings.addAll(sbl.getBindings());

    bindings.addAll(wac.getBeansOfType(SpringBinding.class).values());

    // create adapters
    ServletAdapterList l = new ServletAdapterList(getServletContext());
    for (SpringBinding binding : bindings)
      binding.create(l);

    delegate = new WSServletDelegate(l, getServletContext());
  }

  /**
   * destroys the servlet and releases all associated resources,
   * such as the Spring application context and the JAX-WS delegate.
   */
  @Override
  public void destroy() {
    if (wac instanceof ConfigurableApplicationContext && !WSSpringServlet.wacInjected) {
      ((ConfigurableApplicationContext) wac).close();
    }
    delegate.destroy();
    delegate = null;
  }

  @Override
  protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException {
    try {
      delegate.doPost(request, response, getServletContext());
    } catch (Exception e) {
      //Not needed but added try..catch for sonar issue
      logger.error("doPost: ", e);
      response.setStatus(500);
    }
  }

  @Override
  protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException {
    try {
      delegate.doGet(request, response, getServletContext());
    } catch (Exception e) {
      //Not needed but added try..catch for sonar issue
      logger.error("doGet: ", e);
      response.setStatus(500);
    }
  }

  @Override
  protected void doPut(HttpServletRequest request, HttpServletResponse response) throws ServletException {
    try {
      delegate.doPut(request, response, getServletContext());
    } catch (Exception e) {
      //Not needed but added try..catch for sonar issue
      logger.error("doPut: ", e);
      response.setStatus(500);
    }
  }

  @Override
  protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException {
    try {
      delegate.doDelete(request, response, getServletContext());
    } catch (Exception e) {
      //Not needed but added try..catch for sonar issue
      logger.error("doDelete: ", e);
      response.setStatus(500);
    }
  }
}
