package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.support.CustomXmlBeanDefinitionReader;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * This configuration is used to load spring context from XML config files.
 * Loads only if container.contextConfigLocation is set.
 * <p/>
 * Created by DT214743 on 4/1/2018.
 */
@Configuration
@ConditionalOnProperty(prefix = "container", name = {"contextConfigLocation"})
@ImportResource(locations = "${container.contextConfigLocation}", reader = CustomXmlBeanDefinitionReader.class)
@AutoConfigureAfter(EmbeddedTomcatConfiguration.class)
public class ImportResourceConfiguration {
}
