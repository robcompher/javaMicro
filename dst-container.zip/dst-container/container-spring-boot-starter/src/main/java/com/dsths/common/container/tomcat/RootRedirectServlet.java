package com.dsths.common.container.tomcat;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Simple servlet to redirect url to context path.
 * <p/>
 * Created by DT214743 on 1/18/2019.
 */
public class RootRedirectServlet extends HttpServlet {

  private final String contextPath;

  public RootRedirectServlet(String contextPath) {
    this.contextPath = contextPath;
  }

  @Override
  protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    try {
      resp.sendRedirect(contextPath);
    } catch (Exception e) {
      req.getServletContext().log("Redirect failed.", e);
      resp.setStatus(HttpServletResponse.SC_NOT_FOUND);
    }
  }
}
