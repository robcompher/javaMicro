package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.concurrent.TenantExecutor;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.NoSuchBeanDefinitionException;
import org.springframework.beans.factory.NoUniqueBeanDefinitionException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.AsyncAnnotationBeanPostProcessor;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;
import java.util.concurrent.ThreadPoolExecutor;

/**
 * Created by DT214743 on 3/6/2019.
 */
@Configuration
@ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
@ConditionalOnMissingBean(AsyncConfigurer.class)
@AutoConfigureAfter(TenantConfiguration.class)
public class TenantDefaultAsyncConfiguration extends AsyncConfigurerSupport {

  @Autowired
  private BeanFactory beanFactory;

  @Override
  public Executor getAsyncExecutor() {
    ThreadPoolTaskExecutor executor = null;
    try {
      executor = beanFactory.getBean(ThreadPoolTaskExecutor.class);
    } catch (NoUniqueBeanDefinitionException e) {
      executor = beanFactory.getBean(AsyncAnnotationBeanPostProcessor.DEFAULT_TASK_EXECUTOR_BEAN_NAME,
          ThreadPoolTaskExecutor.class);
    } catch (NoSuchBeanDefinitionException ex) {
      //ignore
    }
    //create default task executor
    if (executor == null) {
      executor = getDefaultTaskExecutor();
    }
    return new TenantExecutor(this.beanFactory, executor);
  }

  private ThreadPoolTaskExecutor getDefaultTaskExecutor() {
    ThreadPoolTaskExecutor executor = new ThreadPoolTaskExecutor();
    executor.setCorePoolSize(5);
    executor.setMaxPoolSize(10);
    executor.setQueueCapacity(500);
    executor.setThreadNamePrefix("default-async-exec-");
    executor.setRejectedExecutionHandler(new ThreadPoolExecutor.CallerRunsPolicy());
    executor.initialize();
    return executor;
  }
}
