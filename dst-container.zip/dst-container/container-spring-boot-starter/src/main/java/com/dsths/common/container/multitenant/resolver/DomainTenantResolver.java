package com.dsths.common.container.multitenant.resolver;

import com.dsths.common.container.multitenant.TenantPathData;
import com.dsths.common.container.multitenant.exception.TenantResolveException;

import javax.servlet.http.HttpServletRequest;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Tries to resolve Tenant from Domain in request.
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
public class DomainTenantResolver implements TenantResolver {

  protected final Pattern pattern;

  public DomainTenantResolver() {
    this.pattern = Pattern.compile("^(?<tenant>.*?)\\..*");
  }

  @Override
  public TenantPathData resolve(HttpServletRequest request) {
    Matcher matcher = pattern.matcher(request.getServerName());

    if (!matcher.matches()) {
      throw new TenantResolveException(String.format("Unable to resolve the tenant from Domain/Host: \"%s\"",
          request.getServerName()));
    }

    return new TenantPathData(matcher.group("tenant"), "", request.getServletPath());
  }
}
