package com.dsths.common.container.multitenant;

/**
 * Created by DT214743 on 12/25/2018.
 */
public class TenantPathData {
  private String currentTenant;
  private String tenantPath;
  private String servletPath;

  public TenantPathData(String currentTenant, String tenantPath, String servletPath) {
    this.currentTenant = currentTenant;
    this.tenantPath = tenantPath;
    this.servletPath = servletPath;
  }

  public String getCurrentTenant() {
    return currentTenant;
  }

  public String getTenantPath() {
    return tenantPath;
  }

  public String getServletPath() {
    return servletPath;
  }
}
