package com.dsths.common.container.support;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.util.ClassUtils;

import java.io.File;
import java.net.URL;
import java.net.URLClassLoader;
import java.util.Arrays;

/**
 * Created by DT214743 on 4/15/2018.
 */
public class ClassLoaderHelper {
  private static final Logger logger = LogManager.getLogger(ClassLoaderHelper.class);

  private ClassLoaderHelper() {
  }

  public static void addPathToClasspath(String directory) {
    try {
      File file = new File(directory);
      if (file.exists()) {
        ClassLoader classLoader = ClassUtils.getDefaultClassLoader();

        // Create class loader using given conf directory
        // Use current classLoader as parent to maintain current visibility
        ClassLoader urlCl = URLClassLoader.newInstance(new URL[]{file.toURI().toURL()}, classLoader);

        ClassUtils.overrideThreadContextClassLoader(urlCl);
      } else {
        logger.info("Configuration directory [" + directory + "] not found.");
      }
    } catch (Exception e) {
      logger.error("Failed to add configuration directory [" + directory + "] to classpath", e);
    }
  }

  /**
   * Reset classloader to actual classloader to prevent issues on reload/junit tests
   *
   * @param directory
   */
  public static void resetClassLoader(String directory) {
    try {
      File file = new File(directory);
      if (file.exists()) {
        URL fileURL = file.toURI().toURL();
        ClassLoader classLoader = ClassUtils.getDefaultClassLoader();
        if (classLoader instanceof URLClassLoader) {
          long count = Arrays.stream(((URLClassLoader) classLoader).getURLs()).filter(fileURL::equals).count();
          if (count > 0) {
            ClassUtils.overrideThreadContextClassLoader(classLoader.getParent());
          }
        }
      }
    } catch (Exception e) {
      logger.error("Failed to add configuration directory [" + directory + "] to classpath", e);
    }
  }
}
