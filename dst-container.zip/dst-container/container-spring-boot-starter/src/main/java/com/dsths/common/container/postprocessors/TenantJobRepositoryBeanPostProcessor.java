package com.dsths.common.container.postprocessors;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.Advised;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.repository.support.AbstractJobRepositoryFactoryBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * Created by DT214743 on 2/22/2019.
 */
public class TenantJobRepositoryBeanPostProcessor implements BeanPostProcessor {

  private final TenantRequestContext tenantRequestContext;

  public TenantJobRepositoryBeanPostProcessor(TenantRequestContext tenantRequestContext) {
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
    if (bean instanceof AbstractJobRepositoryFactoryBean) {
      try {
        ((Advised) ((AbstractJobRepositoryFactoryBean) bean).getObject())
            .addAdvice(new TenantJobParamInterceptor(tenantRequestContext));
      } catch (Exception e) {
        throw new BeanCreationException(e.getMessage(), e);
      }
    }
    return bean;
  }

  private class TenantJobParamInterceptor implements MethodInterceptor {
    private final TenantRequestContext tenantRequestContext;

    public TenantJobParamInterceptor(TenantRequestContext tenantRequestContext) {
      this.tenantRequestContext = tenantRequestContext;
    }

    @Override
    public Object invoke(MethodInvocation invocation) throws Throwable {
      if (invocation.getMethod().getName().equals("createJobExecution")) {
        Object[] args = invocation.getArguments();
        JobParameters jobParameters = (JobParameters) args[1];
        JobParameters effectiveParameters = new JobParametersBuilder(jobParameters)
            .addString(Constants.TENANT_KEY, tenantRequestContext.getCurrentTenant(), false).toJobParameters();
        args[1] = effectiveParameters;
      }
      return invocation.proceed();
    }
  }

  @Override
  public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
    return bean;
  }
}
