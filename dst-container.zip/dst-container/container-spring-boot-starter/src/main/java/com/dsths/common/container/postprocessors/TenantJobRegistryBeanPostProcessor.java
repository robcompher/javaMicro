package com.dsths.common.container.postprocessors;

import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.batch.TenantMapJobRegistry;
import org.springframework.batch.core.configuration.support.MapJobRegistry;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * Created by DT214743 on 2/22/2019.
 */
public class TenantJobRegistryBeanPostProcessor implements BeanPostProcessor {

  private final TenantRequestContext tenantRequestContext;

  public TenantJobRegistryBeanPostProcessor(TenantRequestContext tenantRequestContext) {
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
    if (bean instanceof MapJobRegistry) {
      return new TenantMapJobRegistry((MapJobRegistry) bean, tenantRequestContext);
    }
    return bean;
  }

  @Override
  public Object postProcessBeforeInitialization(Object bean, String beanName) throws BeansException {
    return bean;
  }
}
