package com.dsths.common.container.postprocessors;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantApplicationContext;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValue;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.BeanDefinitionHolder;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.core.Ordered;
import org.springframework.scheduling.quartz.SchedulerFactoryBean;

import java.util.Optional;

/**
 * Created by DT214743 on 2/26/2019.
 */
public class TenantSchedulerFactoryBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter implements Ordered {
  private final TenantApplicationContext tenantApplicationContext;
  private final DefaultListableBeanFactory beanFactory;

  public TenantSchedulerFactoryBeanPostProcessor(TenantApplicationContext tenantApplicationContext,
                                                 DefaultListableBeanFactory beanFactory) {
    this.beanFactory = beanFactory;
    this.tenantApplicationContext = tenantApplicationContext;
  }

  @Override
  public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName) {
    if(bean instanceof SchedulerFactoryBean && tenantApplicationContext.isTenanted()) {
      String tenant = extractTenant(beanName);
      if (tenant != null) {
        processDataSourceProperty(pvs, tenant);

        processJobFactoryProperty(pvs, tenant);
      }
    }
    return pvs;
  }

  private void processJobFactoryProperty(PropertyValues pvs, String tenant) {
    PropertyValue pvJobFactory = pvs.getPropertyValue(Constants.JOB_FACTORY);
    if (pvJobFactory != null && pvJobFactory.getValue() != null) {
      BeanDefinitionHolder jobFactoryHolder = (BeanDefinitionHolder) pvJobFactory.getValue();
      BeanDefinitionBuilder bd = BeanDefinitionBuilder.genericBeanDefinition(
          "com.dsths.common.container.multitenant.batch.TenantAwareQuartzJobFactory");
      bd.addPropertyValue("tenant", tenant);
      if (jobFactoryHolder != null) {
        bd.addPropertyValue(Constants.JOB_FACTORY, jobFactoryHolder);
      }
      BeanDefinitionHolder delegateJobFactoryHolder = new BeanDefinitionHolder(bd.getBeanDefinition(),
          generateBeanName(tenant, "jobFactory#" + Math.random()));

      ((MutablePropertyValues) pvs).add(Constants.JOB_FACTORY, delegateJobFactoryHolder);
    }
  }

  private void processDataSourceProperty(PropertyValues pvs, String tenant) {
    PropertyValue pvDataSource = pvs.getPropertyValue(Constants.DATASOURCE);

    if (pvDataSource != null && pvDataSource.getValue() != null) {
      RuntimeBeanReference beanReference = (RuntimeBeanReference) pvDataSource.getValue();
      String tenantDatasourceName = Constants.getKeyPrefix(tenant) + beanReference.getBeanName();
      if (this.beanFactory.containsBeanDefinition(tenantDatasourceName) || this.beanFactory.containsBean(tenantDatasourceName)) {
        ((MutablePropertyValues) pvs).add(Constants.DATASOURCE, new RuntimeBeanReference(tenantDatasourceName));
      }
    }
  }

  private String generateBeanName(String key, String beanName) {
    return Constants.getKeyPrefix(key) + beanName;
  }

  private String extractTenant(final String beanName) {
    if (tenantApplicationContext.isTenanted()) {
      Optional<String> tenant = tenantApplicationContext.getAllTenants().stream().filter(beanName::startsWith).findFirst();
      if (tenant.isPresent())
        return tenant.get();
    }
    return null;
  }

  @Override
  public int getOrder() {
    return Ordered.HIGHEST_PRECEDENCE + 1;
  }
}
