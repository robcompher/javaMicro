package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.listeners.HikariServletListener;
import com.dsths.common.container.tomcat.CustomTomcatWebServerFactory;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.web.servlet.ServletWebServerFactoryAutoConfiguration;
import org.springframework.boot.web.servlet.server.ServletWebServerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.config.annotation.web.http.EnableSpringHttpSession;

import javax.servlet.ServletContextListener;

/**
 * Embedded Tomcat configuration
 *
 * @author Kamal Ramakrishnan (dt78836)
 *         Modified by Arun Kommineni (DT214743) on 3/23/2018.
 */
@ConditionalOnClass(
    name = {"org.springframework.boot.web.embedded.tomcat.TomcatWebServer", "org.apache.catalina.startup.Tomcat"}
)
@Configuration
@EnableSpringHttpSession
@ConditionalOnWebApplication(
    type = ConditionalOnWebApplication.Type.SERVLET
)
@AutoConfigureBefore(ServletWebServerFactoryAutoConfiguration.class)
public class EmbeddedTomcatConfiguration {

  @Bean
  public ServletWebServerFactory tomcatServletWebServerFactory() {
    return new CustomTomcatWebServerFactory();
  }

  @Bean
  public ServletContextListener dbListener() {
    return new HikariServletListener();
  }
}