package com.dsths.common.container.property.visitors;

import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;

/**
 * Created by DT214743 on 12/27/2018.
 */
public interface PropertyVisitor extends Ordered {
  void visit(ConfigurableEnvironment environment);
}
