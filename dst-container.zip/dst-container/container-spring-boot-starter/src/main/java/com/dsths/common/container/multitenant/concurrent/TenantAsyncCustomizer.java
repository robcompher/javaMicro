package com.dsths.common.container.multitenant.concurrent;

import org.springframework.aop.interceptor.AsyncUncaughtExceptionHandler;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.scheduling.annotation.AsyncConfigurer;
import org.springframework.scheduling.annotation.AsyncConfigurerSupport;

import java.util.concurrent.Executor;

/**
 * Created by DT214743 on 3/6/2019.
 */
public class TenantAsyncCustomizer extends AsyncConfigurerSupport {

  private final BeanFactory beanFactory;
  private final AsyncConfigurer delegate;

  public TenantAsyncCustomizer(BeanFactory beanFactory, AsyncConfigurer delegate) {
    this.beanFactory = beanFactory;
    this.delegate = delegate;
  }

  @Override
  public Executor getAsyncExecutor() {
    return new TenantExecutor(this.beanFactory, this.delegate.getAsyncExecutor());
  }

  @Override
  public AsyncUncaughtExceptionHandler getAsyncUncaughtExceptionHandler() {
    return this.delegate.getAsyncUncaughtExceptionHandler();
  }

}
