package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.jaxws.WSSpringServlet;
import com.dsths.common.container.multitenant.TenantApplicationContextImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import javax.servlet.Servlet;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.springframework.util.StringUtils.tokenizeToStringArray;

/**
 * This configuration registers WSSpringServlet to serve SOAP requests and initializes only if "container.soap.enabled" property is set.
 * <p/>
 * container.soap.application-path, Path that serves as the base URI for the application.
 * Default value is set as "/secured/soap/*"
 * <p/>
 * Created by DT214743 on 3/7/2018.
 */
@Configuration
@ConditionalOnClass(
    name = {"com.sun.xml.ws.transport.http.servlet.WSSpringServlet", "javax.servlet.ServletRegistration"}
)
@ConditionalOnProperty(value = Constants.CONTAINER_SOAP_ENABLED)
public class SoapConfiguration {
  private static final String FORWARD_SLASH = "/";

  @Autowired
  private TenantApplicationContextImpl tenantAppContext;

  @Bean
  public Servlet wsSpringServlet() {
    return new WSSpringServlet();
  }

  @Bean
  public ServletRegistrationBean soapBean(final Environment environment) {
    ServletRegistrationBean bean = new ServletRegistrationBean(wsSpringServlet());
    bean.setUrlMappings(getUrlPaths(environment.getProperty(Constants.CONTAINER_SOAP_APPLICATION_PATH)));
    bean.setLoadOnStartup(3);
    return bean;
  }

  private List<String> getUrlPaths(String propPath) {
    List<String> urlPaths = new ArrayList<>();
    String[] paths = tokenizeToStringArray(propPath, ConfigurableApplicationContext.CONFIG_LOCATION_DELIMITERS);
    Arrays.stream(paths).map(this::cleanPathPattern).forEach(path -> {
      if (tenantAppContext.isTenanted()) {
        tenantAppContext.getAllTenants().forEach(tenant -> urlPaths.add('/' + tenant + cleanPathPattern(path)));
      } else {
        urlPaths.add(cleanPathPattern(path));
      }
    });
    return urlPaths;
  }

  private String cleanPathPattern(String applicationPath) {
    if (!applicationPath.startsWith(FORWARD_SLASH)) {
      applicationPath = FORWARD_SLASH + applicationPath;
    }

    if (applicationPath.endsWith(FORWARD_SLASH)) {
      applicationPath = applicationPath + "*";
    }

    if (!applicationPath.endsWith("/*")) {
      applicationPath = applicationPath + "/*";
    }
    return applicationPath;
  }
}
