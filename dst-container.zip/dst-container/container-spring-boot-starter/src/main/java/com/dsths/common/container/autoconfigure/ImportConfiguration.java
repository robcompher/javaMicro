package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.support.AdditionalImportSelector;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

/**
 * This configuration is used to load additional configuration classes.
 * Loads only if container.import.config.class is set.
 * <p/>
 * Created by DT214743 on 4/1/2018.
 */
@Configuration
@ConditionalOnProperty(prefix = "container", name = {"import.config.classes"})
@Import(AdditionalImportSelector.class)
@AutoConfigureAfter(EmbeddedTomcatConfiguration.class)
public class ImportConfiguration {
}
