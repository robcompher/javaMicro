package com.dsths.common.container.property;

import com.dsths.common.container.multitenant.property.TenantMapPropertySource;
import com.dsths.common.container.multitenant.property.TenantPropertiesVisitor;
import com.dsths.common.container.property.visitors.AdditionalPropertyLocationsVisitor;
import com.dsths.common.container.property.visitors.ContainerPropertiesVisitor;
import com.dsths.common.container.property.visitors.DefaultSettingsVisitor;
import com.dsths.common.container.property.visitors.EmberIndexPageVisitor;
import com.dsths.common.container.property.visitors.PasswordDecryptionVisitor;
import com.dsths.common.container.property.visitors.PropertyVisitor;
import com.dsths.common.container.support.SpringEnvironmentHelper;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.context.config.ConfigFileApplicationListener;
import org.springframework.boot.env.EnvironmentPostProcessor;
import org.springframework.boot.env.RandomValuePropertySource;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;

/**
 * Created by DT214743 on 4/9/2018.
 */
public class CustomEnvironmentPostProcessor implements EnvironmentPostProcessor, Ordered {
  private static final Logger logger = LogManager.getLogger(CustomEnvironmentPostProcessor.class);
  private static final Comparator<PropertyVisitor> ASCENDING_COMPARATOR = Comparator.comparing(PropertyVisitor::getOrder);
  public static final String CONTAINER_ENVIRONMENT_SOURCE_NAME = "containerEnvironmentSource";
  public static final int ORDER = ConfigFileApplicationListener.DEFAULT_ORDER + 1;

  private final List<PropertyVisitor> propertyVisitors;

  public CustomEnvironmentPostProcessor() {
    logger.debug("Initializing CustomEnvironmentPostProcessor");
    //populate property visitors
    this.propertyVisitors = new ArrayList<>();
    this.propertyVisitors.add(new TenantPropertiesVisitor());
    this.propertyVisitors.add(new AdditionalPropertyLocationsVisitor());
    this.propertyVisitors.add(new ContainerPropertiesVisitor());
    this.propertyVisitors.add(new DefaultSettingsVisitor());
    this.propertyVisitors.add(new EmberIndexPageVisitor());
    this.propertyVisitors.add(new PasswordDecryptionVisitor());

    Collections.sort(this.propertyVisitors, ASCENDING_COMPARATOR);
  }

  @Override
  public int getOrder() {
    return ORDER;
  }

  @Override
  public void postProcessEnvironment(ConfigurableEnvironment environment, SpringApplication application) {
    SpringEnvironmentHelper.setEnvironment(environment);
    //Add container environment properties to house decrypted properties, tenant config list etc to
    // dynamically generated properties
    TenantMapPropertySource propertySource =
        new TenantMapPropertySource(CONTAINER_ENVIRONMENT_SOURCE_NAME, new LinkedHashMap<>());

    environment.getPropertySources().addAfter(RandomValuePropertySource.RANDOM_PROPERTY_SOURCE_NAME, propertySource);

    //post-process properties
    this.propertyVisitors.stream().forEach(visitor -> visitor.visit(environment));
  }
}
