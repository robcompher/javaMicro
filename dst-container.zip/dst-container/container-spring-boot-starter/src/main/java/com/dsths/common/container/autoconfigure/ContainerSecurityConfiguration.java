package com.dsths.common.container.autoconfigure;

import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;

/**
 * Created by DT214743 on 1/4/2019.
 */
@Configuration
@ConditionalOnClass({WebSecurityConfigurerAdapter.class})
@Order(Ordered.LOWEST_PRECEDENCE - 100)
public class ContainerSecurityConfiguration extends WebSecurityConfigurerAdapter {

  @Override
  protected void configure(final AuthenticationManagerBuilder auth) throws Exception {
    //Intentionally left blank to use application configured auth manager
  }

  @Override
  public void configure(WebSecurity web) {
    web.ignoring().antMatchers("/container/**");
  }
}
