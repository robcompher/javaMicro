package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.multitenant.session.CustomConcurrentHashMap;
import com.dsths.common.container.multitenant.session.TenantCookieSerializer;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.condition.ConditionalOnWebApplication;
import org.springframework.boot.autoconfigure.session.SessionProperties;
import org.springframework.boot.autoconfigure.web.ServerProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.context.properties.PropertyMapper;
import org.springframework.boot.web.servlet.server.Session;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.MapSessionRepository;
import org.springframework.session.SessionRepository;
import org.springframework.session.config.annotation.web.http.EnableSpringHttpSession;
import org.springframework.session.web.http.CookieSerializer;

import java.util.concurrent.ConcurrentMap;

/**
 * Enables In-memory Spring Http Session with Tenant Cookie Serializer to work with Tenanted environment.
 * Created by DT214743 on 1/7/2019.
 */
@Configuration
@ConditionalOnClass(name = {"org.springframework.boot.web.servlet.server.Session"})
@ConditionalOnWebApplication
@EnableConfigurationProperties({ServerProperties.class, SessionProperties.class})
@EnableSpringHttpSession
public class SessionConfiguration {
  @Bean
  public CookieSerializer cookieSerializer(ServerProperties serverProperties) {
    TenantCookieSerializer cookieSerializer = new TenantCookieSerializer();
    Session.Cookie cookie = serverProperties.getServlet().getSession().getCookie();
    PropertyMapper map = PropertyMapper.get().alwaysApplyingWhenNonNull();
    map.from(cookie::getName).to(cookieSerializer::setCookieName);
    map.from(cookie::getDomain).to(cookieSerializer::setDomainName);
    map.from(cookie::getPath).to(cookieSerializer::setCookiePath);
    map.from(cookie::getHttpOnly).to(cookieSerializer::setUseHttpOnlyCookie);
    map.from(cookie::getSecure).to(cookieSerializer::setUseSecureCookie);
    map.from(cookie::getMaxAge).to(maxAge -> cookieSerializer.setCookieMaxAge((int) maxAge.getSeconds()));
    return cookieSerializer;
  }

  @Bean
  @ConditionalOnProperty(prefix = "spring.session", name = "store-type", havingValue = "none")
  public ConcurrentMap concurrentHashMap() {
    return new CustomConcurrentHashMap();
  }

  @Bean
  @ConditionalOnProperty(prefix = "spring.session", name = "store-type", havingValue = "none")
  @ConditionalOnMissingBean
  public SessionRepository sessionRepository() {
    return new MapSessionRepository(concurrentHashMap());
  }

}
