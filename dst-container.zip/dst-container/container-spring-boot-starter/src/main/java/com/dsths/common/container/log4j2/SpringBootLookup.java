package com.dsths.common.container.log4j2;

import com.dsths.common.container.support.SpringEnvironmentHelper;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.config.plugins.Plugin;
import org.apache.logging.log4j.core.lookup.AbstractLookup;
import org.apache.logging.log4j.core.lookup.StrLookup;

/**
 * Created by DT214743 on 11/8/2018.
 */
@Plugin(name = "spring", category = StrLookup.CATEGORY)
public class SpringBootLookup extends AbstractLookup {
  @Override
  public String lookup(final LogEvent event, final String key) {
    return SpringEnvironmentHelper.getProperty(key);
  }
}
