package com.dsths.common.container.postprocessors;

import com.dsths.common.container.multitenant.concurrent.TenantAsyncCustomizer;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.core.PriorityOrdered;
import org.springframework.scheduling.annotation.AsyncAnnotationBeanPostProcessor;
import org.springframework.scheduling.annotation.AsyncConfigurer;

/**
 * Created by DT214743 on 2/26/2019.
 */
public class TenantAsyncConfigurerBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter implements PriorityOrdered, BeanFactoryAware {

  private BeanFactory beanFactory;

  @Override
  public Object postProcessAfterInitialization(Object bean, String beanName) throws BeansException {
    if (bean instanceof AsyncConfigurer && !(bean instanceof TenantAsyncCustomizer)) {
      AsyncConfigurer configurer = (AsyncConfigurer) bean;
      return new TenantAsyncCustomizer(this.beanFactory, configurer);
    }
    return bean;
  }

  @Override
  public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
    this.beanFactory = beanFactory;
  }

  @Override
  public int getOrder() {
    return AsyncAnnotationBeanPostProcessor.LOWEST_PRECEDENCE - 1;
  }
}
