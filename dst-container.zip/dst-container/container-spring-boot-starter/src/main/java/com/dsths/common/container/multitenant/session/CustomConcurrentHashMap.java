package com.dsths.common.container.multitenant.session;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.session.MapSession;

import java.util.concurrent.ConcurrentHashMap;

/**
 * Created by DT214743 on 3/12/2019.
 */
public class CustomConcurrentHashMap extends ConcurrentHashMap {

  @Scheduled(cron = "${container.expired.session.purge.cron}")
  public void removeExpiredSessions() {
    // MapSessionRepository: that the supplied map itself is responsible for purging the expired sessions.
    this.keySet().stream().forEach(key -> {
      MapSession session = (MapSession) this.get(key);
      if(session.isExpired()) {
        this.remove(session);
      }
    });
  }
}
