package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantApplicationContextImpl;
import com.sun.jersey.spi.spring.container.servlet.SpringServlet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.AutoConfigureBefore;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.jersey.JerseyAutoConfiguration;
import org.springframework.boot.autoconfigure.jersey.JerseyProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.util.Assert;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.springframework.util.StringUtils.tokenizeToStringArray;

/**
 * Jersey 1 configuration and loads if container.jersey.enabled set.
 * <p/>
 * Check spring boot documentation on passing init (spring.jersey.init.*) parameters
 * <p/>
 * spring.jersey.application-path, Path that serves as the base URI for the application.
 * Default value is set as "/secured/rest/*". Use "," to configure multiple path mappings
 * <p/>
 * Created by DT214743 on 3/14/2018.
 */
@Configuration
@ConditionalOnClass(
    name = {"com.sun.jersey.api.core.ResourceConfig", "com.sun.jersey.spi.spring.container.servlet.SpringServlet", "javax.servlet.ServletRegistration"}
)
@EnableConfigurationProperties({JerseyProperties.class})
@AutoConfigureBefore(JerseyAutoConfiguration.class)
@Order(Ordered.LOWEST_PRECEDENCE - 1)
public class Jersey1Configuration {

  private static final String FORWARD_SLASH = "/";

  @Autowired
  private TenantApplicationContextImpl tenantAppContext;

  @Bean
  @ConditionalOnProperty(value = Constants.CONTAINER_JERSEY_ENABLED)
  public ServletRegistrationBean jersey(final JerseyProperties jerseyProperties) {
    Assert.notNull(jerseyProperties.getApplicationPath(), Constants.SPRING_JERSEY_APPLICATION_PATH);

    ServletRegistrationBean bean = new ServletRegistrationBean();
    bean.setServlet(new SpringServlet());
    //set init properties
    addInitParameters(bean, jerseyProperties);
    bean.setUrlMappings(getUrlPaths(jerseyProperties));
    bean.setOrder(jerseyProperties.getFilter().getOrder());
    bean.setName("jerseyServlet");
    bean.setLoadOnStartup(2);
    return bean;
  }

  private List<String> getUrlPaths(final JerseyProperties jerseyProperties) {
    Assert.notNull(jerseyProperties.getApplicationPath(), Constants.SPRING_JERSEY_APPLICATION_PATH);

    List<String> urlPaths = new ArrayList<>();
    String[] paths = tokenizeToStringArray(jerseyProperties.getApplicationPath(), ConfigurableApplicationContext.CONFIG_LOCATION_DELIMITERS);
    Arrays.stream(paths).map(this::cleanPathPattern).forEach(path -> {
      if (tenantAppContext.isTenanted()) {
        tenantAppContext.getAllTenants().forEach(tenant -> urlPaths.add(FORWARD_SLASH + tenant + cleanPathPattern(path)));
      } else {
        urlPaths.add(cleanPathPattern(path));
      }
    });
    return urlPaths;
  }

  private void addInitParameters(final ServletRegistrationBean bean, final JerseyProperties jerseyProperties) {
    //add first so that if some applications provide custom implementation, this value will be replaced with app custom implementation
    bean.addInitParameter("com.sun.jersey.config.property.resourceConfigClass", "com.dsths.common.container.jersey.JerseyResourcesConfig");

    //Add all init parameters given in property file
    if (jerseyProperties.getInit() != null) {
      jerseyProperties.getInit().forEach(bean::addInitParameter);
    }
  }

  private String cleanPathPattern(String applicationPath) {
    if (!applicationPath.startsWith(FORWARD_SLASH)) {
      applicationPath = FORWARD_SLASH + applicationPath;
    }

    if (applicationPath.endsWith(FORWARD_SLASH)) {
      applicationPath = applicationPath + "*";
    }

    if (!applicationPath.endsWith("/*")) {
      applicationPath = applicationPath + "/*";
    }
    return applicationPath;
  }
}
