package com.dsths.common.container.autoconfigure;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantApplicationContext;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.postprocessors.TenantJobBeanPostProcessor;
import com.dsths.common.container.postprocessors.TenantJobRegistryBeanPostProcessor;
import com.dsths.common.container.postprocessors.TenantJobRepositoryBeanPostProcessor;
import com.dsths.common.container.postprocessors.TenantSchedulerFactoryBeanPostProcessor;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by DT214743 on 2/18/2019.
 */
@Configuration
@ConditionalOnClass(name = {"org.springframework.batch.core.Job"})
@AutoConfigureAfter(TenantConfiguration.class)
public class TenantBatchConfiguration {

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public TenantJobRegistryBeanPostProcessor tenantJobRegistryBeanPostProcessor(TenantRequestContext tenantRequestContext) {
    return new TenantJobRegistryBeanPostProcessor(tenantRequestContext);
  }

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public TenantJobBeanPostProcessor tenantJobBeanPostProcessor(TenantRequestContext tenantRequestContext) {
    return new TenantJobBeanPostProcessor(tenantRequestContext);
  }

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  public TenantJobRepositoryBeanPostProcessor tenantJobRepositoryBeanPostProcessor(TenantRequestContext tenantRequestContext) {
    return new TenantJobRepositoryBeanPostProcessor(tenantRequestContext);
  }

  @Bean
  @ConditionalOnMissingBean
  @ConditionalOnProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY)
  @ConditionalOnClass(name = "org.springframework.scheduling.quartz.SchedulerFactoryBean")
  public TenantSchedulerFactoryBeanPostProcessor tenantSchedulerFactoryBeanPostProcessor(
      TenantApplicationContext tenantApplicationContext, DefaultListableBeanFactory beanFactory) {
    return new TenantSchedulerFactoryBeanPostProcessor(tenantApplicationContext, beanFactory);
  }
}
