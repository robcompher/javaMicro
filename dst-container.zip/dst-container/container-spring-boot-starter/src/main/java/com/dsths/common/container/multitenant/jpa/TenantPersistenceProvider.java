package com.dsths.common.container.multitenant.jpa;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.eclipse.persistence.config.PersistenceUnitProperties;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.boot.context.event.ApplicationStartedEvent;
import org.springframework.cglib.proxy.Enhancer;
import org.springframework.cglib.proxy.MethodInterceptor;
import org.springframework.cglib.proxy.MethodProxy;
import org.springframework.context.ApplicationListener;

import javax.persistence.EntityManagerFactory;
import javax.persistence.spi.PersistenceProvider;
import javax.persistence.spi.PersistenceUnitInfo;
import javax.persistence.spi.ProviderUtil;
import java.io.Serializable;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Custom JPA PersistenceProvider (EclipseLink) implementation to support multi-tenancy. This class returns proxy EntityManagerFactory on call to
 * create container managed EntityManagerFactory and delegate calls to EntityManagerFactory created for each tenant based on TenantId in request context.
 * This resolves issue related to SequenceGenerator caching with allocationSize in multi-tenancy environment.
 *
 * For Application managed EntityManagerFactory simply calls org.eclipse.persistence.jpa.PersistenceProvider.createEntityManagerFactory(String,Map)
 * and it is the responsibility of calls to make it Tenant Aware.
 *
 * Created by DT214743 on 7/11/2019.
 */
public class TenantPersistenceProvider implements PersistenceProvider, InitializingBean, ApplicationListener<ApplicationStartedEvent> {
  private PersistenceProvider persistenceProvider;

  private TenantRequestContext tenantRequestContext;

  private List<EntityManagerFactoryProxy> handlers = new ArrayList<>();
  private boolean started = false;

  public TenantPersistenceProvider(TenantRequestContext tenantRequestContext) {
    this.tenantRequestContext = tenantRequestContext;
  }
  
  public void setPersistenceProvider(PersistenceProvider persistenceProvider) {
    this.persistenceProvider = persistenceProvider;
  }

  public void setPersistenceProviderClass(Class<? extends PersistenceProvider> persistenceProviderClass) {
    this.persistenceProvider = BeanUtils.instantiateClass(persistenceProviderClass);
  }

  public void afterPropertiesSet() throws Exception {
    //if no persistence provider is set use eclipselink persistence provider
    if(persistenceProvider == null) {
      persistenceProvider = new org.eclipse.persistence.jpa.PersistenceProvider();
    }
  }

  @Override
  public EntityManagerFactory createEntityManagerFactory(String s, Map map) {
    return persistenceProvider.createEntityManagerFactory(s, map);
  }

  @Override
  public EntityManagerFactory createContainerEntityManagerFactory(PersistenceUnitInfo persistenceUnitInfo, Map map) {
    EntityManagerFactoryProxy methodInterceptor = new EntityManagerFactoryProxy(persistenceUnitInfo, map);
    handlers.add(methodInterceptor);

    Enhancer enhancer = new Enhancer();
    enhancer.setInterfaces(new Class<?>[]{EntityManagerFactory.class});
    enhancer.setCallback(methodInterceptor);
    return EntityManagerFactory.class.cast(enhancer.create());
  }

  @Override
  public void generateSchema(PersistenceUnitInfo persistenceUnitInfo, Map map) {
    persistenceProvider.generateSchema(persistenceUnitInfo, map);
  }

  @Override
  public boolean generateSchema(String s, Map map) {
    return persistenceProvider.generateSchema(s, map);
  }

  @Override
  public ProviderUtil getProviderUtil() {
    return persistenceProvider.getProviderUtil();
  }

  @SuppressWarnings("unused")
  public void destroy() {
    handlers.stream().forEach(EntityManagerFactoryProxy::destroy);
    handlers.clear();
  }

  @Override
  public void onApplicationEvent(ApplicationStartedEvent applicationStartedEvent) {
    started = true;
  }

  /**
   * Proxy class which resolves tenant EntityManagerFactory runtime and delegate calls to it.
   */
  private class EntityManagerFactoryProxy implements MethodInterceptor {

    private PersistenceUnitInfo originalPersistenceUnitInfo;

    private Map originalProperties;

    private Map<Serializable, EntityManagerFactory> entityManagerFactories = new ConcurrentHashMap<>();

    public EntityManagerFactoryProxy(PersistenceUnitInfo originalPersistenceUnitInfo, Map originalProperties) {
      this.originalPersistenceUnitInfo = originalPersistenceUnitInfo;
      this.originalProperties = originalProperties;
      this.initTenantEntityManagerFactories();
    }

    @Override
    public Object intercept(Object o, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
      return method.invoke(getTenantEntityManagerFactory(), args);
    }

    private EntityManagerFactory getTenantEntityManagerFactory() {
      String tenantId = tenantRequestContext.getCurrentTenant();
      if (!started && tenantId == null) {
        tenantId = tenantRequestContext.getTenantApplicationContext().getPrimaryTenant();
      } else if (started && tenantId == null) {
        throw new IllegalStateException("No tenant context found. Make sure the calls are made with in tenant context.");
      }

      EntityManagerFactory emf = entityManagerFactories.get(tenantId);
      if (emf == null) {
        throw new IllegalStateException(String.format("No EntityManager defined for tenant [%s]", tenantId));
      }
      return emf;
    }

    private void initTenantEntityManagerFactories() {
      tenantRequestContext.getTenantApplicationContext().getAllTenants().forEach(tenantId -> {
        Map properties = new HashMap<>(originalProperties);
        properties.put(PersistenceUnitProperties.SESSION_NAME, String.format("[%s]-[%s]-session",
            tenantId, originalPersistenceUnitInfo.getPersistenceUnitName()));
        properties.put(PersistenceUnitProperties.MULTITENANT_PROPERTY_DEFAULT, tenantId);

        Enhancer enhancer = new Enhancer();
        enhancer.setInterfaces(new Class<?>[]{PersistenceUnitInfo.class});
        enhancer.setCallback(new PersistenceUnitInfoProxy(originalPersistenceUnitInfo, tenantId));
        PersistenceUnitInfo persistenceUnitInfoProxy = PersistenceUnitInfo.class.cast(enhancer.create());

        EntityManagerFactory entityManagerFactory = persistenceProvider.createContainerEntityManagerFactory(persistenceUnitInfoProxy, properties);
        entityManagerFactories.put(tenantId, entityManagerFactory);
      });
    }

    public void destroy() {
      entityManagerFactories.values().stream().filter(EntityManagerFactory::isOpen).forEach(EntityManagerFactory::close);
    }
  }

  /**
   * Proxy class which override getPersistenceUnitName per tenant.
   */
  private static class PersistenceUnitInfoProxy implements MethodInterceptor {
    private String puName;
    private PersistenceUnitInfo originalPersistenceUnitInfo;

    public PersistenceUnitInfoProxy(PersistenceUnitInfo puInfo, String tenantId) {
      this.puName = String.format("[%s]-[%s]-pu)", tenantId, puInfo.getPersistenceUnitName());
      this.originalPersistenceUnitInfo = puInfo;
    }

    @Override
    public Object intercept(Object o, Method method, Object[] args, MethodProxy methodProxy) throws Throwable {
      if ("getPersistenceUnitName".equals(method.getName())) {
        return puName;
      } else {
        return method.invoke(originalPersistenceUnitInfo, args);
      }
    }
  }
}
