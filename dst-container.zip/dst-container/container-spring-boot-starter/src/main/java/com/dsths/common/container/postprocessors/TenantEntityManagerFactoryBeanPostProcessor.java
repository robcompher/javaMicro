package com.dsths.common.container.postprocessors;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.jpa.TenantPersistenceProvider;
import org.springframework.beans.BeansException;
import org.springframework.beans.MutablePropertyValues;
import org.springframework.beans.PropertyValues;
import org.springframework.beans.factory.config.InstantiationAwareBeanPostProcessorAdapter;
import org.springframework.beans.factory.config.RuntimeBeanReference;
import org.springframework.beans.factory.config.TypedStringValue;
import org.springframework.beans.factory.support.BeanDefinitionBuilder;
import org.springframework.beans.factory.support.DefaultListableBeanFactory;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;

/**
 * EMF bean post processor to add custom persistence provider
 *
 * Created by DT214743 on 3/29/2019.
 */
public class TenantEntityManagerFactoryBeanPostProcessor extends InstantiationAwareBeanPostProcessorAdapter {
  private final DefaultListableBeanFactory beanFactory;
  private final TenantRequestContext tenantRequestContext;

  public TenantEntityManagerFactoryBeanPostProcessor(DefaultListableBeanFactory beanFactory, TenantRequestContext tenantRequestContext) {
    this.beanFactory = beanFactory;
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public PropertyValues postProcessProperties(PropertyValues pvs, Object bean, String beanName) throws BeansException {
    if(bean instanceof LocalContainerEntityManagerFactoryBean) {
      MutablePropertyValues mpvs = ((MutablePropertyValues) pvs);

      String ppBeanName = getPersistenceProviderBeanName(mpvs);

      registerTenantPersistenceProviderBean(mpvs, ppBeanName);

      mpvs.add(Constants.PERSISTENCE_PROVIDER, new RuntimeBeanReference(ppBeanName));
    }
    return pvs;
  }

  private void registerTenantPersistenceProviderBean(MutablePropertyValues mpvs, String ppBeanName) {
    //Define tenant persistence prodiver bean
    BeanDefinitionBuilder bd = BeanDefinitionBuilder.genericBeanDefinition(TenantPersistenceProvider.class);
    bd.addConstructorArgValue(tenantRequestContext);
    bd.setDestroyMethodName("destroy");

    if (mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER) != null
        && mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER).getValue() != null) {
      bd.addPropertyValue(Constants.PERSISTENCE_PROVIDER, mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER).getValue());

      mpvs.removePropertyValue(mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER));
    } else if (mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER_CLAZZ) != null
        && mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER_CLAZZ).getValue() != null) {
      bd.addPropertyValue(Constants.PERSISTENCE_PROVIDER_CLAZZ, mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER_CLAZZ).getValue());

      mpvs.removePropertyValue(mpvs.getPropertyValue(Constants.PERSISTENCE_PROVIDER_CLAZZ));
    }

    beanFactory.registerBeanDefinition(ppBeanName, bd.getBeanDefinition());
  }

  private String getPersistenceProviderBeanName(MutablePropertyValues mpvs) {
    String ppBeanName;
    if(mpvs.getPropertyValue("persistenceUnitName") != null) {
      ppBeanName = String.format("persistenceProvider_%s", ((TypedStringValue) mpvs.getPropertyValue("persistenceUnitName").getValue()).getValue());
    } else {
      ppBeanName = String.format("persistenceProvider_%s", String.valueOf(Math.random()));
    }
    return ppBeanName;
  }
}
