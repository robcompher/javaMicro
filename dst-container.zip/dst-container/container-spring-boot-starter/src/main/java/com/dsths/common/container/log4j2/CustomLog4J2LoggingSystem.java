package com.dsths.common.container.log4j2;

import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LogEvent;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.AbstractConfiguration;
import org.apache.logging.log4j.core.config.ConfigurationFactory;
import org.apache.logging.log4j.core.config.ConfigurationSource;
import org.apache.logging.log4j.core.config.composite.CompositeConfiguration;
import org.springframework.boot.logging.LogFile;
import org.springframework.boot.logging.log4j2.Log4J2LoggingSystem;
import org.springframework.util.ResourceUtils;

import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by DT214743 on 3/27/2018.
 */
public class CustomLog4J2LoggingSystem extends Log4J2LoggingSystem {
  private static final Logger LOGGER = LogManager.getLogger(CustomLog4J2LoggingSystem.class);

  public CustomLog4J2LoggingSystem(ClassLoader classLoader) {
    super(classLoader);
  }

  @Override
  public void beforeInitialize() {
    super.beforeInitialize();
    LoggerContext loggerContext = (LoggerContext) LogManager.getContext(false);

    loggerContext.getConfiguration().removeFilter(loggerContext.getConfiguration().getFilter());
  }

  /**
   * Override to add server log configuration
   *
   * @param location
   * @param logFile
   */
  @Override
  protected void loadConfiguration(String location, LogFile logFile) {
    try {
      LOGGER.debug("loading log4j2 configuration");
      LoggerContext ex = (LoggerContext) LogManager.getContext(false);

      DeferredAppender deferredAppender = ex.getConfiguration().getAppender("DeferredAppender");
      if (deferredAppender == null)
        return;
      List<LogEvent> deferredEvents = deferredAppender.getMessages();

      List<AbstractConfiguration> configs = new ArrayList<>();

      //Add server log config
      URL url = ResourceUtils.getURL("classpath:server-log4j2.xml");
      LOGGER.debug("server log4j2 url: " + url);
      try (InputStream stream = url.openStream()) {
        ConfigurationSource source = this.getConfigSource(stream, url);
        AbstractConfiguration loggingConfig = (AbstractConfiguration) ConfigurationFactory.getInstance().getConfiguration(ex, source);
        configs.add(loggingConfig);
      }

      LOGGER.debug("application log4j2 url: " + location);
      //Add additional log location
      if (StringUtils.isNotEmpty(location)) {
        url = ResourceUtils.getURL(location);
        try (InputStream stream = url.openStream();) {
          ConfigurationSource source = this.getConfigSource(stream, url);
          AbstractConfiguration loggingConfig = (AbstractConfiguration) ConfigurationFactory.getInstance().getConfiguration(ex, source);
          configs.add(loggingConfig);
        }
      }

      ex.start(new CompositeConfiguration(configs));
      deferredAppender = ex.getConfiguration().getAppender("DeferredAppender");
      deferredAppender.getMessages().addAll(deferredEvents);
    } catch (Exception var6) {
      throw new IllegalStateException("Could not initialize Log4J2 logging from " + location, var6);
    }
  }

  /**
   * copied from Log4J2LoggingSystem
   */
  private ConfigurationSource getConfigSource(InputStream stream, URL url) throws IOException {
    return "file".equals(url.getProtocol()) ? new ConfigurationSource(stream, ResourceUtils.getFile(url))
        : new ConfigurationSource(stream, url);
  }
}
