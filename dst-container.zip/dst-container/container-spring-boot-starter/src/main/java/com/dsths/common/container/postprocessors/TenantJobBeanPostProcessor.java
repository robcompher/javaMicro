package com.dsths.common.container.postprocessors;

import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.batch.TenantJob;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.job.AbstractJob;
import org.springframework.beans.factory.config.BeanPostProcessor;

/**
 * Created by DT214743 on 10/24/2019.
 */
public class TenantJobBeanPostProcessor implements BeanPostProcessor {
  private final TenantRequestContext tenantRequestContext;

  public TenantJobBeanPostProcessor(TenantRequestContext tenantRequestContext) {
    this.tenantRequestContext = tenantRequestContext;
  }

  @Override
  public Object postProcessAfterInitialization(Object bean, String beanName) {
    if (bean instanceof AbstractJob && !(bean instanceof TenantJob)) {
      return new TenantJob((Job) bean, tenantRequestContext);
    }
    return bean;
  }

  @Override
  public Object postProcessBeforeInitialization(Object bean, String beanName) {
    return bean;
  }
}

