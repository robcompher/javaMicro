package com.dsths.common.container.multitenant.property;

import com.dsths.common.container.Constants;
import com.dsths.common.container.property.CustomEnvironmentPostProcessor;
import com.dsths.common.container.property.visitors.AbstractPropertyVisitor;
import com.dsths.common.container.property.visitors.DefaultSettingsVisitor;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.env.OriginTrackedMapPropertySource;
import org.springframework.boot.env.PropertiesPropertySourceLoader;
import org.springframework.boot.env.PropertySourceLoader;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Looks up tenant properties using defined config location, prefix and profile.
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
public class TenantPropertiesVisitor extends AbstractPropertyVisitor {
  private static final Logger logger = LogManager.getLogger(TenantPropertiesVisitor.class);

  private static final int ORDER = DefaultSettingsVisitor.ORDER + 1;

  @Override
  public void visit(ConfigurableEnvironment environment) {
    String resourceLocations = environment.getProperty(Constants.TENANT_CONFIG_LOCATION);
    logger.info("Tenant config search location : {}", resourceLocations);
    PropertySourceLoader propertySourceLoader = new PropertiesPropertySourceLoader();
    if (!StringUtils.isEmpty(resourceLocations)) {
      Map<String, ArrayDeque<OriginTrackedMapPropertySource>> allPropertySources = new HashMap<>();

      Set<String> locations = getSearchLocations(resourceLocations, environment);
      locations.stream().forEach(location ->
          load(propertySourceLoader, location, allPropertySources, environment));

      List<String> inactiveTenants = new ArrayList<>();
      allPropertySources.forEach((fileName, psList) -> psList.stream()
          .map(propertySource -> propertySource.getProperty(Constants.CONTAINER_TENANT_ACTIVE))
          .filter(Objects::nonNull)
          .filter(a -> !Boolean.valueOf((String) a)).findFirst()
          .ifPresent(inactive -> inactiveTenants.add(fileName)));
      //remove inactive tenants
      inactiveTenants.stream().forEach(key -> allPropertySources.remove(key));

      if (!allPropertySources.isEmpty()) {
        TenantOriginTrackedMapPropertySource propertySource = new TenantOriginTrackedMapPropertySource(allPropertySources);
        TenantMapPropertySource containerEnvSource = getContainerEnvironmentPropertySource(environment);
        containerEnvSource.getSource().put(Constants.CONTAINER_TENANTS_PROPERTY_KEY,
            propertySource.getAllTenants().stream().collect(Collectors.joining(",")));

        environment.getPropertySources().addAfter(CustomEnvironmentPostProcessor.CONTAINER_ENVIRONMENT_SOURCE_NAME,
            propertySource);
      }
    }
  }

  private void load(PropertySourceLoader propertySourceLoader, String location,
                    Map<String, ArrayDeque<OriginTrackedMapPropertySource>> allPropertySources,
                    ConfigurableEnvironment environment) {
    try {
      String nameRegExPattern = environment.getRequiredProperty(Constants.TENANT_CONFIG_TENANT_NAME_PATTERN);

      Resource[] resources = ResourcePatternUtils.getResourcePatternResolver(null)
          .getResources(location);

      if (resources.length == 0) {
        logger.info("No tenant resources found in path ({})", location);
      } else {
        logger.info("Tenant resources found in path ({})", location);
      }

      //non-profile
      Arrays.stream(resources).forEachOrdered(resource -> {
        String fileNameWithoutExtn = StringUtils.stripFilenameExtension(resource.getFilename());
        if (fileNameWithoutExtn.matches(nameRegExPattern)) {
          logger.info("Loading non-profile resource: {}", resource.getFilename());
          loadProperties(resource, fileNameWithoutExtn, propertySourceLoader, allPropertySources);
        }
      });

      //profile
      Arrays.stream(environment.getActiveProfiles()).forEach(profile ->
              Arrays.stream(resources).forEachOrdered(resource -> {
                String fileNameWithoutExtn = StringUtils.stripFilenameExtension(resource.getFilename());
                if (fileNameWithoutExtn.matches(nameRegExPattern + '-' + profile)) {
                  logger.info("Loading profile resource: {}", resource.getFilename());
                  loadProperties(resource, fileNameWithoutExtn, propertySourceLoader, allPropertySources);
                }
              })
      );
    } catch (IOException e) {
      logger.info("No tenant resources found in path ({})", location);
    }
  }

  private void loadProperties(Resource resource, String fileNameWithoutExtn, PropertySourceLoader propertySourceLoader,
                              Map<String, ArrayDeque<OriginTrackedMapPropertySource>> allPropertySources) {
    try {
      List<PropertySource<?>> properties = propertySourceLoader.load(resource.getFilename(), resource);
      if (!properties.isEmpty()) {
        OriginTrackedMapPropertySource propertySource = (OriginTrackedMapPropertySource) properties.get(0);
        Optional<String> key = allPropertySources.keySet().stream()
            .filter(fileNameWithoutExtn::startsWith).findFirst();
        if (!key.isPresent()) {
          allPropertySources.put(fileNameWithoutExtn, new ArrayDeque<>());
          allPropertySources.get(fileNameWithoutExtn).add(propertySource);
        } else {
          allPropertySources.get(key.get()).add(propertySource);
        }
      }
    } catch (IOException e) {
      //this will never happen as we are getting file name from found resources
      logger.warn("Tenant resource location ({}) not found in classpath", resource.getFilename(), e);
    }
  }

  @Override
  public int getOrder() {
    return ORDER;
  }
}
