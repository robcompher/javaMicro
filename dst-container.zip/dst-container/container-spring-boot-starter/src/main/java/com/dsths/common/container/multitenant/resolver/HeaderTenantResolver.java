package com.dsths.common.container.multitenant.resolver;

import com.dsths.common.container.multitenant.TenantPathData;
import com.dsths.common.container.multitenant.exception.TenantResolveException;
import org.apache.commons.lang.StringUtils;

import javax.servlet.http.HttpServletRequest;

/**
 * Tries to resolve Tenant from request Header (X-TENANT)
 * <p/>
 * Created by DT214743 on 12/27/2018.
 */
public class HeaderTenantResolver implements TenantResolver {

  private static final String TENANT_HEADER_NAME = "X-TENANT";


  @Override
  public TenantPathData resolve(HttpServletRequest request) {
    String tenant = request.getHeader(TENANT_HEADER_NAME);

    if (StringUtils.isEmpty(tenant)) {
      throw new TenantResolveException(String.format("Unable to resolve the tenant from header: \"%s\"",
          TENANT_HEADER_NAME));
    }

    return new TenantPathData(tenant, "", request.getServletPath());
  }
}
