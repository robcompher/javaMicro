package com.dsths.common.container.property.visitors;

import com.dsths.common.container.multitenant.property.TenantMapPropertySource;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.boot.env.PropertiesPropertySourceLoader;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.util.StringUtils;

import java.io.IOException;
import java.util.List;

/**
 * Created by DT214743 on 12/27/2018.
 */
public class ContainerPropertiesVisitor extends AbstractPropertyVisitor {
  private static final Logger logger = LogManager.getLogger(ContainerPropertiesVisitor.class);

  private static final String CONTAINER_DEFAULT_PROPERTIES = "classpath:com/dsths/property/defaults/container.properties";
  private static final String SPRING_AUTOCONFIGURE_EXCLUDE = "spring.autoconfigure.exclude";
  private static final String SERVER_TOMCAT_ADDITIONAL_TLD_SKIP_PATTERNS = "server.tomcat.additional-tld-skip-patterns";
  public static final int ORDER = AdditionalPropertyLocationsVisitor.ORDER + 1;

  @Override
  public void visit(ConfigurableEnvironment environment) {
    logger.info("loading container properties");
    //load container defaults
    try {
      Resource resource = ResourcePatternUtils.getResourcePatternResolver(null).getResource(CONTAINER_DEFAULT_PROPERTIES);
      if (resource != null) {
        List<PropertySource<?>> containerProps = new PropertiesPropertySourceLoader().load(CONTAINER_DEFAULT_PROPERTIES, resource);

        if (!containerProps.isEmpty()) {
          addLastPropertySource(environment, containerProps.get(0));
          //auto configure excludes
          String appExcludes = environment.getProperty(SPRING_AUTOCONFIGURE_EXCLUDE);
          String containerExcludes = environment.getProperty("container.autoconfigure.default.exclude");

          TenantMapPropertySource containerEnvSource = getContainerEnvironmentPropertySource(environment);
          if (!StringUtils.isEmpty(environment.getProperty(SPRING_AUTOCONFIGURE_EXCLUDE))) {
            containerEnvSource.getSource().put(SPRING_AUTOCONFIGURE_EXCLUDE, appExcludes.concat(",").concat(containerExcludes));
          } else {
            containerEnvSource.getSource().put(SPRING_AUTOCONFIGURE_EXCLUDE, containerExcludes);
          }

          //tomcat tld scan excludes
          appExcludes = environment.getProperty(SERVER_TOMCAT_ADDITIONAL_TLD_SKIP_PATTERNS);
          containerExcludes = environment.getProperty("container.default.additional-tld-skip-patterns");
          if (!StringUtils.isEmpty(environment.getProperty(SERVER_TOMCAT_ADDITIONAL_TLD_SKIP_PATTERNS))) {
            containerEnvSource.getSource().put(SERVER_TOMCAT_ADDITIONAL_TLD_SKIP_PATTERNS, appExcludes.concat(",").concat(containerExcludes));
          } else {
            containerEnvSource.getSource().put(SERVER_TOMCAT_ADDITIONAL_TLD_SKIP_PATTERNS, containerExcludes);
          }
        }
      }
    } catch (IOException e) {
      logger.warn(CONTAINER_DEFAULT_PROPERTIES + " not found in classpath", e);
    }
  }

  @Override
  public int getOrder() {
    return ORDER;
  }
}
