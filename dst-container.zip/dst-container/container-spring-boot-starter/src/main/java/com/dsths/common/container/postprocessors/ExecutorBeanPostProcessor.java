package com.dsths.common.container.postprocessors;

import com.dsths.common.container.multitenant.concurrent.TenantExecutor;
import com.dsths.common.container.multitenant.concurrent.TenantThreadPoolTaskExecutor;
import org.aopalliance.intercept.MethodInterceptor;
import org.aopalliance.intercept.MethodInvocation;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.aop.framework.AopConfigException;
import org.springframework.aop.framework.ProxyFactoryBean;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;
import org.springframework.util.ReflectionUtils;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.concurrent.Executor;

/**
 * Created by DT214743 on 2/6/2019.
 */
public class ExecutorBeanPostProcessor implements BeanPostProcessor, BeanFactoryAware {
  private static final Logger log = LogManager.getLogger(ExecutorBeanPostProcessor.class);

  private BeanFactory beanFactory;

  @Override
  public void setBeanFactory(BeanFactory beanFactory) throws BeansException {
    this.beanFactory = beanFactory;
  }

  @Override
  public Object postProcessBeforeInitialization(Object bean, String beanName) {
    return bean;
  }

  @Override
  public Object postProcessAfterInitialization(Object bean, String beanName) {
    if (bean instanceof Executor && !(bean instanceof ThreadPoolTaskExecutor) && !(bean instanceof TenantExecutor)) {
      Method execute = ReflectionUtils.findMethod(bean.getClass(), "execute", Runnable.class);
      boolean methodFinal = Modifier.isFinal(execute.getModifiers());
      boolean classFinal = Modifier.isFinal(bean.getClass().getModifiers());
      boolean cglibProxy = !methodFinal && !classFinal;
      Executor executor = (Executor) bean;
      try {
        return createProxy(bean, cglibProxy, executor);
      } catch (AopConfigException e) {
        if (cglibProxy) {
          if (log.isDebugEnabled()) {
            log.debug("Exception occurred while trying to create a proxy, falling back to JDK proxy", e);
          }
          return createProxy(bean, false, executor);
        }
        throw e;
      }
    } else if (bean instanceof ThreadPoolTaskExecutor && !(bean instanceof TenantThreadPoolTaskExecutor)) {
      boolean classFinal = Modifier.isFinal(bean.getClass().getModifiers());
      boolean cglibProxy = !classFinal;
      ThreadPoolTaskExecutor executor = (ThreadPoolTaskExecutor) bean;
      return createThreadPoolTaskExecutorProxy(bean, cglibProxy, executor);
    }
    return bean;
  }

  Object createThreadPoolTaskExecutorProxy(Object bean, boolean cglibProxy,
                                           ThreadPoolTaskExecutor executor) {
    ProxyFactoryBean factory = new ProxyFactoryBean();
    factory.setProxyTargetClass(cglibProxy);
    factory.addAdvice(new ExecutorMethodInterceptor<ThreadPoolTaskExecutor>(executor, this.beanFactory) {
      @Override
      Executor executor(BeanFactory beanFactory, ThreadPoolTaskExecutor executor) {
        return new TenantThreadPoolTaskExecutor(beanFactory, executor);
      }
    });
    factory.setTarget(bean);
    return factory.getObject();
  }

  @SuppressWarnings("unchecked")
  Object createProxy(Object bean, boolean cglibProxy, Executor executor) {
    ProxyFactoryBean factory = new ProxyFactoryBean();
    factory.setProxyTargetClass(cglibProxy);
    factory.addAdvice(new ExecutorMethodInterceptor(executor, this.beanFactory));
    factory.setTarget(bean);
    return factory.getObject();
  }
}

class ExecutorMethodInterceptor<T extends Executor> implements MethodInterceptor {

  private final T delegate;
  private final BeanFactory beanFactory;

  ExecutorMethodInterceptor(T delegate, BeanFactory beanFactory) {
    this.delegate = delegate;
    this.beanFactory = beanFactory;
  }

  @Override
  public Object invoke(MethodInvocation invocation)
      throws Throwable {
    Executor executor = executor(this.beanFactory, this.delegate);
    Method methodOnTracedBean = getMethod(invocation, executor);
    if (methodOnTracedBean != null) {
      return methodOnTracedBean.invoke(executor, invocation.getArguments());
    }
    return invocation.proceed();
  }

  private Method getMethod(MethodInvocation invocation, Object object) {
    Method method = invocation.getMethod();
    return ReflectionUtils
        .findMethod(object.getClass(), method.getName(), method.getParameterTypes());
  }

  Executor executor(BeanFactory beanFactory, T executor) {
    return new TenantExecutor(beanFactory, executor);
  }
}