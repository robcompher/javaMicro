package com.dsths.common.container.property.visitors;

import com.dsths.common.configuration.ConfigurationManager;
import com.dsths.common.configuration.ConfigurationManagerFactory;
import com.dsths.common.configuration.ConfigurationPropertySource;
import com.dsths.common.configuration.EffectiveConfigurationFactory;
import com.dsths.common.configuration.SpringEnvironmentEffectiveConfigurationFactory;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.env.ConfigurableEnvironment;

/**
 * Created by DT214743 on 12/27/2018.
 */
public class DefaultSettingsVisitor extends AbstractPropertyVisitor {
  private static final Logger logger = LogManager.getLogger(DefaultSettingsVisitor.class);

  public static final int ORDER = ContainerPropertiesVisitor.ORDER + 1;

  /**
   * Use app defaults configuration instead of default-settings.xml
   *
   * @param environment
   * @return
   */
  @Override
  public void visit(ConfigurableEnvironment environment) {
    logger.info("loading properties using ConfigurationManagerFactory");
    try {
      EffectiveConfigurationFactory factory = new SpringEnvironmentEffectiveConfigurationFactory(environment);
      ConfigurationManagerFactory configurationManagerFactory = new ConfigurationManagerFactory();
      configurationManagerFactory.setEnvironment(environment);
      configurationManagerFactory.setEffectiveConfigurationFactory(factory);
      configurationManagerFactory.setCreateMissingLocalOverrides(false);
      configurationManagerFactory.setFailOnMissingLocalOverrides(false);

      ConfigurationManager cm = configurationManagerFactory.getObject();
      ConfigurationPropertySource cps = new ConfigurationPropertySource("configuration", cm);

      addLastPropertySource(environment, cps);
    } catch (Exception e) {
      logger.info("Failed to load settings xml's", e);
    }
  }

  @Override
  public int getOrder() {
    return ORDER;
  }
}
