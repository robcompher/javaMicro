package com.dsths.common.container.listeners;

import com.dsths.common.container.log4j2.DeferredAppender;
import com.dsths.common.container.property.CustomEnvironmentPostProcessor;
import org.apache.logging.log4j.Level;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.LoggerContext;
import org.apache.logging.log4j.core.config.Configuration;
import org.apache.logging.log4j.core.config.LoggerConfig;
import org.springframework.boot.context.event.ApplicationFailedEvent;
import org.springframework.boot.context.event.ApplicationPreparedEvent;
import org.springframework.context.ApplicationEvent;
import org.springframework.context.event.GenericApplicationListener;
import org.springframework.core.Ordered;
import org.springframework.core.ResolvableType;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.PropertySource;

import java.util.Arrays;
import java.util.LinkedList;
import java.util.List;

/**
 * Created by DT214743 on 10/18/2018.
 * <p/>
 * Based on https://stackoverflow.com/questions/48212761/how-to-log-all-active-properties-of-a-spring-boot-application-before-the-beans-i
 */
public class PropertiesLoggerListener implements GenericApplicationListener, Ordered {
  private static final Logger log = LogManager.getLogger(PropertiesLoggerListener.class);
  public static final int ORDER = CustomEnvironmentPostProcessor.ORDER + 1;
  public static final String DEBUG = "debug";
  public static final String PROP_SEPARATOR = "*****";
  private ConfigurableEnvironment environment;

  @Override
  public void onApplicationEvent(ApplicationEvent event) {
    //deferred logging
    LoggerContext logContext = (LoggerContext) LogManager.getContext(false);
    Configuration configuration = logContext.getConfiguration();

    if (event instanceof ApplicationPreparedEvent) {
      DeferredAppender deferredAppender = configuration.getAppender("DeferredAppender");
      if(deferredAppender != null)
        deferredAppender.replayTo();

      onApplicationPreparedEvent((ApplicationPreparedEvent) event);
    } else if (event instanceof ApplicationFailedEvent) {
      DeferredAppender deferredAppender = configuration.getAppender("DeferredAppender");
      if(deferredAppender != null)
        deferredAppender.replayTo();
    }
  }

  @Override
  public boolean supportsEventType(ResolvableType resolvableType) {
    Class<?> type = resolvableType.getRawClass();

    return ApplicationPreparedEvent.class.isAssignableFrom(type)
        || ApplicationFailedEvent.class.isAssignableFrom(type);
  }

  @Override
  public boolean supportsSourceType(Class<?> sourceType) {
    return true;
  }

  public void onApplicationPreparedEvent(ApplicationPreparedEvent event) {
    //log env properties
    environment = event.getApplicationContext().getEnvironment();
    if (environment.containsProperty(DEBUG)) {
      //deferred logging
      LoggerContext logContext = (LoggerContext) LogManager.getContext(false);
      Configuration configuration = logContext.getConfiguration();

      LoggerConfig loggerConfig = configuration.getLoggerConfig("com.dsths.common.container.core.listeners.PropertiesLoggerListener");
      Level newLevel = Level.valueOf(DEBUG);
      loggerConfig.setLevel(newLevel);
      logContext.updateLoggers();
    }
    printProperties();
  }

  public void printProperties() {
    try {
      if (environment.containsProperty(DEBUG) || log.isDebugEnabled()) {
        log.debug("-----------------------");
        log.debug("All properties");
        log.debug("-----------------------");
        for (EnumerablePropertySource propertySource : findPropertiesPropertySources()) {
          log.debug("******* " + propertySource.getName() + " *******");
          String[] propertyNames = propertySource.getPropertyNames();
          Arrays.sort(propertyNames);
          for (String propertyName : propertyNames) {
            printProperty(propertySource, propertyName);
          }
        }
      }
    } catch (Exception e) {
      log.warn("Unknown error occurred", e);
    }
  }

  private void printProperty(EnumerablePropertySource propertySource, String propertyName) {
    boolean isPassword = propertyName.toLowerCase().contains("password");
    if (propertySource.getProperty(propertyName) instanceof String) {
      String sourceProperty = (String) propertySource.getProperty(propertyName);
      try {
        String resolvedProperty = environment.getProperty(propertyName);
        if (resolvedProperty.equals(sourceProperty)) {
          if (isPassword) {
            resolvedProperty = PROP_SEPARATOR;
          }
          log.debug("{}={}", propertyName, resolvedProperty);
        } else {
          if (isPassword) {
            sourceProperty = PROP_SEPARATOR;
            resolvedProperty = sourceProperty;
          }
          log.debug("{}={} OVERRIDDEN to {}", propertyName, sourceProperty, resolvedProperty);
        }
      } catch (Exception e) {
        if (isPassword) {
          sourceProperty = PROP_SEPARATOR;
        }
        log.debug("{}={} Not Resolved", propertyName, sourceProperty);
      }
    }
  }

  private List<EnumerablePropertySource> findPropertiesPropertySources() {
    List<EnumerablePropertySource> propertiesPropertySources = new LinkedList<>();
    for (PropertySource<?> propertySource : environment.getPropertySources()) {
      if (propertySource instanceof EnumerablePropertySource) {
        propertiesPropertySources.add((EnumerablePropertySource) propertySource);
      }
    }
    return propertiesPropertySources;
  }

  @Override
  public int getOrder() {
    return ORDER;
  }
}
