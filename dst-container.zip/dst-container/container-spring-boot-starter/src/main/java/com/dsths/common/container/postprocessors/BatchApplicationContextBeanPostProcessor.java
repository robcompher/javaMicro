package com.dsths.common.container.postprocessors;

import com.dsths.common.container.Constants;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.support.BeanDefinitionRegistry;
import org.springframework.beans.factory.support.BeanDefinitionRegistryPostProcessor;
import org.springframework.context.EnvironmentAware;
import org.springframework.core.Ordered;
import org.springframework.core.env.Environment;

/**
 * Created by DT214743 on 3/22/2019.
 */
public class BatchApplicationContextBeanPostProcessor implements BeanDefinitionRegistryPostProcessor, EnvironmentAware, Ordered {
  public static final int DEFAULT_ORDER = Ordered.LOWEST_PRECEDENCE + 1;
  private Environment environment;

  @Override
  public void postProcessBeanDefinitionRegistry(BeanDefinitionRegistry beanDefinitionRegistry) {
    //no op
  }

  @Override
  public void postProcessBeanFactory(final ConfigurableListableBeanFactory beanFactory) {
    if (environment.getProperty(Constants.CONTAINER_TENANTS_PROPERTY_KEY) != null) {
      ExecutorBeanPostProcessor executorBeanPostProcessor = new ExecutorBeanPostProcessor();
      executorBeanPostProcessor.setBeanFactory(beanFactory);
      beanFactory.addBeanPostProcessor(executorBeanPostProcessor);

      TenantAsyncConfigurerBeanPostProcessor tenantAsyncBeanPostProcessor = new TenantAsyncConfigurerBeanPostProcessor();
      tenantAsyncBeanPostProcessor.setBeanFactory(beanFactory);
      beanFactory.addBeanPostProcessor(tenantAsyncBeanPostProcessor);
    }
  }

  @Override
  public int getOrder() {
    return DEFAULT_ORDER;
  }

  @Override
  public void setEnvironment(Environment environment) {
    this.environment = environment;
  }
}
