package com.dsths.common.container.property.visitors;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.property.TenantMapPropertySource;
import com.dsths.encryption.Crypt;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.core.Ordered;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.io.support.ResourcePatternUtils;
import org.springframework.util.StringUtils;

import java.io.File;
import java.util.Arrays;
import java.util.stream.StreamSupport;

/**
 * Created by DT214743 on 12/27/2018.
 */
public class PasswordDecryptionVisitor extends AbstractPropertyVisitor {
  private static final Logger logger = LogManager.getLogger(PasswordDecryptionVisitor.class);
  public static final int DEFAULT_ORDER = Ordered.LOWEST_PRECEDENCE - 1000;

  @Override
  public void visit(ConfigurableEnvironment environment) {
    decryptNonSslPassword(environment);
    decryptSslPassword(environment);
  }

  protected void decryptSslPassword(ConfigurableEnvironment environment) {
    TenantMapPropertySource containerEnvSource = getContainerEnvironmentPropertySource(environment);
    try {
      //server.ssl.key-store-password= # Password used to access the key store.
      String encryptedPassword = environment.getProperty("server.ssl.key-store.encryptedPassword");
      String encryptionKeyFile = environment.getProperty("server.ssl.key-store.encryptionKeyFile");
      if (!StringUtils.isEmpty(encryptedPassword) || !StringUtils.isEmpty(encryptionKeyFile)) {
        String password = decryptPassword(encryptedPassword, encryptionKeyFile, "Invalid SSL key-store password and/or encryptionKeyFile");

        containerEnvSource.getSource().put("server.ssl.key-store-password", password);
      }

      //server.ssl.key-password= # Password used to access the key in the key store.
      encryptedPassword = environment.getProperty("server.ssl.key.encryptedPassword");
      encryptionKeyFile = environment.getProperty("server.ssl.key.encryptionKeyFile");
      if (!StringUtils.isEmpty(encryptedPassword) || !StringUtils.isEmpty(encryptionKeyFile)) {
        String password = decryptPassword(encryptedPassword, encryptionKeyFile, "Invalid SSL key password and/or encryptionKeyFile");

        containerEnvSource.getSource().put("server.ssl.key-password", password);
      }

      //server.ssl.trust-store-password= # Password used to access the trust store.
      encryptedPassword = environment.getProperty("server.ssl.trust-store.encryptedPassword");
      encryptionKeyFile = environment.getProperty("server.ssl.trust-store.encryptionKeyFile");
      if (!StringUtils.isEmpty(encryptedPassword) || !StringUtils.isEmpty(encryptionKeyFile)) {
        String password = decryptPassword(encryptedPassword, encryptionKeyFile, "Invalid SSL trust-store password and/or encryptionKeyFile");
        containerEnvSource.getSource().put("server.ssl.trust-store-password", password);
      }
    } catch (IllegalArgumentException e) {
      logger.error(Constants.PD_DECRYPTION_ERROR, e);
    }
  }

  protected void decryptNonSslPassword(ConfigurableEnvironment environment) {
    final TenantMapPropertySource containerEnvSource = getContainerEnvironmentPropertySource(environment);
    StreamSupport.stream(environment.getPropertySources().spliterator(), false)
        .filter(ps -> ps instanceof EnumerablePropertySource)
        .map(ps -> ((EnumerablePropertySource) ps).getPropertyNames())
        .flatMap(Arrays::<String>stream)
        .filter(propName -> !propName.startsWith("server.ssl.") && propName.endsWith(Constants.ENCRYPTED_PD_KEY))
        .forEach(key -> {
          try {
            //Decrypt ds password
            String encryptedPassword = environment.getProperty(key);
            String encryptionKeyFile = environment.getProperty(key.replaceFirst(Constants.ENCRYPTED_PD_KEY,
                Constants.ENCRYPTION_KEY_FILE));
            String password = decryptPassword(encryptedPassword, encryptionKeyFile, Constants.PD_DECRYPTION_ERROR);

            containerEnvSource.getSource().put(key.replaceFirst(Constants.ENCRYPTED_PD_KEY, "password"), password);
          } catch (IllegalArgumentException e) {
            logger.error("For property : "+key, e);
          }
        });
  }

  protected String decryptPassword(String encryptedPassword, String encryptionKeyFile, String errorMsg) {
    if (StringUtils.isEmpty(encryptedPassword)) {
      throw new IllegalArgumentException(String.format(errorMsg, encryptedPassword, encryptionKeyFile) + ": encryptedPassword is empty");
    }
    if (StringUtils.isEmpty(encryptionKeyFile)) {
      throw new IllegalArgumentException(String.format(errorMsg, encryptedPassword, encryptionKeyFile) + ": "+Constants.ENCRYPTION_KEY_FILE +" is empty");
    }
    String password;
    try {
      File file = ResourcePatternUtils.getResourcePatternResolver(null).getResource(encryptionKeyFile).getFile();
      password = Crypt.decryptIt(file.getCanonicalPath(), encryptedPassword);
    } catch (Exception ex) {
      throw new IllegalArgumentException(
          String.format(Constants.PD_DECRYPTION_ERROR, encryptedPassword, encryptionKeyFile), ex);
    }
    if (StringUtils.isEmpty(password)) {
      throw new IllegalArgumentException(
          String.format(Constants.PD_DECRYPTION_ERROR, encryptedPassword, encryptionKeyFile));
    }
    return password;
  }

  @Override
  public int getOrder() {
    return DEFAULT_ORDER;
  }
}
