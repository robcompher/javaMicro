package com.dsths.common.container.multitenant.integration;

import com.dsths.common.container.Constants;
import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.ChannelInterceptor;

/**
 * Created by DT214743 on 2/12/2019.
 */
public class TenantChannelInterceptor implements ChannelInterceptor {
  @Autowired
  private TenantRequestContext tenantRequestContext;

  /**
   * preSend is invoked before a message is sent and returns the message that will be
   * sent to the channel when the method returns. If the method returns null, nothing
   * is sent. This allows the implementation to control what gets sent to the
   * channel, effectively filtering the messages.
   *
   * @param message
   * @param channel
   * @return
   */
  @Override
  public Message<?> preSend(Message<?> message, MessageChannel channel) {
    Message<?> resultMessage = message;
    if (tenantRequestContext.isTenanted()
        && !message.getHeaders().containsKey(Constants.TENANT_KEY)
        && tenantRequestContext.getCurrentTenant() != null) {
      resultMessage = MessageBuilder.withPayload(message.getPayload())
          .copyHeaders(message.getHeaders())
          .setHeader(Constants.TENANT_KEY, tenantRequestContext.getCurrentTenant()).build();
    }
    return resultMessage;
  }
}
