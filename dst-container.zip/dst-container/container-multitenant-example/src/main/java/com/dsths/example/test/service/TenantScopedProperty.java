package com.dsths.example.test.service;

import com.dsths.common.container.multitenant.scope.TenantScoped;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;


@Component
@TenantScoped
@ConfigurationProperties(prefix = "some")
public class TenantScopedProperty {
  private String property;

  public String getProperty() {
    return property;
  }

  public void setProperty(String property) {
    this.property = property;
  }
}
