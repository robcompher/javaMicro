package com.dsths.example.test.service;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * Created by DT214743 on 3/5/2019.
 */
@Component
public class ScheduledTasks {
  private static final Logger log = LogManager.getLogger(ScheduledTasks.class);
  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Scheduled(fixedDelay = 5000)
  public void scheduleFixedDelayTask() {
    log.info("Fixed delay task - " + System.currentTimeMillis() / 5000 +" - tenant "+tenantRequestContext.getCurrentTenant());
  }
}
