package com.dsths.example.test.spring;

import com.dsths.common.container.batch.CustomDefaultBatchConfigurer;
import com.dsths.example.test.batch.TestBatchTasklet;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.BatchConfigurer;
import org.springframework.batch.core.configuration.annotation.JobBuilderFactory;
import org.springframework.batch.core.configuration.annotation.StepBuilderFactory;
import org.springframework.batch.core.launch.support.RunIdIncrementer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.sql.DataSource;

/**
 * Created by DT214743 on 10/28/2019.
 */
@Configuration
public class BatchConfig {

  @Autowired
  private JobBuilderFactory jobs;

  @Autowired
  private StepBuilderFactory steps;

//  @Bean
//  public BatchConfigurer batchConfigurer(@Qualifier("datasource_2") DataSource dataSource) {
//    return new CustomDefaultBatchConfigurer(dataSource);
//  }
  @Bean
  public TestBatchTasklet testBatchTasklet() {
    return new TestBatchTasklet();
  }

  @Bean
  public Step stepOne(){
    return steps.get("stepOne")
        .tasklet(testBatchTasklet())
        .build();
  }

  @Bean
  public Job testJob(){
    return jobs.get("testJob")
        .incrementer(new RunIdIncrementer())
        .start(stepOne())
        .build();
  }
}
