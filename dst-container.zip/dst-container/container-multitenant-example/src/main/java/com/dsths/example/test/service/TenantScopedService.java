package com.dsths.example.test.service;

import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.common.container.multitenant.scope.TenantScoped;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.SQLException;


@Service
@TenantScoped
public class TenantScopedService {
  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Value("${foo.bar}")
  private String fooBarValue;

  @Autowired
  private TenantScopedProperty tenantScopedProperty;

  @Autowired
  @Qualifier("datasource_2")
  private DataSource ds2;

  public String identity() {
    try (Connection conn = ds2.getConnection()) {
      conn.getMetaData();
    } catch (SQLException e) {
      e.printStackTrace();
    }
    return String.format(
        "%s -> tenant: %s | foo.bar: %s | some.property(TenantScoped): %s",
        "TenantScopedService-" + Integer.toHexString(this.hashCode()), tenantRequestContext.getCurrentTenant(),
        fooBarValue, tenantScopedProperty.getProperty()
    );
  }
}
