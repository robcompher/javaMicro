package com.dsths.example.test.service;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

/**
 * Created by DT214743 on 1/8/2019.
 */
@Service
public class SingletonService {
  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Value("${foo.bar}")
  private String fooBarValue;

  @Autowired
  private TenantScopedProperty tenantScopedProperty;

  @Autowired
  @Qualifier("datasource_2")
  private DataSource ds2;

  public String identity() {
    try (Connection conn = ds2.getConnection()) {
      DatabaseMetaData metaData = conn.getMetaData();
    } catch (SQLException e) {
      //
    }
    return String.format(
        "%s -> tenant: %s | foo.bar: %s | some.property(TenantScoped): %s",
        "SingletonService-" + Integer.toHexString(this.hashCode()), tenantRequestContext.getCurrentTenant(),
        fooBarValue, tenantScopedProperty.getProperty()
    );
  }
}
