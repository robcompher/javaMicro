package com.dsths.example.test.controller;

import com.dsths.common.container.multitenant.TenantRequestContext;
import com.dsths.example.test.service.AsyncServices;
import com.dsths.example.test.service.SingletonService;
import com.dsths.example.test.service.TenantScopedService;
import org.springframework.batch.core.Job;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobParameters;
import org.springframework.batch.core.JobParametersBuilder;
import org.springframework.batch.core.launch.JobLauncher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;


@RestController
public class EchoController {
  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Autowired
  private TenantScopedService tenantScopedService;

  @Autowired
  private SingletonService singletonService;

  @Autowired
  private AsyncServices asyncServices;

  @Autowired
  private JobLauncher jobLauncher;

  @Autowired
  @Qualifier("testJob")
  private Job job;

  @RequestMapping("/echo")
  public Map echo(@RequestParam String arg) throws Exception {
    Map<String, Object> result = new HashMap<>();
    result.put("tenant", tenantRequestContext.getCurrentTenant());
    result.put("identity", tenantScopedService.identity());
    result.put("echo", arg);
    result.put("singleton-identity", singletonService.identity());
    return result;
  }

  @RequestMapping("/asyncCall")
  public String asyncCall() throws Exception {
    return asyncServices.process().get();
  }

  @RequestMapping("/launchJob")
  public String launchJob() throws Exception {
    JobParameters params = new JobParametersBuilder()
        .addString("JobID", String.valueOf(System.currentTimeMillis()))
        .toJobParameters();
    JobExecution jobExecution = jobLauncher.run(job, params);
    while(jobExecution.isRunning()) {
      Thread.sleep(100);
    }
    return jobExecution.getExitStatus().getExitCode();
  }
}
