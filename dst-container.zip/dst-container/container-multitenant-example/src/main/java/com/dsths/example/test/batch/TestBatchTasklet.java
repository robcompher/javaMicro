package com.dsths.example.test.batch;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Created by DT214743 on 10/28/2019.
 */
public class TestBatchTasklet implements Tasklet {
  private static final Logger log = LogManager.getLogger(TestBatchTasklet.class);
  @Autowired
  private TenantRequestContext tenantRequestContext;

  public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext) throws Exception {
    log.info("Tenant " + tenantRequestContext.getCurrentTenant());
    return RepeatStatus.FINISHED;
  }
}
