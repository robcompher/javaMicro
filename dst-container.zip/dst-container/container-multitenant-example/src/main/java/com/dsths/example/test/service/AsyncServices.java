package com.dsths.example.test.service;

import com.dsths.common.container.multitenant.TenantRequestContext;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.scheduling.annotation.AsyncResult;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Future;

/**
 * Created by DT214743 on 3/6/2019.
 */
@Component
public class AsyncServices {
  private static final Logger log = LogManager.getLogger(AsyncServices.class);

  @Autowired
  private TenantRequestContext tenantRequestContext;

  @Async
  public Future<String> process() throws InterruptedException {
    log.info("###Start Processing with Thread id: " + Thread.currentThread().getId());

    // Sleep 3s for simulating the processing
    Thread.sleep(3000);

    String processInfo = String.format("Processing is Done with Thread id= %d, tenant= %s", Thread.currentThread().getId(),
        tenantRequestContext.getCurrentTenant());
    return new AsyncResult<>(processInfo);
  }
}
