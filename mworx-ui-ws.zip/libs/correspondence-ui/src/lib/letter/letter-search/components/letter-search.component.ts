import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, ListChoice, LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector, ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { LetterService } from '../../services/letter.service';
import { LetterSearchQuery } from '../../state/letter-search.query';
import { LetterSearchState } from '../../state/letter-search.store';
import { LETTER_PAGINATOR } from '../letter-search-paginator';

@Component({
  selector: 'correspondence-letter-search',
  templateUrl: './letter-search.component.html',
  styleUrls: ['./letter-search.component.scss'],
})
@UntilDestroy()
export class LetterSearchComponent implements OnInit {
  letterSearchForm: FormGroup;
  gridApi: GridApi;
  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
  };
  letterActiveValues$: Observable<Array<ListChoice>>;
  lobLibListItems$: Observable<LibList[]>;
  columnDefs: any;

  constructor(
    private fb: FormBuilder,
    private lookupService: LookupService,
    private configService: ConfigService,
    private letterSearchQuery: LetterSearchQuery,
    private errorService: ErrorService,
    private dialog: MatDialog,
    private authService: SessionService,
    private letterService: LetterService,
    private notificationService: NotificationService,
    private requestService: RequestService,
    @Inject(LETTER_PAGINATOR)
    public paginatorRef: GridPaginatorPlugin<LetterSearchState>
  ) {}

  ngOnInit(): void {
    this.letterActiveValues$ = this.lookupService.getYesNoBoth();
    this.lobLibListItems$ = this.lookupService.getAllLobs();
    this.initColumns();
    this.letterSearchForm = this.fb.group({
      letterType: [''],
      letterName: [''],
      letterCode: [''],
      lobId: [''],
      active: ['Y'],
      lob: new FormGroup({
        lobId: new FormControl(this.authService.getCurrentUserLob().lobId),
      }),
    });
    if (this.authService.currentUser().currentLobName !== this.configService.get('auth.constants.systemLob')) {
      this.letterSearchForm.controls['lobId'].disable();
      this.letterSearchForm.patchValue({ lobId: this.authService.getCurrentUserLob().lobId });
    }

    this.paginatorRef.requestFunction = () => this.letterService.search();
    this.paginatorRef.filtersUpdateFunction = criteria => this.letterService.updateSearchCriteria(criteria);
  }

  initColumns() {
    this.columnDefs = [
      {
        headerName: 'Line Of Business',
        field: 'lobId',
        sortable: false,
        valueGetter: { data: this.lobLibListItems$, idField: 'id', labelField: 'label' },
      },
      { headerName: 'Correspondence Name', field: 'letterName' },
      { headerName: 'Correspondence Type', field: 'letterType' },
      { headerName: 'Correspondence Code', field: 'letterCode' },
      { headerName: 'Active', field: 'active' },
      {
        headerName: 'Actions',
        colId: 'Actions',
        minWidth: 150,
        sortable: false,
        cellRenderer: 'buttonRenderer',
        cellRendererParams: {
          actions: [
            {
              onClick: this.onViewActionClick.bind(this),
              label: 'View',
              icon: 'remove_red_eye',
              color: 'primary',
              permissions: ['PERMIT_CORRESPONDENCE_LETTER_VIEW'],
            },
            {
              onClick: this.onEditActionClick.bind(this),
              label: 'Edit',
              icon: 'edit',
              color: 'primary',
              permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'],
            },
            {
              onClick: this.onDeleteActionClick.bind(this),
              label: 'Delete',
              icon: 'delete',
              color: 'warn',
              show: this.showAction.bind(this),
              permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'],
            },
          ],
        },
      },
    ];
  }

  showAction(action: any, data: any) {
    return data.active !== 'N';
  }

  onSearch($event: any) {
    const clientQuery = this.letterSearchForm.value;

    clientQuery.lob = {
      lobId: clientQuery.lobId,
    };
    this.letterService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset($event: any) {
    this.letterSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.letterSearchForm.reset(criteria);
      if (this.authService.currentUser().currentLobName !== this.configService.get('auth.constants.systemLob')) {
        this.letterSearchForm.patchValue({ lobId: this.authService.getCurrentUserLob().lobId });
      }
      this.onSearch($event);
    });
  }

  onViewActionClick(e: any) {
    const ngZone = AppInjector.get(NgZone);
    ngZone.run(() => {
      this.requestService.navigate(['/correspondence/letter/view'], { state: { data: e.rowData } });
    });
  }

  onEditActionClick(e: any) {
    const ngZone = AppInjector.get(NgZone);
    ngZone.run(() => {
      this.requestService.navigate(['/correspondence/letter/edit'], { state: { data: e.rowData } });
    });
  }

  openConfirmDialog(msg: string) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('metadata.constants.messages.confirmMsg'))
      .afterClosed()
      .pipe(
        untilDestroyed(this),
        filter(res => !!res)
      )

      .subscribe(() => {
        this.letterService
          .deleteByID(e.rowData.id)
          .pipe(
            untilDestroyed(this),
            catchError((error: HttpErrorResponse) => {
              return this.errorService.handleTableValidationErrors(error);
            })
          )
          .subscribe(() => {
            this.notificationService.showSuccess(
              this.configService.get('correspondence.constants.messages.letterMsg')('deleted', e.rowData.letterName)
            );
            this.onReset(e);
          });
      });
  }
}
