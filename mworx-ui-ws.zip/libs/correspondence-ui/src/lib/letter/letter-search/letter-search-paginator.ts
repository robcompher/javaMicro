import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { LetterSearchQuery } from '../state/letter-search.query';

export const LETTER_PAGINATOR = new InjectionToken('LETTER_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const letterQuery = inject(LetterSearchQuery);

    return new GridPaginatorPlugin(letterQuery);
  },
});
