import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';
import { LetterSearchModule } from '../letter-search/letter-search.module';
import { LetterDashboardComponent } from './components/letter-dashboard.component';

@NgModule({
  declarations: [LetterDashboardComponent],
  imports: [CommonModule, MatButtonModule, MatIconModule, RouterModule, SharedUiLayoutModule, SharedSessionModule, LetterSearchModule],

  exports: [LetterDashboardComponent],
})
export class LetterDashboardModule {}
