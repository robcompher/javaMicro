import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LetterDashboardComponent } from './letter-dashboard.component';

describe('LetterDashboardComponent', () => {
  let component: LetterDashboardComponent;
  let fixture: ComponentFixture<LetterDashboardComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LetterDashboardComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LetterDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
