import { Component, OnInit, ViewChild } from '@angular/core';
import { LetterSearchComponent } from '../../letter-search/components/letter-search.component';

@Component({
  selector: 'correspondence-letter-dashboard',
  templateUrl: './letter-dashboard.component.html',
  styleUrls: ['./letter-dashboard.component.scss'],
})
export class LetterDashboardComponent implements OnInit {
  @ViewChild('letterSearch')
  private letterSearch: LetterSearchComponent;

  constructor() {}

  ngOnInit(): void {}

  onReset($event: any) {
    this.letterSearch.onReset($event);
  }

  onSearch($event: any) {
    this.letterSearch.onSearch($event);
  }
}
