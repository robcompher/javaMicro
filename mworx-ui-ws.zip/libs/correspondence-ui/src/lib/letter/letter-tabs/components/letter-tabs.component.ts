import { Component, NgZone, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { ID } from '@datorama/akita';
import { AppInjector, EventService, RequestService, StoresResetService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest } from 'rxjs';
import { LetterService } from '../../services/letter.service';
import { LetterQuery } from '../../state/letter.query';
@UntilDestroy()
@Component({
  selector: 'correspondence-letter-tabs',
  templateUrl: './letter-tabs.component.html',
  styleUrls: ['./letter-tabs.component.scss'],
})
export class LetterTabsComponent implements OnInit {
  tabs = [];
  loadedStatus: Array<number>;
  showSaveButton = true;
  showResetButton = true;
  showSearchButton = false;
  showAddButton = false;
  firstTabName = 'Correspondence';

  pageTitle: string;
  id: ID;
  tabIndex = 0;

  constructor(
    private requestService: RequestService,
    private eventService: EventService,
    private letterService: LetterService,
    private letterQuery: LetterQuery,
    private storesResetService: StoresResetService
  ) {}

  ngOnInit(): void {
    this.loadedStatus = new Array<number>();

    if (this.requestService.url().search('add') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this))
        .subscribe(res => {
          this.id = res.data.id;
          this.letterService
            .getLetterById(this.id)
            .pipe(untilDestroyed(this))
            .subscribe(() => {});
          combineLatest([this.letterQuery.selectLoading(), this.letterQuery.letters$(this.id)])
            .pipe(untilDestroyed(this))
            .subscribe(([loading, letter]) => {
              if (!loading && letter) {
                this.requestService
                  .selectData()
                  .pipe(untilDestroyed(this))
                  .subscribe(data => {
                    this.pageTitle = data.title + ' : ' + letter.letterName;
                  });
              }
            });
        });
    }
    this.initTabs();
    if (this.requestService.url().search('view') !== -1) {
      this.showAddButton = false;
      this.showSaveButton = false;
      this.showResetButton = false;
    }
    //default load first tab
    this.loadedStatus.push(0);
  }

  protected initTabs() {
    this.tabs.push({
      tabName: this.firstTabName,
      content: import('../../letter-add-edit/components/letter-add-edit.component').then(({ LetterAddEditComponent }) => LetterAddEditComponent),
    });
    if (this.id) {
      this.tabs.push({
        tabName: 'Linked Tags',
        content: import('../../letter-linked-tags-search/components/letter-linked-tags-search.component').then(
          ({ LetterLinkedTagsSearchComponent }) => LetterLinkedTagsSearchComponent
        ),
      });
    }
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    if (this.loadedStatus.indexOf(tabChangeEvent.index) === -1) {
      this.loadedStatus.push(tabChangeEvent.index);
    }
    this.tabIndex = tabChangeEvent.index;
    if (this.requestService.url().search('view') === -1) {
      this.showAddButton = this.tabs[this.tabIndex].tabName !== this.firstTabName;
      this.showSaveButton = this.tabs[this.tabIndex].tabName === this.firstTabName;
      this.showResetButton = true;
    } else {
      this.showResetButton = this.tabs[this.tabIndex].tabName !== this.firstTabName;
    }
    this.showSearchButton = this.tabs[this.tabIndex].tabName !== this.firstTabName;
  }

  private whichForm(tabName: string): string {
    if (tabName === this.firstTabName) return 'correspondenceEventForm';
    else return 'linkedTagsEventForm';
  }

  onReset($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onResetForm', formName);
    }
  }

  goBackToDashboard($event) {
    if ($event) {
      const ngZone = AppInjector.get(NgZone);
      this.storesResetService.resetStore('letterTags-search');
      ngZone.run(() => {
        this.requestService.navigate(['/correspondence/letter/dashboard']);
      });
    }
  }

  onSearch($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onSearchForm', formName);
    }
  }

  onAdd($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onAddForm', formName);
    }
  }
}
