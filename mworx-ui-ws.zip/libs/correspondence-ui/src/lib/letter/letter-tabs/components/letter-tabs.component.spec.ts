import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LetterTabsComponent } from './letter-tabs.component';

describe('LetterTabsComponent', () => {
  let component: LetterTabsComponent;
  let fixture: ComponentFixture<LetterTabsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LetterTabsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LetterTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
