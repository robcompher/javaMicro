import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { LetterAddEditModule } from '../letter-add-edit';
import { LetterLinkedTagsSearchModule } from '../letter-linked-tags-search/letter-linked-tags-search.module';
import { LetterTabsComponent } from './components/letter-tabs.component';

@NgModule({
  declarations: [LetterTabsComponent],
  imports: [
    CommonModule,
    LetterAddEditModule,
    LetterLinkedTagsSearchModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    RouterModule,
    SharedUiLayoutModule,
  ],
  exports: [LetterTabsComponent],
})
export class LetterTabsModule {}
