import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { TagSearchQuery } from '../../tag/state/tag-search.query';

export const LETTER_TAG_ADD_PAGINATOR = new InjectionToken('LETTER_TAG_ADD_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const letterTagQuery = inject(TagSearchQuery);

    return new GridPaginatorPlugin(letterTagQuery);
  },
});
