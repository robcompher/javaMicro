import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LetterLinkedTagsAddComponent } from './letter-linked-tags-add.component';

describe('LetterLinkedTagsAddComponent', () => {
  let component: LetterLinkedTagsAddComponent;
  let fixture: ComponentFixture<LetterLinkedTagsAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LetterLinkedTagsAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LetterLinkedTagsAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
