import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { GridPaginatorPlugin } from '@mworx/grid';
import { LibList, LookupDataService } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService, StoresResetService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Tag } from '../../../tag/models/tag.model';
import { TagService } from '../../../tag/services/tag.service';
import { TagSearchState } from '../../../tag/state/tag-search.store';
import { LETTER_TAG_ADD_PAGINATOR } from '../letter-tag-add-paginator';
@UntilDestroy()
@Component({
  selector: 'correspondence-letter-linked-tags-add',
  templateUrl: './letter-linked-tags-add.component.html',
  styleUrls: ['./letter-linked-tags-add.component.scss'],
})
export class LetterLinkedTagsAddComponent implements OnInit {
  isSaveButtonEnabled: boolean;
  tagTypeListItems$: Observable<LibList[]>;
  pageTitle: string;
  gridApi: GridApi;
  tagSearchForm: FormGroup;
  @ViewChild('tagSearchFormDirective')
  tagSearchFormDirective: FormGroupDirective;
  lookupDataService: LookupDataService;
  tagIds: Tag[] = [];

  columnDefs = [
    {
      field: 'Select',
      sortable: false,
      checkboxSelection: true,
      maxWidth: 80,
    },
    {
      headerName: 'Tag Name',
      field: 'tagName',
      cellRenderer: 'showTooltipCellRenderer',
      cellRendererParams: { tooltipField: 'bizDescription', tooltipLabel: 'Description' },
    },
    { headerName: 'Tag Type', field: 'tagTypeValue', sortable: false },

    { headerName: 'Already Linked', valueGetter: (params: ValueGetterParams) => this.getLetterAssigned(params), sortable: false },
  ];
  gridOptions: GridOptions = {
    rowSelection: 'multiple',
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
    isRowSelectable: function (rowNode) {
      return rowNode.data ? !Array.isArray(rowNode.data.letters) || !rowNode.data.letters.length : false;
    },
    onRowSelected: event => {
      const index = this.tagIds.findIndex(x => x.id === event.node.data.id);
      if (event.node.isSelected()) {
        if (index === -1) {
          this.tagIds.push(event.node.data);
        }
      } else {
        if (index !== -1) {
          this.tagIds.splice(index, 1);
        }
      }
    },
    onSelectionChanged: () => {
      this.isSaveButtonEnabled = this.tagIds.length > 0;
    },
    onPaginationChanged: () => {
      this.gridApi?.forEachNode(node => (this.tagIds.findIndex(x => x.id === node.data.id) !== -1 ? node.setSelected(true) : null));
    },
  };

  constructor(
    private storesResetService: StoresResetService,
    private dialogRef: MatDialogRef<LetterLinkedTagsAddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    @Inject(LETTER_TAG_ADD_PAGINATOR)
    public paginatorRef: GridPaginatorPlugin<TagSearchState>,
    private tagService: TagService,
    private configService: ConfigService,
    private fb: FormBuilder,
    private errorService: ErrorService,
    private notifyService: NotificationService
  ) {
    this.lookupDataService = AppInjector.get(LookupDataService);
  }

  ngOnInit(): void {
    this.isSaveButtonEnabled = false;
    this.pageTitle = 'Add Tags to ' + this.data.letter.letterName;
    this.tagTypeListItems$ = this.lookupDataService.getLibListByCategoryWithLOB(
      this.configService.get('metadata.constants.categories.tagType'),
      this.data.letter.lobId
    );
    this.tagSearchForm = this.fb.group({
      tagType: [''],
      tagName: [''],
      active: ['Y'],
    });
    this.tagSearchForm.patchValue({ libLtrId: this.data.letter.id, lob: { lobId: this.data.letter.lobId } });

    this.paginatorRef.requestFunction = () => this.tagService.searchLinkedLetterTagWithLetter();

    this.paginatorRef.filtersUpdateFunction = criteria => {
      this.tagService.updateSearchCriteria({ ...criteria, ...{ libLtrId: this.data.letter.id, lob: { lobId: this.data.letter.lobId } } });
    };
  }

  getLetterAssigned(params: ValueGetterParams) {
    let letterAssigned = '';
    if (params.data) {
      if (!Array.isArray(params.data.letters) || !params.data.letters.length) {
        letterAssigned = 'N';
      } else {
        letterAssigned = 'Y';
      }
    }

    return letterAssigned;
  }

  closePopup(event?: string) {
    this.storesResetService.resetStore('tag-search');
    this.dialogRef.close({ event: event ? event : null });
  }

  onReset() {
    this.tagSearchFormDirective.resetForm();
    this.tagSearchForm.patchValue({ libLtrId: this.data.letter.id, lob: { lobId: this.data.letter.lobId } });
    this.onSearch();
  }

  onSearch() {
    this.tagService.updateSearchCriteria(this.tagSearchForm.value);
    this.gridApi.onFilterChanged();
  }

  onSave() {
    const multipleTagAdd = {
      active: 'Y',
      libLtrId: this.data.letter.id,
      libTagIds: this.getTagIds(),
      libTagId: null,
    };
    this.tagService
      .addMultipleLinkedTags(multipleTagAdd)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          return this.errorService.handleTableValidationErrors(response);
        })
      )
      .subscribe(() => {
        this.notifyService.showSuccess(
          this.configService.get('defaultMessages.actionResponse')('added', 'Tags to Letter', this.data.letter.letterName)
        );
        this.closePopup('saved');
      });
  }

  private getTagIds() {
    const tagIds = this.tagIds.map(rec => rec.id);

    return tagIds;
  }
}
