import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { LetterTagsSearchQuery } from '../state/letter-tags-search.query';

export const LETTER_TAG_PAGINATOR = new InjectionToken('LETTER_TAG_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const letterTagQuery = inject(LetterTagsSearchQuery);

    return new GridPaginatorPlugin(letterTagQuery);
  },
});
