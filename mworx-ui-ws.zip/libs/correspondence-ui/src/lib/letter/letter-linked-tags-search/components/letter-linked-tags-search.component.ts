import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, ListChoice, LookupService } from '@mworx/lookup';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { combineLatest, Observable } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { LetterLinkedTagsAddComponent } from '../../letter-linked-tags-add/components/letter-linked-tags-add.component';
import { Letter } from '../../models/letter.model';
import { LetterService } from '../../services/letter.service';
import { LetterTagsSearchQuery } from '../../state/letter-tags-search.query';
import { LetterTagsSearchState } from '../../state/letter-tags-search.store';
import { LetterQuery } from '../../state/letter.query';
import { LETTER_TAG_PAGINATOR } from '../letter-tag-search-paginator';

@Component({
  selector: 'correspondence-letter-linked-tags-search',
  templateUrl: './letter-linked-tags-search.component.html',
  styleUrls: ['./letter-linked-tags-search.component.scss'],
})
@UntilDestroy()
export class LetterLinkedTagsSearchComponent implements OnInit {
  letterTagsSearchForm: FormGroup;
  gridApi: GridApi;
  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
  };
  tagActiveValues$: Observable<Array<ListChoice>>;
  tagTypeListItems$: Observable<LibList[]>;
  columnDefs: any;
  letter: Letter;

  constructor(
    private fb: FormBuilder,
    private lookupService: LookupService,
    private configService: ConfigService,
    private letterTagSearchQuery: LetterTagsSearchQuery,
    private errorService: ErrorService,
    private dialog: MatDialog,
    private letterService: LetterService,
    private notificationService: NotificationService,
    private requestService: RequestService,
    private eventService: EventService,
    private letterQuery: LetterQuery,
    @Inject(LETTER_TAG_PAGINATOR)
    public paginatorRef: GridPaginatorPlugin<LetterTagsSearchState>
  ) {}

  ngOnInit(): void {
    this.tagActiveValues$ = this.lookupService.getYesNoBoth();
    this.tagTypeListItems$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.tagType'));

    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.letterService
          .getLetterById(res.data.id)
          .pipe(untilDestroyed(this))
          .subscribe(() => {});
        combineLatest([this.letterQuery.selectLoading(), this.letterQuery.letters$(res.data.id)])
          .pipe(untilDestroyed(this))
          .subscribe(([loading, letter]) => {
            if (!loading && letter) {
              this.letter = letter;
            }
          });
      });

    this.initColumns();
    this.initEventSubscribers();
    this.letterTagsSearchForm = this.fb.group({
      tagType: [''],
      tagName: [''],
      biz_description: [''],
      active: ['Y'],
    });
    this.paginatorRef.requestFunction = () => this.letterService.searchLetterTags(this.letter.id, this.letter.lobId);
    this.paginatorRef.filtersUpdateFunction = criteria => this.letterService.updateLetterTagSearchCriteria(criteria);
  }

  initColumns() {
    this.columnDefs = [
      {
        headerName: 'Tag Name',
        field: 'tag.tagName',
        cellRenderer: 'showTooltipCellRenderer',
        cellRendererParams: { tooltipField: 'tag.bizDescription', tooltipLabel: 'Description' },
      },
      { headerName: 'Tag Type', field: 'tag.tagTypeValue', sortable: false },
      { headerName: 'Data Format', field: 'tag.dataformat' },
      { headerName: 'Active', field: 'active' },
      {
        headerName: 'Actions',
        colId: 'Actions',
        minWidth: 150,
        sortable: false,
        cellRenderer: 'buttonRenderer',
        cellRendererParams: {
          actions: [
            {
              onClick: this.onDeleteActionClick.bind(this),
              label: 'Delete',
              icon: 'delete',
              color: 'warn',
              show: this.showAction.bind(this),
              permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'],
            },
          ],
        },
      },
    ];
  }

  initEventSubscribers() {
    this.eventService
      .on('letterChange')
      .pipe(
        untilDestroyed(this),
        filter(letter => !!letter)
      )
      .subscribe(letter => {
        this.letter = letter;
      });
    this.eventService
      .on('onSearchForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'linkedTagsEventForm')
      )
      .subscribe(() => {
        this.onSearch();
      });
    this.eventService
      .on('onResetForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'linkedTagsEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });
    this.eventService
      .on('onAddForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'linkedTagsEventForm')
      )
      .subscribe(() => {
        this.onAdd();
      });
  }

  showAction(action: any, data: any) {
    return data.active !== 'N' && this.requestService.url().search('view') === -1;
  }

  onAdd() {
    this.dialog
      .open(LetterLinkedTagsAddComponent, {
        minWidth: '65%',
        data: {
          letter: this.letter,
        },
      })
      .afterClosed()
      .pipe(
        untilDestroyed(this),
        filter(res => res?.event === 'saved')
      )
      .subscribe(() => {
        this.onReset();
      });
  }
  onSearch() {
    const clientQuery = this.letterTagsSearchForm.value;

    clientQuery.lob = {
      lobId: clientQuery.lobId,
    };
    this.letterService.updateLetterTagSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset() {
    this.letterTagSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.letterTagsSearchForm.reset(criteria);
      this.onSearch();
    });
  }

  openConfirmDialog(msg: string) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('metadata.constants.messages.confirmMsg'))
      .afterClosed()
      .pipe(
        untilDestroyed(this),
        filter(res => !!res)
      )

      .subscribe(() => {
        this.letterService
          .deleteLetterTagByID(e.rowData.id)
          .pipe(
            untilDestroyed(this),
            catchError((error: HttpErrorResponse) => {
              return this.errorService.handleValidationErrors(this.letterTagsSearchForm, error);
            })
          )
          .subscribe(() => {
            this.notificationService.showSuccess(
              this.configService.get('correspondence.constants.messages.tagMsg')('deleted', e.rowData.tag.tagName)
            );
            this.onReset();
          });
      });
  }
}
