import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LetterLinkedTagsSearchComponent } from './letter-linked-tags-search.component';

describe('LetterLinkedTagsSearchComponent', () => {
  let component: LetterLinkedTagsSearchComponent;
  let fixture: ComponentFixture<LetterLinkedTagsSearchComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LetterLinkedTagsSearchComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LetterLinkedTagsSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
