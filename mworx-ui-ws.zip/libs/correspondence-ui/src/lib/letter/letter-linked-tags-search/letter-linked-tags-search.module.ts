import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { LetterLinkedTagsSearchComponent } from './components/letter-linked-tags-search.component';

@NgModule({
  declarations: [LetterLinkedTagsSearchComponent],
  imports: [
    CommonModule,
    SharedUiGridModule,
    SharedUiLayoutModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatSelectModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    SharedUiFormsModule,
  ],
  exports: [LetterLinkedTagsSearchComponent],
})
export class LetterLinkedTagsSearchModule {}
