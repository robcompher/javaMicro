import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse, withTransaction } from '@datorama/akita';
import { LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector } from '@mworx/util';
import { Observable, Subject } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { LetterSearchCriteria } from '../models/letter-search.model';
import { LetterTagsSearchCriteria } from '../models/letter-tags-search.model';
import { Letter } from '../models/letter.model';
import { LinkLetterTag } from '../models/link-letter-tag.model ';
import { LetterSearchQuery } from '../state/letter-search.query';
import { LetterSearchStore } from '../state/letter-search.store';
import { LetterTagsSearchQuery } from '../state/letter-tags-search.query';
import { LetterTagsSearchStore } from '../state/letter-tags-search.store';
import { LetterQuery } from '../state/letter.query';
import { LetterStore } from '../state/letter.store';

@Injectable({ providedIn: 'root' })
export class LetterService {
  private http: HttpClient;
  private lookupService: LookupService;
  private configService: ConfigService;
  private authService: SessionService;
  private letterSearchQuery: LetterSearchQuery;
  private letterQuery: LetterQuery;
  private letterStore: LetterStore;
  private letterSearchStore: LetterSearchStore;
  private letterTagsSearchStore: LetterTagsSearchStore;
  private letterTagsSearchQuery: LetterTagsSearchQuery;
  onMetaEventFormReset = new Subject<void>();

  constructor() {
    this.http = AppInjector.get(HttpClient);
    this.lookupService = AppInjector.get(LookupService);
    this.configService = AppInjector.get(ConfigService);
    this.http = AppInjector.get(HttpClient);
    this.authService = AppInjector.get(SessionService);
    this.letterSearchQuery = AppInjector.get(LetterSearchQuery);
    this.letterQuery = AppInjector.get(LetterQuery);
    this.letterStore = AppInjector.get(LetterStore);
    this.letterSearchStore = AppInjector.get(LetterSearchStore);
    this.letterTagsSearchStore = AppInjector.get(LetterTagsSearchStore);
    this.letterTagsSearchQuery = AppInjector.get(LetterTagsSearchQuery);
  }
  public search(): Observable<PaginationResponse<Letter>> {
    const lob = this.lookupService.getCurrentUserLob();

    let criteria = { ...{ lob }, ...this.letterSearchQuery.getValue().ui.filters };
    if (!criteria.lob?.lobId && this.authService.currentUser().currentLobName !== this.configService.get('auth.constants.systemLob')) {
      criteria = { ...this.letterSearchQuery.getValue().ui.filters, ...{ lob } };
    }

    return this.http.post<PaginationResponse<Letter>>(this.configService.get('correspondence.constants.url.letterSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<Letter>;
      })
    );
  }

  public searchLetterTags(letterId: ID, lobId: number): Observable<PaginationResponse<LinkLetterTag>> {
    const lob = {
      lobId: lobId,
    };

    const criteria = { ...this.letterTagsSearchQuery.getValue().ui.filters, ...{ libLtrId: letterId }, ...{ lob } };

    return this.http.post<PaginationResponse<LinkLetterTag>>(this.configService.get('correspondence.constants.url.letterTagSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<LinkLetterTag>;
      })
    );
  }

  public updateLetterTagSearchCriteria(criteria: LetterTagsSearchCriteria) {
    const prevCriteria = this.letterTagsSearchStore.getValue().ui.filters;
    this.letterTagsSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public deleteByID(id: ID): Observable<any> {
    return this.http
      .put<any>(this.configService.get('correspondence.constants.url.letterDelete'), { id: id })
      .pipe(
        tap(resp => {
          this.letterStore.remove(id);
        })
      );
  }
  public deleteLetterTagByID(id: ID): Observable<any> {
    return this.http
      .put<any>(this.configService.get('correspondence.constants.url.letterTagDelete'), { id: id })
      .pipe();
  }

  public updateSearchCriteria(criteria: LetterSearchCriteria) {
    const prevCriteria = this.letterSearchStore.getValue().ui.filters;
    this.letterSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public getLetterById(id: ID): Observable<Letter> {
    return this.letterQuery.selectEntity(id).pipe(
      switchMap(cacheEntry => {
        const apiCall = this.http
          .post<any>(this.configService.get('correspondence.constants.url.letterById'), { id: id })
          .pipe(
            withTransaction(response => {
              if (response) {
                this.letterStore.upsert(id, response);
                this.letterStore.setHasCache(true);
              }
            }),
            switchMap(res => this.letterQuery.selectEntity(id))
          );

        return cacheEntry ? this.letterQuery.selectEntity(id) : apiCall;
      })
    );
  }

  public addOrUpdateLetter(letter: Letter): Observable<any> {
    if (this.letterQuery.hasEntity(letter.id) && Boolean(letter.id)) {
      return this.http
        .put<Letter>(this.configService.get('correspondence.constants.url.addUpdateLetter'), { ...this.letterQuery.getEntity(letter.id), ...letter })
        .pipe(
          tap(currentLetter => {
            this.letterStore.upsert(currentLetter.id, currentLetter);
            this.letterSearchStore.upsert(currentLetter.id, currentLetter);
          })
        );
    } else {
      return this.http.post<Letter>(this.configService.get('correspondence.constants.url.addUpdateLetter'), letter).pipe(
        tap(currentLetter => {
          this.letterStore.upsert(currentLetter.id, currentLetter);
          this.letterSearchStore.upsert(currentLetter.id, currentLetter);
        })
      );
    }
  }

  isRefreshSearchGrid(): boolean {
    return this.letterSearchStore.isRefreshSearchGrid();
  }

  setRefreshSearchGrid(value: boolean) {
    this.letterSearchStore.setRefreshSearchGrid(value);
  }
}
