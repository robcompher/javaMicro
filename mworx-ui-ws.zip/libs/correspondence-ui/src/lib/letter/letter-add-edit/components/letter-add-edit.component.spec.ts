import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LetterAddEditComponent } from './letter-add-edit.component';

describe('LetterAddEditComponent', () => {
  let component: LetterAddEditComponent;
  let fixture: ComponentFixture<LetterAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LetterAddEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LetterAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
