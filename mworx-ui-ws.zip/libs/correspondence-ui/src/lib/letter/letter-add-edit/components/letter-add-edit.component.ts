import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { LibList, LookupDataService, LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector, ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest, Observable } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { LetterService } from '../../services/letter.service';
import { LetterQuery } from '../../state/letter.query';

@UntilDestroy()
@Component({
  selector: 'correspondence-letter-add-edit',
  templateUrl: './letter-add-edit.component.html',
  styleUrls: ['./letter-add-edit.component.scss'],
})
export class LetterAddEditComponent implements OnInit {
  letterAddEditForm: FormGroup;
  private fb: FormBuilder;
  id: ID;
  letterService: LetterService;
  lobLibListItems$: Observable<LibList[]>;
  benefitNameListItems$: Observable<LibList[]>;
  lobId: number;

  action: string;
  @ViewChild('letterAddEditFormDirective')
  letterAddEditFormDirective: FormGroupDirective;
  errorService: ErrorService;
  notifyService: NotificationService;
  configService: ConfigService;
  authService: SessionService;
  letterQuery: LetterQuery;
  lookupService: LookupService;
  lookupDataService: LookupDataService;
  eventService: EventService;
  constructor(private requestService: RequestService) {
    this.fb = AppInjector.get(FormBuilder);
    this.letterService = AppInjector.get(LetterService);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.configService = AppInjector.get(ConfigService);
    this.letterQuery = AppInjector.get(LetterQuery);
    this.authService = AppInjector.get(SessionService);
    this.lookupService = AppInjector.get(LookupService);
    this.eventService = AppInjector.get(EventService);
    this.lookupDataService = AppInjector.get(LookupDataService);
  }

  ngOnInit(): void {
    this.buildForm();
    this.initEventSubscribers();
    this.lobLibListItems$ = this.lookupService.getAllLobs();
    this.benefitNameListItems$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.benefitName'));
    this.letterAddEditForm
      .get('lobId')
      .valueChanges.pipe(
        untilDestroyed(this),
        filter(res => !!res)
      )
      .subscribe(lobId => {
        this.benefitNameListItems$ = this.lookupDataService.getLibListByCategoryWithLOB(
          this.configService.get('metadata.constants.categories.benefitName'),
          lobId
        );
      });
    if (this.authService.currentUser().currentLobName !== this.configService.get('auth.constants.systemLob')) {
      this.letterAddEditForm.controls['lobId'].disable();
      this.lobId = this.authService.getCurrentUserLob().lobId;
      this.letterAddEditForm.patchValue({ lobId: this.lobId });
    }

    if (this.requestService.url().search('add') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this))
        .subscribe(res => {
          this.id = res.data.id;
          this.letterService
            .getLetterById(this.id)
            .pipe(untilDestroyed(this))
            .subscribe(() => {});
          combineLatest([this.letterQuery.selectLoading(), this.letterQuery.letters$(this.id)])
            .pipe(untilDestroyed(this))
            .subscribe(([loading, letter]) => {
              if (!loading && letter) {
                this.action = 'updated';
                if (this.requestService.url().search('view') !== -1) {
                  this.letterAddEditForm.disable();
                }
                this.letterAddEditForm.patchValue(letter, { emitEvent: true });
              }
            });
        });
    } else {
      this.action = 'created';
    }
  }

  private initializeData() {
    if (this.id) {
      this.letterQuery
        .letters$(this.id)
        .pipe(untilDestroyed(this))
        .subscribe(u => {
          this.letterAddEditFormDirective.resetForm(u);
        });
    } else if (this.letterAddEditFormDirective) {
      this.letterAddEditFormDirective.resetForm({ active: 'Y', lobId: this.lobId });
    }
  }

  private buildForm() {
    this.letterAddEditForm = this.fb.group({
      letterName: [null, [Validators.required]],
      letterType: [null, [Validators.required]],
      legacySystemId: [null],
      benefitName: [null],
      description: [null],
      letterCode: [null, [Validators.required]],
      active: ['Y'],
      lobId: [null, [Validators.required]],
    });
  }

  initEventSubscribers() {
    this.eventService
      .on('onResetForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'correspondenceEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });
  }

  onReset() {
    this.initializeData();
  }

  onSubmit() {
    if (this.letterAddEditForm.invalid) {
      return;
    }
    const letterForm = this.letterAddEditForm.value;
    letterForm.id = this.id;
    if (this.lobId) {
      letterForm.lobId = this.lobId;
    }

    this.letterService
      .addOrUpdateLetter(letterForm)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.letterAddEditForm, error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')(this.action, 'Correspondence', response.letterName));
        this.letterService.setRefreshSearchGrid(true);
        this.eventService.dispatch('letterChange', response);
        if (!this.id) {
          this.requestService.navigate(['/correspondence/letter/edit'], { state: { data: response } });
        }
      });
  }
}
