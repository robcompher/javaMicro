import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule } from '@angular/router';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { LetterAddEditComponent } from './components/letter-add-edit.component';

@NgModule({
  declarations: [LetterAddEditComponent],
  imports: [
    CommonModule,
    SharedUiLayoutModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatIconModule,
    SharedUiGridModule,
    ReactiveFormsModule,
    SharedUtilModule,
    SharedUiFormsModule,
    RouterModule,
  ],
  exports: [LetterAddEditComponent],
})
export class LetterAddEditModule {}
