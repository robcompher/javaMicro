import { ID } from '@datorama/akita';

export interface Letter {
  id: ID;
  lobId: number;
  letterType: string;
  letterName: string;
  description: string;
  letterCode: string;
  active: string;
  kegacySystemId: string;
  benefitName: number;
}
