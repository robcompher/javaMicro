import { SearchCriteria } from '@mworx/grid';

export interface LetterTagsSearchCriteria extends SearchCriteria {
  libLtrId: number;
  libTagId: number;
  letterType: string;
  letterName: string;
  tagType: number;
  tagName: string;
  biz_description: string;
  active: string;
  lob: {
    lobId: number;
  };
}
