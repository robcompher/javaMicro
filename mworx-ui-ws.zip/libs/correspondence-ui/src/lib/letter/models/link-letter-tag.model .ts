import { ID } from '@datorama/akita';
import { Tag } from '../../tag/models/tag.model';
import { Letter } from './letter.model';

export interface LinkLetterTag {
  id: ID;
  active: string;
  letter: Letter;
  tag: Tag;
}
