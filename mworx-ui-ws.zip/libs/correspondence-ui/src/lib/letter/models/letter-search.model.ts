import { SearchCriteria } from '@mworx/grid';

export interface LetterSearchCriteria extends SearchCriteria {
  letterType: string;
  letterName: string;
  letterCode: string;
  benefitName: number;
  active: string;
  lob: {
    lobId: number;
  };
}
