import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { LetterSearchCriteria } from '../models/letter-search.model';
import { Letter } from '../models/letter.model';

export interface LetterSearchState extends EntityState<Letter> {}
let refreshSearchGrid = false;
const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'letterName',
        sortOrder: 'asc',
      },
      letterType: null,
      letterName: null,
      letterCode: null,
      benefitName: null,
      active: 'Y',
      lob: {
        lobId: null,
      },
    } as LetterSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'letterSearch', idKey: 'id', resettable: true })
export class LetterSearchStore extends EntityStore<LetterSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<LetterSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
