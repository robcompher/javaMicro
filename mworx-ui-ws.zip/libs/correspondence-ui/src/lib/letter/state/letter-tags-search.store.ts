import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { LetterTagsSearchCriteria } from '../models/letter-tags-search.model';
import { LinkLetterTag } from '../models/link-letter-tag.model ';

export interface LetterTagsSearchState extends EntityState<LinkLetterTag> {}

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'effDate',
        sortOrder: 'desc',
      },
      libLtrId: null,
      libTagId: null,
      letterType: null,
      letterName: null,
      tagType: null,
      tagName: null,
      biz_description: null,
      active: 'Y',
      lob: {
        lobId: null,
      },
    } as LetterTagsSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'letterTags-search', idKey: 'id', resettable: true })
export class LetterTagsSearchStore extends EntityStore<LetterTagsSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<LetterTagsSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
