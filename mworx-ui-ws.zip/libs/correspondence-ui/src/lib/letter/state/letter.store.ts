import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Letter } from '../models/letter.model';

export interface LetterState extends EntityState<Letter> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'letter', idKey: 'id' })
export class LetterStore extends EntityStore<LetterState> {
  constructor() {
    super();
  }
}
