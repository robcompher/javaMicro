import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { LetterTagsSearchState, LetterTagsSearchStore } from './letter-tags-search.store';

@Injectable({ providedIn: 'root' })
export class LetterTagsSearchQuery extends QueryEntity<LetterTagsSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: LetterTagsSearchStore) {
    super(store);
  }
}
