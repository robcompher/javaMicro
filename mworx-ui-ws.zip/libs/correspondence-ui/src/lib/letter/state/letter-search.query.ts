import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { LetterSearchState, LetterSearchStore } from './letter-search.store';

@Injectable({ providedIn: 'root' })
export class LetterSearchQuery extends QueryEntity<LetterSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: LetterSearchStore) {
    super(store);
  }
}
