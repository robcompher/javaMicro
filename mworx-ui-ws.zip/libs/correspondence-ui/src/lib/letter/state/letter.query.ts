import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { LetterState, LetterStore } from './letter.store';

@Injectable({ providedIn: 'root' })
export class LetterQuery extends QueryEntity<LetterState> {
  constructor(protected store: LetterStore) {
    super(store);
  }

  filters$ = this.select(state => state.ui.filters);
  letters$ = id => this.selectEntity(id);
}
