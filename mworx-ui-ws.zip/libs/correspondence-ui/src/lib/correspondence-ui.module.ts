import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedLookupModule } from '@mworx/lookup';
import { CorrespondenceRoutingModule } from './correspondence-routing.module';
import { CorrespondenceJobsModule } from './correspondence/correspondence-job/correspondence-jobs.module';
import { GroupHierarchyModule } from './correspondence/group-hierarchy/group-hierarchy.module';
import { ScheduleCorrespondenceModule } from './correspondence/schedule-correspondence/schedule-correspondence.module';
import { LetterAddEditModule } from './letter/letter-add-edit/letter-add-edit.module';
import { LetterDashboardModule } from './letter/letter-dashboard/letter-dashboard.module';
import { LetterLinkedTagsAddModule } from './letter/letter-linked-tags-add/letter-linked-tags-add.module';
import { LetterSearchModule } from './letter/letter-search/letter-search.module';
import { LetterTabsModule } from './letter/letter-tabs/letter-tabs.module';
import { TagAttributeAddModule } from './tag/tag-attribute-add/tag-attribute-add.module';
import { TagDashboardModule } from './tag/tag-dashboard/tag-dashboard.module';
import { TagSearchModule } from './tag/tag-search/tag-search.module';
import { TagTabsModule } from './tag/tag-tabs/tag-tabs.module';
@NgModule({
  imports: [
    CommonModule,
    CorrespondenceRoutingModule,
    SharedLookupModule,
    CorrespondenceJobsModule,
    ScheduleCorrespondenceModule,
    LetterDashboardModule,
    LetterSearchModule,
    LetterAddEditModule,
    LetterTabsModule,
    GroupHierarchyModule,
    TagDashboardModule,
    TagSearchModule,
    TagTabsModule,
    LetterLinkedTagsAddModule,
    TagAttributeAddModule,
  ],
  declarations: [],
})
export class CorrespondenceUiModule {}
