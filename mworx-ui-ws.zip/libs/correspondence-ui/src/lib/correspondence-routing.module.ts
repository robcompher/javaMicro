import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PermitsGuard } from '@mworx/session';
import { CorrespondenceJobComponent } from './correspondence/correspondence-job/components/correspondence-job.component';
import { ScheduleCorrespondenceComponent } from './correspondence/schedule-correspondence/components/schedule-correspondence.component';
import { LetterDashboardComponent } from './letter/letter-dashboard/components/letter-dashboard.component';
import { LetterTabsComponent } from './letter/letter-tabs/components/letter-tabs.component';
import { TagDashboardComponent } from './tag/tag-dashboard/components/tag-dashboard.component';
import { TagTabsComponent } from './tag/tag-tabs/components/tag-tabs.component';

const routes: Routes = [
  {
    path: 'extract',
    component: CorrespondenceJobComponent,
    canActivate: [PermitsGuard],
    data: {
      permissions: ['PERMIT_CORRESPONDENCE_LETTER_VIEW'],
    },
  },
  {
    path: 'schedule',
    component: ScheduleCorrespondenceComponent,
    canActivate: [PermitsGuard],
    data: {
      permissions: ['PERMIT_CORRESPONDENCE_LETTER_VIEW'],
    },
  },
  {
    path: 'letter/dashboard',
    component: LetterDashboardComponent,
    canActivate: [PermitsGuard],
    data: {
      permissions: ['PERMIT_CORRESPONDENCE_LETTER_VIEW'],
      title: 'Correspondences',
    },
  },
  {
    path: 'letter/view',
    component: LetterTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_CORRESPONDENCE_LETTER_VIEW'], title: 'View Correspondences' },
  },

  {
    path: 'letter/add',
    component: LetterTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'], title: 'Add Correspondences' },
  },

  {
    path: 'letter/edit',
    component: LetterTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'], title: 'Edit Correspondences' },
  },
  {
    path: 'tag/dashboard',
    component: TagDashboardComponent,
    canActivate: [PermitsGuard],
    data: {
      permissions: ['PERMIT_CORRESPONDENCE_LETTER_VIEW'],
      title: 'Tags',
    },
  },
  {
    path: 'tag/view',
    component: TagTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_CORRESPONDENCE_LETTER_VIEW'], title: 'View Tag' },
  },

  {
    path: 'tag/add',
    component: TagTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'], title: 'Add Tag' },
  },

  {
    path: 'tag/edit',
    component: TagTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'], title: 'Edit Tag' },
  },
];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CorrespondenceRoutingModule {}
