import { Injectable } from '@angular/core';
import { Query } from '@datorama/akita';
import { CorrespondenceCommonState, CorrespondenceCommonStore } from './correspondence-common-store';

@Injectable({ providedIn: 'root' })
export class CorrespondenceCommonQuery extends Query<CorrespondenceCommonState> {
  correspondenceTypes$ = this.select('correspondenceTypes');
  constructor(protected store: CorrespondenceCommonStore) {
    super(store);
  }
}
