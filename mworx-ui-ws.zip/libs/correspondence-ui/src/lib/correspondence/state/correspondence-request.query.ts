import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { CorrespondenceRequestState, CorrespondenceRequestStore } from './correspondence-request.store';

@Injectable({ providedIn: 'root' })
export class CorrespondenceRequestQuery extends QueryEntity<CorrespondenceRequestState> {
  constructor(protected store: CorrespondenceRequestStore) {
    super(store);
  }
  filters$ = this.select(state => {
    return state.ui.filters;
  });
  initialState$ = this.store.getInitialState();
}
