import { Injectable } from '@angular/core';
import { Store, StoreConfig } from '@datorama/akita';
export interface CorrespondenceCommonState {
  correspondenceTypes: string[];
}

export function createInitialState(): CorrespondenceCommonState {
  return {
    correspondenceTypes: [],
  };
}

@Injectable({ providedIn: 'root' })
@StoreConfig({
  name: 'correspondenceCommon-meta',
  resettable: true,
  cache: {
    ttl: 3600000,
  },
})
export class CorrespondenceCommonStore extends Store<CorrespondenceCommonState> {
  constructor() {
    super(createInitialState());
  }
}
