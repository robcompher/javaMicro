import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { CorrespondenceRequestQuery } from './correspondence-request.query';

export const CORRESPONDENCE_SEARCH_PAGINATOR = new InjectionToken('CORRESPONDENCE_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const correspondenceRequestQuery = inject(CorrespondenceRequestQuery);

    return new GridPaginatorPlugin(correspondenceRequestQuery);
  },
});
