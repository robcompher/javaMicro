import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { CorrespondenceRequestSearchCriteria } from '../models/correspondence-job-search-criteria';
import { CorrespondenceRequest } from '../models/correspondence-request.model';

export interface CorrespondenceRequestState extends EntityState<CorrespondenceRequest> {}

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'scheduleDate',
        sortOrder: 'asc',
      },
      scheduleDate: null,
      correspondenceType: null,
      correspondenceCode: null,
      correspondenceName: null,
      groupName: null,
      familyId: null,
      memberId: null,
      personIdentifiler: null,
      outputFileGeneratedBy: null,
    } as CorrespondenceRequestSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'correspondence-request', idKey: 'id', resettable: true })
export class CorrespondenceRequestStore extends EntityStore<CorrespondenceRequestState> {
  constructor() {
    super(initialState);
  }
  getInitialState(): Observable<CorrespondenceRequestSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
