import { ID } from '@datorama/akita';

export interface CorrespondenceRequest {
  id: ID;
  scheduleDate: Date;
  toDateOperator: string;
  correspondenceType: string;
  correspondenceCode: string;
  correspondenceName: string;
  groupNumber: string;
  familyId: number;
  memberId: number;
  personIdentifiler: number;
  outputFileGeneratedBy: string;
  exclude: Array<number>;
}

export function createCorrespondenceRequest(params: Partial<CorrespondenceRequest>) {
  return {
    scheduleDate: null,
    toDateOperator: null,
    correspondenceType: null,
    correspondenceCode: null,
    correspondenceName: null,
    id: null,
    groupNumber: null,
    familyId: null,
    memberId: null,
    personIdentifiler: null,
    outputFileGeneratedBy: null,
    exclude: null,
    ...params,
  } as CorrespondenceRequest;
}
