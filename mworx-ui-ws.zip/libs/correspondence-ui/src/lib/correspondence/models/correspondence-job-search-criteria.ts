import { ID } from '@datorama/akita';
import { SearchCriteria } from '@mworx/grid';

export interface CorrespondenceRequestSearchCriteria extends SearchCriteria {
  id: ID;
  scheduleDate: Date;
  correspondenceType: string;
  correspondenceCode: string;
  correspondenceName: string;
  groupName: string;
  familyId: number;
  memberId: number;
  personIdentifiler: number;
  outputFileGeneratedBy: string;
}
