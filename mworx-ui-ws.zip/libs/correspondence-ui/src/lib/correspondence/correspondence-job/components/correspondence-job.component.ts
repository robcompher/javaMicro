import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { ConfigService } from '@common/config';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { ListChoice, LookupDataService, LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable, of } from 'rxjs';
import { filter, map, mergeMap, switchMap, toArray } from 'rxjs/operators';
import { CorrespondenceService } from '../../services/correspondence.service';
import { CORRESPONDENCE_SEARCH_PAGINATOR } from '../../state/correspondence-paginator';
import { CorrespondenceRequestQuery } from '../../state/correspondence-request.query';
import { CorrespondenceRequestState } from '../../state/correspondence-request.store';

@UntilDestroy()
@Component({
  selector: 'correspondence-correspondence-job',
  templateUrl: './correspondence-job.component.html',
  styleUrls: ['./correspondence-job.component.scss'],
})
export class CorrespondenceJobComponent implements OnInit {
  correspondenceJobSearchForm: FormGroup;
  gridApi: GridApi;
  @ViewChild('correspondenceJobSearchDirective')
  correspondenceJobSearchDirective: FormGroupDirective;
  operatorsList$: Observable<Array<ListChoice>>;
  groups$: Observable<Array<any>>;
  familyId$: Observable<Array<any>>;
  memberId$: Observable<Array<any>>;
  types$: Observable<Array<string>>;
  codes$: Observable<Array<string>>;
  names$: Observable<Array<string>>;
  outputFileGeneratedBy$: Observable<Array<ListChoice>>;
  correspondeceTypes: Array<string>;
  correspondeceCodes: Array<string>;
  correspondeceNames: Array<string>;
  columnDefs = [
    {
      field: 'Include',
      sortable: false,
      checkboxSelection: true,
    },
    {
      headerName: 'External LR ID',
      field: 'extLrId',
    },
    {
      headerName: 'Schedule Date',
      field: 'scheduleDate',
    },
    {
      headerName: 'Correspondence Type',
      field: 'correspondenceType',
    },
    {
      headerName: 'Correspondence Code',
      field: 'correspondenceCode',
    },
    {
      headerName: 'Correspondence Name',
      field: 'correspondenceName',
    },
    {
      headerName: 'Group',
      field: 'groupName',
    },
    {
      headerName: 'Person Identifier',
      field: 'personIdentifier',
    },
    {
      headerName: 'Family Id',
      field: 'familyId',
    },
    {
      headerName: 'Member Id',
      field: 'memberId',
    },
    {
      headerName: 'Member First Name',
      field: 'memberFirstName',
    },
    {
      headerName: 'Member Last Name',
      field: 'memberLastName',
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
    rowSelection: 'multiple',
    onPaginationChanged: () => {
      this.gridApi?.forEachNode(node => {
        node.setSelected(true);
      });
    },
  };

  private fb: FormBuilder;
  private correspondenceService: CorrespondenceService;
  private correspondenceJobQuery: CorrespondenceRequestQuery;
  private lookupService: LookupService;
  private configService: ConfigService;
  private lookUpDataService: LookupDataService;
  private sessionService: SessionService;
  private notificationService: NotificationService;

  constructor(@Inject(CORRESPONDENCE_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<CorrespondenceRequestState>) {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.lookUpDataService = AppInjector.get(LookupDataService);
    this.correspondenceService = AppInjector.get(CorrespondenceService);
    this.correspondenceJobQuery = AppInjector.get(CorrespondenceRequestQuery);
    this.configService = AppInjector.get(ConfigService);
    this.sessionService = AppInjector.get(SessionService);
    this.notificationService = AppInjector.get(NotificationService);
  }

  ngOnInit(): void {
    this.initForm();
    this.outputFileGeneratedBy$ = this.lookupService.getOutputFileGeneratedBy();
  }

  initForm() {
    this.operatorsList$ = this.lookupService.getOperators();
    this.correspondenceJobSearchForm = this.fb.group({
      scheduleDate: [],
      toDateOperator: [],
      correspondenceType: [],
      correspondenceCode: [],
      correspondenceName: [],
      familyId: [],
      memberId: [],
      personIdentifiler: [],
      groupNumber: [],
      outputFileGeneratedBy: [],
    });

    this.groups$ = this.correspondenceJobSearchForm.get('groupNumber').valueChanges.pipe(
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getGroups(searchValue.label);
          }
        }

        return of([]);
      })
    );

    this.familyId$ = this.correspondenceJobSearchForm.get('familyId').valueChanges.pipe(
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getFamilyIdentifier(searchValue.label);
          }
        }

        return of([]);
      })
    );

    this.memberId$ = this.correspondenceJobSearchForm.get('memberId').valueChanges.pipe(
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getMemberIds(searchValue.label);
          }
        }

        return of([]);
      })
    );

    this.correspondenceJobQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.correspondenceJobSearchForm.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () => this.correspondenceService.search();

    this.paginatorRef.filtersUpdateFunction = criteria => this.correspondenceService.updateSearchCriteria(criteria);

    this.types$ = this.correspondenceService.getCorrespondenceTypes();
    this.codes$ = this.correspondenceService.getCorrespondenceCodes();
    this.names$ = this.correspondenceService.getCorrespondenceNames();
  }

  getGroups(groupName: string, groupId?: number): Observable<Array<ListChoice>> {
    return this.lookUpDataService.getGroupByName(groupName, this.sessionService.currentUser().currentLobId, groupId).pipe(
      filter(data => data && data.length > 0),
      mergeMap((items: any[]) => items),
      map((item: any) => {
        return {
          value: item.id,
          label: item.groupName + '-' + item.groupNumber,
        } as ListChoice;
      }),
      toArray()
    );
  }

  getFamilyIdentifier(familyIdentifier: string): Observable<Array<ListChoice>> {
    return this.correspondenceService.getFamilyIdentifier(familyIdentifier).pipe(
      filter(data => data && data.length > 0),
      mergeMap((items: any) => items),
      map((item: any) => {
        return {
          value: item.familyId,
          label: item.familyId,
        } as ListChoice;
      }),
      toArray()
    );
  }

  getMemberIds(memberId: string): Observable<Array<ListChoice>> {
    return this.correspondenceService.getMemberIds(memberId).pipe(
      filter(data => data && data.length > 0),
      mergeMap((items: any) => items),
      map((item: any) => {
        return {
          value: item.memberId,
          label: item.memberId,
        } as ListChoice;
      }),
      toArray()
    );
  }

  onSearch() {
    if (this.correspondenceJobSearchForm.invalid) {
      return;
    }
    const correspondenceForm = this.correspondenceJobSearchForm.value;
    correspondenceForm.groupId = correspondenceForm.groupNumber?.value;
    correspondenceForm.memberId = correspondenceForm.memberId?.value;
    correspondenceForm.familyId = correspondenceForm.familyId?.value;
    this.correspondenceService.updateSearchCriteria(correspondenceForm);
    if (this.gridApi) {
      this.gridApi.onFilterChanged();
    }
  }

  onReset() {
    this.correspondenceJobQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.correspondenceJobSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }

  onTypeValueChange(values) {
    this.correspondeceTypes = values;
    if (values.length > 0) {
      this.codes$ = this.correspondenceService.getCorrespondenceCodes(values);
      this.names$ = this.correspondenceService.getCorrespondenceNames(null, null, values);
    } else {
      this.codes$ = this.correspondenceService.getCorrespondenceCodes();
      this.names$ = of([]);
    }
  }

  onCodeValueChange(values) {
    this.correspondeceCodes = values;
    if (values.length > 0) {
      this.names$ = this.correspondenceService.getCorrespondenceNames(values);
    } else {
      this.names$ = this.correspondenceService.getCorrespondenceNames(null, null, this.correspondeceTypes);
    }
  }

  onExtract() {
    const formValues = this.correspondenceJobSearchForm.value;
    formValues.groupId = formValues.groupNumber?.value;
    formValues.familyId = formValues.familyId?.value;
    formValues.memberId = formValues.memberId?.values;
    formValues.exclude = this.getLetterIds();
    this.correspondenceService
      .extractCorrespondenceJob(formValues)
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.notificationService.showSuccess(this.configService.get('correspondence.constants.messages.jobSuccess'));
        this.onReset();
      });
  }

  getLetterIds() {
    const unselectedRows = [];
    this.gridApi.forEachNode(node => {
      if (!node.isSelected()) {
        unselectedRows.push(node.data.id);
      }
    });

    return unselectedRows;
  }
}
