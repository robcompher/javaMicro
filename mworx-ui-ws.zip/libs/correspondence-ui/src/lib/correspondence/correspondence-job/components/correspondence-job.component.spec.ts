import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CorrespondenceJobComponent } from './correspondence-job.component';

describe('CorrespondenceJobComponent', () => {
  let component: CorrespondenceJobComponent;
  let fixture: ComponentFixture<CorrespondenceJobComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CorrespondenceJobComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CorrespondenceJobComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
