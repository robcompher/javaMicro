import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDividerModule } from '@angular/material/divider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedLookupModule } from '@mworx/lookup';
import { SharedSessionModule } from '@mworx/session';
import { SharedUtilModule } from '@mworx/util';
import { CorrespondenceJobComponent } from './components/correspondence-job.component';
@NgModule({
  declarations: [CorrespondenceJobComponent],
  imports: [
    CommonModule,
    SharedLookupModule,
    SharedUiGridModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatSelectModule,
    SharedUtilModule,
    MatAutocompleteModule,
    MatDatepickerModule,
    SharedUiFormsModule,
    SharedUiLayoutModule,
    MatDividerModule,
    SharedSessionModule,
  ],
  exports: [CorrespondenceJobComponent],
})
export class CorrespondenceJobsModule {}
