import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { LibList, ListChoice, LookupDataService, LookupService, StatusType } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector, ErrorService, EventService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable, of } from 'rxjs';
import { catchError, distinctUntilChanged, filter, map, mergeMap, switchMap, toArray } from 'rxjs/operators';
import { GroupHierarchyComponent } from '../../group-hierarchy/components/group-hierarchy.component';
import { CorrespondenceService } from '../../services/correspondence.service';

@UntilDestroy()
@Component({
  selector: 'correspondence-schedule-correspondence',
  templateUrl: './schedule-correspondence.component.html',
})
export class ScheduleCorrespondenceComponent implements OnInit {
  scheduleCorrespondenceForm: FormGroup;

  @ViewChild('scheduleCorrespondenceDirective')
  scheduleCorrespondenceDirective: FormGroupDirective;

  types$: Observable<string[]>;
  codes$: Observable<Array<string>>;
  names$: Observable<Array<string>>;
  benefitNames$: Observable<Array<BenefitName>>;
  memberStatus$: Observable<StatusType[]>;
  memberIds$: Observable<Array<any>>;
  familyIds$: Observable<Array<any>>;
  groups$: Observable<Array<any>>;

  correspondeceTypes: Array<string>;
  correspondeceCodes: Array<string>;
  correspondeceNames: Array<string>;
  correspondenceBenefitNames: Array<string>;

  benefitNamesLookup$: Observable<LibList[]>;

  correspondenceRequiredFields: Array<string> = ['correspondenceCode', 'correspondenceName'];
  memberOneRequiredField: Array<string> = ['groupId', 'familyId', 'memberName'];

  showBenefitName: boolean;
  enableScheduleButton = false;
  enableOrDisableTreeIcon: boolean;
  selectedGroupId: string;

  private fb: FormBuilder;
  private correspondenceService: CorrespondenceService;
  private lookupService: LookupService;
  private configService: ConfigService;
  private lookUpDataService: LookupDataService;
  private sessionService: SessionService;
  private notificationService: NotificationService;
  private eventService: EventService;
  private dialog: MatDialog;
  private errorService: ErrorService;

  constructor() {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.lookUpDataService = AppInjector.get(LookupDataService);
    this.correspondenceService = AppInjector.get(CorrespondenceService);
    this.configService = AppInjector.get(ConfigService);
    this.sessionService = AppInjector.get(SessionService);
    this.notificationService = AppInjector.get(NotificationService);
    this.eventService = AppInjector.get(EventService);
    this.dialog = AppInjector.get(MatDialog);
    this.errorService = AppInjector.get(ErrorService);
  }

  ngOnInit(): void {
    this.initForm();

    this.eventService
      .on('resetPersonDatespanForm')
      .pipe(untilDestroyed(this))
      .subscribe(() => {
        this.onReset();
      });
  }

  initForm() {
    this.enableScheduleButton = false;
    this.scheduleCorrespondenceForm = this.fb.group({
      correspondenceType: [null, [Validators.required]],
      benefitId: [],
      correspondenceCode: [null, [Validators.required]],
      correspondenceName: [null, [Validators.required]],
      groupId: [],
      familyId: [],
      memberName: [],
      memberStatus: [],
      enrollDate: [],
      scheduleDate: [],
    });

    this.initGroups();
    this.initFamily();
    this.initMembers();

    this.types$ = this.correspondenceService.getCorrespondenceTypes();
    this.names$ = this.correspondenceService.getCorrespondenceNames();
    this.memberStatus$ = this.lookupService.getAllStatuses();

    this.showBenefitName = false;
    this.enableOrDisableTreeIcon = true;

    this.subscribeMemberFieldChange(this.memberOneRequiredField);
    this.subscribeCorrFieldChange(this.correspondenceRequiredFields);

    this.enableOrDisableTreeAction();
    this.setGroupNametoField();
  }

  enableOrDisableTreeAction() {
    this.scheduleCorrespondenceForm
      .get('groupId')
      .valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
      .subscribe(res => {
        this.enableOrDisableTreeIcon = !res?.value;
      });
  }

  setGroupNametoField() {
    this.eventService
      .on('selectedGroupId')
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        if (res) {
          this.setGroupName(res);
        } else {
          this.enableOrDisableTreeIcon = true;
        }
      });
  }

  setGroupName(groupId) {
    if (groupId) {
      this.lookupService
        .getGroupById(groupId)
        .pipe(untilDestroyed(this))
        .subscribe(group => {
          this.scheduleCorrespondenceForm.patchValue({
            groupId: { label: group.groupName, value: groupId },
          });
        });
    }
  }

  subscribeMemberFieldChange(subscribeArray: Array<string>) {
    for (const value of subscribeArray) {
      this.scheduleCorrespondenceForm
        .get(value)
        .valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
        .subscribe(() => {
          this.updateScheduleCorrButton();
        });
    }
  }

  subscribeCorrFieldChange(subscribeArray: Array<string>) {
    for (const value of subscribeArray) {
      this.scheduleCorrespondenceForm
        .get(value)
        .valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
        .subscribe(() => {
          this.updateScheduleCorrButton();
        });
    }
  }

  private updateScheduleCorrButton() {
    // all corr fields have data
    let allCorrFieldFilledIn = true;
    for (const value of this.correspondenceRequiredFields) {
      const fieldValue = this.scheduleCorrespondenceForm.get(value).value;
      if (allCorrFieldFilledIn && fieldValue && fieldValue instanceof Array && fieldValue.length > 0) {
        allCorrFieldFilledIn = true;
      } else {
        allCorrFieldFilledIn = false;
      }
    }
    //  one member field have data
    let oneMemberFieldFilledIn = false;
    for (const value of this.memberOneRequiredField) {
      const fieldValue = this.scheduleCorrespondenceForm.get(value).value;
      if (fieldValue?.value) {
        oneMemberFieldFilledIn = true;
      }
    }
    this.enableScheduleButton = oneMemberFieldFilledIn && allCorrFieldFilledIn;
  }

  initGroups() {
    this.groups$ = this.scheduleCorrespondenceForm.get('groupId').valueChanges.pipe(
      distinctUntilChanged(),
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getGroups(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  initFamily() {
    this.familyIds$ = this.scheduleCorrespondenceForm.get('familyId').valueChanges.pipe(
      distinctUntilChanged(),
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getFamilyIds(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  initMembers() {
    this.memberIds$ = this.scheduleCorrespondenceForm.get('memberName').valueChanges.pipe(
      distinctUntilChanged(),
      untilDestroyed(this),
      switchMap((searchValue: any) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getMemberIds(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  getGroups(groupName: string, groupId?: number): Observable<Array<ListChoice>> {
    return this.lookUpDataService.getGroupByName(groupName, this.sessionService.currentUser().currentLobId, groupId).pipe(
      untilDestroyed(this),
      filter(data => data && data.length > 0),
      mergeMap((items: any[]) => items),
      map((item: any) => {
        return {
          value: item.id,
          label: item.groupName + '-' + item.groupNumber,
        } as ListChoice;
      }),
      toArray()
    );
  }

  getMemberIds(memberName: string): Observable<Array<ListChoice>> {
    return this.lookUpDataService
      .getMemberIds(
        memberName,
        this.scheduleCorrespondenceForm.get('groupId').value?.value,
        this.scheduleCorrespondenceForm.get('familyId').value?.value
      )
      .pipe(
        untilDestroyed(this),
        filter(data => data && data.length > 0),
        mergeMap((items: any[]) => items),
        map((item: any) => {
          return {
            value: item.mid,
            label: item.memberId,
          } as ListChoice;
        }),
        toArray()
      );
  }

  getFamilyIds(familyId: string): Observable<Array<ListChoice>> {
    return this.lookUpDataService.getFamilyIds(familyId, this.scheduleCorrespondenceForm.get('groupId').value?.value).pipe(
      untilDestroyed(this),
      filter(data => data && data.length > 0),
      mergeMap((items: any[]) => items),
      map((item: any) => {
        return {
          value: item.familyId,
          label: item.familyId,
        } as ListChoice;
      }),
      toArray()
    );
  }

  openTreePopup() {
    this.selectedGroupId = this.scheduleCorrespondenceForm.get('groupId').value?.value;
    this.dialog.open(GroupHierarchyComponent, {
      width: '70%',
      height: '70%',
      data: {
        selectedGroupId: this.selectedGroupId,
      },
    });
  }

  onReset() {
    this.scheduleCorrespondenceDirective.resetForm();
    this.codes$ = of([]);
    this.names$ = of([]);
    this.benefitNames$ = of([]);
    this.showBenefitName = false;
    this.enableScheduleButton = false;
  }

  onSearch() {
    if (this.scheduleCorrespondenceForm.invalid) {
      return;
    }

    this.correspondenceService.updateSearchCriteria(this.scheduleCorrespondenceForm.value);
  }

  onTypeValueChange(values) {
    this.correspondeceTypes = [];
    this.correspondeceTypes.push(values);
    if (this.correspondeceTypes.length > 0) {
      this.benefitNames$ = this.correspondenceService.getBenefitNames(this.correspondeceTypes);
      this.names$ = this.correspondenceService.getCorrespondenceNames(null, null, this.correspondeceTypes);
    }

    this.benefitNames$.pipe(untilDestroyed(this)).subscribe(res => {
      if (res?.length > 0) {
        this.showBenefitName = true;
        this.codes$ = this.correspondenceService.getCorrespondenceCodes(this.correspondeceTypes, res);
      } else {
        this.showBenefitName = false;
        this.codes$ = this.correspondenceService.getCorrespondenceCodes(this.correspondeceTypes);
      }
      this.scheduleCorrespondenceForm.get('correspondenceCode').setValue('');
      this.scheduleCorrespondenceForm.get('correspondenceName').setValue('');
      this.scheduleCorrespondenceForm.get('benefitId').setValue('');
    });
  }

  onBenefitNameChange(values) {
    this.correspondenceBenefitNames = values;
    if (values.length > 0) {
      this.codes$ = this.correspondenceService.getCorrespondenceCodes(this.correspondeceTypes, values);
    }
  }

  onCodeValueChange(values) {
    this.correspondeceCodes = values;
    if (values.length > 0) {
      this.names$ = this.correspondenceService.getCorrespondenceNames(values, this.correspondenceBenefitNames, this.correspondeceTypes);
    } else {
      this.names$ = this.correspondenceService.getCorrespondenceNames(null, null, this.correspondeceTypes);
    }
  }

  onScheduleCorrespondence() {
    if (this.scheduleCorrespondenceForm.invalid) {
      return;
    }

    const formRequest = this.scheduleCorrespondenceForm.value;
    formRequest.groupId = this.scheduleCorrespondenceForm.get('groupId').value?.value;
    formRequest.familyId = this.scheduleCorrespondenceForm.get('familyId').value?.value;
    formRequest.mid = this.scheduleCorrespondenceForm.get('memberName').value?.value;
    formRequest.memberId = this.scheduleCorrespondenceForm.get('memberName').value?.label;
    formRequest.lob = this.lookupService.getCurrentUserLob();
    formRequest.triggerEvent = true;
    if (this.scheduleCorrespondenceForm.get('benefitId').value === '') formRequest.benefitId = null;
    if (this.scheduleCorrespondenceForm.get('correspondenceName').value === '') formRequest.correspondenceName = null;
    if (this.scheduleCorrespondenceForm.get('correspondenceCode').value === '') formRequest.correspondenceCode = null;

    this.correspondenceService
      .onScheduleCorrespondence(formRequest)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.scheduleCorrespondenceForm, response);
        })
      )
      .subscribe(() => {
        this.notificationService.showSuccess(this.configService.get('correspondence.constants.messages.scheduleCorrespondenceSuccess'));
        this.onReset();
      });
  }
}
export interface BenefitName {
  benefitId: number;
  benefitName: string;
}
