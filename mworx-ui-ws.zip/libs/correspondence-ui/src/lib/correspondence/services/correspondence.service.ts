import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { PaginationResponse } from '@datorama/akita';
import { LookupService } from '@mworx/lookup';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map, mergeMap, tap } from 'rxjs/operators';
import { GroupNode } from '../group-hierarchy/components/group-hierarchy.component';
import { CorrespondenceRequestSearchCriteria } from '../models/correspondence-job-search-criteria';
import { CorrespondenceRequest } from '../models/correspondence-request.model';
import { BenefitName } from '../schedule-correspondence/components/schedule-correspondence.component';
import { CorrespondenceCommonQuery } from '../state/correspondence-common-query';
import { CorrespondenceCommonStore } from '../state/correspondence-common-store';
import { CorrespondenceRequestStore } from '../state/correspondence-request.store';

@Injectable({
  providedIn: 'root',
})
export class CorrespondenceService {
  private correspondenceJobStore: CorrespondenceRequestStore;
  private httpClient: HttpClient;
  private configService: ConfigService;
  private correspondenceCommonStore: CorrespondenceCommonStore;
  private correspondenceCommonQuery: CorrespondenceCommonQuery;
  private lookupService: LookupService;

  constructor() {
    this.correspondenceJobStore = AppInjector.get(CorrespondenceRequestStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.correspondenceCommonStore = AppInjector.get(CorrespondenceCommonStore);
    this.correspondenceCommonQuery = AppInjector.get(CorrespondenceCommonQuery);
    this.lookupService = AppInjector.get(LookupService);
  }

  public search(): Observable<PaginationResponse<CorrespondenceRequest>> {
    const criteria = { ...this.correspondenceJobStore.getValue().ui.filters };

    return this.httpClient
      .post<PaginationResponse<CorrespondenceRequest>>(this.configService.get('correspondence.constants.url.findBySearch'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<CorrespondenceRequest>;
        })
      );
  }

  public updateSearchCriteria(criteria: CorrespondenceRequestSearchCriteria) {
    const prevCriteria = this.correspondenceJobStore.getValue().ui.filters;
    this.correspondenceJobStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  getCorrespondenceTypes(): Observable<Array<string>> {
    return this.correspondenceCommonQuery.selectHasCache().pipe(
      mergeMap(hasCache => {
        const getCorrespondenceTypesApiCall = this.httpClient
          .post<any>(this.configService.get('correspondence.constants.url.getAllCorrespondenceTypes'), {
            lob: this.lookupService.getCurrentUserLob(),
          })
          .pipe(
            map(res => res.letterTypes),
            tap(jobStatusResponse => {
              this.correspondenceCommonStore.update({ correspondenceTypes: jobStatusResponse });
            })
          );

        return hasCache ? this.correspondenceCommonQuery.correspondenceTypes$ : getCorrespondenceTypesApiCall;
      })
    );
  }

  getBenefitNames(types?: any): Observable<Array<BenefitName>> {
    const data = {
      letterType: types,
      lob: this.lookupService.getCurrentUserLob(),
    };

    return this.httpClient.post<any>(this.configService.get('correspondence.constants.url.getBenefitNames'), data).pipe(map(res => res.benefitNames));
  }

  getCorrespondenceCodes(types?: any, benfitNames?: any): Observable<Array<string>> {
    const benefitName = [];
    benfitNames?.forEach(element => {
      benefitName.push(element.benefitName);
    });
    const data = {
      letterType: types,
      benfitName: benefitName,
      lob: this.lookupService.getCurrentUserLob(),
    };

    return this.httpClient
      .post<any>(this.configService.get('correspondence.constants.url.getCorrespondenceCodes'), data)
      .pipe(map(res => res.letterCodes));
  }

  getCorrespondenceNames(codes?: any, benfitNames?: any, types?: any): Observable<Array<string>> {
    const data = {
      letterType: types,
      benfitName: benfitNames,
      letterCode: codes,
      lob: this.lookupService.getCurrentUserLob(),
    };

    return this.httpClient
      .post<any>(this.configService.get('correspondence.constants.url.getCorrespondenceNames'), data)
      .pipe(map(res => res.letterNames));
  }

  extractCorrespondenceJob(correspondenceFormValues) {
    return this.httpClient.post(this.configService.get('staging.constants.url.correspondenceExtractJob'), correspondenceFormValues);
  }

  getFamilyIdentifier(familyIdentifier: string): Observable<any> {
    const data = {
      familyIdentifier: familyIdentifier,
      lob: this.lookupService.getCurrentUserLob(),
    };

    return this.httpClient.post(this.configService.get('membership.constants.url.getFamilies'), data);
  }

  getMemberIds(memberId: string): Observable<any> {
    const data = {
      memberId: memberId,
      lob: this.lookupService.getCurrentUserLob(),
    };

    return this.httpClient.post(this.configService.get('membership.constants.url.getFamilies'), data);
  }

  onScheduleCorrespondence(formRequest) {
    return this.httpClient.post(this.configService.get('correspondence.constants.url.scheduleCorrespondence'), formRequest);
  }

  getChildernById(id): Observable<GroupNode> {
    const request = {
      groupId: +id,
      onlyChildGroups: true,
    };

    return this.httpClient.post<GroupNode>(this.configService.get('metadata.constants.url.getGroupHierarchyById'), request);
  }
}
