import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatTreeModule } from '@angular/material/tree';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedLookupModule } from '@mworx/lookup';
import { SharedSessionModule } from '@mworx/session';
import { SharedUtilModule } from '@mworx/util';
import { GroupHierarchyComponent } from './components/group-hierarchy.component';

@NgModule({
  declarations: [GroupHierarchyComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatDatepickerModule,
    MatCheckboxModule,
    ReactiveFormsModule,
    MatAutocompleteModule,
    SharedUiGridModule,
    SharedUiFormsModule,
    MatSelectModule,
    SharedUiLayoutModule,
    MatTabsModule,
    MatTreeModule,
    MatTooltipModule,
    SharedLookupModule,
    SharedSessionModule,
    SharedUtilModule,

    MatExpansionModule,
    MatPaginatorModule,
  ],
  exports: [GroupHierarchyComponent],
})
export class GroupHierarchyModule {}
