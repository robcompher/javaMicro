import { SelectionModel } from '@angular/cdk/collections';
import { NestedTreeControl } from '@angular/cdk/tree';
import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { AppInjector, EventService } from '@mworx/util';
import { UntilDestroy } from '@ngneat/until-destroy';
import { CorrespondenceService } from '../../services/correspondence.service';

@UntilDestroy()
@Component({
  selector: 'correspondence-group-hierarchy',
  templateUrl: './group-hierarchy.component.html',
})
export class GroupHierarchyComponent implements OnInit {
  constructor(
    @Inject(MAT_DIALOG_DATA) public data,

    private dialogRef: MatDialogRef<GroupHierarchyComponent>
  ) {
    this.correspondenceService = AppInjector.get(CorrespondenceService);
    this.eventService = AppInjector.get(EventService);
  }
  id: number;
  groupChildData: GroupNode;
  showEditIcon = false;
  selectedGroupId: number;

  private correspondenceService: CorrespondenceService;
  private eventService: EventService;

  treeControl = new NestedTreeControl<GroupNode>(node => node.children);
  dataSource = new MatTreeNestedDataSource<GroupNode>();
  checklistSelection = new SelectionModel<GroupNode>(true /* multiple */);
  hasChild = (_: number, node: GroupNode) => !!node.children && node.children.length > 0;

  ngOnInit(): void {
    this.correspondenceService.getChildernById(this.data.selectedGroupId).subscribe(response => {
      this.groupChildData = response;
      const data = [];
      response.children?.forEach(element => {
        data.push({ name: element.groupNumber, id: element.id, children: element.children ? this.getData(element.children) : '' });
      });

      this.dataSource.data = [
        {
          name: response.parentGroupNumber,
          children: data,
          parentNodeCount: 1,
        },
      ];
    });
  }

  itemSelectionToggle(node: GroupNode): void {
    this.checklistSelection.toggle(node);
    this.selectedGroupId = node.parentNodeCount ? this.data.selectedGroupId : node.id;
  }

  descendantsAllSelected(node: GroupNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const descAllSelected =
      descendants.length > 0 &&
      descendants.every(child => {
        return this.checklistSelection.isSelected(child) || this.amIActive(child);
      });

    return descAllSelected;
  }

  amIActive(groupLinkNode: GroupNode): boolean {
    const selectedNodes = this.checklistSelection.selected;
    for (const node of selectedNodes) {
      if (groupLinkNode.id && groupLinkNode.id === node.id) return true;
    }

    return false;
  }

  descendantsPartiallySelected(node: GroupNode): boolean {
    const descendants = this.treeControl.getDescendants(node);
    const result = descendants.some(child => this.checklistSelection.isSelected(child));

    return result && !this.descendantsAllSelected(node);
  }

  getData(element: GroupNode[]) {
    const dataObj = [];
    element.forEach(ele => {
      dataObj.push({ name: ele.groupNumber, id: ele.id, children: ele.children ? this.getData(ele.children) : '' });
    });

    return dataObj;
  }

  closePopup() {
    this.eventService.dispatch('selectedGroupId', this.selectedGroupId);
    this.dialogRef.close();
  }
}

export interface GroupNode {
  name?: string;
  children?: GroupNode[];
  id?: number;
  parentNodeCount?: number;
  parentGroupNumber?: string;
  groupNumber?: string;
}
