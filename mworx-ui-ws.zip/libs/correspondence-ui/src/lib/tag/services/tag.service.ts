import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse, withTransaction } from '@datorama/akita';
import { LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector } from '@mworx/util';
import { Observable, Subject } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { AttributeLinkedTags } from '../models/attribute-linked-tags.model';
import { LinkedLetterTagID } from '../models/linked-letter-tag.model';
import { LinkedTagAttributes } from '../models/linked-tag-attribute.model';
import { MultipleTagAdd } from '../models/multiple-tag-add.model';
import { TagAttributeSearchCriteria } from '../models/tag-attribute-search.model';
import { TagSearchCriteria } from '../models/tag-search.model';
import { Tag } from '../models/tag.model';
import { TagAttributeSearchQuery } from '../state/tag-attributes-search.query';
import { TagAttributeSearchStore } from '../state/tag-attributes-search.store';
import { TagSearchQuery } from '../state/tag-search.query';
import { TagSearchStore } from '../state/tag-search.store';
import { TagQuery } from '../state/tag.query';
import { TagStore } from '../state/tag.store';

@Injectable({ providedIn: 'root' })
export class TagService {
  private http: HttpClient;
  private lookupService: LookupService;
  private configService: ConfigService;
  private authService: SessionService;
  private tagSearchQuery: TagSearchQuery;
  private tagQuery: TagQuery;
  private tagStore: TagStore;
  private tagSearchStore: TagSearchStore;
  private tagAttributeSearchQuery: TagAttributeSearchQuery;
  private tagAttributeSearchStore: TagAttributeSearchStore;
  onMetaEventFormReset = new Subject<void>();

  constructor() {
    this.http = AppInjector.get(HttpClient);
    this.lookupService = AppInjector.get(LookupService);
    this.configService = AppInjector.get(ConfigService);
    this.http = AppInjector.get(HttpClient);
    this.authService = AppInjector.get(SessionService);
    this.tagSearchQuery = AppInjector.get(TagSearchQuery);
    this.tagQuery = AppInjector.get(TagQuery);
    this.tagStore = AppInjector.get(TagStore);
    this.tagSearchStore = AppInjector.get(TagSearchStore);
    this.tagAttributeSearchStore = AppInjector.get(TagAttributeSearchStore);
    this.tagAttributeSearchQuery = AppInjector.get(TagAttributeSearchQuery);
  }
  public search(): Observable<PaginationResponse<Tag>> {
    const lob = this.lookupService.getCurrentUserLob();

    let criteria = { ...{ lob }, ...this.tagSearchQuery.getValue().ui.filters };
    if (!criteria.lob?.lobId && this.authService.currentUser().currentLobName !== this.configService.get('auth.constants.systemLob')) {
      criteria = { ...this.tagSearchQuery.getValue().ui.filters, ...{ lob } };
    }

    return this.http.post<PaginationResponse<Tag>>(this.configService.get('correspondence.constants.url.tagSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<Tag>;
      })
    );
  }

  public searchLinkedLetterTagWithLetter(): Observable<PaginationResponse<Tag>> {
    const criteria = { ...this.tagSearchQuery.getValue().ui.filters };

    return this.http.post<PaginationResponse<Tag>>(this.configService.get('correspondence.constants.url.tagSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<Tag>;
      })
    );
  }

  public searchTagAttributes(tagId: string | number): Observable<PaginationResponse<LinkedTagAttributes>> {
    const libTagId = {
      libTagId: tagId,
    };
    const criteria = { ...this.tagAttributeSearchQuery.getValue().ui.filters, ...libTagId };

    return this.http
      .post<PaginationResponse<LinkedTagAttributes>>(this.configService.get('correspondence.constants.url.tagAttributeSearch'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<LinkedTagAttributes>;
        })
      );
  }

  getAttributesByType(attributeType: string, lobId: number, libTagId: number): Observable<Array<AttributeLinkedTags>> {
    const lob = {
      lobId: lobId,
    };

    return this.http.post<Array<AttributeLinkedTags>>(this.configService.get('correspondence.constants.url.getAllAttributesByTypeAndTag'), {
      attributeType,
      lob: lob,
      libTagId,
    });
  }

  public deleteByID(id: ID): Observable<any> {
    return this.http
      .put<any>(this.configService.get('correspondence.constants.url.tagDelete'), { id: id })
      .pipe(
        tap(resp => {
          this.tagStore.remove(id);
        })
      );
  }

  public deleteTagAttributeByID(id: ID): Observable<any> {
    return this.http
      .put<any>(this.configService.get('correspondence.constants.url.tagAttributeDelete'), { id: id })
      .pipe();
  }

  public updateSearchCriteria(criteria: TagSearchCriteria) {
    const prevCriteria = this.tagSearchStore.getValue().ui.filters;
    this.tagSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public updateTagAttributesSearchCriteria(criteria: TagAttributeSearchCriteria) {
    const prevCriteria = this.tagAttributeSearchStore.getValue().ui.filters;
    this.tagAttributeSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public getTagById(id: ID): Observable<Tag> {
    return this.tagQuery.selectEntity(id).pipe(
      switchMap(cacheEntry => {
        const apiCall = this.http
          .post<any>(this.configService.get('correspondence.constants.url.tagById'), { id: id })
          .pipe(
            withTransaction(response => {
              if (response) {
                this.tagStore.upsert(id, response);
                this.tagStore.setHasCache(true);
              }
            }),
            switchMap(res => this.tagQuery.selectEntity(id))
          );

        return cacheEntry ? this.tagQuery.selectEntity(id) : apiCall;
      })
    );
  }

  public addMultipleLinkedTags(multipleTags: MultipleTagAdd): Observable<any> {
    return this.http.post<LinkedLetterTagID[]>(this.configService.get('correspondence.constants.url.letterTagAdd'), multipleTags).pipe();
  }

  public addTagAttributes(tagAttributes): Observable<LinkedTagAttributes[]> {
    return this.http.post<LinkedTagAttributes[]>(this.configService.get('correspondence.constants.url.addTagAttributes'), tagAttributes).pipe();
  }

  public addOrUpdateTag(tag: Tag, lobId: number): Observable<any> {
    const lob = {
      lob: {
        lobId: lobId,
      },
    };
    if (this.tagQuery.hasEntity(tag.id) && Boolean(tag.id)) {
      return this.http
        .put<Tag>(this.configService.get('correspondence.constants.url.addUpdateTag'), { ...this.tagQuery.getEntity(tag.id), ...tag, ...lob })
        .pipe(
          tap(currentTag => {
            this.tagStore.upsert(currentTag.id, currentTag);
            this.tagSearchStore.upsert(currentTag.id, currentTag);
          })
        );
    } else {
      return this.http
        .post<Tag>(this.configService.get('correspondence.constants.url.addUpdateTag'), { ...tag, ...lob })
        .pipe(
          tap(currentTag => {
            this.tagStore.upsert(currentTag.id, currentTag);
            this.tagSearchStore.upsert(currentTag.id, currentTag);
          })
        );
    }
  }

  isRefreshSearchGrid(): boolean {
    return this.tagSearchStore.isRefreshSearchGrid();
  }

  setRefreshSearchGrid(value: boolean) {
    this.tagSearchStore.setRefreshSearchGrid(value);
  }
}
