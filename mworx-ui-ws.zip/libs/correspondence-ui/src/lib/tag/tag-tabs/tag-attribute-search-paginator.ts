import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { TagAttributeSearchQuery } from '../state/tag-attributes-search.query';

export const TAG_ATTRIBUTE_PAGINATOR = new InjectionToken('TAG_ATTRIBUTE_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const tagAttributeQuery = inject(TagAttributeSearchQuery);

    return new GridPaginatorPlugin(tagAttributeQuery);
  },
});
