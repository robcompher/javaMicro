import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterModule } from '@angular/router';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { TagAddEditComponent } from './components/tag-add-edit.component';
import { TagLinkedAttributesComponent } from './components/tag-linked-attributes.component';
import { TagTabsComponent } from './components/tag-tabs.component';

@NgModule({
  declarations: [TagTabsComponent, TagLinkedAttributesComponent, TagAddEditComponent],
  imports: [
    CommonModule,

    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatIconModule,
    SharedUiGridModule,
    ReactiveFormsModule,
    SharedUtilModule,
    SharedUiFormsModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    RouterModule,
    SharedUiLayoutModule,
  ],
  exports: [TagTabsComponent, TagLinkedAttributesComponent, TagAddEditComponent],
})
export class TagTabsModule {}
