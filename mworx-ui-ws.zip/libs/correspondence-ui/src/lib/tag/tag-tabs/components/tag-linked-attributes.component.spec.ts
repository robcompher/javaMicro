import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TagLinkedAttributesComponent } from './tag-linked-attributes.component';

describe('TagLinkedAttributesComponent', () => {
  let component: TagLinkedAttributesComponent;
  let fixture: ComponentFixture<TagLinkedAttributesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TagLinkedAttributesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TagLinkedAttributesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
