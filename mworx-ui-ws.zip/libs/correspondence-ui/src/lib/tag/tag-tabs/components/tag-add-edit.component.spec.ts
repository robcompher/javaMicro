import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TagAddEditComponent } from './tag-add-edit.component';

describe('TagAddEditComponent', () => {
  let component: TagAddEditComponent;
  let fixture: ComponentFixture<TagAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TagAddEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TagAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
