import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TagTabsComponent } from './tag-tabs.component';

describe('TagTabsComponent', () => {
  let component: TagTabsComponent;
  let fixture: ComponentFixture<TagTabsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TagTabsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TagTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
