import { Component, NgZone, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { ID } from '@datorama/akita';
import { AppInjector, EventService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest } from 'rxjs';
import { TagService } from '../../services/tag.service';
import { TagQuery } from '../../state/tag.query';

@UntilDestroy()
@Component({
  selector: 'correspondence-tag-tabs',
  templateUrl: './tag-tabs.component.html',
  styleUrls: ['./tag-tabs.component.scss'],
})
export class TagTabsComponent implements OnInit {
  tabs = [];
  loadedStatus: Array<number>;
  showSaveButton = true;
  showResetButton = true;
  showAddButton = false;
  firstTabName = 'Tag';

  pageTitle: string;
  id: ID;
  tabIndex = 0;

  constructor(
    private requestService: RequestService,
    private eventService: EventService,
    private tagService: TagService,
    private tagQuery: TagQuery
  ) {}

  ngOnInit(): void {
    this.loadedStatus = new Array<number>();

    if (this.requestService.url().search('add') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this))
        .subscribe(res => {
          this.id = res.data.id;
          this.tagService
            .getTagById(this.id)
            .pipe(untilDestroyed(this))
            .subscribe(() => {});
          combineLatest([this.tagQuery.selectLoading(), this.tagQuery.tags$(this.id)])
            .pipe(untilDestroyed(this))
            .subscribe(([loading, tag]) => {
              if (!loading && tag) {
                this.requestService
                  .selectData()
                  .pipe(untilDestroyed(this))
                  .subscribe(data => {
                    this.pageTitle = data.title + ' : ' + tag.tagName + ' for LOB ' + tag.lob.lobName;
                  });
              }
            });
        });
    }
    this.initTabs();
    if (this.requestService.url().search('view') !== -1) {
      this.showAddButton = false;
      this.showSaveButton = false;
      this.showResetButton = false;
    }
    //default load first tab
    this.loadedStatus.push(0);
  }

  protected initTabs() {
    this.tabs.push({
      tabName: this.firstTabName,
      content: import('./tag-add-edit.component').then(({ TagAddEditComponent }) => TagAddEditComponent),
    });
    if (this.id) {
      this.tabs.push({
        tabName: 'Link Attributes',
        content: import('./tag-linked-attributes.component').then(({ TagLinkedAttributesComponent }) => TagLinkedAttributesComponent),
      });
    }
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    if (this.loadedStatus.indexOf(tabChangeEvent.index) === -1) {
      this.loadedStatus.push(tabChangeEvent.index);
    }
    this.tabIndex = tabChangeEvent.index;
    if (this.requestService.url().search('view') === -1) {
      this.showAddButton = this.tabs[this.tabIndex].tabName !== this.firstTabName;
      this.showSaveButton = this.tabs[this.tabIndex].tabName === this.firstTabName;
      this.showResetButton = this.tabs[this.tabIndex].tabName === this.firstTabName;
    }
  }

  private whichForm(tabName: string): string {
    if (tabName === this.firstTabName) return 'tagEventForm';
    else return 'linkedAttributesEventForm';
  }

  onReset($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onResetForm', formName);
    }
  }

  goBackToDashboard($event) {
    if ($event) {
      const ngZone = AppInjector.get(NgZone);
      ngZone.run(() => {
        this.requestService.navigate(['correspondence/tag/dashboard']);
      });
    }
  }

  onSearch($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onSearchForm', formName);
    }
  }

  onAdd($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onAddForm', formName);
    }
  }
}
