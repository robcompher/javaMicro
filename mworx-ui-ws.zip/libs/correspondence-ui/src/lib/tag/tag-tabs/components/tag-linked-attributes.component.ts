import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { combineLatest } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { Tag } from '../../models/tag.model';
import { TagService } from '../../services/tag.service';
import { TagAttributeSearchState } from '../../state/tag-attributes-search.store';
import { TagQuery } from '../../state/tag.query';
import { TagAttributeAddComponent } from '../../tag-attribute-add/components/tag-attribute-add.component';
import { TAG_ATTRIBUTE_PAGINATOR } from '../tag-attribute-search-paginator';

@Component({
  selector: 'correspondence-tag-linked-attributes',
  templateUrl: './tag-linked-attributes.component.html',
  styleUrls: ['./tag-linked-attributes.component.scss'],
})
@UntilDestroy()
export class TagLinkedAttributesComponent implements OnInit, OnDestroy {
  gridApi: GridApi;
  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
  };
  columnDefs: any;
  tag: Tag;

  constructor(
    private configService: ConfigService,
    private errorService: ErrorService,
    private dialog: MatDialog,
    private tagService: TagService,
    private notificationService: NotificationService,
    private requestService: RequestService,
    private eventService: EventService,
    private tagQuery: TagQuery,
    @Inject(TAG_ATTRIBUTE_PAGINATOR)
    public paginatorRef: GridPaginatorPlugin<TagAttributeSearchState>
  ) {}

  ngOnInit(): void {
    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.tagService
          .getTagById(res.data.id)
          .pipe(untilDestroyed(this))
          .subscribe(() => {});
        combineLatest([this.tagQuery.selectLoading(), this.tagQuery.tags$(res.data.id)])
          .pipe(untilDestroyed(this))
          .subscribe(([loading, tag]) => {
            if (!loading && tag) {
              this.tag = tag;
            }
          });
      });

    this.initColumns();
    this.initEventSubscribers();
    this.paginatorRef.requestFunction = () => this.tagService.searchTagAttributes(this.tag.id);
    this.paginatorRef.filtersUpdateFunction = criteria => this.tagService.updateTagAttributesSearchCriteria(criteria);
  }

  initColumns() {
    this.columnDefs = [
      {
        headerName: 'Attribute Type',
        field: 'libAttribute.attributeType',
        sortable: false,
      },
      {
        headerName: 'Attribute Name',
        field: 'libAttribute.attributeName',
        sortable: false,
      },
      { headerName: 'Active', field: 'active' },
      {
        headerName: 'Actions',
        colId: 'Actions',
        minWidth: 150,
        sortable: false,
        cellRenderer: 'buttonRenderer',
        cellRendererParams: {
          actions: [
            {
              onClick: this.onDeleteActionClick.bind(this),
              label: 'Delete',
              icon: 'delete',
              color: 'warn',
              show: this.showAction.bind(this),
              permissions: ['PERMIT_CORRESPONDENCE_LETTER_UPDATE'],
            },
          ],
        },
      },
    ];
  }

  initEventSubscribers() {
    this.eventService
      .on('onAddForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'linkedAttributesEventForm')
      )
      .subscribe(() => {
        this.onAdd();
      });
  }

  showAction(action: any, data: any) {
    return data.active !== 'N' && this.requestService.url().search('view') === -1;
  }

  onAdd() {
    this.dialog
      .open(TagAttributeAddComponent, {
        minWidth: '50%',
        data: {
          tag: this.tag,
        },
      })
      .afterClosed()
      .pipe(
        untilDestroyed(this),
        filter(res => res?.event === 'saved')
      )
      .subscribe(() => {
        this.gridApi.onFilterChanged();
      });
  }

  openConfirmDialog(msg: string) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('metadata.constants.messages.confirmMsg'))
      .afterClosed()
      .pipe(
        untilDestroyed(this),
        filter(res => !!res)
      )

      .subscribe(() => {
        this.tagService
          .deleteTagAttributeByID(e.rowData.id)
          .pipe(
            untilDestroyed(this),
            catchError((error: HttpErrorResponse) => {
              return this.errorService.handleTableValidationErrors(error);
            })
          )
          .subscribe(() => {
            this.notificationService.showSuccess(
              this.configService.get('correspondence.constants.messages.tagAttributeDeleteMsg')(
                this.tag.tagName,
                e.rowData.libAttribute.attributeType,
                e.rowData.libAttribute.attributeName
              )
            );
            this.gridApi.onFilterChanged();
          });
      });
  }
  ngOnDestroy(): void {
    this.paginatorRef.destroy({ clearCache: true, currentPage: 1 });
  }
}
