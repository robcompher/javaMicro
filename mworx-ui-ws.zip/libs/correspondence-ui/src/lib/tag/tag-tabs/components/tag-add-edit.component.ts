import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { LibList, LookupDataService, LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector, ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest, Observable } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { TagService } from '../../services/tag.service';
import { TagQuery } from '../../state/tag.query';

@UntilDestroy()
@Component({
  selector: 'correspondence-tag-add-edit',
  templateUrl: './tag-add-edit.component.html',
  styleUrls: ['./tag-add-edit.component.scss'],
})
export class TagAddEditComponent implements OnInit {
  tagAddEditForm: FormGroup;
  pageTitle: string;
  private fb: FormBuilder;
  id: ID;
  tagService: TagService;
  lobLibListItems$: Observable<LibList[]>;
  tagTypeListItems$: Observable<LibList[]>;
  lobId: number;

  url: string;
  action: string;
  @ViewChild('tagAddEditFormDirective')
  tagAddEditFormDirective: FormGroupDirective;
  errorService: ErrorService;
  notifyService: NotificationService;
  configService: ConfigService;
  authService: SessionService;
  tagQuery: TagQuery;
  lookupService: LookupService;
  lookupDataService: LookupDataService;
  eventService: EventService;
  constructor(private requestService: RequestService) {
    this.fb = AppInjector.get(FormBuilder);
    this.tagService = AppInjector.get(TagService);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.configService = AppInjector.get(ConfigService);
    this.tagQuery = AppInjector.get(TagQuery);
    this.authService = AppInjector.get(SessionService);
    this.lookupService = AppInjector.get(LookupService);
    this.lookupDataService = AppInjector.get(LookupDataService);
    this.eventService = AppInjector.get(EventService);
  }

  ngOnInit(): void {
    this.buildForm();
    this.initEventSubscribers();
    this.url = this.requestService.url();
    this.lobLibListItems$ = this.lookupService.getAllLobs();
    this.tagTypeListItems$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.tagType'));
    this.tagAddEditForm
      .get('lobId')
      .valueChanges.pipe(
        untilDestroyed(this),
        filter(res => !!res)
      )
      .subscribe(lobId => {
        this.tagTypeListItems$ = this.lookupDataService.getLibListByCategoryWithLOB(
          this.configService.get('metadata.constants.categories.tagType'),
          lobId
        );
      });
    if (this.authService.currentUser().currentLobName !== this.configService.get('auth.constants.systemLob')) {
      this.tagAddEditForm.controls['lobId'].disable();
      this.lobId = this.authService.getCurrentUserLob().lobId;
      this.tagAddEditForm.patchValue({ lobId: this.lobId });
    }

    if (this.url.search('add') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this))
        .subscribe(res => {
          this.id = res.data.id;
          this.tagService
            .getTagById(this.id)
            .pipe(untilDestroyed(this))
            .subscribe(() => {});
          combineLatest([this.tagQuery.selectLoading(), this.tagQuery.tags$(this.id)])
            .pipe(untilDestroyed(this))
            .subscribe(([loading, tag]) => {
              if (!loading && tag) {
                this.action = 'updated';
                if (this.requestService.url().search('view') !== -1) {
                  this.tagAddEditForm.disable();
                }
                this.tagAddEditForm.patchValue({ ...tag, lobId: tag.lob.lobId }, { emitEvent: true });
                this.requestService
                  .selectData()
                  .pipe(untilDestroyed(this))
                  .subscribe(data => {
                    this.pageTitle = data.title + ' : ' + tag.tagName;
                  });
              }
            });
        });
    } else {
      this.action = 'created';
    }
  }

  initEventSubscribers() {
    this.eventService
      .on('onResetForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'tagEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });
  }

  private initializeData() {
    if (this.id) {
      this.tagQuery
        .tags$(this.id)
        .pipe(untilDestroyed(this))
        .subscribe(u => {
          this.tagAddEditFormDirective.resetForm(u);
        });
    } else if (this.tagAddEditFormDirective) {
      this.tagAddEditFormDirective.resetForm({ active: 'Y', lobId: this.lobId });
    }
  }

  private buildForm() {
    this.tagAddEditForm = this.fb.group({
      tagName: [null, [Validators.required]],
      tagType: [null, [Validators.required]],
      dataformat: [null],
      bizDescription: [null],
      techDefinition: [null, [Validators.required]],
      active: ['Y'],
      lobId: [null, [Validators.required]],
    });
  }

  onReset() {
    this.initializeData();
  }

  onSubmit() {
    if (this.tagAddEditForm.invalid) {
      return;
    }
    const tagForm = this.tagAddEditForm.value;
    tagForm.id = this.id;
    // if lobId disabled can't get it from form so use variable
    const lobId = tagForm.lobId ? tagForm.lobId : this.lobId;

    this.tagService
      .addOrUpdateTag(tagForm, lobId)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.tagAddEditForm, error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')(this.action, 'Tag', response.tagName));
        this.tagService.setRefreshSearchGrid(true);
        if (!this.id) {
          this.requestService.navigate(['/correspondence/tag/edit'], { state: { data: response } });
        }
      });
  }
}
