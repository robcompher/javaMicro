import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { TagState, TagStore } from './tag.store';

@Injectable({ providedIn: 'root' })
export class TagQuery extends QueryEntity<TagState> {
  constructor(protected store: TagStore) {
    super(store);
  }

  filters$ = this.select(state => state.ui.filters);
  tags$ = id => this.selectEntity(id);
}
