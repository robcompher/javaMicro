import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Tag } from '../models/tag.model';

export interface TagState extends EntityState<Tag> {}

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'tag', idKey: 'id' })
export class TagStore extends EntityStore<TagState> {
  constructor() {
    super();
  }
}
