import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { TagSearchState, TagSearchStore } from './tag-search.store';

@Injectable({ providedIn: 'root' })
export class TagSearchQuery extends QueryEntity<TagSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: TagSearchStore) {
    super(store);
  }
}
