import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { TagAttributeSearchState, TagAttributeSearchStore } from './tag-attributes-search.store';

@Injectable({ providedIn: 'root' })
export class TagAttributeSearchQuery extends QueryEntity<TagAttributeSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: TagAttributeSearchStore) {
    super(store);
  }
}
