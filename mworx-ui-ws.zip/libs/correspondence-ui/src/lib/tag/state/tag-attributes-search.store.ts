import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { LinkedTagAttributes } from '../models/linked-tag-attribute.model';
import { TagAttributeSearchCriteria } from '../models/tag-attribute-search.model';

export interface TagAttributeSearchState extends EntityState<LinkedTagAttributes> {}

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'created',
        sortOrder: 'desc',
      },
      libAttributeId: null,
      libTagId: null,
      active: 'Y',
      lob: {
        lobId: null,
      },
    } as TagAttributeSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'tagAttributes-search', idKey: 'id', resettable: true })
export class TagAttributeSearchStore extends EntityStore<TagAttributeSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<TagAttributeSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
