import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { TagSearchCriteria } from '../models/tag-search.model';
import { Tag } from '../models/tag.model';

export interface TagSearchState extends EntityState<Tag> {}
let refreshSearchGrid = false;
const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'tagName',
        sortOrder: 'asc',
      },
      tagName: null,
      tagType: null,
      dataformat: null,
      bizDescription: null,
      libLtrId: null,
      active: 'Y',
      lob: {
        lobId: null,
      },
    } as TagSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'tag-search', idKey: 'id', resettable: true })
export class TagSearchStore extends EntityStore<TagSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<TagSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
