import { ID } from '@datorama/akita';

export interface Tag {
  id: ID;
  lob: {
    lobId: number;
    lobName: string;
    organizationName: string;
    organizationId: number;
  };
  tagName: string;
  tagTypeValue: string;
  bizDescription: string;
  techDefinition: string;
  dataformat: string;
  active: string;
  tagType: number;
}
