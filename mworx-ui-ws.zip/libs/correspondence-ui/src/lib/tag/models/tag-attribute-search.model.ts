import { SearchCriteria } from '@mworx/grid';

export interface TagAttributeSearchCriteria extends SearchCriteria {
  libAttributeId: number;
  libTagId: number;
  active: string;
}
