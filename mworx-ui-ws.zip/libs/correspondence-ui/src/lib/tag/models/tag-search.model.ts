import { SearchCriteria } from '@mworx/grid';

export interface TagSearchCriteria extends SearchCriteria {
  tagName: string;
  tagType: number;
  active: string;
  lob: {
    lobId: number;
  };
}
