import { Attribute } from '@mworx/lookup';
import { LinkedTagAttributes } from './linked-tag-attribute.model';

export interface AttributeLinkedTags extends Attribute {
  linkedTagAttributes: Array<LinkedTagAttributes>;
}
