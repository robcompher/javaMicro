import { ID } from '@datorama/akita';
import { Attribute } from '@mworx/lookup';
import { Tag } from './tag.model';

export interface LinkedTagAttributes {
  id: ID;
  libAttributeId: number;
  libTagId: number;
  libTag: Tag;
  libAttribute: Attribute;
  active: string;
}
