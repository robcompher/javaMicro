import { ID } from '@datorama/akita';

export interface LinkedLetterTagID {
  id: ID;
  libLtrId: number;
  libTagId: number;
  active: string;
}
