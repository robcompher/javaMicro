export interface MultipleTagAdd {
  libLtrId: number;
  libTagId: number;
  active: string;
  libTagIds: Array<number | string>;
}
