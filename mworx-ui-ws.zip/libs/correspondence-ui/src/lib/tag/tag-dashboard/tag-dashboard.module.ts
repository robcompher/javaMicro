import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';
import { TagSearchModule } from '../tag-search/tag-search.module';
import { TagDashboardComponent } from './components/tag-dashboard.component';

@NgModule({
  declarations: [TagDashboardComponent],
  imports: [CommonModule, MatButtonModule, MatIconModule, RouterModule, SharedUiLayoutModule, SharedSessionModule, TagSearchModule],

  exports: [TagDashboardComponent],
})
export class TagDashboardModule {}
