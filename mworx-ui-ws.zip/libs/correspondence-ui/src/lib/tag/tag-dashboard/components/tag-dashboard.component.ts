import { Component, OnInit, ViewChild } from '@angular/core';
import { TagSearchComponent } from '../../tag-search/components/tag-search.component';

@Component({
  selector: 'correspondence-tag-dashboard',
  templateUrl: './tag-dashboard.component.html',
  styleUrls: ['./tag-dashboard.component.scss'],
})
export class TagDashboardComponent implements OnInit {
  @ViewChild('tagSearch')
  private tagSearch: TagSearchComponent;

  constructor() {}

  ngOnInit(): void {}

  onReset() {
    this.tagSearch.onReset();
  }

  onSearch() {
    this.tagSearch.onSearch();
  }
}
