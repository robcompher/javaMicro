import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { TagSearchQuery } from '../state/tag-search.query';

export const TAG_PAGINATOR = new InjectionToken('TAG_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const tagQuery = inject(TagSearchQuery);

    return new GridPaginatorPlugin(tagQuery);
  },
});
