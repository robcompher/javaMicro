import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { LookupService } from '@mworx/lookup';
import { ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { AttributeLinkedTags } from '../../models/attribute-linked-tags.model';
import { TagService } from '../../services/tag.service';

@UntilDestroy()
@Component({
  selector: 'correspondence-tag-attribute-add',
  templateUrl: './tag-attribute-add.component.html',
  styleUrls: ['./tag-attribute-add.component.scss'],
})
export class TagAttributeAddComponent implements OnInit {
  pageTitle: string;
  tagAttributeAddForm: FormGroup;
  @ViewChild('tagAttributeAddFormDirective')
  tagAttributeAddFormDirective: FormGroupDirective;

  attributeTypes$: Observable<Array<string>>;
  attributeName$: Observable<Array<AttributeLinkedTags>>;
  attributeList: Array<AttributeLinkedTags>;
  constructor(
    private dialogRef: MatDialogRef<TagAttributeAddComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    private lookupService: LookupService,
    private fb: FormBuilder,
    private tagService: TagService,
    private errorService: ErrorService,
    private notifyService: NotificationService,
    private configService: ConfigService
  ) {}

  ngOnInit(): void {
    this.pageTitle = 'Link Attributes to ' + this.data.tag.tagName + ' For LOB ' + this.data.tag.lob.lobName;
    this.tagAttributeAddForm = this.fb.group({
      attributeType: ['', Validators.required],
      attributeNames: this.fb.group({
        attributeName: ['', Validators.required],
      }),
    });
    this.attributeTypes$ = this.lookupService.getAllAttributeTypes();
  }

  reset() {
    this.tagAttributeAddFormDirective.resetForm();
  }

  onSave() {
    if (this.tagAttributeAddForm.invalid) {
      return;
    }
    const request = this.tagAttributeAddForm.value;
    request.lob = {
      lobId: this.data.tag.lob.lobId,
    };
    request.libTagId = this.data.tag.id;
    this.tagService
      .addTagAttributes(request)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.tagAttributeAddForm, error);
        })
      )
      .subscribe(() => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')('added', 'Attributes to Tag', this.data.tag.tagName));
        this.closePopup('saved');
      });
  }

  closePopup(event?: string) {
    this.dialogRef.close({ event: event ? event : null });
  }

  chooseName(attributeType: string) {
    this.attributeName$ = this.tagService.getAttributesByType(attributeType, this.data.tag.lob.lobId, this.data.tag.id).pipe(
      untilDestroyed(this),
      tap(response => {
        this.attributeList = response;
        const attributeNameList = this.attributeList
          .filter(item => item.linkedTagAttributes?.length > 0)

          .map(item => item.attributeName);
        this.tagAttributeAddForm.patchValue({ attributeNames: { attributeName: attributeNameList } });
      })
    );
  }
}
