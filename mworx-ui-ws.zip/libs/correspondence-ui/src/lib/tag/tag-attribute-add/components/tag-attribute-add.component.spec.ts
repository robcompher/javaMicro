import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TagAttributeAddComponent } from './tag-attribute-add.component';

describe('TagAttributeAddComponent', () => {
  let component: TagAttributeAddComponent;
  let fixture: ComponentFixture<TagAttributeAddComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ TagAttributeAddComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(TagAttributeAddComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
