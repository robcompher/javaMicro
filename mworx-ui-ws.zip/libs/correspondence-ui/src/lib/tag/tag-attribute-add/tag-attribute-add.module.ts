import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule } from '@angular/router';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { TagAttributeAddComponent } from './components/tag-attribute-add.component';

@NgModule({
  declarations: [TagAttributeAddComponent],
  imports: [
    CommonModule,
    SharedUiLayoutModule,
    MatButtonModule,
    MatFormFieldModule,
    MatSelectModule,
    MatInputModule,
    MatCheckboxModule,
    MatIconModule,
    SharedUiGridModule,
    ReactiveFormsModule,
    SharedUtilModule,
    SharedUiFormsModule,
    RouterModule,
  ],
  exports: [TagAttributeAddComponent],
})
export class TagAttributeAddModule {}
