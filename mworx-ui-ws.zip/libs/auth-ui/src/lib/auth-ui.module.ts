import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedLookupModule } from '@mworx/lookup';

import { AuthUiRoutingModule } from './auth-ui-routing.module';
import { PermitDashboardModule } from './roles/permit-dashboard';
import { PermitExistModule } from './roles/permit-exist';
import { PermitNewModule } from './roles/permit-new/permit-new.module';
import { RoleDashboardModule } from './roles/role-dashboard/role-dashboard.module';
import { RoleInfoModule } from './roles/role-info';
import { RoleSearchModule } from './roles/role-search/role-search.module';
import { ChangePasswordModule } from './users/change-password/change-password.module';
import { UserContactModule } from './users/user-contact/user-contact.module';
import { UserDashboardModule } from './users/user-dashboard/user-dashboard.module';
import { UserInfoModule } from './users/user-info/user-info.module';
import { UserProfileModule } from './users/user-profile/user-profile.module';
import { UserSearchModule } from './users/user-search/user-search.module';

@NgModule({
  imports: [
    CommonModule,
    AuthUiRoutingModule,
    UserDashboardModule,
    UserSearchModule,
    RoleDashboardModule,
    PermitDashboardModule,
    PermitNewModule,
    RoleSearchModule,
    RoleInfoModule,
    PermitExistModule,
    UserProfileModule,
    UserInfoModule,
    UserContactModule,
    ChangePasswordModule,
    SharedLookupModule,
  ],
  declarations: [],
  exports: [],
})
export class AuthUiModule {}
