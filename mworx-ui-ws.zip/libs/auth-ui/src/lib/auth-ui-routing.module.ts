import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PermitsGuard } from '@mworx/session';

import { RoleAddEditComponent } from './roles/role-add-edit';
import { RoleViewComponent } from './roles/role-add-edit/components/role-view.component';
import { RoleDashboardComponent } from './roles/role-dashboard';
import { UserAddComponent } from './users/user-add-edit';
import { UserDashboardComponent } from './users/user-dashboard';
import { UserViewComponent } from './users/user-view/components/user-view-component';

const routes: Routes = [
  {
    path: 'users/dashboard',
    component: UserDashboardComponent,
    canActivate: [PermitsGuard],
    data: {
      permissions: ['PERMIT_USER_VIEW'],
    },
  },
  {
    path: 'users/add-user',
    component: UserAddComponent,
    canActivate: [PermitsGuard],
    data: { title: 'Add User', permissions: ['PERMIT_USER_UPDATE'] },
  },
  {
    path: 'users/edit-user',
    component: UserAddComponent,
    canActivate: [PermitsGuard],
    data: { title: 'Edit User', permissions: ['PERMIT_USER_UPDATE'] },
  },
  {
    path: 'roles/dashboard',
    component: RoleDashboardComponent,
    canActivate: [PermitsGuard],
    data: {
      permissions: ['PERMIT_SECURITY_VIEW'],
    },
  },
  {
    path: 'roles/add-role',
    component: RoleAddEditComponent,
    canActivate: [PermitsGuard],
    data: { title: 'Add Role', permissions: ['PERMIT_SECURITY_UPDATE'] },
  },
  {
    path: 'roles/edit-role',
    component: RoleAddEditComponent,
    canActivate: [PermitsGuard],
    data: { title: 'Edit Role', permissions: ['PERMIT_SECURITY_UPDATE'] },
  },
  {
    path: 'roles/view-role',
    component: RoleViewComponent,
    canActivate: [PermitsGuard],
    data: { title: 'View Role', permissions: ['PERMIT_SECURITY_VIEW'] },
  },
  {
    path: 'users/view-user',
    component: UserViewComponent,
    canActivate: [PermitsGuard],
    data: { title: 'View User', permissions: ['PERMIT_USER_VIEW'] },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AuthUiRoutingModule {}
