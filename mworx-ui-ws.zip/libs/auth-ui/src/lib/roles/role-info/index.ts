export * from './components/role-info.component';
export * from './role-info.module';
