import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule } from '@angular/router';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';

import { RoleInfoComponent } from './components/role-info.component';

import { RoleInfoViewComponent } from './components/role-info-view.component';

@NgModule({
  declarations: [RoleInfoComponent, RoleInfoViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    SharedUiLayoutModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatCheckboxModule,
    MatDatepickerModule,
    MatInputModule,
    SharedUiGridModule,
    SharedUtilModule,
    SharedUiFormsModule,
  ],
  exports: [RoleInfoComponent, RoleInfoViewComponent],
})
export class RoleInfoModule {}
