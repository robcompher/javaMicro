import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Role } from '../../models/role.model';
import { RoleService } from '../../services/role.service';
import { RolesQuery } from '../../state/roles.query';

@UntilDestroy()
@Component({
  selector: 'auth-role-info',
  templateUrl: './role-info.component.html',
  styleUrls: ['./role-info.component.scss'],
})
export class RoleInfoComponent implements OnInit {
  roleNewOrUpdateForm: FormGroup;
  roleName: string;
  roleType: string;
  id: ID;
  isButtonVisible = true;
  @ViewChild('userFormDirective')
  userFormDirective: FormGroupDirective;

  constructor(
    private fb: FormBuilder,
    private notifyService: NotificationService,
    private roleService: RoleService,
    private requestService: RequestService,
    private errorService: ErrorService,
    private rolesQuery: RolesQuery,
    private configService: ConfigService,
    private eventService: EventService
  ) {}

  // this is being used by both add and edit functionality
  // the params are the key as depending on whether we have
  // id this component will behave as an edit or create
  ngOnInit(): void {
    this.createForm();
    if (this.requestService.url().search('add-role') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this))
        .subscribe(res => {
          // route for this could come from either the edit link (roleId)
          // or the add link(id). this component needs to support edit in these two paths
          this.id = res.data != null ? res.data.roleId : null;
          if (this.id) {
            //edit functionality
            this.modifyFormToEdit();
          }
        });
    }
    // this is to subscribe to the reset button on the parent add/edit component
    // the reset button on the add/edit component triggers an event to the service
    // and by subscribing to that event this component now can get that event and
    // reset its form as well
    this.eventService
      .on('resetRoleForm')
      .pipe(untilDestroyed(this))
      .subscribe(() => {
        this.onResetRoleInfoForm();
      });
  }

  modifyFormToEdit() {
    combineLatest([this.rolesQuery.selectLoading(), this.rolesQuery.role$(this.id)]).subscribe(([loading, user]) => {
      if (!loading && user) {
        this.roleNewOrUpdateForm.patchValue(user, { emitEvent: false });
      }
    });
  }
  
  createForm() {
    this.roleNewOrUpdateForm = this.fb.group({
      roleId: [],
      roleType: [null, [Validators.required]],
      roleName: [null, [Validators.required]],
      effectiveDate: [null, [Validators.required]],
      termDate: [],
      description: [],
      legacySystemId: [],
      active: ['Y'],
    });
  }

  onRoleSubmit(): void {
    if (this.roleNewOrUpdateForm.invalid) {
      return;
    }
    const role = this.roleNewOrUpdateForm.value;
    if (role.roleId) {
      this.updateRole(role);
    } else {
      this.createRole(role);
    }
  }

  updateRole(role: Role): void {
    this.roleService
      .updateRole(role)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.roleNewOrUpdateForm, error);
        })
      )
      .subscribe(u => this.notifyService.showSuccess(this.configService.get('auth.messages.success.addOrUpdateRole')('updated', role.roleName)));
  }

  createRole(role: Role): void {
    this.roleService
      .addRole(role)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.roleNewOrUpdateForm, error);
        })
      )
      .subscribe(response => {
        if (response) {
          this.notifyService.showSuccess(this.configService.get('auth.messages.success.addOrUpdateRole')('created', role.roleName));
          this.requestService.navigate(['/auth/roles/edit-role'], { state: { data: response } });
        }
      });
  }

  onResetRoleInfoForm() {
    if (this.id) {
      this.rolesQuery.role$(this.id).subscribe(u => {
        this.userFormDirective.resetForm(u);
      });
    } else {
      this.userFormDirective.resetForm({ active: 'Y' });
    }
  }
}
