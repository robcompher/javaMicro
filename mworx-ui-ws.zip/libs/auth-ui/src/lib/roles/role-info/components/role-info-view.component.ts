import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ConfigService } from '@common/config';
import { LookupService } from '@mworx/lookup';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy } from '@ngneat/until-destroy';
import { RoleService } from '../../services/role.service';
import { RolesQuery } from '../../state/roles.query';
import { RoleInfoComponent } from './role-info.component';

@UntilDestroy()
@Component({
  selector: 'auth-role-info-view',
  templateUrl: './role-info.component.html',
  styleUrls: ['./role-info.component.scss'],
})
export class RoleInfoViewComponent extends RoleInfoComponent implements OnInit {
  constructor(
    fb: FormBuilder,
    notifyService: NotificationService,
    roleService: RoleService,
    lookupService: LookupService,
    requestService: RequestService,
    errorService: ErrorService,
    rolesQuery: RolesQuery,
    configService: ConfigService,
    eventService: EventService
  ) {
    super(fb, notifyService, roleService, requestService, errorService, rolesQuery, configService, eventService);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.roleNewOrUpdateForm.disable();
  }
}
