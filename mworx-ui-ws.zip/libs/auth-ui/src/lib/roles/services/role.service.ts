import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse } from '@datorama/akita';
import { EventService } from '@mworx/util';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { Role } from '../models/role.model';
import { RoleSearchCriteria } from '../role-search/models/role-search-criteria.model';
import { RolesStore } from '../state/roles.store';

@Injectable({ providedIn: 'root' })
export class RoleService {
  constructor(private rolesStore: RolesStore, private http: HttpClient, private configService: ConfigService, private eventService: EventService) {}
  roleSearchCriteria: RoleSearchCriteria;

  search(): Observable<PaginationResponse<Role>> {
    const criteria = this.rolesStore.getValue().ui.filters;

    return this.http.post<PaginationResponse<Role>>(this.configService.get('auth.constants.url.role.roleSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.page,
          perPage: criteria.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pageSize),
          ...searchResponse,
        } as PaginationResponse<Role>;
      })
    );
  }

  add(role: Role) {
    this.rolesStore.add(role);
  }

  resetRoleForm(): void {
    this.eventService.dispatch('resetRoleForm');
  }

  addRole(role: Role): Observable<Role> {
    return this.http.post<Role>(this.configService.get('auth.constants.url.role.addRole'), role).pipe(
      map(response => {
        this.rolesStore.upsert(response.roleId, response);

        return response;
      })
    );
  }

  updateRole(role: Role): Observable<Role> {
    return this.http.put<Role>(this.configService.get('auth.constants.url.role.updateRole'), role).pipe(
      map(response => {
        this.updateRoleStore(response);

        return response;
      })
    );
  }

  update(id, role: Partial<Role>) {
    this.rolesStore.update(id, role);
  }

  remove(id: ID) {
    this.rolesStore.remove(id);
  }

  updateSearchCriteria(criteria: RoleSearchCriteria) {
    const prevCriteria = this.rolesStore.getValue().ui.filters;
    this.rolesStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  updateRoleStore(role: Role): Observable<Role> {
    this.rolesStore.update(role.roleId, role);

    return of(role);
  }

  deleteRole(id: ID): Observable<any> {
    return this.http
      .put<any>(this.configService.get('auth.constants.url.role.deleteRole'), { id: id })
      .pipe(
        tap(resp => {
          this.rolesStore.remove(id);
        })
      );
  }
}
