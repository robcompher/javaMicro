import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { PaginationResponse } from '@datorama/akita';
import { Observable, Subject } from 'rxjs';
import { map } from 'rxjs/operators';
import { Permit } from '../models/permit.model';
import { Role } from '../models/role.model';
import { PermitSearchCriteria } from '../permit-exist/models/permit-search-criteria.model';
import { ExistingPermitsStore, NewPermitsStore } from '../state/permits.store';

@Injectable({ providedIn: 'root' })
export class PermitService {
  constructor(
    private existingPermitsStore: ExistingPermitsStore,
    private newPermitsStore: NewPermitsStore,
    private http: HttpClient,
    private configService: ConfigService,
    private newStore: NewPermitsStore
  ) {}
  onPermitFormReset = new Subject<void>();
  permitSearchCriteria: PermitSearchCriteria;

  searchNew(): Observable<PaginationResponse<Permit>> {
    const roleIdCriteria = this.newStore.getValue().ui.filters;

    return this.search(roleIdCriteria);
  }

  searchExist(): Observable<PaginationResponse<Permit>> {
    const roleIdCriteria = this.existingPermitsStore.getValue().ui.filters;

    return this.search(roleIdCriteria);
  }

  private search(roleIdCriteria: any): Observable<PaginationResponse<Permit>> {
    return this.http
      .post<PaginationResponse<Permit>>(this.configService.get('auth.constants.url.role.findByPermitSearchCriteria'), roleIdCriteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: roleIdCriteria.page,
            perPage: roleIdCriteria.pageSize,
            lastPage: Math.ceil(searchResponse.total / roleIdCriteria.pageSize),
            ...searchResponse,
          } as PaginationResponse<Permit>;
        })
      );
  }

  resetForm(): void {
    this.onPermitFormReset.next();
  }

  deletePermit(permit: Partial<Permit>) {
    return this.http.post(this.configService.get('auth.constants.url.role.deletePermit'), permit).pipe(
      map(response => {
        this.existingPermitsStore.remove(permit.linkId);
        this.resetForm();

        return response;
      })
    );
  }

  updateRole(role: Partial<Role>) {
    return this.http.post<Role>(this.configService.get('auth.constants.url.role.addPermit'), role).pipe(
      map(response => {
        this.newStore.remove(role.permits);
        this.resetForm();

        return response;
      })
    );
  }

  updateNewSearchCriteria(criteria: PermitSearchCriteria) {
    const prevCriteria = this.newPermitsStore.getValue().ui.filters;

    this.newPermitsStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  updateExistingSearchCriteria(criteria: PermitSearchCriteria) {
    const prevCriteria = this.existingPermitsStore.getValue().ui.filters;

    this.existingPermitsStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }
}
