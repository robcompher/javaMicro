import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { RoleSearchComponent } from '../../role-search';

@Component({
  selector: 'auth-role-dashboard',
  templateUrl: './role-dashboard.component.html',
  styleUrls: ['./role-dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class RoleDashboardComponent implements OnInit {
  @ViewChild('roleSearch')
  private roleSearch: RoleSearchComponent;

  constructor() {}

  ngOnInit(): void {}

  onSearch($event) {
    this.roleSearch.onSearch($event);
  }

  onReset($event) {
    this.roleSearch.onReset($event);
  }

  addRole(): void {}
}
