import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';

import { RoleSearchModule } from '../role-search/role-search.module';
import { RoleDashboardComponent } from './components/role-dashboard.component';

@NgModule({
  declarations: [RoleDashboardComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatExpansionModule,
    MatButtonModule,
    SharedUiLayoutModule,
    RoleSearchModule,
    RouterModule,
    SharedSessionModule,
  ],

  exports: [RoleDashboardComponent],
})
export class RoleDashboardModule {}
