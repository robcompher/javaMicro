import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { ExistingPermitsStore, NewPermitsStore, PermitState } from './permits.store';

@Injectable({ providedIn: 'root' })
export class ExistingPermitsQuery extends QueryEntity<PermitState> {
  constructor(protected store: ExistingPermitsStore) {
    super(store);
  }
  filters$ = this.select(state => {
    return state.ui.filters;
  });
  initialState$ = this.store.getInitialState();
  permit$ = id => this.selectEntity(id);
}

@Injectable({ providedIn: 'root' })
export class NewPermitsQuery extends QueryEntity<PermitState> {
  constructor(protected store: NewPermitsStore) {
    super(store);
  }
  initialState$ = this.store.getInitialState();
  filters$ = this.select(state => state.ui.filters);
  permit$ = id => this.selectEntity(id);
}
