import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { Permit } from '../models/permit.model';
import { PermitSearchCriteria } from '../permit-exist/models/permit-search-criteria.model';

export interface PermitState extends EntityState<Permit> {}

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'permitPrimary',
        sortOrder: 'asc',
      },
      roleId: null,
      lob: {
        lobName: null,
        lobId: null,
      },
      primaryPermit: null,
      secondaryPermit: null,
      existing: null,
    } as PermitSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'existingPermits', idKey: 'linkId', resettable: true })
export class ExistingPermitsStore extends EntityStore<PermitState> {
  constructor() {
    super(initialState);
  }
  getInitialState(): Observable<PermitSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'newPermits', idKey: 'id', resettable: true })
export class NewPermitsStore extends EntityStore<PermitState> {
  constructor() {
    super(initialState);
  }
  getInitialState(): Observable<PermitSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
