import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { Role } from '../models/role.model';
import { RoleSearchCriteria } from '../role-search/models/role-search-criteria.model';

export interface RolesState extends EntityState<Role> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'roleType',
        sortOrder: 'asc',
      },
      roleType: null,
      roleName: null,
      primaryPermit: null,
      secondaryPermit: null,
      active: 'Y',
    } as RoleSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'roles-search', idKey: 'roleId', resettable: true })
export class RolesStore extends EntityStore<RolesState> {
  constructor() {
    super(initialState);
  }
  getInitialState(): Observable<RoleSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
