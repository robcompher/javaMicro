import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';

import { RolesState, RolesStore } from './roles.store';

@Injectable({ providedIn: 'root' })
export class RolesQuery extends QueryEntity<RolesState> {
  constructor(protected store: RolesStore) {
    super(store);
  }
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  role$ = id => this.selectEntity(id);
}
