import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { filter } from 'rxjs/operators';
import { RoleService } from '../../services/role.service';

@UntilDestroy()
@Component({
  selector: 'auth-role-add-edit',
  templateUrl: './role-add-edit.component.html',
  styleUrls: ['./role-add-edit.component.scss'],
})
export class RoleAddEditComponent implements OnInit {
  tabs = [];
  loadedStatus: Array<number>;
  roleName: string;
  pageTitle: string;
  showSaveAndResetButtons = true;

  constructor(private roleService: RoleService, private requestService: RequestService) { }

  ngOnInit() {
    this.requestService
      .selectData()
      .pipe(untilDestroyed(this))
      .subscribe(data => {
        this.pageTitle = data.title;
      });
    if (this.requestService.url().search('add') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this),
          filter(res => res.data !== null))
        .subscribe(res => {
          this.roleName = res.data.roleName ? res.data.roleName : null;
          if (this.roleName) {
            this.pageTitle = this.pageTitle + ' : ' + this.roleName;
          }
        });
    }

    this.loadedStatus = new Array<number>();
    this.initTabs();
    //default load first tab
    this.loadedStatus.push(0);
  }

  protected initTabs() {
    this.tabs.push({
      tabName: 'Role Info',
      content: import('../../role-info/components/role-info.component').then(({ RoleInfoComponent }) => RoleInfoComponent),
    });
    //permit tabs should be enabled only when editing/viewing the role, not when adding
    if (this.requestService.url().search('add-role') === -1) {
      this.tabs.push({
        tabName: 'Permit Info',
        content: import('../../permit-dashboard/components/permit-dashboard.component').then(
          ({ PermitDashboardComponent }) => PermitDashboardComponent
        ),
      });
    }
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    if (this.loadedStatus.indexOf(tabChangeEvent.index) === -1) {
      this.loadedStatus.push(tabChangeEvent.index);
    }
    this.showSaveAndResetButtons = tabChangeEvent.index > 0 ? false : true;
  }

  onResetUserForm() {
    this.roleService.resetRoleForm();
  }
}
