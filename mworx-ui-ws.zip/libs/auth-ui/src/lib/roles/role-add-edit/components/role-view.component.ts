import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { RequestService } from '@mworx/util';
import { RoleService } from '../../services/role.service';
import { RoleAddEditComponent } from './role-add-edit.component';

@Component({
  selector: 'auth-role-view',
  templateUrl: './role-add-edit.component.html',
  styleUrls: ['./role-add-edit.component.scss'],
})
export class RoleViewComponent extends RoleAddEditComponent implements OnInit {
  showSaveAndResetButtons = false;
  
  constructor(roleService: RoleService, requestService: RequestService) {
    super(roleService, requestService);
  }

  protected initTabs() {
    this.tabs.push({
      tabName: 'Role Info',
      content: import('../../role-info/components/role-info-view.component').then(({ RoleInfoViewComponent }) => RoleInfoViewComponent),
    });
    this.tabs.push({
      tabName: 'Permit Info',
      content: import('../../permit-dashboard/components/permit-dashboard.component').then(
        ({ PermitDashboardComponent }) => PermitDashboardComponent
      ),
    });
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    super.onTabChange(tabChangeEvent);
    this.showSaveAndResetButtons = false;
  }
}
