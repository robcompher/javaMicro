import { ID } from '@datorama/akita';
import { SearchCriteria } from '@mworx/grid';

export interface PermitSearchCriteria extends SearchCriteria {
  roleId: ID;
  lob: {
    lobName: string;
    lobId: string;
  };
  primaryPermit: string;
  secondaryPermit: string;
  existing: boolean;
}
