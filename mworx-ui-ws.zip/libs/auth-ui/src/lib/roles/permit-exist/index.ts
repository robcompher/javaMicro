export * from './components/permit-exist.component';
export * from './permit-exist.module';
