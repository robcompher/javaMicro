import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { GridPaginatorPlugin } from '@mworx/grid';
import { LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { ValueGetterParams } from 'ag-grid-community';
import { NGXLogger } from 'ngx-logger';
import { PermitService } from '../../services/permit.service';
import { ExistingPermitsQuery } from '../../state/permit.query';
import { PermitState } from '../../state/permits.store';
import { EXIST_PERMIT_SEARCH_PAGINATOR } from '../permit-exist-search-paginator';
import { PermitBaseComponent } from './permit-base/permit-base.component';

@UntilDestroy()
@Component({
  selector: 'auth-permit-exist',
  templateUrl: './permit-exist.component.html',
  styleUrls: ['./permit-exist.component.scss'],
})
export class PermitExistComponent extends PermitBaseComponent implements OnInit, OnDestroy {
  roleId: ID;
  columnDefs: any = [
    {
      headerName: 'Primary Permit',
      field: 'permitPrimary',
    },
    {
      headerName: 'Secondary Permit',
      field: 'permitSecondary',
      sortable: false,
    },
    {
      headerName: 'Description',
      field: 'description',
      sortable: false,
    },
    {
      headerName: 'Actions',
      sortable: false,
      hide: !this.isEditable(),
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onDeleteActionClick.bind(this),
            label: 'Delete',
            icon: 'delete',
            color: 'warn',
            permissions: ['PERMIT_SECURITY_UPDATE'],
          },
        ],
      },
    },
  ];

  constructor(
    public fb: FormBuilder,
    public logger: NGXLogger,
    public requestService: RequestService,
    public errorService: ErrorService,
    public lookupService: LookupService,
    public permitService: PermitService,
    public authService: SessionService,
    public existQuery: ExistingPermitsQuery,
    public notifyService: NotificationService,
    public configService: ConfigService,
    @Inject(EXIST_PERMIT_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<PermitState>
  ) {
    super(
      fb,
      logger,
      requestService,
      errorService,
      lookupService,
      permitService,
      authService,
      existQuery,
      notifyService,
      configService,
      paginatorRef
    );
  }

  onPermitSearchSubmit() {
    const clientQuery = this.permitSearchForm.value;
    if (!clientQuery.lob || !clientQuery.lob.lobId) {
      clientQuery.lob = null;
    }
    this.permitService.updateExistingSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  isEditable(): boolean {
    return this.requestService.url().search('edit') !== -1;
  }

  ngOnInit(): void {
    super.ngOnInit();
    const currentLobId = this.authService.currentUser().currentLobId;
    if (this.amISystemLob()) {
      this.columnDefs.unshift({
        headerName: 'LOB Name',
        field: 'lobId',
        sortable: false,
        valueGetter: (params: ValueGetterParams) => this.getLobNameById(params),
      });
    }
    this.permitSearchForm = new FormGroup({
      roleId: new FormControl(''),
      primaryPermit: new FormControl(''),
      secondaryPermit: new FormControl(''),
      lob: new FormGroup({
        lobId: new FormControl(''),
      }),
    });

    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.permitSearchForm.patchValue({ roleId: res.data.roleId, lob: { lobId: currentLobId } });
        this.permitService.updateExistingSearchCriteria(this.permitSearchForm.value);
      });

    this.paginatorRef.requestFunction = () => this.permitService.searchExist();
    this.paginatorRef.filtersUpdateFunction = criteria => this.permitService.updateExistingSearchCriteria({ ...criteria, ...{ existing: true } });
  }

  ngOnDestroy(): void {
    this.paginatorRef.destroy({ clearCache: true, currentPage: 1 });
    this.existQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => this.permitService.updateExistingSearchCriteria(criteria));
  }
}
