import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ConfigService } from '@common/config';
import { QueryEntity } from '@datorama/akita';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { ColumnApi, FirstDataRenderedEvent, GridApi, GridOptions, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { PermitService } from '../../../services/permit.service';
import { PermitState } from '../../../state/permits.store';

@UntilDestroy()
@Component({
  selector: 'auth-permit-base',
  template: ``,
})
export class PermitBaseComponent implements OnInit {
  constructor(
    protected fb: FormBuilder,
    protected logger: NGXLogger,
    protected requestService: RequestService,
    protected errorService: ErrorService,
    protected lookupService: LookupService,
    protected permitService: PermitService,
    protected authService: SessionService,
    protected baseQuery: QueryEntity<PermitState>,
    protected notifyService: NotificationService,
    protected configService: ConfigService,
    protected paginatorRef: GridPaginatorPlugin<PermitState>
  ) {}

  permitSearchForm: FormGroup;
  gridApi: GridApi;

  gridColumnApi: ColumnApi;
  lobLibListItems$: Observable<LibList[]>;
  frameworkComponents = { buttonRenderer: GridActionsComponent };

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    rowSelection: 'multiple',
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
      this.gridColumnApi = event.columnApi;
    },
    onFirstDataRendered: (event: FirstDataRenderedEvent) => {
      setTimeout(() => {
        this.gridColumnApi.autoSizeAllColumns();
        this.gridApi.sizeColumnsToFit();
      }, 400);
    },
  };

  protected getLobNameById(params: ValueGetterParams) {
    let lobName = null;
    if (params.data) {
      this.lobLibListItems$
        .pipe(
          map(liblistArray => {
            return liblistArray.find(eachLibList => eachLibList.id === params.data.lobId);
          })
        )
        .subscribe(foundLob => (foundLob != null ? (lobName = foundLob.label) : (lobName = null)));
    }

    return lobName;
  }

  onDeleteActionClick(e: any) {
    const deletePermit = {
      linkId: e.rowData.linkId,
      roleId: this.permitSearchForm.get('roleId').value,
    };

    this.permitService
      .deletePermit(deletePermit)
      .pipe(
        catchError((response: HttpErrorResponse) => {
          return this.errorService.handleTableValidationErrors(response);
        }),
        untilDestroyed(this)
      )
      .subscribe(() => {
        this.notifyService.showSuccess(
          this.configService.get('auth.messages.success.delete')('Permit', e.rowData.permitPrimary, e.rowData.permitSecondary)
        );
        this.gridApi.onFilterChanged();
      });
  }

  onPermitSearchSubmit() {}

  amISystemLob() {
    const currentLobName = this.authService.currentUser().currentLobName;
    if (currentLobName !== this.configService.get('auth.constants.systemLob')) {
      return false;
    }

    return true;
  }
  ngOnInit(): void {
    this.lobLibListItems$ = this.lookupService.getAllLobs();

    this.permitService.onPermitFormReset.pipe(untilDestroyed(this)).subscribe(() => {
      this.onPermitSearchSubmit();
    });
  }
}
