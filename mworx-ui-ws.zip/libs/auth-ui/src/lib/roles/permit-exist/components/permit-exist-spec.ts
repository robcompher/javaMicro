import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitExistComponent } from './permit-exist.component';

describe('PermitExistComponent', () => {
  let component: PermitExistComponent;
  let fixture: ComponentFixture<PermitExistComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [PermitExistComponent],
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PermitExistComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
