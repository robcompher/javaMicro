import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedLookupModule } from '@mworx/lookup';
import { SharedUtilModule } from '@mworx/util';
import { PermitBaseComponent } from './components/permit-base/permit-base.component';
import { PermitExistComponent } from './components/permit-exist.component';

@NgModule({
  declarations: [PermitExistComponent, PermitBaseComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatSelectModule,
    MatInputModule,
    ReactiveFormsModule,
    SharedUiGridModule,
    SharedUiLayoutModule,
    SharedLookupModule,
    ReactiveFormsModule,
    MatInputModule,
    SharedUtilModule,
    SharedUiFormsModule,
  ],
  exports: [PermitExistComponent],
})
export class PermitExistModule {}
