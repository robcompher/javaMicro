export * from './components/permit-new.component';
export * from './permit-new.module';
