import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatSelectModule } from '@angular/material/select';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedLookupModule } from '@mworx/lookup';
import { SharedSessionModule } from '@mworx/session';
import { SharedUtilModule } from '@mworx/util';
import { AgGridModule } from 'ag-grid-angular';

import { PermitNewComponent } from './components/permit-new.component';

@NgModule({
  declarations: [PermitNewComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatExpansionModule,
    MatSelectModule,
    MatInputModule,
    MatPaginatorModule,
    ReactiveFormsModule,
    SharedUiGridModule,
    SharedUiLayoutModule,
    SharedSessionModule,
    SharedLookupModule,
    ReactiveFormsModule,
    MatInputModule,
    SharedUtilModule,
    SharedUiFormsModule,
    AgGridModule,
  ],
  exports: [PermitNewComponent],
})
export class PermitNewModule {}
