import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';

import { NewPermitsQuery } from '../state/permit.query';

export const NEW_SEARCH_PAGINATOR = new InjectionToken('NEW_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const permitsQuery = inject(NewPermitsQuery);

    return new GridPaginatorPlugin(permitsQuery);
  },
});
