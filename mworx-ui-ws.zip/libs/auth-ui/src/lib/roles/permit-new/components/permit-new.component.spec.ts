import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitNewComponent } from './permit-new.component';

describe('PermitNewComponent', () => {
  let component: PermitNewComponent;
  let fixture: ComponentFixture<PermitNewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PermitNewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PermitNewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
