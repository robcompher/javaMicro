import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridOptions, GridReadyEvent } from 'ag-grid-community';
import { NGXLogger } from 'ngx-logger';
import { catchError } from 'rxjs/operators';
import { Permit } from '../../models/permit.model';
import { PermitBaseComponent } from '../../permit-exist/components/permit-base/permit-base.component';
import { PermitService } from '../../services/permit.service';
import { NewPermitsQuery } from '../../state/permit.query';
import { PermitState } from '../../state/permits.store';
import { NEW_SEARCH_PAGINATOR } from '../permit-new-search-paginator';

@UntilDestroy()
@Component({
  selector: 'auth-permit-new',
  templateUrl: './permit-new.component.html',
  styleUrls: ['./permit-new.component.scss'],
})
export class PermitNewComponent extends PermitBaseComponent implements OnInit, OnDestroy {
  roleName: string;
  roleType: string;
  roleId: ID;
  permitsSelected: Permit[] = [];
  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    rowSelection: 'multiple',
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
      this.gridColumnApi = event.columnApi;
    },
    onRowSelected: event => {
      const index = this.permitsSelected.findIndex(permit => permit.id === event.node.data.id);
      if (event.node.isSelected() && index === -1) {
        this.permitsSelected.push(event.node.data);
      } else if (index !== -1) {
        this.permitsSelected.splice(index, 1);
      }
    },
    onPaginationChanged: () => {
      this.gridApi?.forEachNode(node =>
        this.permitsSelected.findIndex(permit => permit.id === node.data.id) !== -1 ? node.setSelected(true) : null
      );
    },
  };
  columnDefs = [
    {
      headerCheckboxSelection: true,
      checkboxSelection: true,
      maxWidth: 80,
      resizable: false,
    },
    {
      headerName: 'Primary Permit',
      field: 'permitPrimary',
    },
    {
      headerName: 'Secondary Permit',
      field: 'permitSecondary',
      sortable: false,
    },
    {
      headerName: 'Description',
      field: 'description',
      sortable: false,
    },
  ];
  constructor(
    public fb: FormBuilder,
    public logger: NGXLogger,
    public requestService: RequestService,
    public errorService: ErrorService,
    public lookupService: LookupService,
    public permitService: PermitService,
    public authService: SessionService,
    public newQuery: NewPermitsQuery,
    public notifyService: NotificationService,
    public configService: ConfigService,
    @Inject(NEW_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<PermitState>
  ) {
    super(fb, logger, requestService, errorService, lookupService, permitService, authService, newQuery, notifyService, configService, paginatorRef);
  }

  onPermitSearchSubmit() {
    this.permitsSelected = [];
    const clientQuery = this.permitSearchForm.value;
    if (!clientQuery.lob || !clientQuery.lob.lobId) {
      clientQuery.lob = null;
    }
    this.permitService.updateNewSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onSave() {
    const role = {
      roleType: this.roleType,
      roleName: this.roleName,
      active: 'Y',
      permits: this.permitsSelected.map(rec => ({
        ...rec,
        lob: this.permitSearchForm.value.lob,
      })),
    };
    this.permitService
      .updateRole(role)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.permitSearchForm, error);
        }),
        untilDestroyed(this)
      )
      .subscribe(res => {
        this.notifyService.showSuccess(this.configService.get('auth.messages.success.addOrUpdateRole')('updated', role.roleType));
        this.gridApi.onFilterChanged();
      });
  }

  ngOnInit(): void {
    super.ngOnInit();
    const currentLobId = this.authService.currentUser().currentLobId;

    this.permitSearchForm = new FormGroup({
      roleId: new FormControl(''),
      primaryPermit: new FormControl(''),
      secondaryPermit: new FormControl(''),
      lob: new FormGroup({
        lobId: new FormControl(''),
      }),
    });

    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.roleName = res.data.roleName;
        this.roleType = res.data.roleType;
        this.permitSearchForm.patchValue({ roleId: res.data.roleId, lob: { lobId: currentLobId } });
        this.permitService.updateNewSearchCriteria(this.permitSearchForm.value);
      });

    this.paginatorRef.requestFunction = () => this.permitService.searchNew();
    this.paginatorRef.filtersUpdateFunction = criteria => this.permitService.updateNewSearchCriteria({ ...criteria, ...{ existing: false } });
  }

  ngOnDestroy(): void {
    this.paginatorRef.destroy({ clearCache: true, currentPage: 1 });
    this.newQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => this.permitService.updateNewSearchCriteria(criteria));
  }
}
