import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { RolesQuery } from '../state/roles.query';

export const ROLE_SEARCH_PAGINATOR = new InjectionToken('ROLE_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const rolesQuery = inject(RolesQuery);

    return new GridPaginatorPlugin(rolesQuery);
  },
});
