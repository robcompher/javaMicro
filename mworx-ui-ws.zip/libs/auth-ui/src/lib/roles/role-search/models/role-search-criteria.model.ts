import { SearchCriteria } from '@mworx/grid';

export interface RoleSearchCriteria extends SearchCriteria {
  roleType: string;
  roleName: string;
  primaryPermit: string;
  secondaryPermit: string;
  active: string;
}
