import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, Injector, NgZone, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { ListChoice, LookupService } from '@mworx/lookup';
import { ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent, GridSizeChangedEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { catchError, take, tap } from 'rxjs/operators';
import { RoleService } from '../../services/role.service';
import { RolesQuery } from '../../state/roles.query';
import { RolesState } from '../../state/roles.store';
import { ROLE_SEARCH_PAGINATOR } from '../role-search-paginator';

@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'auth-role-search',
  templateUrl: './role-search.component.html',
  styleUrls: ['./role-search.component.scss'],
})
export class RoleSearchComponent implements OnInit {
  gridApi: GridApi;
  roleSearchForm: FormGroup;
  arr$: Observable<Array<ListChoice>>;
  columnDefs = [
    { headerName: 'Role Type', field: 'roleType' },
    { headerName: 'Role Name', field: 'roleName' },
    { headerName: 'Role Description', field: 'description', sortable: false },
    { headerName: 'Active', field: 'active' },
    {
      headerName: 'Actions',
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onViewActionClick.bind(this),
            label: 'View',
            icon: 'remove_red_eye',
            color: 'primary',
            permissions: ['PERMIT_SECURITY_VIEW'],
          },
          {
            onClick: this.onEditActionClick.bind(this),
            label: 'Edit',
            icon: 'edit',
            color: 'primary',
            permissions: ['PERMIT_SECURITY_UPDATE'],
          },
          {
            onClick: this.onDeleteActionClick.bind(this),
            label: 'Delete',
            icon: 'delete',
            color: 'warn',
            permissions: ['PERMIT_SECURITY_UPDATE'],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridSizeChanged: (event: GridSizeChangedEvent) => {
      this.onGridSizeChanged(event);
    },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
  };

  constructor(
    private fb: FormBuilder,
    private roleService: RoleService,
    private roleQuery: RolesQuery,
    private lookupService: LookupService,
    private configService: ConfigService,
    private injector: Injector,
    private requestService: RequestService,
    private notificationService: NotificationService,
    private errorService: ErrorService,
    private dialog: MatDialog,
    @Inject(ROLE_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<RolesState>
  ) {}

  ngOnInit(): void {
    this.arr$ = this.lookupService.getYesNoBoth();
    this.roleQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.roleSearchForm = this.fb.group(criteria, {
        roleType: [''],
        roleName: [''],
        description: [''],
        active: ['Y'],
      });
    });

    this.paginatorRef.requestFunction = () => this.roleService.search();
    this.paginatorRef.filtersUpdateFunction = criteria => this.roleService.updateSearchCriteria(criteria);
  }

  onGridSizeChanged(params) {
    params.api.sizeColumnsToFit();
  }

  showAction(action: any, data: any) {
    if (action.label === 'View') {
      //look at row data n decide on display
      return false;
    }

    return true;
  }

  onViewActionClick(e: any) {
    const ngZone = this.injector.get(NgZone);
    ngZone.run(() => this.requestService.navigate(['/auth/roles/view-role'], { state: { data: e.rowData } }));
  }

  onEditActionClick(e: any) {
    const ngZone = this.injector.get(NgZone);
    ngZone.run(() => this.requestService.navigate(['/auth/roles/edit-role'], { state: { data: e.rowData } }));
  }

  onDeleteActionClick(e: any) {
    if (e.rowData.active === 'N') {
      this.notificationService.showError(this.configService.get('defaultMessages.alreadyInactive'));

      return;
    }
    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.roleService
            .deleteRole(e.rowData.roleId)
            .pipe(
              untilDestroyed(this),
              take(1),
              tap(response => {
                this.notificationService.showSuccess(this.configService.get('auth.messages.success.addOrUpdateRole')('deleted', e.rowData.roleName));
                this.onSearch(e);
              }),
              catchError((error: HttpErrorResponse) => {
                return this.errorService.handleValidationErrors(this.roleSearchForm, error);
              })
            )
            .subscribe(resp => resp);
        }
      });
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  onSearch($event: any) {
    const clientQuery = this.roleSearchForm.value;
    this.roleService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset($event: any) {
    this.roleQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.roleSearchForm.reset(criteria);
      this.onSearch($event);
    });
  }
}
