import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PermitDashboardComponent } from './permit-dashboard.component';

describe('PermitDashboardComponent', () => {
  let component: PermitDashboardComponent;
  let fixture: ComponentFixture<PermitDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PermitDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PermitDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
