import { Component, OnInit } from '@angular/core';
import { RequestService } from '@mworx/util';

@Component({
  selector: 'auth-permit-dashboard',
  templateUrl: './permit-dashboard.component.html',
  styleUrls: ['./permit-dashboard.component.scss'],
})
export class PermitDashboardComponent implements OnInit {
  editMode: boolean;
  constructor(private requestService: RequestService) {}

  ngOnInit(): void {
    this.editMode = this.requestService.url().search('edit') !== -1;
  }
}
