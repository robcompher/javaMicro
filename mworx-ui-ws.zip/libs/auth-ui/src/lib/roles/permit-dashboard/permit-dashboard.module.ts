import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatDividerModule } from '@angular/material/divider';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';

import { PermitExistModule } from '../permit-exist';
import { PermitNewModule } from '../permit-new';
import { PermitDashboardComponent } from './components/permit-dashboard.component';

@NgModule({
  declarations: [PermitDashboardComponent],
  imports: [
    CommonModule,
    MatIconModule,
    MatExpansionModule,
    MatButtonModule,
    MatDividerModule,
    PermitExistModule,
    PermitNewModule,
    RouterModule,
    SharedSessionModule,
    SharedUiLayoutModule,
  ],

  exports: [PermitDashboardComponent],
})
export class PermitDashboardModule {}
