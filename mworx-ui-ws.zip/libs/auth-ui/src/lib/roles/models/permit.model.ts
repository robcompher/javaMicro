import { ID } from '@datorama/akita';

export interface Permit {
  linkId: ID;
  roleId: ID;
  lob: {
    lobId: ID;
    lobName: string;
  };
  id: ID;
  permitPrimary: string;
  permitSecondary: string;
  description: string;
}

export function createPermit(params: Partial<Permit>) {
  return {
    linkId: null,
    roleId: null,
    id: null,
    permitPrimary: null,
    permitSecondary: null,
    description: null,
    lob: { lobId: null, lobName: null },
    ...params,
  } as Permit;
}
