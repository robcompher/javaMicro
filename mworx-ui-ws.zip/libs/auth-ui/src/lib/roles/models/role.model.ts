import { ID } from '@datorama/akita';

import { Permit } from './permit.model';

export interface Role {
  roleId: ID;
  roleType: string;
  roleName: string;
  description: string;
  active: string;
  effectiveDate: Date;
  termDate: Date;
  legacySystemId: string;
  permits: Partial<Permit>[];
}

export function createRole(params: Partial<Role>) {
  return {
    roleId: null,
    roleType: null,
    roleName: null,
    description: null,
    active: null,
    effectiveDate: null,
    termDate: null,
    legacySystemId: null,
    permits: null,
    ...params,
  } as Role;
}
