import { SearchCriteria } from '@mworx/grid';

export interface UserSearchCriteria extends SearchCriteria {
  userName: string;
  firstName: string;
  lastName: string;
  active: string;
  loggedInUsers: boolean;
}
