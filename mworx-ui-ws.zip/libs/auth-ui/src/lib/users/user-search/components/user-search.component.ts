import { Component, Inject, Injector, NgZone, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { ListChoice, LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { NGXLogger } from 'ngx-logger';
import { Observable } from 'rxjs';
import { UserService } from '../../services/user.service';
import { UserSearchQuery } from '../../state/user.search.query';
import { UserSearchState } from '../../state/user.search.store';
import { USER_SEARCH_PAGINATOR } from '../user-search-paginator';

@UntilDestroy()
@Component({
  selector: 'auth-user-search',
  templateUrl: './user-search.component.html',
  styleUrls: ['./user-search.component.scss'],
})
export class UserSearchComponent implements OnInit {
  gridApi: GridApi;
  userSearchForm: FormGroup;
  userActiveValues$: Observable<Array<ListChoice>>;
  @ViewChild('userSearchFormDirective')
  userSearchFormDirective: FormGroupDirective;
  columnDefs = [
    {
      headerName: 'Username',
      field: 'userName',
      cellClassRules: {
        'error-cell': params => params.data && params.data.locked === 'Y',
      },
    },
    { headerName: 'First Name', field: 'firstName' },
    { headerName: 'Last Name', field: 'lastName' },
    { headerName: 'Active', field: 'active' },
    {
      headerName: 'Actions',
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onViewActionClick.bind(this),
            label: 'View',
            icon: 'remove_red_eye',
            color: 'primary',
            permissions: ['PERMIT_USER_VIEW'],
          },
          {
            onClick: this.onEditActionClick.bind(this),
            label: 'Edit',
            icon: 'edit',
            color: 'primary',
            permissions: ['PERMIT_USER_UPDATE'],
          },
          {
            onClick: this.onLockActionClick.bind(this),
            title: 'Lock/Unlock',
            dynamicIcon: this.getLockUnlockIcon.bind(this),
            color: 'secondary',
            permissions: ['PERMIT_USER_UPDATE', 'PERMIT_SECURITY_UPDATE'],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
      if (this.userService.isRefreshSearchGrid()) {
        this.gridApi.onFilterChanged();
        this.userService.setRefreshSearchGrid(false);
      }
    },
  };

  constructor(
    private injector: Injector,
    private requestService: RequestService,
    private fb: FormBuilder,
    private configService: ConfigService,
    private logger: NGXLogger,
    private notifyService: NotificationService,
    private dialog: MatDialog,
    private sessionService: SessionService,
    private lookupService: LookupService,
    private userService: UserService,
    private userSearchQuery: UserSearchQuery,
    @Inject(USER_SEARCH_PAGINATOR)
    public paginatorRef: GridPaginatorPlugin<UserSearchState>
  ) {}

  ngOnInit(): void {
    this.userActiveValues$ = this.lookupService.getYesNoBoth();
    this.userSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.userSearchForm = this.fb.group(criteria, {
        userName: [''],
        firstName: [''],
        lastName: [''],
        loggedInUsers: [false],
        active: ['Y'],
      });
    });

    this.paginatorRef.requestFunction = () => this.userService.search();
    this.paginatorRef.filtersUpdateFunction = criteria => this.userService.updateSearchCriteria(criteria);
  }

  onGridSizeChanged(params) {
    params.api.sizeColumnsToFit();
  }

  getLockUnlockIcon(data: any) {
    if (data && data.locked === 'Y') {
      return 'lock_outline';
    } else {
      return 'lock_open';
    }
  }

  onViewActionClick(e: any) {
    this.logger.debug('view:' + e.rowData);
    const ngZone = this.injector.get(NgZone);
    ngZone.run(() => this.requestService.navigate(['/auth/users/view-user', { userName: e.rowData.userName }])).then();
  }

  onEditActionClick(e: any) {
    const ngZone = this.injector.get(NgZone);
    ngZone.run(() => this.requestService.navigate(['/auth/users/edit-user', { userName: e.rowData.userName }])).then();
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  onLockActionClick(e: any) {
    if (e.rowData.userName === this.sessionService.currentUser().username) {
      this.notifyService.showError(this.configService.get('auth.messages.errors.lockUnlockOwnAccount'));
    } else {
      let userLockedObject;
      if (this.userSearchQuery.getEntity(e.rowData.userId).locked === 'Y') {
        userLockedObject = { lockAction: false, lockMessage: 'unlocked' };
      } else {
        userLockedObject = { lockAction: true, lockMessage: 'locked' };
      }
      // if user currently locked, then send false to unlock, otherwise; true to lock.
      if (userLockedObject.lockAction) {
        this.openConfirmDialog(this.configService.get('auth.messages.confirmLock'))
          .afterClosed()
          .subscribe(res => {
            if (res) {
              this.lockUnlockUser(e, userLockedObject);
            }
          });
      } else {
        this.lockUnlockUser(e, userLockedObject);
      }
    }
  }

  lockUnlockUser(e: any, userLockedObject: any) {
    this.userService.lockUnlockUser(e, userLockedObject.lockAction).subscribe(() => {
      this.notifyService.showSuccess(this.configService.get('auth.messages.success.lockUnlock')(userLockedObject.lockMessage, e.rowData.userName));
      this.onSearch(e);
    });
  }

  onSearch($event: any) {
    this.logger.debug('onSearch');
    const clientQuery = this.userSearchForm.value;
    this.userService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset($event: any) {
    this.userSearchQuery.initialState$.subscribe(criteria => {
      this.userSearchFormDirective.resetForm(criteria);
      this.onSearch($event);
    });
  }
}
