import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { UserSearchQuery } from '../state/user.search.query';

export const USER_SEARCH_PAGINATOR = new InjectionToken('USER_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const userSearchQuery = inject(UserSearchQuery);

    return new GridPaginatorPlugin(userSearchQuery);
  },
});
