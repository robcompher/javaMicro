import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { AuthorizationService } from '@mworx/session';
import { EventService, RequestService } from '@mworx/util';
import { UntilDestroy } from '@ngneat/until-destroy';
import { EventType } from '../../models/event-type';
import { UserService } from '../../services/user.service';
import { UserAddComponent } from '../../user-add-edit/components/user-add-edit.component';

@UntilDestroy()
@Component({
  selector: 'auth-user-view',
  templateUrl: '../../user-add-edit/components/user-add-edit.component.html',
  styleUrls: ['../../user-add-edit/components/user-add-edit.component.scss'],
})
export class UserViewComponent extends UserAddComponent implements OnInit {
  constructor(userService: UserService, requestService: RequestService, authService: AuthorizationService, public eventService: EventService) {
    super(userService, requestService, authService, eventService);
  }

  protected initTabs() {
    super.setEditable(false);
    this.tabs.push({
      tabName: 'Basic Info',
      content: import('../../user-info-view/components/user-info-view.component').then(({ UserInfoViewComponent }) => UserInfoViewComponent),
    });
    this.tabs.push({
      tabName: 'Contacts',
      content: import('../../user-contact-view/components/user-contact-view.component').then(
        ({ UserContactViewComponent }) => UserContactViewComponent
      ),
    });
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    super.onTabChange(tabChangeEvent);
    this.eventService.dispatch(EventType.isEditable, false);
  }
}
