import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { SharedUiFormsModule } from '@mworx/forms';
import { GridActionsComponent, SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { AgGridModule } from 'ag-grid-angular';
import { UserContactViewComponent } from '../user-contact-view';
import { UserContactComponent } from './components/user-contact.component';

@NgModule({
  declarations: [UserContactComponent, UserContactViewComponent],
  imports: [
    CommonModule,
    SharedUiLayoutModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    SharedUiGridModule,
    SharedUtilModule,
    SharedUiFormsModule,
    AgGridModule.withComponents([GridActionsComponent]),
  ],
  exports: [UserContactComponent, GridActionsComponent, UserContactViewComponent],
})
export class UserContactModule {}
