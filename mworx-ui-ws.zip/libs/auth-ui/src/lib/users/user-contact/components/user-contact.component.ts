import { HttpErrorResponse, HttpEvent } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { ConfigService } from '@common/config';
import { GridActionsComponent } from '@mworx/grid';
import { LibList, LookupService } from '@mworx/lookup';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { CellValueChangedEvent, GridApi, GridOptions, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';
import { combineLatest, Observable, throwError } from 'rxjs';
import { catchError, map } from 'rxjs/operators';
import { EventType } from '../../models/event-type';
import { UserContactInfo } from '../../models/user.model';
import { UserService } from '../../services/user.service';
import { UserQuery } from '../../state/user.query';

@UntilDestroy()
@Component({
  selector: 'auth-user-contact',
  templateUrl: './user-contact.component.html',
  styleUrls: ['./user-contact.component.scss'],
})
export class UserContactComponent implements OnInit {
  private static rowError: number;
  gridApi: GridApi;
  contactsGridOptions: GridOptions;
  @ViewChild('userContactsFormDirective')
  userContactsFormDirective: FormGroupDirective;
  frameworkComponents = { buttonRenderer: GridActionsComponent };
  userContactForm: FormGroup;
  userName: string;
  contactTypeLibListItems: LibList[];
  paginatorRef: Function;
  columnDefs = [
    {
      headerName: 'Contact Type',
      field: 'contactTypeLabel',
      sortable: false,
      valueGetter: (params: ValueGetterParams) => this.getContactTypeLabel(params),
    },

    {
      headerName: 'Contact Info',
      field: 'contactInfo',
      sortable: false,

      cellStyle: function (params) {
        return UserContactComponent.highlightErrorCell(params, UserContactComponent.rowError);
      },
    },
  ];

  private static highlightErrorCell(params, rowError) {
    if (params.node.rowIndex === rowError) {
      return { borderColor: 'red' };
    } else {
      return null;
    }
  }

  getContactTypeLabel(params: ValueGetterParams) {
    let contactTypeLabel = '';
    if (params.data) {
      this.contactTypeLibListItems.forEach(item => {
        if (item.id === params.data.contactType) {
          params.data.contactTypeLabel = item.label;
          contactTypeLabel = item.label;
        }
      });
    }

    return contactTypeLabel;
  }

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private errorService: ErrorService,
    private lookupService: LookupService,
    private notifyService: NotificationService,
    private requestService: RequestService,
    private userQuery: UserQuery,
    private configService: ConfigService,
    public eventService: EventService
  ) {
    const _this = this;
    _this.contactsGridOptions = <GridOptions>{
      onCellValueChanged: (event: CellValueChangedEvent) => this.onContactValueChanged(event),
      pagination: false,
      onGridReady: function (event: GridReadyEvent) {
        _this.gridApi = event.api;
      },
    };
  }

  ngOnInit(): void {
    this.requestService
      .selectParams()
      .pipe(untilDestroyed(this))
      .subscribe(param => {
        this.userName = param.userName;
      });
    UserContactComponent.rowError = -1;
    this.userContactForm = this.fb.group({
      userContact: this.fb.group({
        contactType: ['', [Validators.required]],
        contactInfo: ['', [Validators.required]],
      }),
    });
    if (this.isEditable()) {
      this.columnDefs.push(this.actionsColumnEdit());
    }

    this.paginatorRef = () => this.getData();
    this.eventService
      .on(EventType.resetContactForm)
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        if (EventType.clicked === res) {
          this.userContactsFormDirective.resetForm();
        }
      });
    this.eventService
      .on(EventType.saveContactForm)
      .pipe(untilDestroyed(this))
      .subscribe(() => {
        this.onUserContactSubmit();
      });
  }

  getData() {
    const contactTypeLibListUrl = this.configService.get('auth.constants.meta.categories.contactType');

    return combineLatest([
      this.userQuery.selectLoading(),
      this.userQuery.user$(this.userName),
      this.lookupService.getLibListByCategory(contactTypeLibListUrl),
    ]).pipe(
      map(([loading, user, libListResponse]) => {
        if (!loading && user && libListResponse) {
          this.contactTypeLibListItems = libListResponse;
          const contacts = user.userContacts;

          return contacts.map(contact => ({ ...contact }));
        }

        return [];
      })
    );
  }

  onDeleteActionClick(e: any) {
    const contactTypeLabel: string = e.rowData.contactTypeLabel;
    const contactTypeInfo: UserContactInfo = { userName: this.userName, userContact: e.rowData };
    this.userService
      .removeUserContact(contactTypeInfo)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return this.handleErrorsForContactGrid(error);
        })
      )
      .subscribe(u => {
        this.notifyService.showSuccess(this.configService.get('auth.messages.success.userContact')('deleted', contactTypeLabel));
        this.onRefresh();
      });
  }

  onContactValueChanged(event: CellValueChangedEvent) {
    const contactTypeLabel: string = event.data.contactTypeLabel;
    const contactTypeInfo: UserContactInfo = { userName: this.userName, userContact: event.data };
    UserContactComponent.rowError = -1;

    this.userService
      .updateUserContact(contactTypeInfo)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          UserContactComponent.rowError = event.rowIndex;
          const refreshParams = {
            force: true,
            rowNodes: [event.node],
          };
          event.api.refreshCells(refreshParams);

          return this.handleErrorsForContactGrid(error);
        })
      )
      .subscribe(u => {
        this.notifyService.showSuccess(this.configService.get('auth.messages.success.userContact')('updated', contactTypeLabel));
        this.onRefresh();
      });
  }
  onUserContactSubmit(): void {
    if (this.userContactForm.invalid) {
      return;
    }
    const userContact = this.userContactForm.value.userContact;
    const contactTypeInfo: UserContactInfo = { userName: this.userName, userContact: userContact };
    const contactTypeLabel = this.contactTypeLibListItems.filter(item => item.id === userContact.contactType).map(item => item.label);
    this.userService
      .addUserContact(contactTypeInfo)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.userContactForm, error);
        })
      )
      .subscribe(u => {
        this.notifyService.showSuccess(this.configService.get('auth.messages.success.userContact')('created', contactTypeLabel));
        this.onResetContactsForm();
        this.onRefresh();
      });
  }

  onResetContactsForm() {
    this.userContactsFormDirective.resetForm();
  }

  handleErrorsForContactGrid(response: HttpErrorResponse): Observable<HttpEvent<any>> {
    let errorMessage = '';
    if (422 === response.status && response.error.apierror && response.error.apierror.subErrors) {
      response.error.apierror.subErrors.forEach((element: any) => {
        errorMessage = errorMessage.concat(element.message + ' ');
      });

      return throwError(errorMessage);
    }

    return throwError(response);
  }

  onRefresh() {
    this.gridApi.onFilterChanged();
  }

  isEditable(): boolean {
    const url = this.requestService.url();
    if (url.includes('view')) {
      return false;
    } else {
      return true;
    }
  }

  actionsColumnEdit(): any {
    const actionColumn = {
      headerName: 'Actions',
      sortable: false,
      maxWidth: 170,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onDeleteActionClick.bind(this),
            label: 'Delete',
            icon: 'delete',
            color: 'warn',
            permissions: ['PERMIT_USER_UPDATE'],
          },
        ],
      },
    };
    if (this.isEditable()) {
      actionColumn.cellRendererParams.actions.splice(1);
    }

    return actionColumn;
  }
}
