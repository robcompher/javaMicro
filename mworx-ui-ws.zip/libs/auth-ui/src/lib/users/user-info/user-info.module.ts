import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule } from '@angular/router';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { UserInfoViewComponent } from '../user-info-view/components/user-info-view.component';
import { UserInfoComponent } from './components/user-info.component';

@NgModule({
  declarations: [UserInfoComponent, UserInfoViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    SharedUiLayoutModule,
    MatSelectModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatDatepickerModule,
    MatCheckboxModule,
    MatInputModule,
    SharedUiGridModule,
    SharedUtilModule,
    SharedUiFormsModule,
  ],
  exports: [UserInfoComponent, UserInfoViewComponent],
})
export class UserInfoModule {}
