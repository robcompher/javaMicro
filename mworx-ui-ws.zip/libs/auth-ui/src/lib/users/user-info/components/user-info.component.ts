import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { ConfigService } from '@common/config';
import { LibList, LookupService } from '@mworx/lookup';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest, Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { EventType } from '../../models/event-type';
import { UserRole } from '../../models/role.model';
import { User } from '../../models/user.model';
import { RoleService } from '../../services/role.service';
import { UserService } from '../../services/user.service';
import { UserQuery } from '../../state/user.query';

@UntilDestroy()
@Component({
  selector: 'auth-user-info',
  templateUrl: './user-info.component.html',
  styleUrls: ['./user-info.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class UserInfoComponent implements OnInit {
  userNewOrUpdateForm: FormGroup;
  userName: string;
  isButtonVisible = true;
  userRoles$: Observable<UserRole[]>;
  genderLibListItems$: Observable<LibList[]>;
  @ViewChild('userFormDirective')
  userFormDirective: FormGroupDirective;

  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    private notifyService: NotificationService,
    private roleService: RoleService,
    private lookupService: LookupService,
    private requestService: RequestService,
    private errorService: ErrorService,
    private eventService: EventService,
    private userQuery: UserQuery,
    private configService: ConfigService
  ) {}

  ngOnInit(): void {
    this.initMetadata();
    this.createForm();
    this.requestService
      .selectParams()
      .pipe(untilDestroyed(this))
      .subscribe(param => {
        this.userName = param.userName;
        if (!this.userName) {
          this.userNewOrUpdateForm.get('password').setValidators([Validators.required]);
        } else {
          const request = {
            userName: this.userName,
          };
          this.userService.getUserByUserName(request).pipe(untilDestroyed(this)).subscribe();
          combineLatest([this.userQuery.selectLoading(), this.userQuery.user$(this.userName)])
            .pipe(untilDestroyed(this))
            .subscribe(([loading, user]) => {
              if (!loading && !!user) {
                this.userNewOrUpdateForm.patchValue(user, { emitEvent: false });
              }
            });
        }
      });

    this.eventService
      .on(EventType.resetUserForm)
      .pipe(untilDestroyed(this))
      .subscribe(() => {
        this.onResetUserForm();
      });

    this.eventService
      .on(EventType.saveUserForm)
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.onUserSubmit();
      });
  }

  initMetadata() {
    this.userRoles$ = this.roleService.getUserRoles();
    this.genderLibListItems$ = this.lookupService.getLibListByCategory('gender');
  }

  createForm() {
    this.userNewOrUpdateForm = this.fb.group({
      userId: [],
      userName: [null, [Validators.required]],
      password: [],
      firstName: [null, [Validators.required]],
      middleName: [],
      lastName: [null, [Validators.required]],
      prefix: [],
      suffix: [],
      gender: [null, [Validators.required]],
      manager: [],
      company: [],
      department: [],
      legacySystemId: [],
      active: ['Y'],
      locked: ['N'],
      birthDate: [],
      effDate: [null, [Validators.required]],
      secRole: this.fb.group({
        roleId: [],
      }),
    });
  }

  onUserSubmit(): void {
    if (this.userNewOrUpdateForm.invalid) {
      return;
    }
    const user = this.userNewOrUpdateForm.value;
    if (!user.secRole && !user.secRole.roleId) {
      user.secRole = null;
    }

    if (user.userId) {
      this.userQuery
        .user$(this.userName)
        .pipe(untilDestroyed(this))
        .subscribe(u => {
          user.userContacts = u.userContacts;
        });
      this.updateUser(user);
    } else {
      this.createUser(user);
    }
  }

  updateUser(user: User): void {
    this.userService
      .updateUser(user)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.userNewOrUpdateForm, error);
        })
      )
      .subscribe(u => {
        this.userService.setRefreshSearchGrid(true);
        this.notifyService.showSuccess(this.configService.get('auth.messages.success.addOrUpdateUser')('updated', user.userName));
      });
  }

  createUser(user: User): void {
    this.userService
      .addUser(user)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.userNewOrUpdateForm, error);
        })
      )
      .subscribe(userResponse => {
        if (userResponse) {
          this.userService.setRefreshSearchGrid(true);
          this.notifyService.showSuccess(this.configService.get('auth.messages.success.addOrUpdateUser')('created', userResponse.userName));
          this.requestService.navigate(['/auth/users/edit-user', { userName: userResponse.userName }]);
        }
      });
  }

  onResetUserForm() {
    if (this.userName) {
      this.userQuery
        .user$(this.userName)
        .pipe(untilDestroyed(this))
        .subscribe(u => {
          this.userFormDirective.resetForm(u);
        });
    } else {
      this.userFormDirective.resetForm({ active: 'Y' });
    }
  }
}
