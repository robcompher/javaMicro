export * from './components/user-info.component';
export * from './user-info.module';
