export * from './components/user-profile.component';
export * from './user-profile.module';
