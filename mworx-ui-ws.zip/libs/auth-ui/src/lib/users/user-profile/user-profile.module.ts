import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';

import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { SharedUiLayoutModule } from '@mworx/layout';

import { ProfileFormModule } from '../profile-form/profile-form.module';
import { UserProfileComponent } from './components/user-profile.component';

@NgModule({
  declarations: [UserProfileComponent],
  imports: [CommonModule, SharedUiLayoutModule, MatButtonModule, MatDialogModule, MatFormFieldModule, ReactiveFormsModule, ProfileFormModule],
  exports: [UserProfileComponent],
})
export class UserProfileModule {}
