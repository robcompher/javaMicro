import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { EventService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';

interface DialogData {
  email: string;
}

@UntilDestroy()
@Component({
  selector: 'auth-user-profile',
  templateUrl: './user-profile.component.html',
  styleUrls: ['./user-profile.component.scss']
})
export class UserProfileComponent implements OnInit {

  showSaveButton;

  constructor(
    public dialogRef: MatDialogRef<UserProfileComponent>,
    @Inject(MAT_DIALOG_DATA) public data: DialogData,
    private eventService: EventService) { }

  onNoClick(): void {
    this.dialogRef.close();
  }

  ngOnInit(): void {
    this.eventService
      .on('setShowSaveButton')
      .pipe(
        untilDestroyed(this)
      )
      .subscribe(res => {
        this.showSaveButton = res;
      });
  }

  onSave() {
    this.eventService.dispatch('submitPasswordChange', 'profile');
  }
}
