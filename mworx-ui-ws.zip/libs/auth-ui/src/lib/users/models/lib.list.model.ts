import { ID } from '@datorama/akita';

export interface LibList {
  id: ID;
  category: string;
  value: string;
  displayText: string;
}

export interface LibListByCategoryRequest {
  category: string;
}
