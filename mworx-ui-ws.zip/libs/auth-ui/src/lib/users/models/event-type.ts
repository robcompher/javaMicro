export enum EventType {
  resetContactForm = 'resetContactForm',
  clicked = 'clicked',
  isEditable = 'isEditable',
  resetPasswordForm = 'resetPasswordForm',
  showSaveAndResetButtons = 'showSaveAndResetButtons',
  resetUserForm = 'resetUserForm',
  saveContactForm = 'saveContactForm',
  savePasswordForm = 'savePasswordForm',
  saveUserForm = 'saveUserForm',
  submitPasswordChange = 'submitPasswordChange',
  focusCurrentPassword = 'focusCurrentPassword',
}
