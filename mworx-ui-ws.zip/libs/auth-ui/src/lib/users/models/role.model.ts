import { ID } from '@datorama/akita';

export interface UserRole {
  roleId: ID;
  roleName: string;
  roleType: string;
}
