import { ID } from '@datorama/akita';
import { UserRole } from './role.model';

export interface User {
  userId: ID;
  userName: string;
  gender: string;
  firstName: string;
  password: string;
  lastName: string;
  middleName: string;
  active: string;
  locked: string;
  loggedInUsers: boolean;
  prefix: string;
  suffix: string;
  title: string;
  legacySystemId: string;
  birthDate: string;
  description: string;
  effDate: string;
  termDate: string;
  internalId: string;
  modelFrom: string;
  secRole: UserRole;
  userContacts: UserContact[];
  userLogin: {
    password: string;
    lastLogin: string;
    lastLogout: string;
  };
}

export function createUser(params: Partial<User>) {
  return {
    userId: null,
    userName: null,
    firstName: null,
    lastName: null,
    active: 'Y',
    locked: 'N',
    loggedInUsers: false,
    password: null,
    gender: null,
    middleName: null,
    prefix: null,
    suffix: null,
    legacySystemId: null,
    birthDate: null,
    description: null,
    effDate: null,
    secRole: { roleId: null },
    ...params,
  } as User;
}

export interface ChangePasswordRequest {
  userName: string;
  password: string;
  confirmPassword: string;
}

export interface MyProfilePasswordRequest {
  currentPassword: string;
  newPassword: string;
  confirmPassword: string;
}

export interface GetUserByUserNameRequest {
  userName: string;
}

export interface UserContact {
  contactId: ID;
  contactInfo: string;
  contactType: string;
  contactTypeLabel: string;
}

export interface UserContactInfo {
  userName: string;
  userContact: UserContact;
}
