import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ConfigService } from '@common/config';
import { LookupService } from '@mworx/lookup';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy } from '@ngneat/until-destroy';
import { UserService } from '../../services/user.service';
import { UserQuery } from '../../state/user.query';
import { UserContactComponent } from '../../user-contact/components/user-contact.component';

@UntilDestroy()
@Component({
  selector: 'auth-user-contact-view',
  templateUrl: '../../user-contact/components/user-contact.component.html',
  styleUrls: ['../../user-contact/components/user-contact.component.scss'],
})
export class UserContactViewComponent extends UserContactComponent implements OnInit {
  editable: boolean;
  constructor(
    fb: FormBuilder,
    userService: UserService,
    errorService: ErrorService,
    libListService: LookupService,
    notifyService: NotificationService,
    requestService: RequestService,
    userQuery: UserQuery,
    configService: ConfigService,
    public eventService: EventService
  ) {
    super(fb, userService, errorService, libListService, notifyService, requestService, userQuery, configService, eventService);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.userContactForm.disable();
  }
}
