export * from './components/change-password.component';
export * from './change-password.module';
