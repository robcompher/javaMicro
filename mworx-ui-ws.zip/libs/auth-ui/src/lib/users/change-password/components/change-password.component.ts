import { HttpErrorResponse } from '@angular/common/http';
import { Component, ElementRef, Input, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { Creds, SessionService } from '@mworx/session';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { catchError, filter } from 'rxjs/operators';
import { EventType } from '../../models/event-type';
import { UserService } from '../../services/user.service';

@UntilDestroy()
@Component({
  selector: 'auth-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.scss'],
})
export class ChangePasswordComponent implements OnInit {
  changePasswordForm: FormGroup;
  userName: string;
  @Input() myProfile = false;
  @Input() passwordExpired = false;
  @ViewChild('currentPassword') currentPassword: ElementRef;
  @ViewChild('changePasswordFormDirective')
  changePasswordFormDirective: FormGroupDirective;

  constructor(
    private fb: FormBuilder,
    private errorService: ErrorService,
    private userService: UserService,
    private notifyService: NotificationService,
    private requestService: RequestService,
    private sessionService: SessionService,
    public eventService: EventService
  ) {}

  ngOnInit(): void {
    if (this.myProfile || this.passwordExpired) {
      this.changePasswordForm = this.fb.group({
        currentPassword: new FormControl(null, [Validators.required]),
        newPassword: new FormControl(null, [Validators.required]),
        confirmPassword: new FormControl(null, [Validators.required]),
      });
      this.eventService
        .on(EventType.submitPasswordChange)
        .pipe(
          untilDestroyed(this),
          filter(res => res === 'profile' || res === 'expired')
        )
        .subscribe(() => this.onChangePassword());
      this.eventService
        .on(EventType.focusCurrentPassword)
        .pipe(
          untilDestroyed(this),
          filter(res => res === 'profile')
        )
        .subscribe(() => this.focusCurrentPassword());
    } else {
      this.changePasswordForm = this.fb.group({
        userName: new FormControl(''),
        password: new FormControl('', [Validators.required]),
        confirmPassword: new FormControl('', [Validators.required]),
      });
      this.requestService
        .selectParams()
        .pipe(untilDestroyed(this))
        .subscribe(param => {
          this.userName = param.userName;
        });
      this.eventService
        .on(EventType.resetPasswordForm)
        .pipe(untilDestroyed(this))
        .subscribe(res => {
          if (EventType.clicked === res) {
            this.changePasswordFormDirective.resetForm();
          }
        });

      this.eventService
        .on(EventType.savePasswordForm)
        .pipe(untilDestroyed(this))
        .subscribe(() => {
          this.onChangePassword();
        });
    }
  }

  focusCurrentPassword(): void {
    this.currentPassword.nativeElement.focus();
  }

  onChangePassword(): void {
    if (this.myProfile || this.passwordExpired) {
      this.onProfileChangePassword();
    } else {
      this.onUserChangePassword();
    }
  }
  onUserChangePassword(): void {
    if (this.changePasswordForm.invalid) {
      return;
    }
    const request = this.changePasswordForm.value;
    request.userName = this.userName;
    this.userService
      .changePassword(request)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.changePasswordForm, error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(response);
        this.onResetChangePasswordForm();
      });
  }

  onProfileChangePassword(): void {
    if (this.changePasswordForm.invalid) {
      return;
    }

    const request = this.changePasswordForm.value;
    this.userService
      .changeProfilePassword(request)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.changePasswordForm, error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(response);
        if (this.myProfile) {
          this.onResetChangePasswordForm();
        } else if (this.passwordExpired) {
          this.redirectToHome(this.changePasswordForm.value.newPassword);
        }
      });
  }

  private redirectToHome(password: string) {
    const credentials = { username: '', password: '' };
    credentials.username = this.sessionService.currentUser().username;
    credentials.password = password;
    this.sessionService.logout();
    this.sessionService.login(credentials as Creds).subscribe(
      response => this.requestService.navigate(['']),
      error => this.requestService.navigate(['/login'])
    );
  }

  onResetChangePasswordForm() {
    this.changePasswordFormDirective.resetForm();
  }
}
