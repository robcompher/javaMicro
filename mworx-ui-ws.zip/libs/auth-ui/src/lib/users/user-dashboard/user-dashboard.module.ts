import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';
import { UserSearchModule } from '../user-search/user-search.module';
import { UserDashboardComponent } from './components/user-dashboard.component';
@NgModule({
  declarations: [UserDashboardComponent],
  imports: [CommonModule, MatIconModule, MatButtonModule, SharedUiLayoutModule, UserSearchModule, RouterModule, SharedSessionModule],
  exports: [UserDashboardComponent],
})
export class UserDashboardModule {}
