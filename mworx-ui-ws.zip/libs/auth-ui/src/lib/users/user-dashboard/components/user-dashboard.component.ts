import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { UserSearchComponent } from '../../user-search';

@Component({
  selector: 'auth-user-dashboard',
  templateUrl: './user-dashboard.component.html',
  styleUrls: ['./user-dashboard.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class UserDashboardComponent implements OnInit {
  @ViewChild('userSearch')
  private userSearch: UserSearchComponent;

  constructor() { }

  ngOnInit(): void {
  }

  onSearch($event) {
    this.userSearch.onSearch($event);
  }

  onUserSearchReset($event) {
    this.userSearch.onReset($event);
  }
}
