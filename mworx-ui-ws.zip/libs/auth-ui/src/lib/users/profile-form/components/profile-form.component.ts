import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { AuthorizationService } from '@mworx/session';
import { EventService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';

@UntilDestroy()
@Component({
  selector: 'auth-profile-form',
  templateUrl: './profile-form.component.html',
  styleUrls: ['./profile-form.component.scss'],
})
export class ProfileFormComponent implements OnInit {
  tabs = [];
  passwordTabExists = false;
  constructor(private authService: AuthorizationService, private eventService: EventService) {}

  ngOnInit(): void {
    this.tabs.push('Basic Info');
    this.tabs.push('Contacts');
    const changePasswordPermissions = ['PERMIT_USER_CHANGE_PASSWORD'];
    this.authService
      .hasAccess(changePasswordPermissions)
      .pipe(untilDestroyed(this))
      .subscribe(access => {
        if (access) {
          this.passwordTabExists = true;
          this.tabs.push('Change Password');
        }
      });
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    if (this.passwordTabExists) {
      const showSaveButton = this.tabs[tabChangeEvent.index] === 'Change Password' ? true : false;
      this.eventService.dispatch('setShowSaveButton', showSaveButton);
      if (showSaveButton) {
        this.eventService.dispatch('focusCurrentPassword', 'profile');
      }
    }
  }
}
