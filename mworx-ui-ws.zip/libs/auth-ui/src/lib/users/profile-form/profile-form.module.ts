import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatTabsModule } from '@angular/material/tabs';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { ChangePasswordModule } from '../change-password/change-password.module';
import { UserContactModule } from '../user-contact/user-contact.module';
import { UserInfoModule } from '../user-info/user-info.module';
import { ProfileFormComponent } from './components/profile-form.component';
@NgModule({
  declarations: [ProfileFormComponent],
  imports: [
    CommonModule,
    MatTabsModule,
    UserInfoModule,
    SharedUiLayoutModule,
    SharedUiGridModule,
    SharedUtilModule,
    UserContactModule,
    ChangePasswordModule,
  ],
  exports: [ProfileFormComponent],
})
export class ProfileFormModule {}
