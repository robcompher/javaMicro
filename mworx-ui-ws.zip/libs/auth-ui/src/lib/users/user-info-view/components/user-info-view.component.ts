import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { ConfigService } from '@common/config';
import { LookupService } from '@mworx/lookup';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy } from '@ngneat/until-destroy';
import { RoleService } from '../../services/role.service';
import { UserService } from '../../services/user.service';
import { UserQuery } from '../../state/user.query';
import { UserInfoComponent } from '../../user-info/components/user-info.component';

@Component({
  selector: 'auth-user-info-view',
  templateUrl: '../../user-info/components/user-info.component.html',
  styleUrls: ['../../user-info/components/user-info.component.scss'],
})
@UntilDestroy()
export class UserInfoViewComponent extends UserInfoComponent implements OnInit {
  constructor(
    fb: FormBuilder,
    userService: UserService,
    notifyService: NotificationService,
    roleService: RoleService,
    lookupService: LookupService,
    requestService: RequestService,
    errorService: ErrorService,
    userQuery: UserQuery,
    eventService: EventService,
    configService: ConfigService
  ) {
    super(fb, userService, notifyService, roleService, lookupService, requestService, errorService, eventService, userQuery, configService);
  }

  ngOnInit(): void {
    super.ngOnInit();
    this.userNewOrUpdateForm.disable();
  }
}
