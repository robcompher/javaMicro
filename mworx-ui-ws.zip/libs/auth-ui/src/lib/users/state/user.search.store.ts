import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';

import { User } from '../models/user.model';
import { UserSearchCriteria } from '../user-search/models/user-search-criteria.model';

export interface UserSearchState extends EntityState<User> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'userName',
        sortOrder: 'asc',
      },
      firstName: null,
      lastName: null,
      userName: null,
      loggedInUsers: false,
      active: 'Y',
    } as UserSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'users-search', idKey: 'userId', resettable: true })
export class UserSearchStore extends EntityStore<UserSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<UserSearchState> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
