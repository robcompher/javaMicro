import { Injectable } from '@angular/core';
import { Query, QueryEntity } from '@datorama/akita';
import { GenderLibListState, GenderLibListStore } from './lib.list.store';

@Injectable({ providedIn: 'root' })
export class GenderLibListQuery extends Query<GenderLibListState> {
  genderLibList$ = this.select('genderLibList');
  constructor(protected store: GenderLibListStore) {
    super(store);
  }
}
