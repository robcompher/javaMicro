import { Injectable } from '@angular/core';
import { QueryConfig, QueryEntity } from '@datorama/akita';
import { UserRole } from '../models/role.model';
import { UserRolesState, UserRolesStore } from './user.roles.store';

const rolesSortBy = (entity1: UserRole, entity2: UserRole, state) => {
  const roleType1 = entity1.roleType;
  const roleType2 = entity2.roleType;
  const roleName1 = entity1.roleName;
  const roleName2 = entity2.roleName;
  const roleTypeSort = roleType1.localeCompare(roleType2);

  return roleTypeSort === 0 ? roleName1.localeCompare(roleName2) : roleTypeSort;
};

@QueryConfig({
  sortBy: rolesSortBy,
})
@Injectable({ providedIn: 'root' })
export class UserRolesQuery extends QueryEntity<UserRolesState> {
  constructor(protected store: UserRolesStore) {
    super(store);
  }
}
