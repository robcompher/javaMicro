import { Injectable } from '@angular/core';
import { Store, StoreConfig } from '@datorama/akita';
import { LibList } from '../models/lib.list.model';

export interface GenderLibListState {
  genderLibList: LibList[];
}

export function createInitialState(): GenderLibListState {
  return {
    genderLibList: [],
  };
}

@Injectable({ providedIn: 'root' })
@StoreConfig({
  name: 'genderLibList-meta',
  resettable: true,
  cache: {
    ttl: 3600000,
  },
})
export class GenderLibListStore extends Store<GenderLibListState> {
  constructor() {
    super(createInitialState());
  }
}
