import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { UserSearchState, UserSearchStore } from './user.search.store';

@Injectable({ providedIn: 'root' })
export class UserSearchQuery extends QueryEntity<UserSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: UserSearchStore) {
    super(store);
  }
}
