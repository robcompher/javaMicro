import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { UserRole } from '../models/role.model';

export interface UserRolesState extends EntityState<UserRole> {}

export function createInitialState(): UserRolesState {
  return {
    userRoles: [],
  };
}

@Injectable({ providedIn: 'root' })
@StoreConfig({
  name: 'userRoles-meta',
  idKey: 'roleId',
  resettable: true,
  cache: {
    ttl: 3600000,
  },
})
export class UserRolesStore extends EntityStore<UserRolesState> {
  constructor() {
    super(createInitialState());
  }
}
