import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { UserViewComponent } from '../user-view/components/user-view-component';
import { UserAddComponent } from './components/user-add-edit.component';

@NgModule({
  declarations: [UserAddComponent, UserViewComponent],
  imports: [
    CommonModule,
    RouterModule,
    SharedUiLayoutModule,
    MatButtonModule,
    MatDialogModule,
    MatFormFieldModule,
    MatTabsModule,
    ReactiveFormsModule,
    SharedUtilModule,
  ],
  exports: [UserAddComponent, UserViewComponent],
})
export class UserAddModule {}
