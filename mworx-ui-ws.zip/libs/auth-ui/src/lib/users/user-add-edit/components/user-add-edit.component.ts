import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { AuthorizationService } from '@mworx/session';
import { EventService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { EventType } from '../../models/event-type';
import { UserService } from '../../services/user.service';

@UntilDestroy()
@Component({
  selector: 'auth-user-add-edit',
  templateUrl: './user-add-edit.component.html',
  styleUrls: ['./user-add-edit.component.scss'],
})
export class UserAddComponent implements OnInit {
  tabs = [];
  loadedStatus: Array<number>;
  userName: string;
  pageTitle: string;
  showSaveAndResetButtons = true;
  isEditable: boolean;
  tabNumber: number;
  form: string;

  constructor(
    private userService: UserService,
    private requestService: RequestService,
    private authService: AuthorizationService,
    public eventService: EventService
  ) {}

  ngOnInit() {
    this.requestService
      .selectData()
      .pipe(untilDestroyed(this))
      .subscribe(data => {
        this.pageTitle = data.title;
        this.requestService
          .selectParams()
          .pipe(untilDestroyed(this))
          .subscribe(param => {
            if (param.userName) {
              this.pageTitle = this.pageTitle + ' : ' + param.userName;
            }
            this.isEditable = param.isEditable;
          });
      });
    this.loadedStatus = new Array<number>();
    this.initTabs();
    //default load first tab
    this.loadedStatus.push(0);

    this.eventService
      .on(EventType.resetUserForm)
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        if (res === EventType.clicked) {
          this.userService.resetUserForm();
        }
      });
  }

  protected initTabs() {
    this.isEditable = true;
    this.tabs.push({
      tabName: 'Basic Info',
      content: import('../../user-info/components/user-info.component').then(({ UserInfoComponent }) => UserInfoComponent),
    });
    this.tabNumber = 0;
    this.form = EventType.saveUserForm;
    this.requestService
      .selectParams()
      .pipe(untilDestroyed(this))
      .subscribe(param => {
        this.userName = param.userName;
        if (this.userName) {
          this.tabs.push({
            tabName: 'Contacts',
            content: import('../../user-contact/components/user-contact.component').then(({ UserContactComponent }) => UserContactComponent),
          });
          const changePasswordPermissions = ['PERMIT_SECURITY_UPDATE'];
          this.authService.hasAccess(changePasswordPermissions).subscribe(access => {
            if (access) {
              this.tabs.push({
                tabName: 'Change Password',
                content: import('../../change-password/components/change-password.component').then(
                  ({ ChangePasswordComponent }) => ChangePasswordComponent
                ),
              });
            }
          });
        }
      });
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    if (this.loadedStatus.indexOf(tabChangeEvent.index) === -1) {
      this.loadedStatus.push(tabChangeEvent.index);
    }
    this.showSaveAndResetButtons = tabChangeEvent.index > 0 ? false : true;
    this.tabNumber = tabChangeEvent.index;

    this.eventService.dispatch(EventType.isEditable, true);

    switch (this.tabNumber) {
      case 0:
        this.form = EventType.saveUserForm;
        break;
      case 1:
        this.form = EventType.saveContactForm;
        break;
      case 2:
        this.form = EventType.savePasswordForm;
        break;
      default:
        break;
    }
  }

  onResetUserForm() {
    this.userService.resetUserForm();
  }

  onReset() {
    switch (this.tabNumber) {
      case 0:
        this.eventService.dispatch(EventType.resetUserForm, EventType.clicked);
        break;
      case 1:
        this.eventService.dispatch(EventType.resetContactForm, EventType.clicked);
        break;
      case 2:
        this.eventService.dispatch(EventType.resetPasswordForm, EventType.clicked);
        break;
      default:
        break;
    }
  }

  onSave() {
    switch (this.tabNumber) {
      case 0:
        this.eventService.dispatch(EventType.saveUserForm, EventType.clicked);
        break;
      case 1:
        this.eventService.dispatch(EventType.saveContactForm, EventType.clicked);
        break;
      case 2:
        this.eventService.dispatch(EventType.savePasswordForm, EventType.clicked);
        break;
      default:
        break;
    }
  }

  public setEditable(editable: boolean): void {
    this.isEditable = editable;
  }
}
