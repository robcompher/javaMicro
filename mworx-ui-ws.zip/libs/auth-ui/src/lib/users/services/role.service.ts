import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { withTransaction } from '@datorama/akita';
import { Observable } from 'rxjs';
import { switchMap } from 'rxjs/operators';
import { UserRole } from '../models/role.model';
import { UserRolesQuery } from '../state/user.roles.query';
import { UserRolesStore } from '../state/user.roles.store';

@Injectable({ providedIn: 'root' })
export class RoleService {
  constructor(
    private http: HttpClient,
    private configService: ConfigService,
    private userRolesQuery: UserRolesQuery,
    private userRolesStore: UserRolesStore
  ) {}

  getUserRoles(): Observable<UserRole[]> {
    return this.userRolesQuery.selectHasCache().pipe(
      switchMap(hasCache => {
        const apiCall = this.http.post<UserRole[]>(this.configService.get('auth.constants.url.role.getRoleNameAndTypes'), {}).pipe(
          withTransaction(response => {
            if (response.length !== 0) {
              this.userRolesStore.upsertMany(response);
              this.userRolesStore.setHasCache(true);
            }
          }),
          switchMap(res => this.userRolesQuery.selectAll())
        );

        return hasCache ? this.userRolesQuery.selectAll() : apiCall;
      })
    );
  }
}
