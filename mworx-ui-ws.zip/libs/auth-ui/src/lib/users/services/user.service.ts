import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { arrayAdd, arrayRemove, arrayUpdate, ID, PaginationResponse } from '@datorama/akita';
import { EventService } from '@mworx/util';
import { Observable, of } from 'rxjs';
import { map, tap } from 'rxjs/operators';

import { UserRole } from '../models/role.model';
import { ChangePasswordRequest, GetUserByUserNameRequest, MyProfilePasswordRequest, User, UserContactInfo } from '../models/user.model';
import { UserQuery } from '../state/user.query';
import { UserSearchStore } from '../state/user.search.store';
import { UserStore } from '../state/user.store';
import { UserSearchCriteria } from '../user-search/models/user-search-criteria.model';

@Injectable({ providedIn: 'root' })
export class UserService {
  constructor(
    private userSearchStore: UserSearchStore,
    private userQuery: UserQuery,
    private userStore: UserStore,
    private http: HttpClient,
    private configService: ConfigService,
    private eventService: EventService
  ) {}

  search(): Observable<PaginationResponse<User>> {
    const criteria = this.userSearchStore.getValue().ui.filters;

    return this.http.post<PaginationResponse<User>>(this.configService.get('auth.constants.url.userSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<User>;
      })
    );
  }

  resetUserForm(): void {
    this.eventService.dispatch('resetUserForm');
  }

  getUserByUserName(request: GetUserByUserNameRequest) {
    if (!this.userQuery.hasUser(request.userName)) {
      return this.http.post<User>(this.configService.get('auth.constants.url.getUserByUserName'), request).pipe(
        tap(response => {
          let user = response;
          if (!user.secRole) {
            user = { ...user, ...{ secRole: { roleId: null } as UserRole } };
          }
          this.userStore.upsert(user.userName, user);
        })
      );
    }

    return of();
  }

  addUser(user: User): Observable<any> {
    return this.http.post<User>(this.configService.get('auth.constants.url.addUser'), user).pipe(
      map(response => {
        this.userStore.upsert(response.userName, response);

        return response;
      })
    );
  }

  changePassword(request: ChangePasswordRequest): Observable<any> {
    return this.http.post<Object>(this.configService.get('auth.constants.url.changePassword'), request);
  }

  changeProfilePassword(request: MyProfilePasswordRequest): Observable<any> {
    return this.http.post<Object>(this.configService.get('auth.constants.url.myprofileChangePassword'), request);
  }
  updateUser(user: User): Observable<any> {
    return this.http.put<User>(this.configService.get('auth.constants.url.updateUser'), user).pipe(map(response => this.updateUserStore(response)));
  }

  addUserContact(userContactInfo: UserContactInfo): Observable<any> {
    return this.http.post<UserContactInfo>(this.configService.get('auth.constants.url.userContact'), userContactInfo).pipe(
      map(response => {
        this.userStore.update(response.userName, user => ({
          userContacts: arrayAdd(user.userContacts, response.userContact),
        }));

        return response;
      })
    );
  }

  updateUserContact(userContactInfo: UserContactInfo): Observable<any> {
    return this.http.put<UserContactInfo>(this.configService.get('auth.constants.url.userContact'), userContactInfo).pipe(
      map(response => {
        this.userStore.update(response.userName, user => ({
          userContacts: arrayUpdate(
            user.userContacts,
            response.userContact.contactId,
            { contactInfo: response.userContact.contactInfo },
            'contactId'
          ),
        }));

        return response;
      })
    );
  }

  removeUserContact(userContactInfo: UserContactInfo): Observable<any> {
    return this.http.put<UserContactInfo>(this.configService.get('auth.constants.url.deleteUserContact'), userContactInfo).pipe(
      map(response => {
        this.userStore.update(userContactInfo.userName, user => ({
          userContacts: arrayRemove(user.userContacts, userContactInfo.userContact.contactId, 'contactId'),
        }));

        return response;
      })
    );
  }

  remove(id: ID) {
    this.userSearchStore.remove(id);
  }

  lockUnlockUser(e: any, locked: boolean) {
    return this.http
      .post(this.configService.get('auth.constants.url.lockUnlockUser'), { userName: e.rowData.userName, lock: locked }, { responseType: 'text' })
      .pipe(
        tap(resp => {
          this.userStore.remove(e.rowData.userName);
        })
      );
  }

  updateSearchCriteria(criteria: UserSearchCriteria) {
    const prevCriteria = this.userSearchStore.getValue().ui.filters;
    this.userSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  getUserFromStore(userName: string) {
    return this.userQuery.getEntity(userName);
  }

  updateUserStore(user: User) {
    this.userStore.update(user.userName, user);
    this.userSearchStore.update(user.userId,user);
  }

  isRefreshSearchGrid(): boolean {
    return this.userSearchStore.isRefreshSearchGrid();
  }

  setRefreshSearchGrid(value: boolean) {
    this.userSearchStore.setRefreshSearchGrid(value);
  }
}
