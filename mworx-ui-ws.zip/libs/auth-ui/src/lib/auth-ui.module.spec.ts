import { async, TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AuthUiModule } from './auth-ui.module';
describe('AuthUiModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [AuthUiModule, RouterTestingModule]
    }).compileComponents();
  }));

  it('should create', () => {
    expect(AuthUiModule).toBeDefined();
  });
});
