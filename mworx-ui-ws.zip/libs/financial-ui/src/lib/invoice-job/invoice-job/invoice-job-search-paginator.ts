import { inject, InjectionToken } from '@angular/core';

import { GridPaginatorPlugin } from '@mworx/grid';
import { InvoiceJobSearchQuery } from '../state/invoice-job-search.query';

export const INVOICE_JOB_SEARCH_PAGINATOR = new InjectionToken('INVOICE_JOB_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const invoiceJobSearchQuery = inject(InvoiceJobSearchQuery);

    return new GridPaginatorPlugin(invoiceJobSearchQuery);
  },
});
