import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedUtilModule } from '@mworx/util';
import { InvoiceJobDetailsComponent } from './components/invoice-job-details.component';
import { InvoiceJobLaunchComponent } from './components/invoice-job-launch.component';
import { InvoiceJobSearchComponent } from './components/invoice-job-search.component';

@NgModule({
  declarations: [InvoiceJobSearchComponent, InvoiceJobDetailsComponent, InvoiceJobLaunchComponent],
  imports: [
    CommonModule,
    SharedUiFormsModule,
    SharedUiGridModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSelectModule,
    SharedUiLayoutModule,
    SharedUtilModule,
    MatDatepickerModule,
  ],
  exports: [InvoiceJobSearchComponent, InvoiceJobDetailsComponent, InvoiceJobLaunchComponent],
})
export class InvoiceJobModule {}
