import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { ListChoice, LookupDataService, LookupService, PeriodCycle } from '@mworx/lookup';
import { AppInjector, ErrorService, EventService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable, of } from 'rxjs';
import { catchError, filter, flatMap, map, switchMap, toArray } from 'rxjs/operators';
import { InvoiceJobService } from '../../services/invoice-job.service';

@UntilDestroy()
@Component({
  selector: 'financial-invoice-job-launch',
  templateUrl: './invoice-job-launch.component.html',
  styleUrls: ['./invoice-job-launch.component.scss'],
})
export class InvoiceJobLaunchComponent implements OnInit {
  invoiceJobLaunchForm: FormGroup;
  @ViewChild('invoiceJobLaunchDirective')
  invoiceJobLaunchDirective: FormGroupDirective;
  pageTitle: string;

  invoiceJobSearchDirective: FormGroupDirective;
  periodCycles$: Observable<Array<PeriodCycle>>;
  monthOfTheYearValues$: Observable<Array<ListChoice>>;

  private fb: FormBuilder;
  private dialog: MatDialog;
  private invoiceJobService: InvoiceJobService;

  private lookupService: LookupService;
  private configService: ConfigService;
  private lookUpDataService: LookupDataService;
  private errorService: ErrorService;
  private notifyService: NotificationService;
  private eventService: EventService;
  constructor(@Inject(MAT_DIALOG_DATA) public data, private dialogRef: MatDialogRef<InvoiceJobLaunchComponent>) {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.lookUpDataService = AppInjector.get(LookupDataService);
    this.invoiceJobService = AppInjector.get(InvoiceJobService);
    this.configService = AppInjector.get(ConfigService);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.eventService = AppInjector.get(EventService);
    this.dialog = AppInjector.get(MatDialog);
  }

  ngOnInit(): void {
    this.initForm();
  }

  initForm() {
    this.invoiceJobLaunchForm = this.fb.group({
      periodCycle: [null, Validators.required],
      premiumMonth: [null, Validators.required],
      premiumYear: [null, Validators.required],
      accountingMonth: [null, Validators.required],
      accountingYear: [null, Validators.required],
      invoiceDueDate: [null, Validators.required],
    });
    this.pageTitle = 'Launch Invoicing Job';
    this.monthOfTheYearValues$ = this.lookupService.getMonths();
    this.periodCycles$ = this.invoiceJobLaunchForm.get('periodCycle').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getPeriodCycles(searchValue.label);
          }
          // populate next premium month
          else if (searchValue.label !== null && searchValue.value !== null) {
            this.invoiceJobService
              .getNextBillRun(searchValue.value)
              .pipe(untilDestroyed(this))
              .subscribe(response => {
                this.invoiceJobLaunchForm.patchValue(response);
              });
          }
        }

        return of([]);
      })
    );
  }

  getPeriodCycles(periodCycleName: string, periodCycleId?: number): Observable<Array<ListChoice>> {
    return this.lookUpDataService.getPeriodCycles(periodCycleName, periodCycleId).pipe(
      filter(data => data && data.length > 0),
      flatMap((items: PeriodCycle[]) => items),
      map((item: any) => {
        return {
          value: item.id,
          label: item.cycleName,
        } as ListChoice;
      }),
      toArray()
    );
  }

  onReset() {
    if (this.invoiceJobLaunchDirective) {
      this.invoiceJobLaunchDirective.resetForm();
    }
  }
  closePopup(): void {
    this.dialogRef.close();
  }
  onLaunch() {
    if (this.invoiceJobLaunchForm.invalid) {
      return;
    }
    const clientRequest = this.invoiceJobLaunchForm.value;
    clientRequest.periodCycleName = clientRequest.periodCycle?.label;

    this.invoiceJobService
      .validateInvoiceJob(clientRequest)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          let warnMessage: string;
          let hasErrorMessage = false;
          if (422 === error.status && error.error.apierror && error.error.apierror.subErrors) {
            error.error.apierror.subErrors.forEach((element: any) => {
              if (element.message.includes('WARN')) {
                warnMessage = element.message;
              } else {
                hasErrorMessage = true;
              }
            });
          }
          if (warnMessage && !hasErrorMessage) {
            this.openConfirmDialog(warnMessage)
              .afterClosed()
              .pipe(
                untilDestroyed(this),
                filter(res => !!res)
              )
              .subscribe(() => {
                this.launchJob(clientRequest);
              });

            return of();
          } else {
            return this.errorService.handleValidationErrors(this.invoiceJobLaunchForm, error);
          }
        })
      )
      .subscribe(() => {
        this.launchJob(clientRequest);
      });
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  launchJob(clientRequest: any) {
    this.invoiceJobService
      .startInvoiceJob(clientRequest)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.invoiceJobLaunchForm, error);
        })
      )
      .subscribe(() => {
        this.notifyService.showSuccess(
          this.configService.get('financial.constants.messages.invoiceJobSuccessMessage')(clientRequest.periodCycleName)
        );
        this.onReset();
        this.eventService.dispatch('searchJobInvoice');
        this.dialogRef.close();
      });
  }
}
