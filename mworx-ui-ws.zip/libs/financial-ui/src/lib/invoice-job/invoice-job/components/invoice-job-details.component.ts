import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit} from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { AppInjector, ErrorService, EventService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { catchError, filter } from 'rxjs/operators';
import { InvoiceJobSummary } from '../../models/invoice-job-summary.model';
import { InvoiceJobService } from '../../services/invoice-job.service';

@UntilDestroy()
@Component({
  selector: 'financial-invoice-job-details',
  templateUrl: './invoice-job-details.component.html',
  styleUrls: ['./invoice-job-details.component.scss'],
})
export class InvoiceJobDetailsComponent implements OnInit {
  pageTitle: string;
  buttonVisible: boolean;
  summary: InvoiceJobSummary;

  private invoiceJobService: InvoiceJobService;
  private eventService: EventService;
  private errorService: ErrorService;
  private notifyService: NotificationService;
  private configService: ConfigService;

  constructor(@Inject(MAT_DIALOG_DATA) public data, private dialogRef: MatDialogRef<InvoiceJobDetailsComponent>) {
    this.invoiceJobService = AppInjector.get(InvoiceJobService);
    this.eventService = AppInjector.get(EventService);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.configService = AppInjector.get(ConfigService);
  }

  ngOnInit(): void {
    this.pageTitle = 'Invoicing Job Details';
    this.buttonVisible = this.data?.postInd === 'N' && this.data?.archiveInd === 'N';
    this.initializeData();
  }

  initializeData() {
    this.invoiceJobService
      .getSummaryData(this.data.jobId)
      .pipe(
        untilDestroyed(this),
        filter(response => response != null)
      )
      .subscribe(response => {
        this.formatSummary(response);
        this.summary = response;
      });
  }

  formatSummary(summary: InvoiceJobSummary) {
    Object.entries(summary).forEach(([key, value]) => {
      if (!value) {
        summary[key] = 0;
      }
    });
  }

  closePopup(): void {
    this.dialogRef.close();
  }
  postInvoiceJob(): void {
    this.invoiceJobService
      .postJob(this.data.id)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleTableValidationErrors(error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(
          this.configService.get('financial.constants.messages.invoiceJobPostArchiveMessage')('Posted', this.data.premiumBilling)
        );

        this.closeAndRefreshSearch();
      });
  }
  archiveInvoiceJob(): void {
    this.invoiceJobService
      .archiveJob(this.data.id)
      .pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleTableValidationErrors(error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(
          this.configService.get('financial.constants.messages.invoiceJobPostArchiveMessage')('Archived', this.data.premiumBilling)
        );
        this.closeAndRefreshSearch();
      });
  }
  closeAndRefreshSearch() {
    this.eventService.dispatch('searchJobInvoice');
    this.dialogRef.close();
  }
}
