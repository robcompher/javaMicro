import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceJobDetailsComponent } from './invoice-job-details.component';

describe('InvoiceJobDetailsComponent', () => {
  let component: InvoiceJobDetailsComponent;
  let fixture: ComponentFixture<InvoiceJobDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceJobDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceJobDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
