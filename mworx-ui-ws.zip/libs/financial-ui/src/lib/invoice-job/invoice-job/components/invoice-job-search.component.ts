import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, ListChoice, LookupDataService, LookupService, PeriodCycle } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { AppInjector, EventService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable, of } from 'rxjs';
import { filter, map, mergeMap, switchMap, toArray } from 'rxjs/operators';
import { InvoiceJobService } from '../../services/invoice-job.service';
import { InvoiceJobSearchQuery } from '../../state/invoice-job-search.query';
import { InvoiceJobSearchState } from '../../state/invoice-job-search.store';
import { INVOICE_JOB_SEARCH_PAGINATOR } from '../invoice-job-search-paginator';
import { InvoiceJobDetailsComponent } from './invoice-job-details.component';

@UntilDestroy()
@Component({
  selector: 'financial-invoice-job-search',
  templateUrl: './invoice-job-search.component.html',
  styleUrls: ['./invoice-job-search.component.scss'],
})
export class InvoiceJobSearchComponent implements OnInit {
  invoiceJobSearchForm: FormGroup;
  gridApi: GridApi;
  @ViewChild('invoiceJobSearchDirective')
  invoiceJobSearchDirective: FormGroupDirective;
  monthValues$: Observable<LibList[]>;
  postedList$: Observable<Array<ListChoice>>;
  archivedList$: Observable<Array<ListChoice>>;
  operatorsList$: Observable<Array<ListChoice>>;
  periodCycles$: Observable<Array<PeriodCycle>>;
  groups$: Observable<Array<any>>;

  columnDefs = [
    {
      headerName: 'Job Id',
      field: 'jobId',
    },
    {
      headerName: 'Submitted By',
      field: 'submittedBy',
    },
    {
      headerName: 'Run ID',
      field: 'premiumBilling',
      cellRenderer: 'routerLinkRenderer',
      cellRendererParams: {
        onClick: this.onPremiumBillingClick.bind(this),
      },
    },
    {
      headerName: 'Premium Year',
      field: 'periodYear',
    },
    {
      headerName: 'Premium Month',
      field: 'periodMonth',
      sortable: false,
      valueGetter: 'category:month',
    },
    {
      headerName: 'Posted',
      field: 'postInd',
    },
    {
      headerName: 'Archive',
      field: 'archiveInd',
    },
    {
      headerName: 'Status',
      field: 'status',
      cellRenderer: function (params) {
        return params.data?.status?.toUpperCase() === 'COMPLETED' && params.data?.errorFileInd === 'Y'
          ? params.value + '<i class="large material-icons-outlined icon-red" title="Job completed with error(s)">error</i>'
          : params.value;
      },
    },
    {
      headerName: 'Actions',
      colId: 'Actions',
      minWidth: 150,
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            label: 'Menu',
            icon: 'settings',
            color: 'primary',

            title: 'More Actions',
            menuActions: [
              {
                label: 'Processed File',
                icon: 'attachment',
                color: 'primary',
                title: 'Processed File',
                onClick: this.onProcessedFileActionClick.bind(this),
              },
              {
                label: 'Log File',
                icon: 'save_alt',
                color: 'warn',
                title: 'Log File',
                show: this.showAction.bind(this),
                onClick: this.onLogFileActionClick.bind(this),
              },
              {
                label: 'Error File',
                icon: 'assignment_late',
                color: 'error',
                title: 'Error File',
                show: this.showAction.bind(this),
                onClick: this.onErrorFileActionClick.bind(this),
              },
              {
                label: 'Details',
                show: this.showAction.bind(this),
                onClick: this.onDetailsActionClick.bind(this),
              },
            ],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
  };

  private fb: FormBuilder;
  private invoiceJobService: InvoiceJobService;
  private invoiceJobSearchQuery: InvoiceJobSearchQuery;
  private lookupService: LookupService;
  private configService: ConfigService;
  private lookUpDataService: LookupDataService;
  private sessionService: SessionService;
  private requestService: RequestService;
  public dialog: MatDialog;
  public eventService: EventService;

  constructor(@Inject(INVOICE_JOB_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<InvoiceJobSearchState>) {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.lookUpDataService = AppInjector.get(LookupDataService);
    this.invoiceJobService = AppInjector.get(InvoiceJobService);
    this.invoiceJobSearchQuery = AppInjector.get(InvoiceJobSearchQuery);
    this.configService = AppInjector.get(ConfigService);
    this.sessionService = AppInjector.get(SessionService);
    this.requestService = AppInjector.get(RequestService);
    this.dialog = AppInjector.get(MatDialog);
    this.eventService = AppInjector.get(EventService);
  }

  ngOnInit(): void {
    this.initForm();
    this.eventService
      .on('searchJobInvoice')
      .pipe(untilDestroyed(this))
      .subscribe(() => {
        this.onSearch();
      });
  }

  initForm() {
    this.monthValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.month'));
    this.postedList$ = this.lookupService.getYesNoBoth();
    this.archivedList$ = this.lookupService.getYesNoBoth();
    this.operatorsList$ = this.lookupService.getOperators();
    this.invoiceJobSearchForm = this.fb.group({
      periodYear: [],
      periodMonth: [],
      submittedBy: [],
      groupId: [],
      cycleId: [],
      periodCycleId: [],
      groupAutoId: [],
      postInd: [],
      archiveInd: ['N'],
      jobId: [],
      fromDate: [],
      toDate: [],
      fromDateOperator: [],
      toDateOperator: [],
    });

    this.periodCycles$ = this.invoiceJobSearchForm.get('periodCycleId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getPeriodCycles(searchValue.label);
          }
        }

        return of([]);
      })
    );

    this.groups$ = this.invoiceJobSearchForm.get('groupAutoId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getGroups(searchValue.label);
          }
        }

        return of([]);
      })
    );

    this.invoiceJobSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.invoiceJobSearchForm.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () => this.invoiceJobService.search();

    this.paginatorRef.filtersUpdateFunction = criteria => this.invoiceJobService.updateSearchCriteria(criteria);
  }

  showAction(action: any, data: any) {
    if (
      (action.label === 'Error File' && data?.errorfileInd === 'Y') ||
      (action.label === 'Log File' && data?.logfileInd === 'Y') ||
      (action.label === 'Details' && data?.status?.toUpperCase() === 'COMPLETED')
    ) {
      return true;
    }

    return false;
  }

  onPremiumBillingClick(e: any) {
    this.requestService.navigate(['/financial/invoice/dashboard/'], {
      state: {
        data: {
          backButtonRoute: '/financial/invoice-job/dashboard/',
          ...e.rowData,
        },
      },
    });
  }

  onProcessedFileActionClick(e: any) {
    this.invoiceJobService.downloadFiles(e.rowData?.jobId, 'process', e.rowData?.premiumBilling.concat('.xml'));
  }

  onErrorFileActionClick(e: any) {
    this.invoiceJobService.downloadErrorFile(e.rowData?.jobId, e.rowData?.premiumBilling.concat('.csv'));
  }

  onLogFileActionClick(e: any) {
    this.invoiceJobService.downloadFiles(e.rowData?.jobId, 'log', e.rowData?.premiumBilling.concat('.log'));
  }

  getPeriodCycles(periodCycleName: string, periodCycleId?: number): Observable<Array<ListChoice>> {
    return this.lookUpDataService.getPeriodCycles(periodCycleName, periodCycleId).pipe(
      filter(data => data && data.length > 0),
      mergeMap((items: PeriodCycle[]) => items),
      map((item: any) => {
        return {
          value: item.id,
          label: item.cycleName,
        } as ListChoice;
      }),
      toArray()
    );
  }

  getGroups(groupName: string, groupId?: number): Observable<Array<ListChoice>> {
    return this.lookUpDataService.getGroupByName(groupName, this.sessionService.currentUser().currentLobId, groupId).pipe(
      filter(data => data && data.length > 0),
      mergeMap((items: any[]) => items),
      map((item: any) => {
        return {
          value: item.id,
          label: item.groupName + '-' + item.groupNumber,
        } as ListChoice;
      }),
      toArray()
    );
  }

  onSearch() {
    if (this.invoiceJobSearchForm.invalid) {
      return;
    }
    const clientQuery = this.invoiceJobSearchForm.value;
    clientQuery.cycleId = clientQuery.periodCycleId?.value;
    clientQuery.groupId = clientQuery.groupAutoId?.value;
    this.invoiceJobService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }
  onReset() {
    this.invoiceJobSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.invoiceJobSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }

  onDetailsActionClick(e: any) {
    if (e.rowData?.jobId) {
      this.dialog.open(InvoiceJobDetailsComponent, {
        width: '50%',
        height: 'auto',
        data: e.rowData,
      });
    }
  }
}
