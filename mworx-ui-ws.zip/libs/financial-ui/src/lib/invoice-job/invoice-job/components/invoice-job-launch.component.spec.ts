import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceJobLaunchComponent } from './invoice-job-launch.component';

describe('InvoiceJobLaunchComponent', () => {
  let component: InvoiceJobLaunchComponent;
  let fixture: ComponentFixture<InvoiceJobLaunchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceJobLaunchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceJobLaunchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
