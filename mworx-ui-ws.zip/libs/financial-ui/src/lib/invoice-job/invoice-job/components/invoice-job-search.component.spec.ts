import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceJobSearchComponent } from './invoice-job-search.component';

describe('InvoiceJobSearchComponent', () => {
  let component: InvoiceJobSearchComponent;
  let fixture: ComponentFixture<InvoiceJobSearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceJobSearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceJobSearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
