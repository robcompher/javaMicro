import { ID } from '@datorama/akita';

export interface InvoiceJob {
  id: ID;
  periodMonth: number;
  periodYear: number;
  accountingMonth: number;
  accountingYear: number;
  status: string;
  premiumBilling: string;
  cycleId: number;
  archiveInd: string;
  jobId: number;
  postInd: string;
  postDate: any;
  created: any;
  createBy: number;
  updated: any;
  updatedBy: number;
  errorfileInd: string;
  logfileInd: string;
}

export function initialEvent(params: Partial<InvoiceJob>) {
  return {
    id: null,
    periodMonth: null,
    periodYear: null,
    accountingMonth: null,
    accountingYear: null,
    status: null,
    premiumBilling: null,
    cycleId: null,
    archiveInd: null,
    jobId: null,
    postInd: null,
    postDate: null,
    created: null,
    createBy: null,
    updated: null,
    updatedBy: null,
    errorfileInd: null,
    logfileInd: null,
  } as InvoiceJob;
}
