import { SearchCriteria } from '@mworx/grid';

export interface InvoiceJobSearchCriteria extends SearchCriteria {
  periodMonth: number;
  periodYear: number;
  cycleId: number;
  groupId: number;
  postInd: string;
  archiveInd: string;
  submittedBy: string;
  fromDate: any;
  toDate: any;
  fromDateOperator: string;
  toDateOperator: string;
  jobId: number;
}
