export interface InvoiceJobLaunch {
  periodCycleName: string;
  premiumMonth: number;
  premiumYear: number;
  accountingMonth: number;
  accountingYear: number;
  invoiceDueDate: any;
}
