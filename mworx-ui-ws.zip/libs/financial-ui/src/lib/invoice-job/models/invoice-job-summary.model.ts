export interface InvoiceJobSummary {
  premiumRecordCount: number;
  premiumAdjustmentRecordCount: number;
  subsidyRecordCount: number;
  subsidyAdjustmentRecordCount: number;
  feeRecordCount: number;
  feeAdjustmentRecordCount: number;
  manualAdjustmentRecordCount: number;
  totalRecords: number;
  totalPremiumAdjustmentAmount: number;
  totalSubsidyAdjustmentAmount: number;
  totalPremiumAmount: number;
  totalSubsidyAmount: number;
  totalFeeAmount: number;
  totalFeeAdjustmentAmount: number;
  totalManualAdjustmentAmount: number;
  netAmountBilledToMembers: number;
  totalReceivable: number;
  totalInvoiceCount: number;
}
