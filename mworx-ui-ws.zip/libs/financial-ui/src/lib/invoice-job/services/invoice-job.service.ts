import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse } from '@datorama/akita';
import { AppInjector } from '@mworx/util';
import * as FileSaver from 'file-saver';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { InvoiceJobLaunch } from '../models/invoice-job-launch.model';
import { InvoiceJobSearchCriteria } from '../models/invoice-job-search.model';
import { InvoiceJobSummary } from '../models/invoice-job-summary.model';
import { InvoiceJob } from '../models/invoice-job.model';
import { InvoiceJobSearchStore } from '../state/invoice-job-search.store';
@Injectable({
  providedIn: 'root',
})
export class InvoiceJobService {
  private invoiceJobSearchStore: InvoiceJobSearchStore;
  private httpClient: HttpClient;
  private configService: ConfigService;

  constructor() {
    this.invoiceJobSearchStore = AppInjector.get(InvoiceJobSearchStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
  }

  public search(): Observable<PaginationResponse<InvoiceJob>> {
    const criteria = { ...this.invoiceJobSearchStore.getValue().ui.filters };

    return this.httpClient
      .post<PaginationResponse<InvoiceJob>>(this.configService.get('financial.constants.url.getInvoiceJobsBySearchCriteria'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<InvoiceJob>;
        })
      );
  }

  public updateSearchCriteria(criteria: InvoiceJobSearchCriteria) {
    const prevCriteria = this.invoiceJobSearchStore.getValue().ui.filters;
    this.invoiceJobSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public startInvoiceJob(invoiceJobLaunch: InvoiceJobLaunch): Observable<any> {
    return this.httpClient.post<any>(this.configService.get('financial.constants.url.startInvoicingJob'), invoiceJobLaunch);
  }
  public validateInvoiceJob(invoiceJobLaunch: InvoiceJobLaunch): Observable<any> {
    return this.httpClient.post<any>(this.configService.get('financial.constants.url.validateInvoicingJob'), invoiceJobLaunch);
  }
  public getNextBillRun(cycleId: string | number | object): Observable<any> {
    return this.httpClient.post<any>(this.configService.get('financial.constants.url.getNextBillRun'), { cycleId: cycleId });
  }

  downloadErrorFile(jobId: number, errorFile: string) {
    const data = {
      id: jobId,
    };
    this.httpClient
      .post(this.configService.get('staging.constants.url.errorFileDownload'), data, { responseType: 'blob', observe: 'response' })
      .pipe(
        map(res => ({
          content: res.body,
          fileName: errorFile,
        }))
      )
      .subscribe(res => this.downloadFile(res));
  }

  downloadFiles(jobId: number, fileType: string, filePath: string) {
    const data = {
      fileType,
      jobId,
    };
    this.httpClient
      .post(this.configService.get('staging.constants.url.fileDownload'), data, { responseType: 'blob', observe: 'response' })
      .pipe(
        map(res => ({
          content: res.body,
          fileName: filePath.substring(filePath.lastIndexOf('/') + 1),
        }))
      )
      .subscribe(resData => this.downloadFile(resData));
  }

  downloadFile(data) {
    const blobData = new Blob([data.content]);
    FileSaver.saveAs(blobData, data.fileName);
  }
  getSummaryData(jobId: number): Observable<InvoiceJobSummary> {
    return this.httpClient.post<InvoiceJobSummary>(this.configService.get('financial.constants.url.getInvoiceJobSummary'), { jobId: jobId });
  }
  archiveJob(id: ID): Observable<InvoiceJob> {
    return this.httpClient.post<InvoiceJob>(this.configService.get('financial.constants.url.archiveJob'), { id: id });
  }
  postJob(id: ID): Observable<InvoiceJob> {
    return this.httpClient.post<InvoiceJob>(this.configService.get('financial.constants.url.postJob'), { id: id });
  }
}
