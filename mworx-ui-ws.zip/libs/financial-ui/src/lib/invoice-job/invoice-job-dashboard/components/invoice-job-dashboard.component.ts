import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { AppInjector } from '@mworx/util';
import { InvoiceJobLaunchComponent } from '../../invoice-job/components/invoice-job-launch.component';
import { InvoiceJobSearchComponent } from '../../invoice-job/components/invoice-job-search.component';

@Component({
  selector: 'financial-invoice-job-dashboard',
  templateUrl: './invoice-job-dashboard.component.html',
  styleUrls: ['./invoice-job-dashboard.component.scss'],
})
export class InvoiceJobDashboardComponent implements OnInit {
  @ViewChild('invoiceJobSearch')
  private invoiceJobSearch: InvoiceJobSearchComponent;

  public dialog: MatDialog;

  constructor() {
    this.dialog = AppInjector.get(MatDialog);
  }
  ngOnInit(): void {}

  onReset($event: any) {
    if ($event) {
      this.invoiceJobSearch.onReset();
    }
  }

  onSearch($event: any) {
    if ($event) {
      this.invoiceJobSearch.onSearch();
    }
  }
  onLaunch($event: any) {
    if ($event) {
      this.dialog.open(InvoiceJobLaunchComponent, {
        width: '50%',
        height: 'auto',
      });
    }
  }
}
