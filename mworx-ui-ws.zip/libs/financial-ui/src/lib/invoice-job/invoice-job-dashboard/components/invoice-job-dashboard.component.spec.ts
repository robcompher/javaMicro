import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { InvoiceJobDashboardComponent } from './invoice-job-dashboard.component';

describe('InvoiceJobDashboardComponent', () => {
  let component: InvoiceJobDashboardComponent;
  let fixture: ComponentFixture<InvoiceJobDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ InvoiceJobDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(InvoiceJobDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
