import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';
import { InvoiceJobModule } from '../invoice-job/invoice-job.module';
import { InvoiceJobDashboardComponent } from './components/invoice-job-dashboard.component';

@NgModule({
  declarations: [InvoiceJobDashboardComponent],
  imports: [CommonModule, MatButtonModule, MatIconModule, RouterModule, SharedUiLayoutModule, SharedSessionModule, InvoiceJobModule],

  exports: [InvoiceJobDashboardComponent],
})
export class InvoiceJobDashboardModule {}
