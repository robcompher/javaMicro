import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { InvoiceJobSearchCriteria } from '../models/invoice-job-search.model';
import { InvoiceJob } from '../models/invoice-job.model';

export interface InvoiceJobSearchState extends EntityState<InvoiceJob> {}

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'created',
        sortOrder: 'desc',
      },
      periodMonth: null,
      periodYear: null,
      cycleId: null,
      groupId: null,
      postInd: null,
      archiveInd: 'N',
      submittedBy: null,
      fromDate: null,
      toDate: null,
      jobId: null,
      fromDateOperator: 'GREATERTHAN_EQUAL',
      toDateOperator: 'LESSTHAN_EQUAL',
    } as InvoiceJobSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'invoice-job-search', idKey: 'id', resettable: true })
export class InvoiceJobSearchStore extends EntityStore<InvoiceJobSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<InvoiceJobSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
