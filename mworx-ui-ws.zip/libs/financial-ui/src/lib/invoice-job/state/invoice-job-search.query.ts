import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { InvoiceJobSearchState, InvoiceJobSearchStore } from './invoice-job-search.store';

@Injectable({ providedIn: 'root' })
export class InvoiceJobSearchQuery extends QueryEntity<InvoiceJobSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: InvoiceJobSearchStore) {
    super(store);
  }
}
