import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SharedLookupModule } from '@mworx/lookup';
import { AgGridModule } from 'ag-grid-angular';
import { AdjustmentAddEditModule } from './adjustment/adjustment-add-edit/adjustment-add-edit.module';
import { AdjustmentDashboardModule } from './adjustment/adjustment-dashboard/adjustment-dashboard.module';
import { AdjustmentSearchModule } from './adjustment/adjustment-search/adjustment-search.module';
import { InvAdjSelectDialogModule } from './adjustment/inv-adj-select-dialog/inv-adj-select-dialog.module';
import { FeesAddEditModule } from './fees/fees-add-edit/fees-add-edit.module';
import { FeesDashboardModule } from './fees/fees-dashboard/fees-dashboard.module';
import { FeesSearchModule } from './fees/fees-search/fees-search.module';
import { FeesTabsModule } from './fees/fees-tabs/fees-tabs.module';
import { GroupsModule } from './fees/groups/groups.module';
import { MembersModule } from './fees/members/members.module';
import { FinancialUiRoutingModule } from './financial-ui-routing.module';
import { InvoiceJobDashboardModule } from './invoice-job/invoice-job-dashboard/invoice-job-dashboard.module';
import { InvoiceJobModule } from './invoice-job/invoice-job/invoice-job.module';
import { InvoiceDashboardModule } from './invoice/invoice-dashboard/invoice-dashboard.module';
import { InvoiceSearchModule } from './invoice/invoice-search/invoice-search.module';
import { LinkRateFactorSetAddEditModule } from './rating/link-rate-factor-set-add-edit/link-rate-factor-set-add-edit.module';
import { RateFactorAddEditModule } from './rating/ratefactor-add-edit/ratefactor-add-edit.module';
import { RatefactorDashboardModule } from './rating/ratefactor-dashboard/ratefactor-dashboard.module';

@NgModule({
  imports: [
    AdjustmentAddEditModule,
    AdjustmentDashboardModule,
    AdjustmentSearchModule,
    CommonModule,
    FeesAddEditModule,
    FeesDashboardModule,
    FeesSearchModule,
    FeesTabsModule,
    FinancialUiRoutingModule,
    InvAdjSelectDialogModule,
    GroupsModule,
    SharedLookupModule,
    LinkRateFactorSetAddEditModule,
    RateFactorAddEditModule,
    RatefactorDashboardModule,
    InvoiceJobDashboardModule,
    InvoiceJobModule,
    InvoiceDashboardModule,
    InvoiceSearchModule,
    AgGridModule,
    MembersModule,
  ],
})
export class FinancialUiModule { }
