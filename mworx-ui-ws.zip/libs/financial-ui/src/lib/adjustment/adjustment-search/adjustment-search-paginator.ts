import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { AdjustmentSearchQuery } from '../state/adjustment-search.query';

export const ADJUSTMENT_SEARCH_PAGINATOR = new InjectionToken('ADJUSTMENT_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const adjustmentSearchQuery = inject(AdjustmentSearchQuery);

    return new GridPaginatorPlugin(adjustmentSearchQuery);
  },
});
