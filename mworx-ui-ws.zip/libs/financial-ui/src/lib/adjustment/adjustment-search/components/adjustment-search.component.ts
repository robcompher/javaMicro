import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, NgZone, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, ListChoice, LookupDataService, LookupService } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';
import { Observable, of } from 'rxjs';
import { catchError, filter, flatMap, map, switchMap, toArray } from 'rxjs/operators';
import { AdjustmentService } from '../../services/adjustment.service';
import { AdjustmentSearchQuery } from '../../state/adjustment-search.query';
import { AdjustmentSearchState } from '../../state/adjustment-search.store';
import { ADJUSTMENT_SEARCH_PAGINATOR } from '../adjustment-search-paginator';

@UntilDestroy()
@Component({
  selector: 'financial-adjustment-search',
  templateUrl: './adjustment-search.component.html',
  styleUrls: ['./adjustment-search.component.scss']
})
export class AdjustmentSearchComponent implements OnInit, OnDestroy {
  adjustmentSearchForm: FormGroup;
  gridApi: GridApi;
  adjustmentTypeValues$: Observable<Array<LibList>>;
  billToValues$: Observable<Array<LibList>>;
  groups$: Observable<Array<ListChoice>>;
  postedValues$: Observable<Array<ListChoice>>;
  activeValues$: Observable<Array<ListChoice>>;

  @ViewChild('adjustmentSearchDirective')
  adjustmentSearchDirective: FormGroupDirective;
  columnDefs;

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;

      if (this.adjustmentService.isRefreshSearchGrid()) {
        this.gridApi.onFilterChanged();
        this.adjustmentService.setRefreshSearchGrid(false);
      }
    },
  };

  private configService: ConfigService;
  private dialog: MatDialog;
  private errorService: ErrorService;
  private fb: FormBuilder;
  private adjustmentSearchQuery: AdjustmentSearchQuery;
  private adjustmentService: AdjustmentService;
  private lookupService: LookupService;
  private lookupDataService: LookupDataService;
  private notificationService: NotificationService;
  private requestService: RequestService;
  constructor(@Inject(ADJUSTMENT_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<AdjustmentSearchState>) {
    this.configService = AppInjector.get(ConfigService);
    this.dialog = AppInjector.get(MatDialog);
    this.errorService = AppInjector.get(ErrorService);
    this.fb = AppInjector.get(FormBuilder);
    this.adjustmentSearchQuery = AppInjector.get(AdjustmentSearchQuery);
    this.adjustmentService = AppInjector.get(AdjustmentService);
    this.lookupService = AppInjector.get(LookupService);
    this.lookupDataService = AppInjector.get(LookupDataService);
    this.notificationService = AppInjector.get(NotificationService);
    this.requestService = AppInjector.get(RequestService);
  }

  ngOnInit(): void {
    this.createForm();
    this.initFormLists();

    this.columnDefs = [
      {
        headerName: 'Adjustment Type',
        field: 'adjustmentType',
        valueGetter: 'category:' + this.configService.get('metadata.constants.categories.adjustmentType'),
        sortable: false
      },
      {
        headerName: 'Bill To',
        field: 'billTo',
        valueGetter: 'category:' + this.configService.get('metadata.constants.categories.billTo'),
        sortable: false
      },
      {
        headerName: 'Billable Acct Name',
        valueGetter: (params: ValueGetterParams) => this.billableAcctValueGetter(params, 'name'),
        sortable: false
      },
      {
        headerName: 'Billable Acct Nbr',
        valueGetter: (params: ValueGetterParams) => this.billableAcctValueGetter(params, 'number'),
        sortable: false
      },
      { headerName: 'Amount', field: 'amount', type: 'currencyColumn' },
      { headerName: 'Created', field: 'created', type: 'dateColumn' },
      { headerName: 'Posted', field: 'postInd' },
      { headerName: 'Active', field: 'active' },
      {
        headerName: 'Actions',
        colId: 'Actions',
        minWidth: 150,
        sortable: false,
        cellRenderer: 'buttonRenderer',
        cellRendererParams: {
          actions: [
            {
              onClick: this.onViewActionClick.bind(this),
              title: 'View',
              icon: 'remove_red_eye',
              color: 'primary',
              permissions: ['PERMIT_ADJUSTMENT_VIEW'],
            },
            {
              onClick: this.onEditActionClick.bind(this),
              title: 'Edit',
              icon: 'edit',
              color: 'primary',
              show: this.showAction.bind(this),
              permissions: ['PERMIT_ADJUSTMENT_UPDATE'],
            },
            {
              onClick: this.onDeleteActionClick.bind(this),
              title: 'Delete',
              icon: 'delete',
              color: 'warn',
              show: this.showAction.bind(this),
              permissions: ['PERMIT_ADJUSTMENT_UPDATE'],
            },
          ],
        },
      },
    ];

    this.adjustmentSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.adjustmentSearchForm.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () => this.adjustmentService.search();
    this.paginatorRef.filtersUpdateFunction = criteria => this.adjustmentService.updateSearchCriteria(criteria);
  }

  billableAcctValueGetter(params: ValueGetterParams, type: string) {
    const billableAcctInfo = this.adjustmentService.getBillableAcctInfo(params.data);
    if (type === 'name') {
      return billableAcctInfo.name ? billableAcctInfo.name : '';
    } else {
      return billableAcctInfo.number ? billableAcctInfo.number : '';
    }
  }

  ngOnDestroy(): void {
    this.paginatorRef.destroy({ clearCache: true, currentPage: 1 });
    this.adjustmentSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => this.adjustmentService.updateSearchCriteria(criteria));
  }

  createForm() {
    this.adjustmentSearchForm = this.fb.group({
      adjustmentType: [''],
      billTo: [''],
      groupAutoId: [''],
      familyId: [''],
      createdFrom: [''],
      createdTo: [''],
      postInd: [''],
      active: [''],
    });
  }

  initFormLists() {
    this.billToValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.billTo'));
    this.postedValues$ = this.lookupService.getYesNoBoth();
    this.activeValues$ = this.lookupService.getYesNoBoth();
    this.adjustmentTypeValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.adjustmentType'));
    this.groups$ = this.adjustmentSearchForm.get('groupAutoId').valueChanges.pipe(
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.lookupDataService.getGroupByName(searchValue.label, (this.lookupService.getCurrentUserLob()).lobId).pipe(
              filter(data => data && data.length > 0),
              flatMap((items: any[]) => items),
              map((item: any) => {
                return {
                  value: item.id,
                  label: item.groupName + '-' + item.groupNumber,
                } as ListChoice;
              }),
              toArray()
            );
          }
        }

        return of([]);
      })
    );
  }

  showAction(action: any, data: any) {
    if (data.invoiceBilledDTO?.invoiceNumber || (action.title === 'Delete' && data.active === 'N')) {
      return false;
    }

    return true;
  }

  onViewActionClick(e: any) {
    const ngZone = AppInjector.get(NgZone);
    ngZone.run(() => {
      this.requestService.navigate(['/financial/adjustment/view'], { state: { data: e.rowData } });
    });
  }

  onEditActionClick(e: any) {
    const ngZone = AppInjector.get(NgZone);
    ngZone.run(() => {
      this.requestService.navigate(['/financial/adjustment/edit'], { state: { data: e.rowData } });
    });
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.adjustmentService
            .deleteByID(e.rowData.id)
            .pipe(
              untilDestroyed(this),
              catchError((error: HttpErrorResponse) => {
                return this.errorService.handleTableValidationErrors(error);
              })
            )
            .subscribe(() => {
              this.lookupService.getLibListByCategoryAndId(this.configService.get('metadata.constants.categories.adjustmentType'), e.rowData.adjustmentType)
                .pipe(untilDestroyed(this))
                .subscribe(liblist => {
                  const notifyMessage = this.adjustmentService.getNotifyMessage(e.rowData)
                  this.notificationService.showSuccess(this.configService.get('defaultMessages.actionResponse')('deleted', 'adjustment', notifyMessage ? liblist.label + '-' + notifyMessage : liblist.label));
                  this.onReset();
                });
            });
        }
      });
  }

  onSearch() {
    if (this.adjustmentSearchForm.invalid) {
      return;
    }

    const clientQuery = this.adjustmentSearchForm.value;
    clientQuery.groupId = clientQuery.groupAutoId ? clientQuery.groupAutoId.value : null;
    this.adjustmentService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset() {
    this.adjustmentSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.adjustmentSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }
}
