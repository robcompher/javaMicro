import { SearchCriteria } from '@mworx/grid';

export interface InvoiceAdjustedSearchCriteria extends SearchCriteria {
  groupId: number;
  familyId: number;
  invoiceNumber: string;
  postInd: string;
  onlyZeroBalance: string;
}
