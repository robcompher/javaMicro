import { ID } from '@datorama/akita';
import { Invoice } from '../../invoice/models/invoice.model';

export interface Adjustment {
  id: ID;
  billTo: number;
  groupId: number;
  adjustmentType: number;
  familyId: string;
  periodStart: any;
  periodEnd: any;
  amount: number;
  postInd: string;
  invoiceAdjDTO: Invoice;
  invoiceBilledDTO: Invoice;
  grpInvoiceAdjDTO: Invoice;
  grpInvoiceBilledDTO: Invoice;
  description: string;
  active: string;
  created: any;
  groupName: string;
  groupNumber: string;
  subscriberName: string;
}

export function createAdjustment(params: Partial<Adjustment>) {
  return {
    id: null,
    billTo: null,
    groupId: null,
    groupName: null,
    groupNumber: null,
    subscriberName: null,
    adjustmentType: null,
    familyId: null,
    periodStart: null,
    periodEnd: null,
    amount: null,
    postInd: null,
    invoiceAdjDTO: null,
    invoiceBilledDTO: null,
    grpInvoiceAdjDTO: null,
    grpInvoiceBilledDTO: null,
    description: null,
    active: null,
    created: null,
    invoiceAdjNbr: null,
    invoiceBilledNbr: null,
    grpInvoiceAdjNbr: null,
    grpInvoiceBilledNbr: null
  } as Adjustment;
}
