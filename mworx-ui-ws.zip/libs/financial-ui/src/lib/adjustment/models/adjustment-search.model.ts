import { SearchCriteria } from '@mworx/grid';

export interface AdjustmentSearchCriteria extends SearchCriteria {
  billTo: number;
  adjustmentType: number;
  groupId: number;
  familyId: number;
  createdFrom: any;
  createdTo: any;
  postInd: string;
  active: string;
}
