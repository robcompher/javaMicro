import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse, withTransaction } from '@datorama/akita';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { Invoice } from '../../invoice/models/invoice.model';
import { AdjustmentSearchCriteria } from '../models/adjustment-search.model';
import { Adjustment } from '../models/adjustment.model';
import { InvoiceAdjustedSearchCriteria } from '../models/invoice-adjusted-search.model';
import { AdjustmentSearchStore } from '../state/adjustment-search.store';
import { AdjustmentQuery } from '../state/adjustment.query';
import { AdjustmentStore } from '../state/adjustment.store';
import { InvoiceAdjustedSearchStore } from '../state/invoice-adjusted-search.store';

@Injectable({
  providedIn: 'root'
})
export class AdjustmentService {
  private adjustmentSearchStore: AdjustmentSearchStore;
  private invoiceAdjustedSearchStore: InvoiceAdjustedSearchStore;
  private httpClient: HttpClient;
  private configService: ConfigService;
  private adjustmentStore: AdjustmentStore;
  private adjustmentQuery: AdjustmentQuery;
  constructor() {
    this.adjustmentSearchStore = AppInjector.get(AdjustmentSearchStore);
    this.invoiceAdjustedSearchStore = AppInjector.get(InvoiceAdjustedSearchStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.adjustmentStore = AppInjector.get(AdjustmentStore);
    this.adjustmentQuery = AppInjector.get(AdjustmentQuery);
  }

  public invoiceSearch(): Observable<PaginationResponse<Invoice>> {
    const criteria = this.invoiceAdjustedSearchStore.getValue().ui.filters;

    return this.httpClient
      .post<PaginationResponse<Invoice>>(this.configService.get('financial.constants.url.getInvoiceRecordsByFamilyOrGroup'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<Invoice>;
        })
      );
  }

  public updateInvoiceAdjustedSearchCriteria(criteria: InvoiceAdjustedSearchCriteria) {
    const prevCriteria = this.invoiceAdjustedSearchStore.getValue().ui.filters;
    this.invoiceAdjustedSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public search(): Observable<PaginationResponse<Adjustment>> {
    const criteria = this.adjustmentSearchStore.getValue().ui.filters;

    return this.httpClient
      .post<PaginationResponse<Adjustment>>(this.configService.get('financial.constants.url.findAdjustmentBySearch'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<Adjustment>;
        })
      );
  }

  public updateSearchCriteria(criteria: AdjustmentSearchCriteria) {
    const prevCriteria = this.adjustmentSearchStore.getValue().ui.filters;
    this.adjustmentSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public deleteByID(id: ID): Observable<any> {
    return this.httpClient
      .put<any>(this.configService.get('financial.constants.url.deleteAdjustment'), { id: id })
      .pipe(
        tap(resp => {
          this.adjustmentSearchStore.remove(id);
          this.adjustmentStore.remove(id);
        })
      );
  }

  public getById(id: ID): Observable<Adjustment> {
    return this.adjustmentQuery.selectEntity(id).pipe(
      switchMap(cacheEntry => {
        const apiCall = this.httpClient
          .post<any>(this.configService.get('financial.constants.url.getPremiumAdjustmentById'), { id: id })
          .pipe(
            withTransaction(response => {
              if (response) {
                this.adjustmentStore.upsert(id, response);
                this.adjustmentStore.setHasCache(true);
              }
            }),
            switchMap(res => this.adjustmentQuery.selectEntity(id))
          );

        return cacheEntry ? this.adjustmentQuery.selectEntity(id) : apiCall;
      })
    );
  }

  public addOrUpdate(adjustmentDTO: Adjustment): Observable<any> {
    if (this.adjustmentQuery.hasEntity(adjustmentDTO.id) && Boolean(adjustmentDTO.id)) {
      return this.httpClient.put<Adjustment>(this.configService.get('financial.constants.url.addOrUpdateAdjustment'),
        { ...this.adjustmentQuery.getEntity(adjustmentDTO.id), ...adjustmentDTO }).pipe(
          tap(currentAdjustment => {
            this.adjustmentStore.upsert(currentAdjustment.id, currentAdjustment);
            this.adjustmentSearchStore.upsert(currentAdjustment.id, currentAdjustment);
          })
        );
    } else {
      return this.httpClient.post<Adjustment>(this.configService.get('financial.constants.url.addOrUpdateAdjustment'), adjustmentDTO).pipe(
        tap(currentAdjustment => {
          this.adjustmentStore.upsert(currentAdjustment.id, currentAdjustment);
          this.adjustmentSearchStore.upsert(currentAdjustment.id, currentAdjustment);
        })
      );
    }
  }

  public getBillableAcctInfo(data: any) {
    const billableAcctInfo = {
      name: null,
      number: null
    };
    if (data) {
      if (data.groupId) {
        billableAcctInfo.name = data.groupName;
        billableAcctInfo.number = data.groupNumber;
      } else {
        billableAcctInfo.name = data.subscriberName;
        billableAcctInfo.number = data.familyId
      }
    }

    return billableAcctInfo;
  }

  public getNotifyMessage(data: any) {
    let displayText = '';
    const billableAcctInfo = this.getBillableAcctInfo(data);
    if (billableAcctInfo.name) {
      displayText = billableAcctInfo.number ? billableAcctInfo.name + '-' : billableAcctInfo.name;
    }
    if (billableAcctInfo.number) {
      displayText = displayText + billableAcctInfo.number;
    }

    return displayText;
  }

  isRefreshSearchGrid(): boolean {
    return this.adjustmentSearchStore.isRefreshSearchGrid();
  }

  setRefreshSearchGrid(value: boolean) {
    this.adjustmentSearchStore.setRefreshSearchGrid(value);
  }
}
