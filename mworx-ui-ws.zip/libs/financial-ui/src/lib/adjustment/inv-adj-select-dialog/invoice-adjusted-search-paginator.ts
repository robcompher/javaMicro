import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { InvoiceAdjustedSearchQuery } from '../state/invoice-adjusted-search.query';

export const INVOICE_ADJUSTED_SEARCH_PAGINATOR = new InjectionToken('INVOICE_ADJUSTED_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const invoiceAdjustedSearchQuery = inject(InvoiceAdjustedSearchQuery);

    return new GridPaginatorPlugin(invoiceAdjustedSearchQuery);
  },
});
