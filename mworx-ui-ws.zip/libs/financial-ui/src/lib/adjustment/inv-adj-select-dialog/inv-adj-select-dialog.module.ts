import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { InvAdjSelectDialogComponent } from './components/inv-adj-select-dialog.component';

@NgModule({
  declarations: [InvAdjSelectDialogComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    SharedUiGridModule,
    SharedUiLayoutModule
  ],
  exports: [InvAdjSelectDialogComponent]
})
export class InvAdjSelectDialogModule { }
