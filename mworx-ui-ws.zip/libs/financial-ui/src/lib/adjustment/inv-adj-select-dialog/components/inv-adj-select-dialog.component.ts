import { Component, Inject, OnDestroy, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { GridPaginatorPlugin } from '@mworx/grid';
import { LookupService } from '@mworx/lookup';
import { AppInjector } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';
import { InvoiceAdjustedSearchCriteria } from '../../models/invoice-adjusted-search.model';
import { AdjustmentService } from '../../services/adjustment.service';
import { InvoiceAdjustedSearchQuery } from '../../state/invoice-adjusted-search.query';
import { InvoiceAdjustedSearchState } from '../../state/invoice-adjusted-search.store';
import { INVOICE_ADJUSTED_SEARCH_PAGINATOR } from '../invoice-adjusted-search-paginator';

@UntilDestroy()
@Component({
  selector: 'financial-inv-adj-select-dialog',
  templateUrl: './inv-adj-select-dialog.component.html',
  styleUrls: ['./inv-adj-select-dialog.component.scss']
})
export class InvAdjSelectDialogComponent implements OnInit, OnDestroy {
  gridApi: GridApi;
  pageTitle: string;
  isSaveButtonEnabled = false;
  invoiceAdjusted = {
    invoiceAdj: null,
    invoiceAdjNbr: null,
    billPeriod: null
  };
  periodMonth: number;
  periodYear: number;
  groupAcct: boolean;
  columnDefs;

  gridOptions: GridOptions = {
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
    onRowSelected: event => {
      if (event.node.isSelected()) {
        this.invoiceAdjusted.invoiceAdj = event.node.data.id;
        this.invoiceAdjusted.invoiceAdjNbr = event.node.data.invoiceNumber;
        this.periodMonth = event.node.data.premBillingDTO.periodMonth;
        this.periodYear = event.node.data.premBillingDTO.periodYear;
        this.isSaveButtonEnabled = true;
      } else {
        let invoiceSelected = false;
        this.gridApi?.forEachNode(node => node.isSelected() ? invoiceSelected = true : null);
        if (!invoiceSelected) {
          this.invoiceAdjusted.invoiceAdj = null;
          this.invoiceAdjusted.invoiceAdjNbr = null;
          this.periodMonth = null;
          this.periodYear = null;
          this.isSaveButtonEnabled = false;
        }
      }
    },
    onPaginationChanged: () => {
      this.gridApi?.forEachNode(node => this.invoiceAdjusted.invoiceAdj === node.data.id ? node.setSelected(true) : null);
    },
  };

  private adjustmentService: AdjustmentService;
  private configService: ConfigService;
  private invoiceAdjustedSearchQuery: InvoiceAdjustedSearchQuery;
  private lookupService: LookupService;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
    private dialogRef: MatDialogRef<InvAdjSelectDialogComponent>,
    @Inject(INVOICE_ADJUSTED_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<InvoiceAdjustedSearchState>
  ) {
    this.adjustmentService = AppInjector.get(AdjustmentService);
    this.configService = AppInjector.get(ConfigService);
    this.lookupService = AppInjector.get(LookupService);
    this.invoiceAdjustedSearchQuery = AppInjector.get(InvoiceAdjustedSearchQuery);
  }

  ngOnInit(): void {
    this.pageTitle = 'Invoice Adjusted Selection for ' + this.data.billableAcctName;
    this.invoiceAdjusted.invoiceAdj = this.data.invoiceAdjusted.invoiceAdj;
    this.invoiceAdjusted.invoiceAdjNbr = this.data.invoiceAdjusted.invoiceAdjNbr;
    if (this.data.groupId) {
      this.groupAcct = true;
    } else {
      this.groupAcct = false;
    }

    this.columnDefs = [
      {
        headerName: 'Select',
        checkboxSelection: true,
        sortable: false,
        maxWidth: 80
      },
      { headerName: 'Invoice Number', field: 'invoiceNumber' },
      {
        headerName: 'Prem Month',
        field: 'premBillingDTO.periodMonth',
        valueGetter: 'category:' + this.configService.get('metadata.constants.categories.month'),
        sortable: false
      },
      { headerName: 'Prem Year', field: 'premBillingDTO.periodYear', sortable: false },
      {
        headerName: 'Balance Due',
        valueGetter: (params: ValueGetterParams) => this.balanceDueValueGetter(params),
        type: 'currencyColumn',
        sortable: false
      },
    ];

    this.adjustmentService.updateInvoiceAdjustedSearchCriteria({ groupId: this.data.groupId, familyId: this.data.familyId } as InvoiceAdjustedSearchCriteria);

    this.paginatorRef.requestFunction = () => this.adjustmentService.invoiceSearch();
    this.paginatorRef.filtersUpdateFunction = criteria => this.adjustmentService.updateInvoiceAdjustedSearchCriteria(criteria);
  }

  balanceDueValueGetter(params: ValueGetterParams) {
    let balance = '';
    if (params.data) {
      if (this.groupAcct) {
        const balance02 = params.data.balance02 ? params.data.balance02 : 0;
        const balance03 = params.data.balance03 ? params.data.balance03 : 0;
        const balance04 = params.data.balance04 ? params.data.balance04 : 0;
        const balance05 = params.data.balance05 ? params.data.balance05 : 0;
        balance = balance02 + balance03 + balance04 + balance05;
      } else {
        balance = params.data.memberBalance ? params.data.memberBalance : 0;
      }
    }

    return balance;
  }

  ngOnDestroy() {
    this.paginatorRef.destroy({ clearCache: true, currentPage: 1 });
    this.invoiceAdjustedSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => this.adjustmentService.updateInvoiceAdjustedSearchCriteria(criteria));
  }

  onClose(): void {
    this.closePopup('cancel', null);
  }

  closePopup(event: string, data: any): void {
    this.dialogRef.close({ event: event, data: data });
  }

  doAction(event: string, data: any): void {
    this.closePopup(event, data);
  }

  onSubmit(): void {
    this.lookupService
      .getLibListByCategoryAndId(this.configService.get('metadata.constants.categories.month'), this.periodMonth)
      .pipe(untilDestroyed(this))
      .subscribe(liblist => {
        this.invoiceAdjusted.billPeriod = liblist?.label ? liblist.label + ' ' + this.periodYear : null
        this.doAction('selected', this.invoiceAdjusted);
      });
  }
}
