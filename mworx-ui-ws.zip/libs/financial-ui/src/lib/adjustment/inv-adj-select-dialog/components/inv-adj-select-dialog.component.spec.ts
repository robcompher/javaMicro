import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InvAdjSelectDialogComponent } from './inv-adj-select-dialog.component';

describe('InvAdjSelectDialogComponent', () => {
  let component: InvAdjSelectDialogComponent;
  let fixture: ComponentFixture<InvAdjSelectDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InvAdjSelectDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InvAdjSelectDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
