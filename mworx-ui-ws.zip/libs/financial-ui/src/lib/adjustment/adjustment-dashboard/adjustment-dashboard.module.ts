import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';
import { AdjustmentSearchModule } from '../adjustment-search/adjustment-search.module';
import { AdjustmentDashboardComponent } from './components/adjustment-dashboard.component';

@NgModule({
  declarations: [AdjustmentDashboardComponent],
  imports: [
    CommonModule,
    AdjustmentSearchModule,
    MatButtonModule,
    MatIconModule,
    RouterModule,
    SharedUiLayoutModule,
    SharedSessionModule
  ],
  exports: [AdjustmentDashboardComponent]
})
export class AdjustmentDashboardModule { }
