import { Component, OnInit, ViewChild } from '@angular/core';
import { AdjustmentSearchComponent } from '../../adjustment-search/components/adjustment-search.component';

@Component({
  selector: 'financial-adjustment-dashboard',
  templateUrl: './adjustment-dashboard.component.html',
  styleUrls: ['./adjustment-dashboard.component.scss']
})
export class AdjustmentDashboardComponent implements OnInit {

  constructor() { }

  @ViewChild('adjustmentSearch')
  private adjustmentSearch: AdjustmentSearchComponent;

  ngOnInit(): void {
  }

  onSearch() {
    this.adjustmentSearch.onSearch();
  }

  onReset() {
    this.adjustmentSearch.onReset();
  }
}
