import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { LibList, ListChoice, LookupDataService, LookupService } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable, of } from 'rxjs';
import { catchError, distinctUntilChanged, filter, flatMap, map, switchMap, toArray } from 'rxjs/operators';
import { InvAdjSelectDialogComponent } from '../../inv-adj-select-dialog';
import { AdjustmentService } from '../../services/adjustment.service';

@UntilDestroy()
@Component({
  selector: 'financial-adjustment-add-edit',
  templateUrl: './adjustment-add-edit.component.html',
  styleUrls: ['./adjustment-add-edit.component.scss']
})
export class AdjustmentAddEditComponent implements OnInit {
  adjustmentAddEditForm: FormGroup;
  @ViewChild('adjustmentAddEditFormDirective')
  adjustmentAddEditFormDirective: FormGroupDirective;
  id: number;
  action: string;
  pageTitle: string;
  invoiceAdjTypes: string[] = [];

  lookupButtonEnabled: boolean;
  adjustmentTypeLabel: string;
  groupAcct: boolean;
  oldBillToValue: string;

  adjustmentTypeValues$: Observable<Array<LibList>>;
  billToValues$: Observable<Array<LibList>>;
  groups$: Observable<Array<ListChoice>>;
  invoices$: Observable<Array<ListChoice>>;

  private fb: FormBuilder;
  private lookupDataService: LookupDataService;
  private lookupService: LookupService;
  private adjustmentService: AdjustmentService;
  private configService: ConfigService;
  private errorService: ErrorService;
  private notifyService: NotificationService;
  private requestService: RequestService;
  private dialog: MatDialog;
  constructor() {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupDataService = AppInjector.get(LookupDataService);
    this.lookupService = AppInjector.get(LookupService);
    this.adjustmentService = AppInjector.get(AdjustmentService);
    this.configService = AppInjector.get(ConfigService);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.requestService = AppInjector.get(RequestService);
    this.dialog = AppInjector.get(MatDialog);
  }

  ngOnInit(): void {
    this.invoiceAdjTypes = this.configService.get('financial.constants.screens.adjustments.invoiceAdjTypes');
    this.createForm();
    this.initFormLists();
    this.onChanges();

    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this), filter(r => !!r))
      .subscribe(res => {
        if (res.data?.id) {
          this.id = res.data.id;
        }
      });

    if (this.requestService.url().search('add') === -1) {
      this.initData();
      if (this.requestService.url().search('view') !== -1) {
        this.adjustmentAddEditForm.disable();
      }
      this.action = 'updated';
    } else {
      this.pageTitle = 'Add Adjustment';
      this.action = 'created';
      this.adjustmentAddEditForm.controls['invoiceAdjAutoId'].disable();
    }

    if (this.requestService.url().search('view') === -1) {
      this.adjustmentAddEditForm.controls['invoiceBilledNbr'].disable();
      this.adjustmentAddEditForm.controls['billPeriod'].disable();
      this.adjustmentAddEditForm.controls['created'].disable();
      this.adjustmentAddEditForm.controls['postInd'].disable();
    }
  }

  createForm(): void {
    this.adjustmentAddEditForm = this.fb.group({
      adjustmentType: [null, Validators.required],
      billTo: [null, Validators.required],
      groupAutoId: [],
      familyId: [],
      amount: [null, Validators.required],
      invoiceBilledNbr: [],
      invoiceAdjAutoId: [],
      billPeriod: [],
      description: [],
      created: [],
      postInd: [],
      active: ['Y'],
    });
  }

  private initFormLists(): void {
    this.adjustmentTypeValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.adjustmentType'));
    this.billToValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.billTo'));
  }

  private onChanges(): void {
    this.invoices$ = this.adjustmentAddEditForm.get('invoiceAdjAutoId').valueChanges.pipe(
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            this.adjustmentAddEditForm.patchValue({ billPeriod: null }, { emitEvent: false });
            const adjustmentForm = this.adjustmentAddEditForm.value;

            return this.lookupDataService.getInvoiceRecordByFamilyOrGroup(
              searchValue.label,
              adjustmentForm.groupAutoId ? adjustmentForm.groupAutoId.value : null,
              adjustmentForm.familyId,
              'Y',
              'N').pipe(
                filter(data => data && data.length > 0),
                flatMap((items: any[]) => items),
                map((item: any) => {
                  return {
                    value: item.id,
                    label: item.invoiceNumber,
                  } as ListChoice;
                }),
                toArray()
              );
          }
        }

        return of([]);
      })
    );
    this.groups$ = this.adjustmentAddEditForm.get('groupAutoId').valueChanges.pipe(
      untilDestroyed(this),
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            this.resetInvoiceAdjusted();

            return this.lookupDataService.getGroupByName(searchValue.label, (this.lookupService.getCurrentUserLob()).lobId).pipe(
              filter(data => data && data.length > 0),
              flatMap((items: any[]) => items),
              map((item: any) => {
                return {
                  value: item.id,
                  label: item.groupName + '-' + item.groupNumber,
                } as ListChoice;
              }),
              toArray()
            );
          }
        }

        return of([]);
      })
    );
    this.adjustmentAddEditForm.get('familyId').valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
      .subscribe(() => this.resetInvoiceAdjusted());
  }

  private initData(): void {
    if (this.id) {
      this.adjustmentService
        .getById(this.id)
        .pipe(
          untilDestroyed(this),
          filter(response => response != null)
        )
        .subscribe(adjustment => {
          this.lookupService
            .getLibListByCategoryAndId(this.configService.get('metadata.constants.categories.adjustmentType'), adjustment.adjustmentType)
            .pipe(
              untilDestroyed(this)
            )
            .subscribe(liblist => {
              this.adjustmentTypeLabel = liblist?.label;
              const displayText = this.adjustmentService.getNotifyMessage(adjustment);
              if (this.requestService.url().search('view') !== -1) {
                this.pageTitle = 'View Adjustment : ';
              } else {
                this.pageTitle = 'Edit Adjustment : ';
              }
              this.pageTitle = this.pageTitle + (displayText ? this.adjustmentTypeLabel + '-' + displayText : this.adjustmentTypeLabel);

              if (adjustment.groupId) {
                this.groupAcct = true;
              } else {
                this.groupAcct = false;
              }
              if (adjustment.invoiceAdjDTO?.invoiceNumber) {
                if (this.requestService.url().search('view') === -1) {
                  this.enableInvoiceAdjustedField();
                } else {
                  this.disableInvoiceAdjustedField();
                }

                this.lookupService
                  .getLibListByCategoryAndId(this.configService.get('metadata.constants.categories.month'),
                    adjustment.invoiceAdjDTO.premBillingDTO?.periodMonth)
                  .pipe(untilDestroyed(this))
                  .subscribe(liblist2 => {
                    const billPeriod = liblist2?.label ? liblist2.label + ' ' + adjustment.invoiceAdjDTO.premBillingDTO.periodYear : null
                    this.adjustmentAddEditForm.patchValue(this.getPatchForm(adjustment, billPeriod), { emitEvent: false });
                  });
              } else {
                this.disableInvoiceAdjustedField();
                this.adjustmentAddEditForm.patchValue(this.getPatchForm(adjustment, null), { emitEvent: false });
              }
            });
        });
    } else if (this.adjustmentAddEditFormDirective) {
      this.lookupButtonEnabled = false;
      this.groupAcct = false;
      this.adjustmentTypeLabel = null;
      this.oldBillToValue = null;
      this.adjustmentAddEditFormDirective.resetForm({ active: 'Y' });
    }
  }

  private getPatchForm(adjustment: any, billPeriod: string): any {
    let adjustmentPatch = {};
    if (adjustment) {
      adjustmentPatch = {
        ...adjustment,
        groupAutoId: {
          value: adjustment.groupId,
          label: adjustment.groupName + '-' + adjustment.groupNumber
        },
        invoiceBilledNbr: adjustment.invoiceBilledDTO?.invoiceNumber,
        invoiceAdjAutoId: {
          value: adjustment.invoiceAdjDTO?.id,
          label: adjustment.invoiceAdjDTO?.invoiceNumber
        },
        billPeriod: billPeriod
      }

    }

    return adjustmentPatch;
  }

  private enableInvoiceAdjustedField(): void {
    this.lookupButtonEnabled = true;
    this.adjustmentAddEditForm.controls['invoiceAdjAutoId'].enable();
  }

  private disableInvoiceAdjustedField(): void {
    this.lookupButtonEnabled = false;
    this.adjustmentAddEditForm.controls['invoiceAdjAutoId'].disable();
  }

  private resetInvoiceAdjusted(): void {
    this.adjustmentAddEditForm.patchValue({ invoiceAdjAutoId: null, billPeriod: null }, { emitEvent: false });
  }

  onReset() {
    this.initData();
  }

  onSubmit() {
    if (this.adjustmentAddEditForm.invalid) {
      return;
    }

    const adjustmentForm = this.adjustmentAddEditForm.value;
    if (this.id) {
      adjustmentForm.id = this.id;
    }
    adjustmentForm.groupId = adjustmentForm.groupAutoId ? adjustmentForm.groupAutoId.value : null;
    adjustmentForm.invoiceAdj = adjustmentForm.invoiceAdjAutoId ? adjustmentForm.invoiceAdjAutoId.value : null;

    this.adjustmentService
      .addOrUpdate(adjustmentForm)
      .pipe(untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.adjustmentAddEditForm, error);
        })
      )
      .subscribe(response => {
        const notifyMessage = this.adjustmentService.getNotifyMessage(response);
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')
          (this.action, 'adjustment', notifyMessage ? this.adjustmentTypeLabel + '-' + notifyMessage : this.adjustmentTypeLabel));
        this.adjustmentService.setRefreshSearchGrid(true);
        if (this.action === 'created') {
          this.requestService.navigate(['/financial/adjustment/edit'],
            { state: { data: response } });
        }
        this.onReset();
      });
  }

  lookupInvoice() {
    const formData = this.adjustmentAddEditForm.value;
    const data = {
      groupId: formData.groupAutoId ? formData.groupAutoId.value : null,
      familyId: formData.familyId,
      billableAcctName: formData.groupAutoId ? formData.groupAutoId.label : formData.familyId,
      invoiceAdjusted: {
        invoiceAdj: formData.invoiceAdjAutoId?.value,
        invoiceAdjNbr: formData.invoiceAdjAutoId?.label
      }
    };
    let dialogRef;
    dialogRef = this.dialog.open(InvAdjSelectDialogComponent, {
      minWidth: '50%',
      data: data,
      disableClose: true,
    });

    dialogRef
      .afterClosed()
      .pipe(untilDestroyed(this))
      .subscribe(result => {
        if (result.event === 'selected') {
          this.adjustmentAddEditForm.patchValue(
            { invoiceAdjAutoId: { value: result.data.invoiceAdj, label: result.data.invoiceAdjNbr }, billPeriod: result.data.billPeriod }
            , { emitEvent: false });
        }
      });
  }

  getBilledPeriod(event: any): void {
    const adjustmentForm = this.adjustmentAddEditForm.value;
    if (adjustmentForm.groupAutoId || adjustmentForm.familyId) {
      this.lookupDataService
        .getInvoiceRecordByFamilyOrGroup(
          event.target.value,
          adjustmentForm.groupAutoId ? adjustmentForm.groupAutoId.value : null,
          adjustmentForm.familyId,
          'Y',
          'N')
        .pipe(untilDestroyed(this),
          filter(data => data && data.length === 1 && data[0].premBillingDTO))
        .subscribe(response => {
          this.lookupService
            .getLibListByCategoryAndId(this.configService.get('metadata.constants.categories.month'),
              response[0].premBillingDTO.periodMonth)
            .pipe(untilDestroyed(this))
            .subscribe(liblist => {
              const billPeriod = liblist?.label ? liblist.label + ' ' + response[0].premBillingDTO.periodYear : null
              this.adjustmentAddEditForm.patchValue({ billPeriod: billPeriod }, { emitEvent: false });
            });
        });
    }
  }

  selectionChange(field: string, value: string, label: string, event: MatOptionSelectionChange) {
    if (event.source.selected && value) {
      if (event.isUserInput) {
        if (field === 'adjustmentType') {
          if (this.invoiceAdjTypes.includes(value.toLowerCase())) {
            this.enableInvoiceAdjustedField();
          } else {
            this.resetInvoiceAdjusted();
            this.disableInvoiceAdjustedField();
          }
          this.adjustmentTypeLabel = label;
        } else {
          if (value.toLowerCase() === this.configService.get('financial.constants.screens.adjustments.familyAcct')) {
            this.groupAcct = false;
            this.adjustmentAddEditForm.patchValue({ groupAutoId: null, invoiceAdjAutoId: null, billPeriod: null }, { emitEvent: false });
          } else {
            this.groupAcct = true;
            if (this.oldBillToValue === this.configService.get('financial.constants.screens.adjustments.familyAcct')) {
              this.adjustmentAddEditForm.patchValue({ familyId: null, invoiceAdjAutoId: null, billPeriod: null }, { emitEvent: false });
            }
            this.oldBillToValue = value.toLowerCase();
          }
        }
      }
    }
  }
}
