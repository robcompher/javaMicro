import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdjustmentAddEditComponent } from './adjustment-add-edit.component';

describe('AdjustmentAddEditComponent', () => {
  let component: AdjustmentAddEditComponent;
  let fixture: ComponentFixture<AdjustmentAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AdjustmentAddEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AdjustmentAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
