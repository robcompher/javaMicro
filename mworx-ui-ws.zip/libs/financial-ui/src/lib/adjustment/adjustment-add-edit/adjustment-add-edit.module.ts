import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { RouterModule } from '@angular/router';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiLayoutModule } from '@mworx/layout';
import { AdjustmentAddEditComponent } from './components/adjustment-add-edit.component';

@NgModule({
  declarations: [AdjustmentAddEditComponent],
  imports: [
    CommonModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule,
    RouterModule,
    SharedUiFormsModule,
    SharedUiLayoutModule
  ],
  exports: [AdjustmentAddEditComponent]
})
export class AdjustmentAddEditModule { }
