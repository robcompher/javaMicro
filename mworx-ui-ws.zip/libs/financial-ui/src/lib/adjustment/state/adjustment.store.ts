import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Adjustment } from '../models/adjustment.model';

export interface AdjustmentState extends EntityState<Adjustment> { }

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'adjustment', idKey: 'id' })
export class AdjustmentStore extends EntityStore<AdjustmentState> {

  constructor() {
    super();
  }

}
