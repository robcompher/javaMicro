import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { AdjustmentSearchState, AdjustmentSearchStore } from './adjustment-search.store';

@Injectable({ providedIn: 'root' })
export class AdjustmentSearchQuery extends QueryEntity<AdjustmentSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: AdjustmentSearchStore) {
    super(store);
  }
}
