import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { Invoice } from '../../invoice/models/invoice.model';
import { InvoiceAdjustedSearchCriteria } from '../models/invoice-adjusted-search.model';

export interface InvoiceAdjustedSearchState extends EntityState<Invoice> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'invoiceNumber',
        sortOrder: 'asc',
      },
      groupId: null,
      familyId: null,
      invoiceNumber: null,
      postInd: 'Y',
      onlyZeroBalance: 'N'
    } as InvoiceAdjustedSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'invoice-adjusted-search', idKey: 'id', resettable: true })
export class InvoiceAdjustedSearchStore extends EntityStore<InvoiceAdjustedSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<InvoiceAdjustedSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
