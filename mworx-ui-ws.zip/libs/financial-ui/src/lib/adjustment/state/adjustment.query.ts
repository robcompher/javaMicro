import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { AdjustmentState, AdjustmentStore } from './adjustment.store';

@Injectable({ providedIn: 'root' })
export class AdjustmentQuery extends QueryEntity<AdjustmentState> {
  constructor(protected store: AdjustmentStore) {
    super(store);
  }

  filters$ = this.select(state => state.ui.filters);
  adjustment$ = id => this.selectEntity(id);

}
