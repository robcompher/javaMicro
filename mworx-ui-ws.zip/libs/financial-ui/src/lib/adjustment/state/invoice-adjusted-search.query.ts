import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { InvoiceAdjustedSearchState, InvoiceAdjustedSearchStore } from './invoice-adjusted-search.store';

@Injectable({ providedIn: 'root' })
export class InvoiceAdjustedSearchQuery extends QueryEntity<InvoiceAdjustedSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: InvoiceAdjustedSearchStore) {
    super(store);
  }
}
