import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { AdjustmentSearchCriteria } from '../models/adjustment-search.model';
import { Adjustment } from '../models/adjustment.model';

export interface AdjustmentSearchState extends EntityState<Adjustment> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'created',
        sortOrder: 'desc',
      },
      billTo: null,
      adjustmentType: null,
      groupId: null,
      familyId: null,
      createdFrom: null,
      createdTo: null,
      postInd: '',
      active: 'Y'
    } as AdjustmentSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'adjustment-search', idKey: 'id', resettable: true })
export class AdjustmentSearchStore extends EntityStore<AdjustmentSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<AdjustmentSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
