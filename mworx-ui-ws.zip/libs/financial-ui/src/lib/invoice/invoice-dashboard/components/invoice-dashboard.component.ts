import { Component, OnInit } from '@angular/core';
import { EventService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { filter } from 'rxjs/operators';

@UntilDestroy()
@Component({
  selector: 'financial-invoice-dashboard',
  templateUrl: './invoice-dashboard.component.html',
  styleUrls: ['./invoice-dashboard.component.scss'],
})
export class InvoiceDashboardComponent implements OnInit {
  pageTitle: string;
  backButtonRoute: string;
  
  constructor(private requestService: RequestService, private eventService: EventService) {}

  ngOnInit() {
    this.requestService
      .selectNavigationExtras()
      .pipe(
        untilDestroyed(this),
        filter(res => res != null)
      )
      .subscribe(res => {
        this.backButtonRoute = res.data?.backButtonRoute;
      });
  }

  startEvent(eventName: string) {
    this.eventService.dispatch(eventName, 'invoiceSearchForm');
  }

  onReset($event) {
    if ($event) {
      this.startEvent('onInvoiceReset');
    }
  }

  onSearch($event) {
    if ($event) {
      this.startEvent('onInvoiceSearch');
    }
  }
}
