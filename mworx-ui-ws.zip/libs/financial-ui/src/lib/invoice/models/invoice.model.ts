import { ID } from '@datorama/akita';
import { InvoiceJob } from '../../invoice-job/models/invoice-job.model';

export interface Invoice {
  id: ID;
  billingId: number;
  premBillingDTO: InvoiceJob;
  priorInvoiceId: number;
  periodStart: any;
  periodEnd: any;
  invoiceDue: any;
  invoiceNumber: any;
  enrollmentId: number;
  premiumDetailId: number;
  policyTypeId: number;
  memberPremium: number;
  memberBalance: number;
  premiumB02: number;
  memberPayment: number;
  adjustmentB02: number;
  paymentB02: number;
  balanceB02: number;
  premiumB03: number;
  adjustmentB03: number;
  paymentB03: number;
  balanceB03: number;
  premiumB04: number;
  adjustmentB04: number;
  paymentB04: number;
  adjustmentB05: number;
  premiumB05: number;
  paymentB05: number;
  balanceB05: number;
  created: any;
  createBy: number;
  updated: any;
  updatedBy: number;
}

export function initialEvent(params: Partial<Invoice>) {
  return {
    id: null,
    billingId: null,
    premBillingDTO: null,
    priorInvoiceId: null,
    periodStart: null,
    periodEnd: null,
    invoiceDue: null,
    invoiceNumber: null,
    enrollmentId: null,
    premiumDetailId: null,
    policyTypeId: null,
    memberPremium: null,
    memberBalance: null,
    premiumB02: null,
    memberPayment: null,
    adjustmentB02: null,
    paymentB02: null,
    balanceB02: null,
    premiumB03: null,
    adjustmentB03: null,
    paymentB03: null,
    balanceB03: null,
    premiumB04: null,
    adjustmentB04: null,
    paymentB04: null,
    adjustmentB05: null,
    premiumB05: null,
    paymentB05: null,
    balanceB05: null,
    created: null,
    createBy: null,
    updated: null,
    updatedBy: null,
  } as Invoice;
}
