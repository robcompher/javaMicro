import { SearchCriteria } from '@mworx/grid';

export interface InvoiceSearchCriteria extends SearchCriteria {
  invoiceNumber: string;
  periodMonth: number;
  periodYear: number;
  premiumBilling: string;
}
