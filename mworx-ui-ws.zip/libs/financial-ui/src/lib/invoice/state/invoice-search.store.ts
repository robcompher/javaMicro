import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { InvoiceSearchCriteria } from '../models/invoice-search.model';
import { Invoice } from '../models/invoice.model';

export interface InvoiceSearchState extends EntityState<Invoice> {}

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'created',
        sortOrder: 'desc',
      },
      invoiceNumber: null,
      periodMonth: null,
      periodYear: null,
      premiumBilling: null,
    } as InvoiceSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'invoice-search', idKey: 'id', resettable: true })
export class InvoiceSearchStore extends EntityStore<InvoiceSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<InvoiceSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
