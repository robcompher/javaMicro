import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { InvoiceSearchState, InvoiceSearchStore } from './invoice-search.store';

@Injectable({ providedIn: 'root' })
export class InvoiceSearchQuery extends QueryEntity<InvoiceSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: InvoiceSearchStore) {
    super(store);
  }
}
