import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { PaginationResponse } from '@datorama/akita';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { InvoiceSearchCriteria } from '../models/invoice-search.model';
import { Invoice } from '../models/invoice.model';
import { InvoiceSearchStore } from '../state/invoice-search.store';

@Injectable({
  providedIn: 'root',
})
export class InvoiceService {
  private invoiceSearchStore: InvoiceSearchStore;
  private httpClient: HttpClient;
  private configService: ConfigService;

  constructor() {
    this.invoiceSearchStore = AppInjector.get(InvoiceSearchStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
  }

  public search(): Observable<PaginationResponse<Invoice>> {
    const criteria = { ...this.invoiceSearchStore.getValue().ui.filters };

    return this.httpClient
      .post<PaginationResponse<Invoice>>(this.configService.get('financial.constants.url.getInvoicesBySearchCriteria'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<Invoice>;
        })
      );
  }

  public updateSearchCriteria(criteria: InvoiceSearchCriteria) {
    const prevCriteria = this.invoiceSearchStore.getValue().ui.filters;
    this.invoiceSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }
}
