import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { ConfigService } from '@common/config';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, LookupService } from '@mworx/lookup';
import { AppInjector, EventService, FormatCurrencyPipe, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { filter } from 'rxjs/operators';
import { InvoiceService } from '../../services/invoice.service';
import { InvoiceSearchQuery } from '../../state/invoice-search.query';
import { InvoiceSearchState } from '../../state/invoice-search.store';
import { INVOICE_SEARCH_PAGINATOR } from '../invoice-search-paginator';
@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'financial-invoice-search',
  templateUrl: './invoice-search.component.html',
  styleUrls: ['./invoice-search.component.scss'],
})
export class InvoiceSearchComponent implements OnInit {
  invoiceSearchForm: FormGroup;
  gridApi: GridApi;
  @ViewChild('invoiceSearchDirective')
  invoiceSearchDirective: FormGroupDirective;
  monthValues$: Observable<LibList[]>;
  premiumBilling: string;
  formatCurrencyPipe: FormatCurrencyPipe;

  columnDefs = [
    {
      headerName: 'Invoice Number',
      field: 'invoiceNumber',
    },
    {
      headerName: 'Prem Month',
      field: 'premBillingDTO.periodMonth',
      sortable: false,
      valueGetter: 'category:month',
    },
    {
      headerName: 'Prem Year',
      field: 'premBillingDTO.periodYear',
    },
    {
      headerName: 'Run ID',
      field: 'premBillingDTO.premiumBilling',
    },
    {
      headerName: 'Invoice Amt',
      field: 'memberPremium',
      type: 'currencyColumn',
    },
    {
      headerName: 'Amt Paid',
      field: 'memberPayment',
      type: 'currencyColumn',
    },
    {
      headerName: 'Balance Due',
      field: 'memberBalance',
      type: 'currencyColumn',
    },
    {
      headerName: 'Prem Amt',
      field: 'memberPremium',
      type: 'currencyColumn',
    },
    {
      headerName: 'Adj Amt',
      field: 'memberAdjustment',
      type: 'currencyColumn',
    },
    {
      headerName: 'Actions',
      colId: 'Actions',
      minWidth: 150,
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            title: 'View',
            icon: 'remove_red_eye',
            color: 'primary',
            permissions: ['PERMIT_INVOICE_VIEW'],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
  };

  private fb: FormBuilder;
  private invoiceService: InvoiceService;
  private invoiceSearchQuery: InvoiceSearchQuery;
  private lookupService: LookupService;
  private configService: ConfigService;
  private eventService: EventService;
  private requestService: RequestService;

  constructor(@Inject(INVOICE_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<InvoiceSearchState>) {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.invoiceService = AppInjector.get(InvoiceService);
    this.invoiceSearchQuery = AppInjector.get(InvoiceSearchQuery);
    this.configService = AppInjector.get(ConfigService);
    this.eventService = AppInjector.get(EventService);
    this.requestService = AppInjector.get(RequestService);
  }

  ngOnInit(): void {
    this.formatCurrencyPipe = new FormatCurrencyPipe();
    this.eventService
      .on('onInvoiceSearch')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'invoiceSearchForm')
      )
      .subscribe(res => {
        this.onSearch();
      });

    this.eventService
      .on('onInvoiceReset')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'invoiceSearchForm')
      )
      .subscribe(() => {
        this.onReset();
      });

    this.initForm();
  }

  initForm() {
    this.requestService
      .selectNavigationExtras()
      .pipe(
        untilDestroyed(this),
        filter(res => res != null)
      )
      .subscribe(res => {
        this.premiumBilling = res.data?.premiumBilling;
        if (this.premiumBilling) {
          this.paginatorRef?.clearCache({ clearStore: true });
        }
      });
    this.monthValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.month'));
    this.invoiceSearchForm = this.fb.group({
      periodYear: [],
      periodMonth: [],
      invoiceNumber: [],
      premiumBilling: [],
    });

    this.invoiceSearchForm.patchValue({ premiumBilling: this.premiumBilling });

    this.paginatorRef.requestFunction = () => this.invoiceService.search();

    this.paginatorRef.filtersUpdateFunction = criteria => this.invoiceService.updateSearchCriteria(criteria);
    this.onSearch();
  }

  onSearch() {
    if (this.invoiceSearchForm.invalid) {
      return;
    }

    this.invoiceService.updateSearchCriteria(this.invoiceSearchForm.value);
    if (this.gridApi) {
      this.gridApi.onFilterChanged();
    }
  }
  onReset() {
    this.invoiceSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.invoiceSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }
}
