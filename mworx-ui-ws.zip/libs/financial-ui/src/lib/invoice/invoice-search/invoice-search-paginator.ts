import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { InvoiceSearchQuery } from '../state/invoice-search.query';

export const INVOICE_SEARCH_PAGINATOR = new InjectionToken('INVOICE_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const invoiceSearchQuery = inject(InvoiceSearchQuery);

    return new GridPaginatorPlugin(invoiceSearchQuery);
  },
});
