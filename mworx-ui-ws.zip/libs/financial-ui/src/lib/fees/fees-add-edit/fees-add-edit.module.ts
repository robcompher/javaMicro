import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiLayoutModule } from '@mworx/layout';
import { FeesAddEditComponent } from './components/fees-add-edit.component';

@NgModule({
  declarations: [FeesAddEditComponent],
  imports: [
    CommonModule,
    MatCheckboxModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    ReactiveFormsModule,
    SharedUiFormsModule,
    SharedUiLayoutModule
  ],
  exports: [FeesAddEditComponent]
})
export class FeesAddEditModule { }
