import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeesAddEditComponent } from './fees-add-edit.component';

describe('FeesAddEditComponent', () => {
  let component: FeesAddEditComponent;
  let fixture: ComponentFixture<FeesAddEditComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeesAddEditComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeesAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
