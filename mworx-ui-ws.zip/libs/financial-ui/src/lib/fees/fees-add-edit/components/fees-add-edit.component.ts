import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { ConfigService } from '@common/config';
import { LibList, LookupService } from '@mworx/lookup';
import { AppInjector, ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest, Observable } from 'rxjs';
import { catchError, distinctUntilChanged, filter } from 'rxjs/operators';
import { FeeService } from '../../services/fees.service';
import { FeeQuery } from '../../state/fee.query';

@UntilDestroy()
@Component({
  selector: 'financial-fees-add-edit',
  templateUrl: './fees-add-edit.component.html',
  styleUrls: ['./fees-add-edit.component.scss']
})
export class FeesAddEditComponent implements OnInit {
  feeForm: FormGroup;
  @ViewChild('feeFormDirective')
  feeFormDirective: FormGroupDirective;
  id: number;
  isButtonVisible = true;
  action: string;
  feeLevelValues$: Observable<LibList[]>;

  private fb: FormBuilder;
  private lookupService: LookupService;
  private eventService: EventService;
  private feesService: FeeService;
  private configService: ConfigService;
  private errorService: ErrorService;
  private notifyService: NotificationService;
  private requestService: RequestService;
  private feeQuery: FeeQuery;

  constructor() {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.eventService = AppInjector.get(EventService);
    this.feesService = AppInjector.get(FeeService);
    this.configService = AppInjector.get(ConfigService);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.feeQuery = AppInjector.get(FeeQuery);
    this.requestService = AppInjector.get(RequestService);
  }

  ngOnInit(): void {
    this.createForm();
    this.initEventSubscribers();
    if (this.requestService.url().search('add') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this), filter(r => !!r))
        .subscribe(res => {
          this.id = res.data.id;
          this.feesService
            .getFeeById(this.id)
            .pipe(untilDestroyed(this))
            .subscribe(() => { });
          combineLatest([this.feeQuery.selectLoading(), this.feeQuery.fee$(this.id)]).pipe(untilDestroyed(this)).subscribe(([loading, fee]) => {
            if (!loading && fee) {
              this.feeForm.patchValue(fee, { emitEvent: true });
            }
          });
        });
      if (this.requestService.url().search('view') !== -1) {
        this.isButtonVisible = false;
        Object.keys(this.feeForm.controls).forEach(key => {
          this.feeForm.controls[key].disable();
        });
      } else {
        this.feeForm.controls['feeName'].disable();
      }
      this.action = 'updated';
    } else {
      this.action = 'created';
    }
    if (this.requestService.url().search('view') === -1) {
      this.onChanges();
    }
  }

  initEventSubscribers() {
    this.eventService
      .on('onResetForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'feeEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });
  }

  onReset() {
    if (this.id) {
      this.feeQuery.fee$(this.id).subscribe(u => {
        this.feeFormDirective.resetForm(u);
      });
    } else {
      this.feeFormDirective.resetForm({ active: 'Y' });
    }
  }

  onSubmit() {
    if (this.feeForm.invalid) {
      return;
    }

    const feeForm = this.feeForm.value;
    feeForm.id = this.id;

    this.feesService
      .addOrUpdateFee(feeForm)
      .pipe(untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.feeForm, error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')(this.action, 'Fee', response.feeName));
        this.feesService.setRefreshSearchGrid(true);
        if (!this.id) {
          this.requestService.navigate(['/financial/fees/edit'], { state: { data: response } });
        }
        if (this.action === 'updated') {
          // only need to dispatch if initially edit mode, i.e. not navigated from add mode,
          // because NgOnInit will be called from add mode, but not if already in edit mode.
          this.eventService.dispatch('feesTabs', response);
        }
      });
  }

  onChanges() {
    this.feeForm.get('feeAmount').valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
      .subscribe(() => {
        this.feeForm.controls['feePct'].updateValueAndValidity();
      });
    this.feeForm.get('feePct').valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
      .subscribe(() => {
        this.feeForm.controls['feeAmount'].updateValueAndValidity();
      });
  }

  createForm() {
    this.feeLevelValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.feeLevel'));
    this.feeForm = this.fb.group({
      feeName: [null, Validators.required],
      feeAmount: [],
      feePct: [],
      feeLevel: [null, Validators.required],
      feeDesc: [],
      active: ['Y'],
    });
  }
}
