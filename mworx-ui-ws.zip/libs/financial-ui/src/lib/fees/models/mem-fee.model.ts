import { ID } from '@datorama/akita';

export interface MemFee {
  id: ID;
  preStatusId: number;
  mid: number;
  groupId: number;
  feeId: number;
  memberId: string;
  cycleId: number;
  effDate: any;
  termDate: any;
  active: string;
  firstName: string;
  lastName: string;
  groupName: string;
  cycleName: string;
  lob: {
    lobId: number;
  };
}

export function createMemFee(params: Partial<MemFee>) {
  return {
    id: null,
    preStatusId: null,
    mid: null,
    groupId: null,
    feeId: null,
    memberId: null,
    cycleId: null,
    effDate: null,
    termDate: null,
    active: null,
    firstName: null,
    lastName: null,
    groupName: null,
    cycleName: null,
    lob: {
      lobId: null,
    },
  } as MemFee;
}
