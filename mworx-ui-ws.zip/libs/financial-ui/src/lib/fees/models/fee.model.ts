import { ID } from '@datorama/akita';

export interface Fee {
  id: ID;
  feeName: string;
  feeDesc: string;
  feeAmount: number;
  feePct: number;
  feeLevel: number;
  active: string;
}

export function createFee(params: Partial<Fee>) {
  return {
    id: null,
    feeName: null,
    feeDesc: null,
    feeAmount: null,
    feePct: null,
    feeLevel: null,
    active: 'Y',
  } as Fee;
}
