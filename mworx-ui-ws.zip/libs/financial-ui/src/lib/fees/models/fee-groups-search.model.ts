import { SearchCriteria } from '@mworx/grid';

export interface FeeGroupsSearchCriteria extends SearchCriteria {
  feeId: number;
  active: string;
  groupId: number;
  cycleId: number;
  premiumType: number;
  effDate: any;
  termDate: any;
  effDateOperator: string;
  termDateOperator: string;
}
