import { SearchCriteria } from '@mworx/grid';

export interface FeesSearchCriteria extends SearchCriteria {
  feeName: string;
  feeAmount: number;
  feePct: number;
  feeLevel: number;
  active: string;
}
