import { ID } from '@datorama/akita';

export interface PremiumRate {
  id: ID;
  basicPremium: string;
  description: string;
  effDate: any;
  termDate: any;
  gpbId: number;
  feeId: number;
  cycleId: number;
  groupId: number;
  premiumName: string;
  premiumSort: number;
  premiumType: number;
  premiumTypeName: string;
  productId: number;
  active: string;
}

export function createPremiumRate(params: Partial<PremiumRate>) {
  return {
    id: null,
    basicPremium: null,
    description: null,
    effDate: null,
    termDate: null,
    gpbId: null,
    feeId: null,
    cycleId: null,
    groupId: null,
    premiumName: null,
    premiumSort: 1,
    premiumType: null,
    premiumTypeName: null,
    productId: null,
    active: 'Y'
  } as PremiumRate;
}
