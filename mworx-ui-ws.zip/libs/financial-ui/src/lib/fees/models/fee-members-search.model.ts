import { SearchCriteria } from '@mworx/grid';

export interface FeeMembersSearchCriteria extends SearchCriteria {
  feeId: number;
  active: string;
  groupId: number;
  cycleId: number;
  effDate: any;
  termDate: any;
  effDateOperator: string;
  termDateOperator: string;
  memberId: string;
  firstName: string;
  lastName: string;
}
