import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { GroupSearchQuery } from './state/group-search.query';

export const GROUP_SEARCH_PAGINATOR = new InjectionToken('GROUP_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const groupSearchQuery = inject(GroupSearchQuery);

    return new GridPaginatorPlugin(groupSearchQuery);
  },
});
