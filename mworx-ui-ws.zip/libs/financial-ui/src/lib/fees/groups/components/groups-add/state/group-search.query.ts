import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { GroupSearchState, GroupSearchStore } from './group-search.store';

@Injectable({ providedIn: 'root' })
export class GroupSearchQuery extends QueryEntity<GroupSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: GroupSearchStore) {
    super(store);
  }
}
