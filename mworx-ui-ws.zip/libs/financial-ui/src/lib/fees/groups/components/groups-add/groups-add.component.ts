import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import { ConfigService } from '@common/config';
import { GridPaginatorPlugin } from '@mworx/grid';
import { LibList, ListChoice, LookupService, PeriodCycle } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService, StoresResetService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';
import { Observable, of } from 'rxjs';
import { catchError, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { CommonService } from '../../../services/common.service';
import { GROUP_SEARCH_PAGINATOR } from './group-search-paginator';
import { Group } from './models/group.model';
import { FinancialGroupService } from './services/group.service';
import { GroupSearchQuery } from './state/group-search.query';
import { GroupSearchState } from './state/group-search.store';

@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'financial-groups-add',
  templateUrl: './groups-add.component.html',
  styleUrls: ['./groups-add.component.scss'],
})
export class GroupsAddComponent implements OnInit {
  @ViewChild('stepper', { static: false }) private myStepper: MatStepper;

  premiumTypeValues$: Observable<LibList[]>;
  periodCycles$: Observable<Array<PeriodCycle>>;
  showOnlyArr$: Observable<ListChoice[]>;
  commonFormGroup: FormGroup;
  groupsFormGroup: FormGroup;
  @ViewChild('commonFormGroupDirective')
  commonFormGroupDirective: FormGroupDirective;
  @ViewChild('groupSearchFormDirective')
  groupSearchFormDirective: FormGroupDirective;

  groupsSelected: Group[] = [];

  gridApi: GridApi;
  pageTitle: string;
  amtOrPct: string;
  actualFee: number;
  showSearchButton = false;
  showSaveButton = false;
  callOnSearch = false;
  isSaveButtonEnabled = false;

  MAX_STEP = 2;
  currentStep = 0;

  columnDefs = [
    {
      headerName: 'Select',
      checkboxSelection: true,
      headerCheckboxSelection: true,
      sortable: false,
    },
    { headerName: 'Group', field: 'groupName' },
    { headerName: 'Group Number', field: 'groupNumber' },
    {
      headerName: 'Type',
      valueGetter: (params: ValueGetterParams) => this.getGroupType(params),
      sortable: false,
    },
    {
      headerName: 'Fee Assigned',
      valueGetter: (params: ValueGetterParams) => this.getFeeAssigned(params),
      sortable: false,
    },
  ];

  gridOptions: GridOptions = {
    rowSelection: 'multiple',
    isRowSelectable: function (rowNode) {
      return rowNode.data ? !Array.isArray(rowNode.data.fees) || !rowNode.data.fees.length : false;
    },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
    onRowSelected: event => {
      const index = this.groupsSelected.findIndex(group => group.id === event.node.data.id);
      if (event.node.isSelected() && index === -1) {
        this.groupsSelected.push(event.node.data);
      } else if (!event.node.isSelected() && index !== -1) {
        this.groupsSelected.splice(index, 1);
      }
      this.isSaveButtonEnabled = this.groupsSelected.length > 0;
    },
    onPaginationChanged: () => {
      this.gridApi?.forEachNode(node => (this.groupsSelected.findIndex(group => group.id === node.data.id) !== -1 ? node.setSelected(true) : null));
    },
  };

  private fb: FormBuilder;
  private commonService: CommonService;
  private configService: ConfigService;
  private errorService: ErrorService;
  private financialGroupService: FinancialGroupService;
  private groupSearchQuery: GroupSearchQuery;
  private lookupService: LookupService;
  private notifyService: NotificationService;
  private storeResetService: StoresResetService;
  constructor(
    @Inject(MAT_DIALOG_DATA) public data,
    private dialogRef: MatDialogRef<GroupsAddComponent>,
    @Inject(GROUP_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<GroupSearchState>
  ) {
    this.fb = AppInjector.get(FormBuilder);
    this.commonService = AppInjector.get(CommonService);
    this.configService = AppInjector.get(ConfigService);
    this.errorService = AppInjector.get(ErrorService);
    this.financialGroupService = AppInjector.get(FinancialGroupService);
    this.groupSearchQuery = AppInjector.get(GroupSearchQuery);
    this.lookupService = AppInjector.get(LookupService);
    this.notifyService = AppInjector.get(NotificationService);
    this.storeResetService = AppInjector.get(StoresResetService);
  }

  getGroupType(params: ValueGetterParams) {
    let groupType = '';
    if (params.data) {
      if (params.data.individualBusiness === 'Y') {
        groupType = 'Individual';
      } else {
        groupType = 'Employer';
      }
    }

    return groupType;
  }

  getFeeAssigned(params: ValueGetterParams) {
    let feeAssigned = '';
    if (params.data) {
      if (!Array.isArray(params.data.fees) || !params.data.fees.length) {
        feeAssigned = 'N';
      } else {
        feeAssigned = 'Y';
      }
    }

    return feeAssigned;
  }

  ngOnInit(): void {
    this.initForms();
    this.initFormLists();
    this.initValueChanges();

    this.pageTitle = 'Add Group Fee: ' + this.data.feeName;
    this.amtOrPct = this.data.feeAmountType;
    this.actualFee = this.data.actualFee;

    this.groupSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.groupsFormGroup.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () => this.financialGroupService.search();
    this.paginatorRef.filtersUpdateFunction = criteria =>
      this.financialGroupService.updateSearchCriteria({
        ...criteria,
        ...{ feeId: this.data.feeId, effDate: this.commonFormGroup.get('effDate').value, termDate: this.commonFormGroup.get('termDate').value },
      });
  }

  initForms(): void {
    this.commonFormGroup = this.fb.group({
      periodCycleId: [null, Validators.required],
      effDate: [null, Validators.required],
      termDate: [''],
      description: [''],
      premiumType: [null, Validators.required],
    });
    this.groupsFormGroup = this.fb.group({
      groupName: [''],
      groupNumber: [''],
      includeIndividualBusiness: [''],
    });
  }

  initFormLists(): void {
    this.showOnlyArr$ = this.lookupService.getEmployerTypes();
    this.premiumTypeValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.premiumType'));
    this.periodCycles$ = this.commonFormGroup.get('periodCycleId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getPeriodCycles(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  initValueChanges(): void {
    this.commonFormGroup
      .get('effDate')
      .valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
      .subscribe(() => {
        this.commonFormGroup.controls['termDate'].updateValueAndValidity();
        this.callOnSearch = true;
      });
    this.commonFormGroup
      .get('termDate')
      .valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
      .subscribe(() => {
        this.commonFormGroup.controls['effDate'].updateValueAndValidity();
        this.callOnSearch = true;
      });
  }

  onClose(): void {
    this.closePopup('cancel', null);
  }

  closePopup(event: string, data: any): void {
    this.storeResetService.resetStore('groups-fees-search');
    this.dialogRef.close({ event: event, data: data });
  }

  doAction(event: string, data: any): void {
    this.closePopup(event, data);
  }

  onReset(): void {
    this.resetGroupsFormGroup();
    this.myStepper.reset();
  }

  resetGroupsFormGroup(): void {
    this.groupSearchQuery.initialState$.subscribe(clientQuery => {
      this.groupSearchFormDirective.resetForm(clientQuery);
      this.onSearch();
    });
  }

  onSearch(): void {
    this.groupsSelected = [];
    const clientQuery = this.groupsFormGroup.value;
    // need to send meta findGroupsBySearch "" in groupName at the least
    // to get ALL groups and not just parent groups
    if (clientQuery.groupName == null) {
      clientQuery.groupName = '';
    }
    this.financialGroupService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onSubmit(): void {
    const premiumRateFormRequest = this.commonFormGroup.value;
    premiumRateFormRequest.cycleId = premiumRateFormRequest.periodCycleId?.value;
    premiumRateFormRequest.active = 'Y';
    premiumRateFormRequest.feeId = this.data.feeId;
    // column length in database is set to 10
    premiumRateFormRequest.premiumName = this.data.feeName.substring(0, 10);
    // sort is required in database
    premiumRateFormRequest.premiumSort = 1;
    premiumRateFormRequest.groupIds = this.groupsSelected.map(rec => rec.id);

    this.financialGroupService
      .addMultiplePremiumRates(premiumRateFormRequest)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          if (422 === response.status && this.commonFormGroup != null && response.error.apierror && response.error.apierror.subErrors) {
            let step1errors = false;
            response.error.apierror.subErrors.forEach((element: any) => {
              const fields = element.field.split(',');
              fields.forEach(fld => {
                const control = this.commonFormGroup.get(fld.trim());
                if (control != null) {
                  step1errors = true;
                }
              });
            });
            if (step1errors) {
              this.myStepper.previous();

              return this.errorService.handleValidationErrors(this.commonFormGroup, response);
            }
          }

          return this.errorService.handleTableValidationErrors(response);
        })
      )
      .subscribe(resp => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')('added', 'Groups to Fee', this.data.feeName));
        this.doAction('created', { ...resp });
      });
  }

  onStepChange(event: any): void {
    this.currentStep = event.selectedIndex + 1;
    if (this.currentStep === this.MAX_STEP) {
      this.showSearchButton = true;
      this.showSaveButton = true;
      if (this.callOnSearch) {
        this.onSearch();
        this.callOnSearch = false;
      }
    } else {
      this.showSearchButton = false;
      this.showSaveButton = false;
    }
  }
}
