import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { Group, LibList, ListChoice, LookupService, PeriodCycle } from '@mworx/lookup';
import { AppInjector, ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable, of } from 'rxjs';
import { catchError, filter, switchMap } from 'rxjs/operators';
import { CommonService } from '../../../services/common.service';
import { FeeGroupsService } from '../../../services/fee-groups.service';
import { FeeService } from '../../../services/fees.service';
import { FeeGroupsSearchQuery } from '../../../state/fee-groups-search.query';
import { FeeGroupsSearchState } from '../../../state/fee-groups-search.store';
import { GroupsAddComponent } from '../groups-add/groups-add.component';
import { GroupsEditComponent } from '../groups-edit/groups-edit.component';
import { FEEGROUPS_SEARCH_PAGINATOR } from './fee-groups-search-paginator';

@UntilDestroy()
@Component({
  selector: 'financial-groups-search',
  templateUrl: './groups-search.component.html',
  styleUrls: ['./groups-search.component.scss'],
})
export class GroupsSearchComponent implements OnInit {
  feeGroupsSearchForm: FormGroup;
  gridApi: GridApi;
  feeGroupsActiveValues$: Observable<Array<ListChoice>>;
  operatorsList$: Observable<Array<ListChoice>>;
  premiumTypeValues$: Observable<LibList[]>;
  periodCycles$: Observable<Array<PeriodCycle>>;
  groups$: Observable<Array<Group>>;
  @ViewChild('feeGroupsSearchDirective')
  feeGroupsSearchDirective: FormGroupDirective;
  feeID: number;
  feeName: string;
  feeType: string;
  fee: number;
  viewOnly = false;
  columnDefs = [
    {
      headerName: 'Group',
      field: 'groupName',
      sortable: false,
    },
    {
      headerName: 'Type',
      field: 'premiumTypeName',
      sortable: false,
    },
    { headerName: 'Eff Date', field: 'effDate', type: 'dateColumn' },
    { headerName: 'Term Date', field: 'termDate', type: 'dateColumn' },
    {
      headerName: 'Period Cycle',
      field: 'cycleName',
      sortable: false,
    },
    { headerName: 'Active', field: 'active' },
    {
      headerName: 'Actions',
      colId: 'Actions',
      minWidth: 150,
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onViewActionClick.bind(this),
            title: 'View',
            icon: 'remove_red_eye',
            color: 'primary',
            permissions: ['PERMIT_PREMIUM_RATE_VIEW'],
          },
          {
            onClick: this.onEditActionClick.bind(this),
            title: 'Edit',
            icon: 'edit',
            color: 'primary',
            show: this.showAction.bind(this),
            permissions: ['PERMIT_PREMIUM_RATE_UPDATE'],
          },
          {
            onClick: this.onDeleteActionClick.bind(this),
            title: 'Delete',
            icon: 'delete',
            color: 'warn',
            show: this.showAction.bind(this),
            permissions: ['PERMIT_PREMIUM_RATE_UPDATE'],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;

      if (this.feeGroupsService.isRefreshSearchGrid()) {
        this.gridApi.onFilterChanged();
        this.feeGroupsService.setRefreshSearchGrid(false);
      }
    },
  };

  private fb: FormBuilder;
  private lookupService: LookupService;
  private requestService: RequestService;
  private commonService: CommonService;
  private feeService: FeeService;
  private feeGroupsService: FeeGroupsService;
  private dialog: MatDialog;
  private notificationService: NotificationService;
  private errorService: ErrorService;
  private configService: ConfigService;
  private eventService: EventService;
  private feeGroupsSearchQuery: FeeGroupsSearchQuery;
  constructor(@Inject(FEEGROUPS_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<FeeGroupsSearchState>) {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.requestService = AppInjector.get(RequestService);
    this.commonService = AppInjector.get(CommonService);
    this.feeService = AppInjector.get(FeeService);
    this.feeGroupsService = AppInjector.get(FeeGroupsService);
    this.dialog = AppInjector.get(MatDialog);
    this.notificationService = AppInjector.get(NotificationService);
    this.errorService = AppInjector.get(ErrorService);
    this.configService = AppInjector.get(ConfigService);
    this.eventService = AppInjector.get(EventService);
    this.feeGroupsSearchQuery = AppInjector.get(FeeGroupsSearchQuery);
  }

  ngOnInit(): void {
    this.createForm();
    this.initFormLists();
    this.initEventSubscribers();

    if (this.requestService.url().search('view') !== -1) {
      this.viewOnly = true;
    }

    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.feeID = res.data.id;
        this.feeName = res.data.feeName;
      });

    this.feeService
      .getFeeById(this.feeID)
      .pipe(
        untilDestroyed(this),
        filter(resp => resp !== null)
      )
      .subscribe(response => {
        if (response.feeAmount) {
          this.feeType = 'Amount';
          this.fee = response.feeAmount;
        } else {
          this.feeType = 'Percentage';
          this.fee = response.feePct;
        }
      });

    this.feeGroupsSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.feeGroupsSearchForm.patchValue(criteria);
    });

    this.feeGroupsSearchForm
      .get('termDate')
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(() => {
        this.checkDatesForOperators();
      });

    this.feeGroupsSearchForm
      .get('effDate')
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(() => {
        this.checkDatesForOperators();
      });

    this.paginatorRef.requestFunction = () => this.feeGroupsService.search();
    this.paginatorRef.filtersUpdateFunction = criteria => this.feeGroupsService.updateSearchCriteria({ ...criteria, ...{ feeId: this.feeID } });
  }

  initFormLists() {
    this.feeGroupsActiveValues$ = this.lookupService.getYesNoBoth();
    this.operatorsList$ = this.lookupService.getOperators();
    this.premiumTypeValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.premiumType'));
    this.periodCycles$ = this.feeGroupsSearchForm.get('periodCycleId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getPeriodCycles(searchValue.label);
          }
        }

        return of([]);
      })
    );
    this.groups$ = this.feeGroupsSearchForm.get('groupAutoId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getGroups(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  createForm() {
    this.feeGroupsSearchForm = this.fb.group({
      groupAutoId: [],
      periodCycleId: [],
      premiumType: [],
      active: [],
      effDate: [],
      termDate: [],
      effDateOperator: [],
      termDateOperator: [],
    });
  }

  initEventSubscribers() {
    this.eventService
      .on('onResetForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'feeGroupsEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });

    this.eventService
      .on('onSearchForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'feeGroupsEventForm')
      )
      .subscribe(() => {
        this.onSearch();
      });

    this.eventService
      .on('onAddForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'feeGroupsEventForm')
      )
      .subscribe(() => {
        this.onAdd();
      });
  }

  showAction(action: any, data: any) {
    if (this.viewOnly) {
      return false;
    }
    if (action.title === 'Delete') {
      return data.active !== 'N';
    }

    return true;
  }

  onAdd() {
    this.openDialog(null, null, 'Add');
  }

  onViewActionClick(e: any) {
    this.openDialog(e.rowData.id, e.rowData.groupId, 'View');
  }

  onEditActionClick(e: any) {
    this.openDialog(e.rowData.id, e.rowData.groupId, 'Edit');
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.feeGroupsService
            .deleteByID(e.rowData.id)
            .pipe(
              untilDestroyed(this),
              catchError((error: HttpErrorResponse) => {
                return this.errorService.handleValidationErrors(this.feeGroupsSearchForm, error);
              })
            )
            .subscribe(() => {
              let groupName = '';
              this.lookupService.getGroupById(e.rowData.groupId).subscribe(group => (groupName = group.groupName));
              this.notificationService.showSuccess(this.configService.get('defaultMessages.actionResponse')('deleted', 'Group', groupName));
              this.onReset();
            });
        }
      });
  }

  onSearch() {
    if (this.feeGroupsSearchForm.invalid) {
      return;
    }
    const clientQuery = this.feeGroupsSearchForm.value;
    clientQuery.cycleId = clientQuery.periodCycleId?.value;
    clientQuery.groupId = clientQuery.groupAutoId?.value;
    this.feeGroupsService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset() {
    this.feeGroupsSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.feeGroupsSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }

  openDialog(premiumRateId: number, groupId: number, actionType: string): void {
    const data = {
      id: null,
      feeId: this.feeID,
      actionType: actionType,
      feeName: this.feeName,
      feeAmountType: this.feeType,
      actualFee: this.fee,
      groupName: null,
    };
    let dialogRef;
    if (actionType === 'Add') {
      dialogRef = this.dialog.open(GroupsAddComponent, {
        minWidth: '50%',
        data: data,
        disableClose: true,
      });
    } else {
      let groupName = '';
      this.lookupService
        .getGroupById(groupId)
        .pipe(untilDestroyed(this))
        .subscribe(group => (groupName = group.groupName));
      data.id = premiumRateId;
      data.groupName = groupName;
      dialogRef = this.dialog.open(GroupsEditComponent, {
        minWidth: '50%',
        data: data,
        disableClose: true,
      });
    }

    dialogRef
      .afterClosed()
      .pipe(untilDestroyed(this))
      .subscribe(result => {
        if (result.event !== 'cancel') {
          this.onRefresh();
        }
      });
  }

  onRefresh() {
    this.gridApi.onFilterChanged();
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  checkDatesForOperators() {
    this.enableOperators(true);
    if (this.feeGroupsSearchForm.get('effDate').value !== null && this.feeGroupsSearchForm.get('termDate').value !== null) {
      this.feeGroupsSearchForm.get('effDateOperator').setValue('GREATERTHAN_EQUAL');
      this.feeGroupsSearchForm.get('termDateOperator').setValue('LESSTHAN_EQUAL');
      this.enableOperators(false);
    }
  }

  enableOperators(enable) {
    if (enable) {
      this.feeGroupsSearchForm.controls['effDateOperator'].enable();
      this.feeGroupsSearchForm.controls['termDateOperator'].enable();
    } else {
      this.feeGroupsSearchForm.controls['effDateOperator'].disable();
      this.feeGroupsSearchForm.controls['termDateOperator'].disable();
    }
  }
}
