import { ID } from '@datorama/akita';

export interface Group {
  id: ID;
  groupName: string;
  groupNumber: number;
}

export function createGroup(params: Partial<Group>) {
  return {
    id: null,
    groupName: null,
    groupNumber: null,
  } as Group;
}
