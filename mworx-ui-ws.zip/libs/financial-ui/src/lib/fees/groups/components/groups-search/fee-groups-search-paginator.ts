import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { FeeGroupsSearchQuery } from '../../../state/fee-groups-search.query';

export const FEEGROUPS_SEARCH_PAGINATOR = new InjectionToken('FEEGROUPS_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const feeGroupsSearchQuery = inject(FeeGroupsSearchQuery);

    return new GridPaginatorPlugin(feeGroupsSearchQuery);
  },
});
