import { PremiumRate } from '../../../../models/premium-rate.model';

export interface MultipleGroups extends PremiumRate {
  groupIds: any;
}
