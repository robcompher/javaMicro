import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { LibList, ListChoice, LookupService, PeriodCycle } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { CommonService } from '../../../services/common.service';
import { FeeGroupsService } from '../../../services/fee-groups.service';
import { PremiumRateQuery } from '../../../state/premium-rate.query';

@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'financial-groups-edit',
  templateUrl: './groups-edit.component.html',
  styleUrls: ['./groups-edit.component.scss']
})
export class GroupsEditComponent implements OnInit {
  premiumRateEditForm: FormGroup;
  @ViewChild('premiumRateEditFormDirective')
  premiumRateEditFormDirective: FormGroupDirective;
  premiumTypeValues$: Observable<LibList[]>;
  periodCycles$: Observable<Array<PeriodCycle>>;

  id: ID;
  pageTitle: string;
  amtOrPct: string;
  actualFee: number;
  buttonVisibility: boolean;

  private commonService: CommonService;
  private configService: ConfigService;
  private errorService: ErrorService;
  private fb: FormBuilder;
  private feeGroupsService: FeeGroupsService;
  private lookupService: LookupService;
  private notifyService: NotificationService;
  private premiumRateQuery: PremiumRateQuery;
  constructor(@Inject(MAT_DIALOG_DATA) public data, private dialogRef: MatDialogRef<GroupsEditComponent>) {
    this.commonService = AppInjector.get(CommonService);
    this.configService = AppInjector.get(ConfigService);
    this.errorService = AppInjector.get(ErrorService);
    this.fb = AppInjector.get(FormBuilder);
    this.feeGroupsService = AppInjector.get(FeeGroupsService);
    this.lookupService = AppInjector.get(LookupService);
    this.notifyService = AppInjector.get(NotificationService);
    this.premiumRateQuery = AppInjector.get(PremiumRateQuery);
  }

  ngOnInit(): void {
    this.id = Number(this.data.id);
    this.initForm();
    this.initFormLists();
    this.initFormData();

    this.pageTitle = this.data.actionType + ' Group Fee: ' + this.data.groupName + ' - ' + this.data.feeName;
    this.amtOrPct = this.data.feeAmountType;
    this.actualFee = this.data.actualFee;

    if (this.data.actionType === 'View') {
      this.premiumRateEditForm.disable();
      this.buttonVisibility = false;
    } else {
      this.premiumRateEditForm.enable();
      this.premiumRateEditForm.controls['effDate'].disable();
      this.buttonVisibility = true;
    }
  }

  initForm(): void {
    this.premiumRateEditForm = this.fb.group({
      periodCycleId: [null, Validators.required],
      effDate: [null, Validators.required],
      termDate: [],
      description: [],
      premiumType: [null, Validators.required],
      active: [],
    })
  }

  initFormLists(): void {
    this.premiumTypeValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.premiumType'));
    this.periodCycles$ = this.premiumRateEditForm.get('periodCycleId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getPeriodCycles(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  initFormData(): void {
    this.feeGroupsService.getPremiumRateById(this.id).pipe(untilDestroyed(this)).subscribe(() => { });
    combineLatest([this.premiumRateQuery.selectLoading(), this.premiumRateQuery.premiumRate$(this.id)]).subscribe(([loading, premiumRate]) => {
      if (!loading && premiumRate) {
        this.premiumRateEditForm.patchValue(premiumRate);
        let periodCycleName = '';
        this.lookupService.getPeriodCycleById(premiumRate.cycleId).pipe(untilDestroyed(this)).subscribe(periodCycle => periodCycleName = periodCycle.cycleName);
        this.premiumRateEditForm.patchValue({ periodCycleId: { value: premiumRate.cycleId, label: periodCycleName } });
      }
    });
  }

  onSubmit() {
    if (this.premiumRateEditForm.invalid) {
      return;
    }

    const premiumRateFormRequest = this.premiumRateEditForm.value;
    premiumRateFormRequest.id = this.id;
    premiumRateFormRequest.cycleId = premiumRateFormRequest.periodCycleId?.value;

    this.feeGroupsService
      .addOrUpdatePremiumRate(premiumRateFormRequest)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.premiumRateEditForm, response);
        })
      )
      .subscribe(resp => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')('updated', 'Group Fee', this.data.groupName + '-' + this.data.feeName));
        this.doAction('updated', { ...resp });
      });
  }

  onReset() {
    this.initFormData();
  }

  closePopup(): void {
    this.dialogRef.close({ event: 'cancel' });
  }

  doAction(event: string, data: any): void {
    this.dialogRef.close({ event: event, data: data });
  }

  resetValidations() {
    this.premiumRateEditForm.controls['termDate'].updateValueAndValidity();
    this.premiumRateEditForm.controls['effDate'].updateValueAndValidity();
  }
}
