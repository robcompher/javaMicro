import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { GroupSearchCriteria } from '../models/group-search.model';
import { Group } from '../models/group.model';

export interface GroupSearchState extends EntityState<Group> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'groupName',
        sortOrder: 'asc',
      },
      groupName: null,
      groupNumber: null,
      includeIndividualBusiness: null,
      effDate: null,
      termDate: null,
      feeId: null,
    } as GroupSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'groups-fees-search', idKey: 'id', resettable: true })
export class GroupSearchStore extends EntityStore<GroupSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<GroupSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
