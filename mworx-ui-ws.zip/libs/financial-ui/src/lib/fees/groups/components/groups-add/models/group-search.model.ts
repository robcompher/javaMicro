import { SearchCriteria } from '@mworx/grid';

export interface GroupSearchCriteria extends SearchCriteria {
  groupName: string;
  groupNumber: string;
  includeIndividualBusiness: string;
  effDate: any;
  termDate: any;
  feeId: number;
}
