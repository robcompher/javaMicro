import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { PaginationResponse } from '@datorama/akita';
import { SessionService } from '@mworx/session';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { GroupSearchCriteria } from '../models/group-search.model';
import { Group } from '../models/group.model';
import { MultipleGroups } from '../models/multiple-groups.model';
import { GroupSearchStore } from '../state/group-search.store';

@Injectable({
  providedIn: 'root',
})
export class FinancialGroupService {
  private httpClient: HttpClient;
  private configService: ConfigService;
  private groupSearchStore: GroupSearchStore;
  private sessionService: SessionService;

  constructor() {
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.groupSearchStore = AppInjector.get(GroupSearchStore);
    this.sessionService = AppInjector.get(SessionService);
  }

  public search(): Observable<PaginationResponse<Group>> {
    const lob = this.sessionService.getCurrentUserLob();
    const criteria = { ...this.groupSearchStore.getValue().ui.filters, ...{ lob } };

    return this.httpClient.post<PaginationResponse<Group>>(this.configService.get('financial.constants.url.findGroupsAndAssociatedFees'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<Group>;
      })
    );
  }

  public updateSearchCriteria(criteria: GroupSearchCriteria) {
    const prevCriteria = this.groupSearchStore.getValue().ui.filters;
    this.groupSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public addMultiplePremiumRates(multipleGroupsDTO: MultipleGroups): Observable<any> {
    return this.httpClient.post<MultipleGroups>(this.configService.get('financial.constants.url.multiplePremiumRates'), multipleGroupsDTO);
  }
}
