import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { GroupsAddComponent } from './components/groups-add/groups-add.component';
import { GroupsEditComponent } from './components/groups-edit/groups-edit.component';
import { GroupsSearchComponent } from './components/groups-search/groups-search.component';

@NgModule({
  declarations: [
    GroupsEditComponent,
    GroupsSearchComponent,
    GroupsAddComponent
  ],
  imports: [
    CommonModule,
    SharedUiFormsModule,
    SharedUiGridModule,
    SharedUiLayoutModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSelectModule,
    MatStepperModule,
    MatDatepickerModule,
  ],
  exports: [
    GroupsEditComponent,
    GroupsSearchComponent,
    GroupsAddComponent
  ]
})
export class GroupsModule { }
