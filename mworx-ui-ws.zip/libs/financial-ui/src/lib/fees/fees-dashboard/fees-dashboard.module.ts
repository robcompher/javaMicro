import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { SharedSessionModule } from '@mworx/session';
import { FeesSearchModule } from '../fees-search/fees-search.module';
import { FeesDashboardComponent } from './components/fees-dashboard.component';

@NgModule({
  declarations: [FeesDashboardComponent],
  imports: [
    CommonModule,
    FeesSearchModule,
    MatButtonModule,
    MatIconModule,
    RouterModule,
    SharedUiLayoutModule,
    SharedSessionModule
  ],
  exports: [FeesDashboardComponent]
})
export class FeesDashboardModule { }
