import { Component, OnInit, ViewChild } from '@angular/core';
import { FeesSearchComponent } from '../../fees-search/components/fees-search.component';

@Component({
  selector: 'financial-fees-dashboard',
  templateUrl: './fees-dashboard.component.html',
  styleUrls: ['./fees-dashboard.component.scss']
})
export class FeesDashboardComponent implements OnInit {

  constructor() { }

  @ViewChild('feesSearch')
  private feesSearch: FeesSearchComponent;

  ngOnInit(): void {
  }

  onSearch() {
    this.feesSearch.onSearch();
  }

  onReset() {
    this.feesSearch.onReset();
  }

}
