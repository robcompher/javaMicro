import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, NgZone, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, ListChoice, LookupService } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { FeeService } from '../../services/fees.service';
import { FeesSearchQuery } from '../../state/fees-search.query';
import { FeesSearchState } from '../../state/fees-search.store';
import { FEES_SEARCH_PAGINATOR } from '../fees-search-paginator';

@UntilDestroy()
@Component({
  selector: 'financial-fees-search',
  templateUrl: './fees-search.component.html',
  styleUrls: ['./fees-search.component.scss']
})
export class FeesSearchComponent implements OnInit {
  feesSearchForm: FormGroup;
  gridApi: GridApi;
  feesActiveValues$: Observable<Array<ListChoice>>;
  feeLevelValues$: Observable<LibList[]>;
  @ViewChild('feesSearchDirective')
  feesSearchDirective: FormGroupDirective;
  columnDefs = [
    {
      headerName: 'Fee Name',
      field: 'feeName',
    },
    {
      headerName: 'Description',
      field: 'feeDesc',
    },
    {
      headerName: 'Amount',
      field: 'feeAmount',
      type: 'currencyColumn'
    },
    {
      headerName: 'Percentage',
      field: 'feePct',
      type: 'percentColumn'
    },
    {
      headerName: 'Fee Level',
      field: 'feeLevel',
      valueGetter: 'category:feeLevel',
      sortable: false
    },
    {
      headerName: 'Active',
      field: 'active'
    },
    {
      headerName: 'Actions',
      colId: 'Actions',
      minWidth: 150,
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onViewActionClick.bind(this),
            title: 'View',
            icon: 'remove_red_eye',
            color: 'primary',
            permissions: ['PERMIT_FEE_VIEW'],
          },
          {
            onClick: this.onEditActionClick.bind(this),
            title: 'Edit',
            icon: 'edit',
            color: 'primary',
            permissions: ['PERMIT_FEE_UPDATE'],
          },
          {
            onClick: this.onDeleteActionClick.bind(this),
            title: 'Delete',
            icon: 'delete',
            color: 'warn',
            show: this.showAction.bind(this),
            permissions: ['PERMIT_FEE_UPDATE'],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;

      if (this.feeService.isRefreshSearchGrid()) {
        this.gridApi.onFilterChanged();
        this.feeService.setRefreshSearchGrid(false);
      }
    },
  };

  private fb: FormBuilder;
  private feeService: FeeService;
  private lookupService: LookupService;
  private feesSearchQuery: FeesSearchQuery;
  private dialog: MatDialog;
  private notificationService: NotificationService;
  private errorService: ErrorService;
  private configService: ConfigService;
  private requestService: RequestService;
  constructor(@Inject(FEES_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<FeesSearchState>) {
    this.fb = AppInjector.get(FormBuilder);
    this.feeService = AppInjector.get(FeeService);
    this.lookupService = AppInjector.get(LookupService);
    this.feesSearchQuery = AppInjector.get(FeesSearchQuery);
    this.dialog = AppInjector.get(MatDialog);
    this.notificationService = AppInjector.get(NotificationService);
    this.errorService = AppInjector.get(ErrorService);
    this.configService = AppInjector.get(ConfigService);
    this.requestService = AppInjector.get(RequestService);
  }

  ngOnInit(): void {
    this.initFormLists();
    this.feesSearchForm = this.fb.group({
      feeName: [],
      feeAmount: [],
      feePct: [],
      feeLevel: [],
      active: [],
    });

    this.feesSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.feesSearchForm.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () => this.feeService.search();

    this.paginatorRef.filtersUpdateFunction = criteria => this.feeService.updateSearchCriteria(criteria);
  }

  initFormLists() {
    this.feesActiveValues$ = this.lookupService.getYesNoBoth();
    this.feeLevelValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.feeLevel'));
  }

  showAction(action: any, data: any) {
    return data.active !== 'N';
  }

  onViewActionClick(e: any) {
    const ngZone = AppInjector.get(NgZone);
    ngZone.run(() => {
      this.requestService.navigate(['/financial/fees/view'], { state: { data: e.rowData } });
    });
  }

  onEditActionClick(e: any) {
    const ngZone = AppInjector.get(NgZone);
    ngZone.run(() => {
      this.requestService.navigate(['/financial/fees/edit'], { state: { data: e.rowData } });
    });
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.feeService
            .deleteByID(e.rowData.id)
            .pipe(
              untilDestroyed(this),
              catchError((error: HttpErrorResponse) => {
                return this.errorService.handleTableValidationErrors(error);
              })
            )
            .subscribe(() => {
              this.notificationService.showSuccess(this.configService.get('defaultMessages.actionResponse')('deleted', 'Fee', e.rowData.feeName));
              this.onReset();
            });
        }
      });
  }

  onSearch() {
    if (this.feesSearchForm.invalid) {
      return;
    }
    const clientQuery = this.feesSearchForm.value;
    this.feeService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset() {
    this.feesSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.feesSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }
}
