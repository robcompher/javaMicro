import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { FeesSearchQuery } from '../state/fees-search.query';

export const FEES_SEARCH_PAGINATOR = new InjectionToken('FEES_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const feesSearchQuery = inject(FeesSearchQuery);

    return new GridPaginatorPlugin(feesSearchQuery);
  },
});
