import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { Fee } from '../models/fee.model';
import { FeesSearchCriteria } from '../models/fees-search.model';

export interface FeesSearchState extends EntityState<Fee> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'id',
        sortOrder: 'asc',
      },
      feeName: null,
      feeAmount: null,
      feePct: null,
      feeLevel: null,
      active: 'Y',
    } as FeesSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'fees-search', idKey: 'id', resettable: true })
export class FeesSearchStore extends EntityStore<FeesSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<FeesSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
