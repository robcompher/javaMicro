import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { FeeMembersSearchCriteria } from '../models/fee-members-search.model';
import { MemFee } from '../models/mem-fee.model';

export interface FeeMembersSearchState extends EntityState<MemFee> {}

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: null,
        sortOrder: 'desc',
      },
      feeId: null,
      groupId: null,
      cycleId: null,
      effDate: null,
      termDate: null,
      memberId: null,
      firstName: null,
      lastName: null,
      effDateOperator: 'GREATERTHAN_EQUAL',
      termDateOperator: 'LESSTHAN_EQUAL',
      active: 'Y',
      lob: {
        lobId: null,
      },
    } as FeeMembersSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'feeMembers-search', idKey: 'id', resettable: true })
export class FeeMembersSearchStore extends EntityStore<FeeMembersSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<FeeMembersSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
