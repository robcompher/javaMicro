import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { FeeGroupsSearchCriteria } from '../models/fee-groups-search.model';
import { PremiumRate } from '../models/premium-rate.model';

export interface FeeGroupsSearchState extends EntityState<PremiumRate> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'effDate',
        sortOrder: 'desc',
      },
      feeId: null,
      groupId: null,
      cycleId: null,
      premiumType: null,
      effDate: null,
      termDate: null,
      effDateOperator: 'GREATERTHAN_EQUAL',
      termDateOperator: 'LESSTHAN_EQUAL',
      active: 'Y',
    } as FeeGroupsSearchCriteria,
  },
};

let refreshSearchGrid = false;
@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'feeGroups-search', idKey: 'id', resettable: true })
export class FeeGroupsSearchStore extends EntityStore<FeeGroupsSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<FeeGroupsSearchCriteria> {
    return of(initialState.ui.filters);
  }

  isRefreshSearchGrid(): boolean {
    return refreshSearchGrid;
  }

  setRefreshSearchGrid(value: boolean) {
    refreshSearchGrid = value;
  }
}
