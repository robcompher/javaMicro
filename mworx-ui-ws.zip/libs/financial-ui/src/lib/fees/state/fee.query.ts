import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { FeeState, FeeStore } from './fee.store';

@Injectable({ providedIn: 'root' })
export class FeeQuery extends QueryEntity<FeeState> {
  constructor(protected store: FeeStore) {
    super(store);
  }

  filters$ = this.select(state => state.ui.filters);
  fee$ = id => this.selectEntity(id);
}
