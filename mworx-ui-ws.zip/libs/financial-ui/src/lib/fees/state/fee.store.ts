import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Fee } from '../models/fee.model';

export interface FeeState extends EntityState<Fee> { }

@Injectable({ providedIn: 'root' })
@StoreConfig({
  name: 'fee', idKey: 'id', resettable: true, cache: {
    ttl: 3600000,
  },
})
export class FeeStore extends EntityStore<FeeState> {
  constructor() {
    super();
  }
}
