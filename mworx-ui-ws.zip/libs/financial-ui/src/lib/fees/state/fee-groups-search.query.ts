import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { FeeGroupsSearchState, FeeGroupsSearchStore } from './fee-groups-search.store';

@Injectable({ providedIn: 'root' })
export class FeeGroupsSearchQuery extends QueryEntity<FeeGroupsSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: FeeGroupsSearchStore) {
    super(store);
  }
}
