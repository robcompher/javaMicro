import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { PremiumRate } from '../models/premium-rate.model';

export interface PremiumRateState extends EntityState<PremiumRate> { }

@Injectable({ providedIn: 'root' })
@StoreConfig({
  name: 'premiumRate', idKey: 'id', resettable: true, cache: {
    ttl: 3600000,
  },
})
export class PremiumRateStore extends EntityStore<PremiumRateState> {
  constructor() {
    super();
  }
}
