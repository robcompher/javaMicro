import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { FeesSearchState, FeesSearchStore } from './fees-search.store';

@Injectable({ providedIn: 'root' })
export class FeesSearchQuery extends QueryEntity<FeesSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: FeesSearchStore) {
    super(store);
  }
}
