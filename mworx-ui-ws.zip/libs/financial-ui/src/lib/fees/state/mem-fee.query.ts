import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { MemFeeState, MemFeeStore } from './mem-fee.store';

@Injectable({ providedIn: 'root' })
export class MemFeeQuery extends QueryEntity<MemFeeState> {
  constructor(protected store: MemFeeStore) {
    super(store);
  }

  filters$ = this.select(state => state.ui.filters);
  memFee$ = id => this.selectEntity(id);
}
