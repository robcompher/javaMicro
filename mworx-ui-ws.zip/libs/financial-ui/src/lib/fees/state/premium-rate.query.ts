import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { PremiumRateState, PremiumRateStore } from './premium-rate.store';

@Injectable({ providedIn: 'root' })
export class PremiumRateQuery extends QueryEntity<PremiumRateState> {
  constructor(protected store: PremiumRateStore) {
    super(store);
  }

  filters$ = this.select(state => state.ui.filters);
  premiumRate$ = id => this.selectEntity(id);
}
