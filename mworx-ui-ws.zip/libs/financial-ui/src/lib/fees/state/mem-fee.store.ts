import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { MemFee } from '../models/mem-fee.model';

export interface MemFeeState extends EntityState<MemFee> { }

@Injectable({ providedIn: 'root' })
@StoreConfig({
  name: 'memFee', idKey: 'id', resettable: true, cache: {
    ttl: 3600000,
  },
})
export class MemFeeStore extends EntityStore<MemFeeState> {
  constructor() {
    super();
  }
}
