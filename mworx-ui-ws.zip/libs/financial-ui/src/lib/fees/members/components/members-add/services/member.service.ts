import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { PaginationResponse } from '@datorama/akita';
import { SessionService } from '@mworx/session';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { MemberSearchCriteria } from '../models/member-search.model';
import { Member } from '../models/member.model';
import { MultipleMembers } from '../models/multiple-members.model';
import { MemberSearchStore } from '../state/member-search.store';

@Injectable({
  providedIn: 'root',
})
export class FinancialMemberService {
  private httpClient: HttpClient;
  private configService: ConfigService;
  private memberSearchStore: MemberSearchStore;
  private sessionService: SessionService;

  constructor() {
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.memberSearchStore = AppInjector.get(MemberSearchStore);
    this.sessionService = AppInjector.get(SessionService);
  }

  public search(): Observable<PaginationResponse<Member>> {
    const lob = this.sessionService.getCurrentUserLob();
    const criteria = { ...this.memberSearchStore.getValue().ui.filters, ...{ lob } };

    return this.httpClient.post<PaginationResponse<Member>>(this.configService.get('financial.constants.url.findMembersAndAssociatedFees'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<Member>;
      })
    );
  }

  public updateSearchCriteria(criteria: MemberSearchCriteria) {
    const prevCriteria = this.memberSearchStore.getValue().ui.filters;
    this.memberSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public addMultipleFees(multipleMembersDTO: MultipleMembers): Observable<any> {
    return this.httpClient.post<MultipleMembers>(this.configService.get('financial.constants.url.multipleMemFees'), multipleMembersDTO);
  }
}
