import { Injectable } from '@angular/core';
import { EntityState, EntityStore, StoreConfig } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { MemberSearchCriteria } from '../models/member-search.model';
import { Member } from '../models/member.model';

export interface MemberSearchState extends EntityState<Member> { }

const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: null,
        sortOrder: 'asc',
      },
      lastName: null,
      firstName: null,
      memberId: null,
    } as MemberSearchCriteria,
  },
};

@Injectable({ providedIn: 'root' })
@StoreConfig({ name: 'members-fees-search', idKey: 'memberId', resettable: true })
export class MemberSearchStore extends EntityStore<MemberSearchState> {
  constructor() {
    super(initialState);
  }

  getInitialState(): Observable<MemberSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
