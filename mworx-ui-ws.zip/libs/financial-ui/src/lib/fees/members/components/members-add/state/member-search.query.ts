import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { MemberSearchState, MemberSearchStore } from './member-search.store';

@Injectable({ providedIn: 'root' })
export class MemberSearchQuery extends QueryEntity<MemberSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: MemberSearchStore) {
    super(store);
  }
}
