import { MemFee } from '../../../../models/mem-fee.model';

export interface MultipleMembers extends MemFee {
  members: any;
}
