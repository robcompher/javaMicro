import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { MemberSearchQuery } from './state/member-search.query';

export const MEMBER_SEARCH_PAGINATOR = new InjectionToken('MEMBER_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const memberSearchQuery = inject(MemberSearchQuery);

    return new GridPaginatorPlugin(memberSearchQuery);
  },
});
