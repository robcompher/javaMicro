import { ID } from '@datorama/akita';

export interface Member {
  memberId: ID;
  preStatusId: number;
  mid: number;
  firstName: string;
  lastName: string;
}

export function createMember(params: Partial<Member>) {
  return {
    memberId: null,
    preStatusId: null,
    mid: null,
    firstName: null,
    lastName: null,
  } as Member;
}
