import { SearchCriteria } from '@mworx/grid';

export interface MemberSearchCriteria extends SearchCriteria {
  firstName: string;
  lastName: string;
  memberId: string;
}
