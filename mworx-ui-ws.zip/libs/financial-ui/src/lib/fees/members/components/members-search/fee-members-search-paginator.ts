import { inject, InjectionToken } from '@angular/core';
import { GridPaginatorPlugin } from '@mworx/grid';
import { FeeMembersSearchQuery } from '../../../state/fee-members-search.query';

export const FEEMEMBERS_SEARCH_PAGINATOR = new InjectionToken('FEEMEMBERS_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const feeMembersSearchQuery = inject(FeeMembersSearchQuery);

    return new GridPaginatorPlugin(feeMembersSearchQuery);
  },
});
