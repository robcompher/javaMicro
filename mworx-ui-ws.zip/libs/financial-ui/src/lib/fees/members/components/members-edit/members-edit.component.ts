import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { Group, ListChoice, PeriodCycle } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { combineLatest, Observable, of } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { CommonService } from '../../../services/common.service';
import { FeeMembersService } from '../../../services/fee-members.service';
import { MemFeeQuery } from '../../../state/mem-fee.query';

@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'financial-members-edit',
  templateUrl: './members-edit.component.html',
  styleUrls: ['./members-edit.component.scss']
})
export class MembersEditComponent implements OnInit {
  memFeeEditForm: FormGroup;
  @ViewChild('memFeeEditFormDirective')
  memFeeEditFormDirective: FormGroupDirective;
  periodCycles$: Observable<Array<PeriodCycle>>;
  groups$: Observable<Array<Group>>;

  id: ID;
  pageTitle: string;
  amtOrPct: string;
  actualFee: number;
  buttonVisibility: boolean;

  private commonService: CommonService;
  private configService: ConfigService;
  private errorService: ErrorService;
  private fb: FormBuilder;
  private feeMembersService: FeeMembersService;
  private notifyService: NotificationService;
  private memFeeQuery: MemFeeQuery;
  constructor(@Inject(MAT_DIALOG_DATA) public data, private dialogRef: MatDialogRef<MembersEditComponent>) {
    this.commonService = AppInjector.get(CommonService);
    this.configService = AppInjector.get(ConfigService);
    this.errorService = AppInjector.get(ErrorService);
    this.fb = AppInjector.get(FormBuilder);
    this.feeMembersService = AppInjector.get(FeeMembersService);
    this.notifyService = AppInjector.get(NotificationService);
    this.memFeeQuery = AppInjector.get(MemFeeQuery);
  }

  ngOnInit(): void {
    this.id = Number(this.data.id);
    this.initForm();
    this.initFormLists();
    this.initFormData();

    this.pageTitle = this.data.actionType + ' Member Fee: ' + this.data.memberNameOrId + ' - ' + this.data.feeName;
    this.amtOrPct = this.data.feeAmountType;
    this.actualFee = this.data.actualFee;

    if (this.data.actionType === 'View') {
      this.memFeeEditForm.disable();
      this.buttonVisibility = false;
    } else {
      this.memFeeEditForm.enable();
      this.memFeeEditForm.controls['effDate'].disable();
      this.memFeeEditForm.controls['groupAutoId'].disable();
      this.buttonVisibility = true;
    }
  }

  initForm(): void {
    this.memFeeEditForm = this.fb.group({
      groupAutoId: [null, Validators.required],
      periodCycleId: [null, Validators.required],
      effDate: [null, Validators.required],
      termDate: [],
      active: [],
    })
  }

  initFormLists(): void {
    this.periodCycles$ = this.memFeeEditForm.get('periodCycleId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getPeriodCycles(searchValue.label);
          }
        }

        return of([]);
      })
    );
    this.groups$ = this.memFeeEditForm.get('groupAutoId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getGroups(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  initFormData(): void {
    this.feeMembersService.getMemFeeById(this.id).pipe(untilDestroyed(this)).subscribe(() => { });
    combineLatest([this.memFeeQuery.selectLoading(), this.memFeeQuery.memFee$(this.id)]).subscribe(([loading, memFee]) => {
      if (!loading && memFee) {
        const memFeePatch = {
          ...memFee,
          periodCycleId: {
            value: memFee.cycleId,
            label: memFee.cycleName
          },
          groupAutoId: {
            value: memFee.groupId,
            label: memFee.groupName
          }
        };

        this.memFeeEditForm.patchValue(memFeePatch);
      }
    });
  }

  onSubmit() {
    if (this.memFeeEditForm.invalid) {
      return;
    }

    const memFeeFormRequest = this.memFeeEditForm.value;
    memFeeFormRequest.id = this.id;
    memFeeFormRequest.cycleId = memFeeFormRequest.periodCycleId?.value;

    this.feeMembersService
      .addOrUpdateMemFee(memFeeFormRequest)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.memFeeEditForm, response);
        })
      )
      .subscribe(resp => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')('updated', 'Fee for Member', this.data.memberNameOrId));
        this.doAction('updated', { ...resp });
      });
  }

  onReset() {
    this.initFormData();
  }

  closePopup(): void {
    this.dialogRef.close({ event: 'cancel' });
  }

  doAction(event: string, data: any): void {
    this.dialogRef.close({ event: event, data: data });
  }

  resetValidations() {
    this.memFeeEditForm.controls['termDate'].updateValueAndValidity();
    this.memFeeEditForm.controls['effDate'].updateValueAndValidity();
  }
}
