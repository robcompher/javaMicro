import { HttpErrorResponse } from '@angular/common/http';
import { AfterViewInit, Component, ElementRef, Inject, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { MatStepper } from '@angular/material/stepper';
import { ConfigService } from '@common/config';
import { GridPaginatorPlugin } from '@mworx/grid';
import { Group, ListChoice, LookupService, PeriodCycle } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent, ValueGetterParams } from 'ag-grid-community';
import { Observable, of } from 'rxjs';
import { catchError, switchMap } from 'rxjs/operators';
import { CommonService } from '../../../services/common.service';
import { MEMBER_SEARCH_PAGINATOR } from './member-search-paginator';
import { Member } from './models/member.model';
import { FinancialMemberService } from './services/member.service';
import { MemberSearchQuery } from './state/member-search.query';
import { MemberSearchState } from './state/member-search.store';

@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'financial-members-add',
  templateUrl: './members-add.component.html',
  styleUrls: ['./members-add.component.scss'],
})
export class MembersAddComponent implements OnInit, AfterViewInit, OnDestroy {
  @ViewChild('stepper', { static: false }) private myStepper: MatStepper;

  periodCycles$: Observable<Array<PeriodCycle>>;
  groups$: Observable<Array<Group>>;
  commonFormGroup: FormGroup;
  membersFormGroup: FormGroup;
  @ViewChild('commonFormGroupDirective')
  commonFormGroupDirective: FormGroupDirective;
  @ViewChild('memberSearchFormDirective')
  memberSearchFormDirective: FormGroupDirective;

  gridApi: GridApi;
  pageTitle: string;
  amtOrPct: string;
  actualFee: number;
  showSearchButton = false;
  showSaveButton = false;
  callOnSearch = false;
  isSaveButtonEnabled = false;
  memberInfo: Member[] = [];

  MAX_STEP = 2;
  currentStep = 0;

  columnDefs = [
    {
      headerName: 'Select',
      checkboxSelection: true,
      sortable: false,
    },
    { headerName: 'Member ID', field: 'memberId' },
    { headerName: 'First Name', field: 'firstName' },
    { headerName: 'Last Name', field: 'lastName' },
    {
      headerName: 'Fee Assigned',
      valueGetter: (params: ValueGetterParams) => this.getFeeAssigned(params),
      sortable: false,
    },
  ];

  gridOptions: GridOptions = {
    rowSelection: 'multiple',
    isRowSelectable: function (rowNode) {
      return rowNode.data ? !Array.isArray(rowNode.data.memFees) || !rowNode.data.memFees.length : false;
    },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
    onRowSelected: event => {
      const index = this.memberInfo.findIndex(x => x.memberId === event.node.data.memberId);
      if (event.node.isSelected()) {
        if (index === -1) {
          this.memberInfo.push(event.node.data);
        }
      } else {
        if (index !== -1) {
          this.memberInfo.splice(index, 1);
        }
      }
    },
    onSelectionChanged: () => {
      if (this.memberInfo.length > 0) {
        this.isSaveButtonEnabled = true;
      } else {
        this.isSaveButtonEnabled = false;
      }
    },
    onPaginationChanged: () => {
      this.gridApi?.forEachNode(node => (this.memberInfo.findIndex(x => x.memberId === node.data.memberId) !== -1 ? node.setSelected(true) : null));
    },
  };

  private fb: FormBuilder;
  private commonService: CommonService;
  private configService: ConfigService;
  private errorService: ErrorService;
  private financialMemberService: FinancialMemberService;
  private memberSearchQuery: MemberSearchQuery;
  private notifyService: NotificationService;
  private lookupService: LookupService;
  constructor(
    private elementRef: ElementRef,
    @Inject(MAT_DIALOG_DATA) public data,
    private dialogRef: MatDialogRef<MembersAddComponent>,
    @Inject(MEMBER_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<MemberSearchState>
  ) {
    this.fb = AppInjector.get(FormBuilder);
    this.commonService = AppInjector.get(CommonService);
    this.configService = AppInjector.get(ConfigService);
    this.errorService = AppInjector.get(ErrorService);
    this.financialMemberService = AppInjector.get(FinancialMemberService);
    this.memberSearchQuery = AppInjector.get(MemberSearchQuery);
    this.notifyService = AppInjector.get(NotificationService);
    this.lookupService = AppInjector.get(LookupService);
  }

  getFeeAssigned(params: ValueGetterParams) {
    let feeAssigned = '';
    if (params.data) {
      if (!Array.isArray(params.data.memFees) || !params.data.memFees.length) {
        feeAssigned = 'N';
      } else {
        feeAssigned = 'Y';
      }
    }

    return feeAssigned;
  }

  ngOnInit(): void {
    this.initForms();
    this.initFormLists();
    this.initValueChanges();

    this.pageTitle = 'Add Member Fee: ' + this.data.feeName;
    this.amtOrPct = this.data.feeAmountType;
    this.actualFee = this.data.actualFee;

    this.memberSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.membersFormGroup.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () => this.financialMemberService.search();
    this.paginatorRef.filtersUpdateFunction = criteria =>
      this.financialMemberService.updateSearchCriteria({
        ...criteria,
        ...{
          feeId: this.data.feeId,
          effDate: this.commonFormGroup.get('effDate').value,
          termDate: this.commonFormGroup.get('termDate').value,
          groupId: this.commonFormGroup.get('groupAutoId').value !== null ? this.commonFormGroup.get('groupAutoId').value.value : 1,
        },
      });
  }

  ngAfterViewInit() {
    //To trigger validation error on header click
    this.elementRef.nativeElement.querySelectorAll('mat-step-header').forEach(item => {
      item.addEventListener('click', () => this.onNext());
    });
  }

  ngOnDestroy() {
    this.paginatorRef.destroy({ clearCache: true, currentPage: 1 });
    this.memberSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => this.financialMemberService.updateSearchCriteria(criteria));
  }

  initForms(): void {
    this.commonFormGroup = this.fb.group({
      groupAutoId: [null, Validators.required],
      periodCycleId: [null, Validators.required],
      effDate: [null, Validators.required],
      termDate: [''],
    });
    this.membersFormGroup = this.fb.group({
      firstName: [''],
      lastName: [''],
      memberId: [''],
    });
  }

  initFormLists(): void {
    this.periodCycles$ = this.commonFormGroup.get('periodCycleId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getPeriodCycles(searchValue.label);
          }
        }

        return of([]);
      })
    );
    this.groups$ = this.commonFormGroup.get('groupAutoId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getGroups(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  setCallSearchAndUpdateValidity(): void {
    this.commonFormGroup.controls['termDate'].updateValueAndValidity();
    this.commonFormGroup.controls['effDate'].updateValueAndValidity();
    this.callOnSearch = true;
  }

  initValueChanges(): void {
    this.commonFormGroup
      .get('groupAutoId')
      .valueChanges.pipe(untilDestroyed(this))
      .subscribe(() => {
        this.callOnSearch = true;
      });
  }

  onClose(): void {
    this.closePopup('cancel', null);
  }

  closePopup(event: string, data: any): void {
    this.dialogRef.close({ event: event, data: data });
  }

  doAction(event: string, data: any): void {
    this.closePopup(event, data);
  }

  onReset(): void {
    this.resetMembersFormGroup();
    this.myStepper.reset();
  }

  resetMembersFormGroup(): void {
    this.memberSearchQuery.initialState$.subscribe(clientQuery => {
      this.memberSearchFormDirective.resetForm(clientQuery);
      this.onSearch();
    });
  }

  onSearch(): void {
    this.memberInfo = [];
    const clientQuery = this.membersFormGroup.value;
    this.financialMemberService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onSubmit(): void {
    const memberFeeFormRequest = this.commonFormGroup.value;
    memberFeeFormRequest.cycleId = memberFeeFormRequest.periodCycleId?.value;
    memberFeeFormRequest.groupId = memberFeeFormRequest.groupAutoId?.value;
    memberFeeFormRequest.active = 'Y';
    memberFeeFormRequest.feeId = this.data.feeId;
    memberFeeFormRequest.members = this.getMembers();
    memberFeeFormRequest.lob = this.lookupService.getCurrentUserLob();

    this.financialMemberService
      .addMultipleFees(memberFeeFormRequest)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          if (422 === response.status && this.commonFormGroup != null && response.error.apierror && response.error.apierror.subErrors) {
            let step1errors = false;
            response.error.apierror.subErrors.forEach((element: any) => {
              const fields = element.field.split(',');
              fields.forEach(fld => {
                const control = this.commonFormGroup.get(fld.trim());
                if (control != null) {
                  step1errors = true;
                }
              });
            });
            if (step1errors) {
              this.myStepper.previous();

              return this.errorService.handleValidationErrors(this.commonFormGroup, response);
            }
          }

          return this.errorService.handleTableValidationErrors(response);
        })
      )
      .subscribe(resp => {
        this.notifyService.showSuccess(this.configService.get('defaultMessages.actionResponse')('added', 'Members to Fee', this.data.feeName));
        this.doAction('created', { ...resp });
      });
  }

  private getMembers() {
    const members = this.memberInfo.map(rec => {
      const member = {
        preStatusId: rec.preStatusId,
        mid: rec.mid,
        memberId: rec.memberId,
      };

      return member;
    });

    return members;
  }

  onStepChange(event: any): void {
    this.currentStep = event.selectedIndex + 1;
    if (this.currentStep === this.MAX_STEP) {
      this.showSearchButton = true;
      this.showSaveButton = true;
      if (this.callOnSearch) {
        this.onSearch();
        this.callOnSearch = false;
      }
    } else {
      this.showSearchButton = false;
      this.showSaveButton = false;
    }
  }

  onNext() {
    this.commonFormGroup.controls['periodCycleId'].updateValueAndValidity();
  }
}
