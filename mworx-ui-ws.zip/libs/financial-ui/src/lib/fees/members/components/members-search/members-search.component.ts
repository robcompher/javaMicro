import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { Group, ListChoice, LookupService, PeriodCycle } from '@mworx/lookup';
import { AppInjector, ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable, of } from 'rxjs';
import { catchError, distinctUntilChanged, filter, switchMap } from 'rxjs/operators';
import { CommonService } from '../../../services/common.service';
import { FeeMembersService } from '../../../services/fee-members.service';
import { FeeService } from '../../../services/fees.service';
import { FeeMembersSearchQuery } from '../../../state/fee-members-search.query';
import { FeeMembersSearchState } from '../../../state/fee-members-search.store';
import { MembersAddComponent } from '../members-add/members-add.component';
import { MembersEditComponent } from '../members-edit/members-edit.component';
import { FEEMEMBERS_SEARCH_PAGINATOR } from './fee-members-search-paginator';

@UntilDestroy()
@Component({
  selector: 'financial-members-search',
  templateUrl: './members-search.component.html',
  styleUrls: ['./members-search.component.scss'],
})
export class MembersSearchComponent implements OnInit {
  feeMembersSearchForm: FormGroup;
  gridApi: GridApi;
  feeMembersActiveValues$: Observable<Array<ListChoice>>;
  periodCycles$: Observable<Array<PeriodCycle>>;
  groups$: Observable<Array<Group>>;
  @ViewChild('feeMembersSearchDirective')
  feeMembersSearchDirective: FormGroupDirective;
  feeID: number;
  feeName: string;
  feeType: string;
  fee: number;
  viewOnly = false;
  columnDefs = [
    { headerName: 'Group', field: 'groupName', sortable: false },
    { headerName: 'Member ID', field: 'memberId' },
    { headerName: 'First Name', field: 'firstName', sortable: false },
    { headerName: 'Last Name', field: 'lastName', sortable: false },
    { headerName: 'Eff Date', field: 'effDate', type: 'dateColumn' },
    { headerName: 'Term Date', field: 'termDate', type: 'dateColumn' },
    { headerName: 'Period Cycle', field: 'cycleName', sortable: false },
    { headerName: 'Active', field: 'active' },
    {
      headerName: 'Actions',
      colId: 'Actions',
      minWidth: 150,
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onViewActionClick.bind(this),
            title: 'View',
            icon: 'remove_red_eye',
            color: 'primary',
            permissions: ['PERMIT_FEE_VIEW'],
          },
          {
            onClick: this.onEditActionClick.bind(this),
            title: 'Edit',
            icon: 'edit',
            color: 'primary',
            show: this.showAction.bind(this),
            permissions: ['PERMIT_FEE_UPDATE'],
          },
          {
            onClick: this.onDeleteActionClick.bind(this),
            title: 'Delete',
            icon: 'delete',
            color: 'warn',
            show: this.showAction.bind(this),
            permissions: ['PERMIT_FEE_UPDATE'],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;

      if (this.feeMembersService.isRefreshSearchGrid()) {
        this.gridApi.onFilterChanged();
        this.feeMembersService.setRefreshSearchGrid(false);
      }
    },
  };

  private fb: FormBuilder;
  private lookupService: LookupService;
  private requestService: RequestService;
  private commonService: CommonService;
  private feeService: FeeService;
  private feeMembersService: FeeMembersService;
  private dialog: MatDialog;
  private notificationService: NotificationService;
  private errorService: ErrorService;
  private configService: ConfigService;
  private eventService: EventService;
  private feeMembersSearchQuery: FeeMembersSearchQuery;
  constructor(@Inject(FEEMEMBERS_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<FeeMembersSearchState>) {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.requestService = AppInjector.get(RequestService);
    this.commonService = AppInjector.get(CommonService);
    this.feeService = AppInjector.get(FeeService);
    this.feeMembersService = AppInjector.get(FeeMembersService);
    this.dialog = AppInjector.get(MatDialog);
    this.notificationService = AppInjector.get(NotificationService);
    this.errorService = AppInjector.get(ErrorService);
    this.configService = AppInjector.get(ConfigService);
    this.eventService = AppInjector.get(EventService);
    this.feeMembersSearchQuery = AppInjector.get(FeeMembersSearchQuery);
  }

  ngOnInit(): void {
    this.createForm();
    this.initFormLists();
    this.onChanges();
    this.initEventSubscribers();

    if (this.requestService.url().search('view') !== -1) {
      this.viewOnly = true;
    }

    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.feeID = res.data.id;
        this.feeName = res.data.feeName;
      });

    this.feeService
      .getFeeById(this.feeID)
      .pipe(
        untilDestroyed(this),
        filter(resp => resp !== null)
      )
      .subscribe(response => {
        if (response.feeAmount) {
          this.feeType = 'Amount';
          this.fee = response.feeAmount;
        } else {
          this.feeType = 'Percentage';
          this.fee = response.feePct;
        }
      });

    this.feeMembersSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.feeMembersSearchForm.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () =>
      this.feeMembersService.search().pipe(
        untilDestroyed(this),
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.feeMembersSearchForm, error);
        })
      );
    this.paginatorRef.filtersUpdateFunction = criteria =>
      this.feeMembersService.updateSearchCriteria({ ...criteria, ...{ feeId: this.feeID }, ...{ lob: this.lookupService.getCurrentUserLob() } });
  }

  initFormLists() {
    this.feeMembersActiveValues$ = this.lookupService.getYesNoBoth();
    this.periodCycles$ = this.feeMembersSearchForm.get('periodCycleId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getPeriodCycles(searchValue.label);
          }
        }

        return of([]);
      })
    );
    this.groups$ = this.feeMembersSearchForm.get('groupAutoId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.commonService.getGroups(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  onChanges() {
    this.feeMembersSearchForm
      .get('firstName')
      .valueChanges.pipe(distinctUntilChanged(), untilDestroyed(this))
      .subscribe(() => this.feeMembersSearchForm.controls['lastName'].updateValueAndValidity());
  }

  createForm() {
    this.feeMembersSearchForm = this.fb.group({
      groupAutoId: [],
      periodCycleId: [],
      active: [],
      effDate: [],
      termDate: [],
      effDateOperator: [],
      termDateOperator: [],
      memberId: [],
      firstName: [],
      lastName: [],
    });
  }

  initEventSubscribers() {
    this.eventService
      .on('onResetForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'feeMembersEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });

    this.eventService
      .on('onSearchForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'feeMembersEventForm')
      )
      .subscribe(() => {
        this.onSearch();
      });

    this.eventService
      .on('onAddForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'feeMembersEventForm')
      )
      .subscribe(() => {
        this.onAdd();
      });
  }

  showAction(action: any, data: any) {
    if (this.viewOnly) {
      return false;
    }
    if (action.title === 'Delete') {
      return data.active !== 'N';
    }

    return true;
  }

  onAdd() {
    this.openDialog(null, 'Add');
  }

  onViewActionClick(e: any) {
    this.openDialog(e.rowData, 'View');
  }

  onEditActionClick(e: any) {
    this.openDialog(e.rowData, 'Edit');
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.feeMembersService
            .deleteByID(e.rowData.id)
            .pipe(
              untilDestroyed(this),
              catchError((error: HttpErrorResponse) => {
                return this.errorService.handleValidationErrors(this.feeMembersSearchForm, error);
              })
            )
            .subscribe(() => {
              this.notificationService.showSuccess(
                this.configService.get('defaultMessages.actionResponse')('deleted', 'Fee for Member', this.getMemberNameOrId(e.rowData))
              );
              this.onReset();
            });
        }
      });
  }

  onSearch() {
    const clientQuery = this.feeMembersSearchForm.value;
    clientQuery.cycleId = clientQuery.periodCycleId?.value;
    clientQuery.groupId = clientQuery.groupAutoId?.value;
    clientQuery.lob = this.lookupService.getCurrentUserLob();
    this.feeMembersService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset() {
    this.feeMembersSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.feeMembersSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }

  openDialog(rowData: any, actionType: string): void {
    const data = {
      id: null,
      feeId: this.feeID,
      actionType: actionType,
      feeName: this.feeName,
      feeAmountType: this.feeType,
      actualFee: this.fee,
      memberNameOrId: null,
    };
    let dialogRef;
    if (actionType === 'Add') {
      dialogRef = this.dialog.open(MembersAddComponent, {
        minWidth: '50%',
        data: data,
        disableClose: true,
      });
    } else {
      data.id = rowData.id;
      data.memberNameOrId = this.getMemberNameOrId(rowData);
      dialogRef = this.dialog.open(MembersEditComponent, {
        minWidth: '50%',
        data: data,
        disableClose: true,
      });
    }

    dialogRef
      .afterClosed()
      .pipe(untilDestroyed(this))
      .subscribe(result => {
        if (result.event !== 'cancel') {
          this.onRefresh();
        }
      });
  }

  onRefresh() {
    this.gridApi.onFilterChanged();
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }

  checkDatesForOperators() {
    this.enableOperators(true);
    if (this.feeMembersSearchForm.get('effDate').value !== null && this.feeMembersSearchForm.get('termDate').value !== null) {
      this.feeMembersSearchForm.get('effDateOperator').setValue('GREATERTHAN_EQUAL');
      this.feeMembersSearchForm.get('termDateOperator').setValue('LESSTHAN_EQUAL');
      this.enableOperators(false);
    }
  }

  enableOperators(enable) {
    if (enable) {
      this.feeMembersSearchForm.controls['effDateOperator'].enable();
      this.feeMembersSearchForm.controls['termDateOperator'].enable();
    } else {
      this.feeMembersSearchForm.controls['effDateOperator'].disable();
      this.feeMembersSearchForm.controls['termDateOperator'].disable();
    }
  }

  private getMemberNameOrId(rowData: any): string {
    let memberNameOrId = '';
    if (rowData.lastName !== null && rowData.firstName !== null) {
      memberNameOrId = rowData.lastName + ', ' + rowData.firstName;
    } else {
      memberNameOrId = rowData.memberId;
    }

    return memberNameOrId;
  }
}
