import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatButtonModule } from '@angular/material/button';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatStepperModule } from '@angular/material/stepper';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { MembersAddComponent } from './components/members-add/members-add.component';
import { MembersEditComponent } from './components/members-edit/members-edit.component';
import { MembersSearchComponent } from './components/members-search/members-search.component';

@NgModule({
  declarations: [MembersSearchComponent, MembersAddComponent, MembersEditComponent],
  imports: [
    CommonModule,
    SharedUiFormsModule,
    SharedUiGridModule,
    SharedUiLayoutModule,
    ReactiveFormsModule,
    MatFormFieldModule,
    MatIconModule,
    MatButtonModule,
    MatAutocompleteModule,
    MatInputModule,
    MatSelectModule,
    MatStepperModule,
    MatDatepickerModule,
  ],
  exports: [MembersSearchComponent, MembersAddComponent, MembersEditComponent]
})
export class MembersModule { }
