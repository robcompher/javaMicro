import { Injectable } from '@angular/core';
import { Group, ListChoice, LookupDataService, LookupService, PeriodCycle } from '@mworx/lookup';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { filter, flatMap, map, toArray } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class CommonService {
  private lookupService: LookupService;
  private lookUpDataService: LookupDataService;

  constructor() {
    this.lookupService = AppInjector.get(LookupService);
    this.lookUpDataService = AppInjector.get(LookupDataService);
  }

  getPeriodCycles(periodCycleName: string, periodCycleId?: number): Observable<Array<ListChoice>> {
    return this.lookUpDataService.getPeriodCycles(periodCycleName, periodCycleId).pipe(
      filter(data => data && data.length > 0),
      flatMap((items: PeriodCycle[]) => items),
      map((item: any) => {
        return {
          value: item.id,
          label: item.cycleName,
        } as ListChoice;
      }),
      toArray()
    );
  }

  getGroups(groupName: string, groupId?: number): Observable<Array<ListChoice>> {
    const lob = this.lookupService.getCurrentUserLob();

    return this.lookUpDataService.getGroupByName(groupName, lob.lobId, groupId).pipe(
      filter(data => data && data.length > 0),
      flatMap((items: Group[]) => items),
      map((item: any) => {
        return {
          value: item.id,
          label: item.groupName,
        } as ListChoice;
      }),
      toArray()
    );
  }
}
