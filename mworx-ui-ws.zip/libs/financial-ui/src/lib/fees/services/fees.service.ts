import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse, withTransaction } from '@datorama/akita';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { Fee } from '../models/fee.model';
import { FeesSearchCriteria } from '../models/fees-search.model';
import { FeeQuery } from '../state/fee.query';
import { FeeStore } from '../state/fee.store';
import { FeesSearchStore } from '../state/fees-search.store';

@Injectable({
  providedIn: 'root',
})
export class FeeService {
  private feesSearchStore: FeesSearchStore;
  private httpClient: HttpClient;
  private configService: ConfigService;
  private feeStore: FeeStore;
  private feeQuery: FeeQuery;

  constructor() {
    this.feesSearchStore = AppInjector.get(FeesSearchStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.feeStore = AppInjector.get(FeeStore);
    this.feeQuery = AppInjector.get(FeeQuery);
  }

  public search(): Observable<PaginationResponse<Fee>> {
    const criteria = this.feesSearchStore.getValue().ui.filters;

    return this.httpClient.post<PaginationResponse<Fee>>(this.configService.get('financial.constants.url.findFeeBySearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<Fee>;
      })
    );
  }

  public updateSearchCriteria(criteria: FeesSearchCriteria) {
    const prevCriteria = this.feesSearchStore.getValue().ui.filters;
    this.feesSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public getFeeById(id: ID): Observable<Fee> {
    return this.feeQuery.selectEntity(id).pipe(
      switchMap(cacheEntry => {
        const apiCall = this.httpClient
          .post<any>(this.configService.get('financial.constants.url.getFeeById'), { id: id })
          .pipe(
            withTransaction(response => {
              if (response) {
                this.feeStore.upsert(id, response);
                this.feeStore.setHasCache(true);
              }
            }),
            switchMap(res => this.feeQuery.selectEntity(id))
          );

        return cacheEntry ? this.feeQuery.selectEntity(id) : apiCall;
      })
    );
  }

  public addOrUpdateFee(feeDTO: Fee): Observable<any> {
    if (this.feeQuery.hasEntity(feeDTO.id) && Boolean(feeDTO.id)) {
      return this.httpClient.put<Fee>(this.configService.get('financial.constants.url.addOrUpdateFee'), { ...this.feeQuery.getEntity(feeDTO.id), ...feeDTO }).pipe(
        tap(currentFee => {
          this.feeStore.upsert(currentFee.id, currentFee);
          this.feesSearchStore.upsert(currentFee.id, currentFee);
        })
      );
    } else {
      return this.httpClient.post<Fee>(this.configService.get('financial.constants.url.addOrUpdateFee'), feeDTO).pipe(
        tap(currentFee => {
          this.feeStore.upsert(currentFee.id, currentFee);
          this.feesSearchStore.upsert(currentFee.id, currentFee);
        })
      );
    }
  }

  public deleteByID(id: ID): Observable<any> {
    return this.httpClient
      .put<any>(this.configService.get('financial.constants.url.deleteFee'), { id: id })
      .pipe(
        tap(resp => {
          this.feesSearchStore.remove(id);
          this.feeStore.remove(id);
        })
      );
  }

  isRefreshSearchGrid(): boolean {
    return this.feesSearchStore.isRefreshSearchGrid();
  }

  setRefreshSearchGrid(value: boolean) {
    this.feesSearchStore.setRefreshSearchGrid(value);
  }
}
