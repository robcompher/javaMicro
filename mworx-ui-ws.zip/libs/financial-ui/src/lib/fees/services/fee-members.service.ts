import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse, withTransaction } from '@datorama/akita';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { FeeMembersSearchCriteria } from '../models/fee-members-search.model';
import { MemFee } from '../models/mem-fee.model';
import { FeeMembersSearchStore } from '../state/fee-members-search.store';
import { MemFeeQuery } from '../state/mem-fee.query';
import { MemFeeStore } from '../state/mem-fee.store';

@Injectable({
  providedIn: 'root',
})
export class FeeMembersService {
  private feeMembersSearchStore: FeeMembersSearchStore;
  private httpClient: HttpClient;
  private configService: ConfigService;
  private memFeeStore: MemFeeStore;
  private memFeeQuery: MemFeeQuery;

  constructor() {
    this.feeMembersSearchStore = AppInjector.get(FeeMembersSearchStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.memFeeQuery = AppInjector.get(MemFeeQuery);
    this.memFeeStore = AppInjector.get(MemFeeStore);
  }

  public search(): Observable<PaginationResponse<MemFee>> {
    const criteria = this.feeMembersSearchStore.getValue().ui.filters;

    return this.httpClient.post<PaginationResponse<MemFee>>(this.configService.get('financial.constants.url.findMemberFeeBySearchCriteria'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<MemFee>;
      })
    );
  }

  public updateSearchCriteria(criteria: FeeMembersSearchCriteria) {
    const prevCriteria = this.feeMembersSearchStore.getValue().ui.filters;
    this.feeMembersSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public getMemFeeById(id: ID): Observable<MemFee> {
    return this.memFeeQuery.selectEntity(id).pipe(
      switchMap(cacheEntry => {
        const apiCall = this.httpClient
          .post<any>(this.configService.get('financial.constants.url.getByMemFeeId'), { id: id })
          .pipe(
            withTransaction(response => {
              if (response) {
                this.memFeeStore.upsert(id, response);
                this.memFeeStore.setHasCache(true);
              }
            }),
            switchMap(res => this.memFeeQuery.selectEntity(id))
          );

        return cacheEntry ? this.memFeeQuery.selectEntity(id) : apiCall;
      })
    );
  }

  public addOrUpdateMemFee(MemFeeDTO: MemFee): Observable<any> {
    if (this.memFeeQuery.hasEntity(MemFeeDTO.id) && Boolean(MemFeeDTO.id)) {
      return this.httpClient.put<MemFee>(this.configService.get('financial.constants.url.addOrUpdateMemFee'), { ...this.memFeeQuery.getEntity(MemFeeDTO.id), ...MemFeeDTO }).pipe(
        tap(currentMemFee => {
          this.memFeeStore.upsert(currentMemFee.id, currentMemFee);
          this.feeMembersSearchStore.upsert(currentMemFee.id, currentMemFee);
        })
      );
    } else {
      return this.httpClient.post<MemFee>(this.configService.get('financial.constants.url.addOrUpdateMemFee'), MemFeeDTO).pipe(
        tap(currentMemFee => {
          this.memFeeStore.upsert(currentMemFee.id, currentMemFee);
          this.feeMembersSearchStore.upsert(currentMemFee.id, currentMemFee);
        })
      );
    }
  }

  public deleteByID(id: ID): Observable<any> {
    return this.httpClient
      .put<any>(this.configService.get('financial.constants.url.deleteByMemFeeId'), { id: id })
      .pipe(
        tap(resp => {
          this.feeMembersSearchStore.remove(id);
          this.memFeeStore.remove(id);
        })
      );
  }

  isRefreshSearchGrid(): boolean {
    return this.feeMembersSearchStore.isRefreshSearchGrid();
  }

  setRefreshSearchGrid(value: boolean) {
    this.feeMembersSearchStore.setRefreshSearchGrid(value);
  }
}
