import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse, withTransaction } from '@datorama/akita';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { FeeGroupsSearchCriteria } from '../models/fee-groups-search.model';
import { PremiumRate } from '../models/premium-rate.model';
import { FeeGroupsSearchStore } from '../state/fee-groups-search.store';
import { PremiumRateQuery } from '../state/premium-rate.query';
import { PremiumRateStore } from '../state/premium-rate.store';

@Injectable({
  providedIn: 'root',
})
export class FeeGroupsService {
  private feeGroupsSearchStore: FeeGroupsSearchStore;
  private httpClient: HttpClient;
  private configService: ConfigService;
  private premiumRateStore: PremiumRateStore;
  private premiumRateQuery: PremiumRateQuery;

  constructor() {
    this.feeGroupsSearchStore = AppInjector.get(FeeGroupsSearchStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.premiumRateStore = AppInjector.get(PremiumRateStore);
    this.premiumRateQuery = AppInjector.get(PremiumRateQuery);
  }

  public search(): Observable<PaginationResponse<PremiumRate>> {
    const criteria = this.feeGroupsSearchStore.getValue().ui.filters;

    return this.httpClient.post<PaginationResponse<PremiumRate>>(this.configService.get('financial.constants.url.findPremiumRateBySearchCriteria'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<PremiumRate>;
      })
    );
  }

  public updateSearchCriteria(criteria: FeeGroupsSearchCriteria) {
    const prevCriteria = this.feeGroupsSearchStore.getValue().ui.filters;
    this.feeGroupsSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public getPremiumRateById(id: ID): Observable<PremiumRate> {
    return this.premiumRateQuery.selectEntity(id).pipe(
      switchMap(cacheEntry => {
        const apiCall = this.httpClient
          .post<any>(this.configService.get('financial.constants.url.getPremiumRateById'), { id: id })
          .pipe(
            withTransaction(response => {
              if (response) {
                this.premiumRateStore.upsert(id, response);
                this.premiumRateStore.setHasCache(true);
              }
            }),
            switchMap(res => this.premiumRateQuery.selectEntity(id))
          );

        return cacheEntry ? this.premiumRateQuery.selectEntity(id) : apiCall;
      })
    );
  }

  public addOrUpdatePremiumRate(premiumRateDTO: PremiumRate): Observable<any> {
    if (this.premiumRateQuery.hasEntity(premiumRateDTO.id) && Boolean(premiumRateDTO.id)) {
      return this.httpClient.put<PremiumRate>(this.configService.get('financial.constants.url.addOrUpdatePremiumRate'), { ...this.premiumRateQuery.getEntity(premiumRateDTO.id), ...premiumRateDTO }).pipe(
        tap(currentPremiumRate => {
          this.premiumRateStore.upsert(currentPremiumRate.id, currentPremiumRate);
          this.feeGroupsSearchStore.upsert(currentPremiumRate.id, currentPremiumRate);
        })
      );
    } else {
      return this.httpClient.post<PremiumRate>(this.configService.get('financial.constants.url.addOrUpdatePremiumRate'), premiumRateDTO).pipe(
        tap(currentPremiumRate => {
          this.premiumRateStore.upsert(currentPremiumRate.id, currentPremiumRate);
          this.feeGroupsSearchStore.upsert(currentPremiumRate.id, currentPremiumRate);
        })
      );
    }
  }

  public deleteByID(id: ID): Observable<any> {
    return this.httpClient
      .put<any>(this.configService.get('financial.constants.url.deletePremiumRate'), { id: id })
      .pipe(
        tap(resp => {
          this.feeGroupsSearchStore.remove(id);
          this.premiumRateStore.remove(id);
        })
      );
  }

  isRefreshSearchGrid(): boolean {
    return this.feeGroupsSearchStore.isRefreshSearchGrid();
  }

  setRefreshSearchGrid(value: boolean) {
    this.feeGroupsSearchStore.setRefreshSearchGrid(value);
  }
}
