export * from './components/fees-tabs.component';
export * from './fees-tabs.module';
