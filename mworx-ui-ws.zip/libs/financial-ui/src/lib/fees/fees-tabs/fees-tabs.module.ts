import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { RouterModule } from '@angular/router';
import { SharedUiLayoutModule } from '@mworx/layout';
import { FeesAddEditModule } from '../fees-add-edit/fees-add-edit.module';
import { GroupsModule } from '../groups/groups.module';
import { FeesTabsComponent } from './components/fees-tabs.component';

@NgModule({
  declarations: [FeesTabsComponent],
  imports: [
    CommonModule,
    FeesAddEditModule,
    GroupsModule,
    MatButtonModule,
    MatIconModule,
    MatTabsModule,
    RouterModule,
    SharedUiLayoutModule,
  ],
  exports: [FeesTabsComponent]
})
export class FeesTabsModule { }
