import { Component, NgZone, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { LookupService } from '@mworx/lookup';
import { AuthorizationService } from '@mworx/session';
import { AppInjector, EventService, RequestService, StoresResetService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { filter } from 'rxjs/operators';

@UntilDestroy()
@Component({
  selector: 'financial-fees-tabs',
  templateUrl: './fees-tabs.component.html',
  styleUrls: ['./fees-tabs.component.scss']
})
export class FeesTabsComponent implements OnInit {
  tabs = [];
  loadedStatus: Array<number>;
  showSaveButton = true;
  groupsTabCanBeViewed = false;
  premiumRatesCanBeUpdated = false;
  membersTabCanBeViewed = false;
  feesCanBeUpdated = false;
  pageTitle: string;
  showAddButton;
  showSearchButton;
  showResetButton;
  tabIndex = 0;
  displayName: string;
  feeAmount: number;
  feePct: number;
  feeLevel: number;
  showMembersTab = false;

  constructor(
    private lookupService: LookupService,
    private storesResetService: StoresResetService,
    private authService: AuthorizationService,
    private requestService: RequestService,
    private eventService: EventService
  ) { }

  ngOnInit(): void {
    this.loadedStatus = new Array<number>();
    if (this.requestService.url().search('add') === -1) {
      this.requestService
        .selectNavigationExtras()
        .pipe(untilDestroyed(this))
        .subscribe(res => {
          this.displayName = ': ' + res.data.feeName;
          this.feeAmount = res.data.feeAmount;
          this.feePct = res.data.feePct;
          this.feeLevel = res.data.feeLevel;
          this.lookupFeeLevel(res.data.feeLevel);
        });
    }
    // groups tab
    const groupsTabViewPermissions = ['PERMIT_PREMIUM_RATE_VIEW'];
    this.authService
      .hasAccess(groupsTabViewPermissions)
      .pipe(untilDestroyed(this),
        filter(resp => resp))
      .subscribe(access => this.groupsTabCanBeViewed = access);
    const premiumRateAddPermissions = ['PERMIT_PREMIUM_RATE_UPDATE'];
    this.authService
      .hasAccess(premiumRateAddPermissions)
      .pipe(untilDestroyed(this),
        filter(resp => resp))
      .subscribe(access => this.premiumRatesCanBeUpdated = access);
    // members tab
    const membersTabViewPermissions = ['PERMIT_FEE_VIEW'];
    this.authService
      .hasAccess(membersTabViewPermissions)
      .pipe(untilDestroyed(this),
        filter(resp => resp))
      .subscribe(access => this.membersTabCanBeViewed = access);
    const feesAddPermissions = ['PERMIT_FEE_UPDATE'];
    this.authService
      .hasAccess(feesAddPermissions)
      .pipe(untilDestroyed(this),
        filter(resp => resp))
      .subscribe(access => this.feesCanBeUpdated = access);
    this.initTabs();
    //default load first tab
    this.loadedStatus.push(0);
    this.setPageTitle(this.tabs[this.tabIndex].tabName);
    //
    this.eventService
      .on('feesTabs')
      .pipe(
        untilDestroyed(this),
        filter(res => res.feeAmount !== this.feeAmount || res.feePct !== this.feePct || this.feeLevel !== res.feeLevel)
      )
      .subscribe(response => {
        this.updateFeeInformation(response);
      });
  }

  protected lookupFeeLevel(feeLevel: number) {
    this.lookupService
      .getLibListByCategoryAndId('feeLevel', feeLevel)
      .pipe(untilDestroyed(this), filter(r => !!r))
      .subscribe(response => response.value.toString().toLowerCase() === 'member' ? this.showMembersTab = true : this.showMembersTab = false);
  }

  protected updateFeeInformation(response: any) {
    this.feeAmount = response.feeAmount;
    this.feePct = response.feePct;

    if (this.feeLevel !== response.feeLevel) {
      const index: number = this.getMembersOrGroupsTabIndex();
      if (index !== -1) {
        this.resetStore(this.tabs[index].tabName)
        this.tabs.splice(index, 1);
      }
      this.lookupFeeLevel(response.feeLevel);
      this.showGroupsOrMembersTab();
      this.feeLevel = response.feeLevel;
    }
  }

  private showGroupsOrMembersTab() {
    if (this.requestService.url().search('add') === -1) {
      if (this.showMembersTab) {
        if (this.membersTabCanBeViewed) {
          this.tabs.push({
            tabName: 'Members',
            content: import('../../members/components/members-search/members-search.component').then(
              ({ MembersSearchComponent }) => MembersSearchComponent
            ),
          });
        }
      } else {
        if (this.groupsTabCanBeViewed) {
          this.tabs.push({
            tabName: 'Groups',
            content: import('../../groups/components/groups-search/groups-search.component').then(
              ({ GroupsSearchComponent }) => GroupsSearchComponent
            ),
          });
        }
      }
    }
  }

  protected initTabs() {
    this.tabs.push({
      tabName: 'Fee',
      content: import('../../fees-add-edit/components/fees-add-edit.component').then(({ FeesAddEditComponent }) => FeesAddEditComponent),
    });
    this.showGroupsOrMembersTab();
  }

  private getMembersOrGroupsTabIndex(): number {
    let index: number;
    if (this.showMembersTab) {
      index = this.tabs.findIndex(x => x.tabName === 'Members');
    } else {
      index = this.tabs.findIndex(x => x.tabName === 'Groups');
    }

    return index;
  }

  private setPageTitle(tabName: string) {
    this.showResetButton = true;
    if (this.requestService.url().search('add') !== -1) {
      this.pageTitle = 'Add Fee';
    } else {
      let numberTitle: string;
      let numberTitleValue: number;
      let editViewTitle: string;

      if (this.feeAmount) {
        numberTitle = "Amount";
        numberTitleValue = this.feeAmount;
      } else {
        numberTitle = "Percentage";
        numberTitleValue = this.feePct;
      }
      if (this.requestService.url().search('edit') !== -1) {
        editViewTitle = "Edit";
      } else if (this.requestService.url().search('view') !== -1) {
        editViewTitle = "View";
        this.showSaveButton = false;
      }
      if (tabName === 'Fee') {
        this.pageTitle = editViewTitle + ' Fee' + this.displayName;
        if (this.requestService.url().search('view') !== -1) {
          this.showResetButton = false;
        }
      } else {
        this.pageTitle = 'Fee Name' + this.displayName + ' - Fee ' + numberTitle + ': ' + numberTitleValue;
      }
    }
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    if (this.loadedStatus.indexOf(tabChangeEvent.index) === -1) {
      this.loadedStatus.push(tabChangeEvent.index);
    }
    this.tabIndex = tabChangeEvent.index;
    const tabName = this.tabs[this.tabIndex].tabName;
    this.setPageTitle(tabName);
    if (this.requestService.url().includes('view')) {
      this.showSaveButton = false;
      this.showAddButton = false;
      this.showSearchButton = tabName === 'Fee' ? false : true;
    } else {
      this.showSaveButton = tabName === 'Fee' ? true : false;
      this.showSearchButton = !this.showSaveButton;
      if (tabName === 'Fee') {
        this.showAddButton = false;
      } else {
        if (this.showMembersTab) {
          this.showAddButton = this.feesCanBeUpdated ? true : false;
        } else {
          this.showAddButton = this.premiumRatesCanBeUpdated ? true : false;
        }
      }
    }
  }

  private whichForm(tabName: string): string {
    if (tabName === 'Fee') return 'feeEventForm';
    if (tabName === 'Groups') return 'feeGroupsEventForm';
    if (tabName === 'Members') return 'feeMembersEventForm';

    return tabName;
  }

  onReset($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onResetForm', formName);
    }
  }

  onSearch($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onSearchForm', formName);
    }
  }

  onAddClick($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onAddForm', formName);
    }
  }

  private resetStore(tabName: string) {
    if (tabName === 'Groups') {
      this.storesResetService.resetStore('feeGroups-search');
    } else {
      this.storesResetService.resetStore('feeMembers-search');
    }
  }

  goBackToDashboard($event) {
    if ($event) {
      const index: number = this.getMembersOrGroupsTabIndex();
      if (index !== -1) {
        this.resetStore(this.tabs[index].tabName)
      }
      const ngZone = AppInjector.get(NgZone);
      ngZone.run(() => {
        this.requestService.navigate(['/financial/fees/dashboard']);
      });
    }
  }
}
