import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FeesTabsComponent } from './fees-tabs.component';

describe('FeesTabsComponent', () => {
  let component: FeesTabsComponent;
  let fixture: ComponentFixture<FeesTabsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ FeesTabsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(FeesTabsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
