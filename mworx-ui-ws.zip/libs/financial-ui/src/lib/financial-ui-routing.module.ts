import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { PermitsGuard } from '@mworx/session';
import { AdjustmentAddEditComponent } from './adjustment/adjustment-add-edit/components/adjustment-add-edit.component';
import { AdjustmentDashboardComponent } from './adjustment/adjustment-dashboard/components/adjustment-dashboard.component';
import { FeesDashboardComponent } from './fees/fees-dashboard/components/fees-dashboard.component';
import { FeesTabsComponent } from './fees/fees-tabs/components/fees-tabs.component';
import { InvoiceJobDashboardComponent } from './invoice-job/invoice-job-dashboard/components/invoice-job-dashboard.component';
import { InvoiceDashboardComponent } from './invoice/invoice-dashboard/components/invoice-dashboard.component';
import { RatefactorDashboardComponent } from './rating/ratefactor-dashboard/components/ratefactor-dashboard.component';

const routes: Routes = [
  {
    path: 'invoice-job/dashboard',
    component: InvoiceJobDashboardComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_INVOICE_VIEW'], title: 'Invoice Jobs' },
  },
  {
    path: 'invoice/dashboard',
    component: InvoiceDashboardComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_INVOICE_VIEW'], title: 'Invoices' },
  },
  {
    path: 'rating/dashboard',
    component: RatefactorDashboardComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_RATE_FACTOR_VIEW'], title: 'Rates' },
  },
  {
    path: 'fees/dashboard',
    component: FeesDashboardComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_FEE_VIEW'], title: 'Fees' },
  },
  {
    path: 'fees/add',
    component: FeesTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_FEE_UPDATE'], title: 'Add Fee' },
  },
  {
    path: 'fees/edit',
    component: FeesTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_FEE_UPDATE'], title: 'Edit Fee' },
  },
  {
    path: 'fees/view',
    component: FeesTabsComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_FEE_VIEW'], title: 'View Fee' },
  },
  {
    path: 'adjustment/dashboard',
    component: AdjustmentDashboardComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_ADJUSTMENT_VIEW'], title: 'Adjustments' },
  },
  {
    path: 'adjustment/add',
    component: AdjustmentAddEditComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_ADJUSTMENT_UPDATE'], title: 'Add Adjustment' },
  },
  {
    path: 'adjustment/edit',
    component: AdjustmentAddEditComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_ADJUSTMENT_UPDATE'], title: 'Edit Adjustment' },
  },
  {
    path: 'adjustment/view',
    component: AdjustmentAddEditComponent,
    canActivate: [PermitsGuard],
    data: { permissions: ['PERMIT_ADJUSTMENT_VIEW'], title: 'View Adjustment' },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class FinancialUiRoutingModule { }
