import { SearchCriteria } from '@mworx/grid';

export interface LnkRateFactorSearchCriteria extends SearchCriteria {
  rfsId: number;
}
