import { Injectable } from '@angular/core';
import { QueryEntity } from '@datorama/akita';
import { LnkRateFactorSearchState, LnkRateFactorSearchStore } from './lnk-ratefactor-search.store';
@Injectable({ providedIn: 'root' })
export class LnkRateFactorSearchQuery extends QueryEntity<LnkRateFactorSearchState> {
  filters$ = this.select(state => state.ui.filters);
  initialState$ = this.store.getInitialState();
  constructor(protected store: LnkRateFactorSearchStore) {
    super(store);
  }
}
