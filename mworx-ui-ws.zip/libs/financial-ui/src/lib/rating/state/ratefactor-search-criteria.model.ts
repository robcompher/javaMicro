import { SearchCriteria } from '@mworx/grid';

export interface RateFactorSetSearchCriteria extends SearchCriteria {
  rateFactorSetName: string;
  active: string;
}
