import { EntityState, EntityStore } from '@datorama/akita';
import { Observable, of } from 'rxjs';
import { LnkRateFactor } from '../models/link-rate-factor.model';
import { LnkRateFactorSearchCriteria } from './lnk-ratefactor-search-criteria.model';

export interface LnkRateFactorSearchState extends EntityState<LnkRateFactor> {}
const initialState = {
  ui: {
    filters: {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'rfId',
        sortOrder: 'asc',
      },
      rfsId: null,
    } as LnkRateFactorSearchCriteria,
  },
};
export class LnkRateFactorSearchStore extends EntityStore<LnkRateFactorSearchState> {
  constructor(rfsId: number) {
    super(initialState, { name: 'LnkRateFactorSearchStore-' + rfsId, idKey: 'linkId', resettable: true });
  }
  getInitialState(): Observable<LnkRateFactorSearchCriteria> {
    return of(initialState.ui.filters);
  }
}
