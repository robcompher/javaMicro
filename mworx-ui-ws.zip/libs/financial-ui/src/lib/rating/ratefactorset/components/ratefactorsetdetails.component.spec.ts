import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatefactorsetdetailsComponent } from './ratefactorsetdetails.component';

describe('RatefactorsetdetailsComponent', () => {
  let component: RatefactorsetdetailsComponent;
  let fixture: ComponentFixture<RatefactorsetdetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatefactorsetdetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatefactorsetdetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
