import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { ListChoice, LookupService } from '@mworx/lookup';
import { ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { RateFactorSetService } from '../../services/ratefactorset.service';
@UntilDestroy()
@Component({
  selector: 'financial-ratefactorset-dialog',
  templateUrl: './ratefactorset-dialog.component.html',
  styleUrls: ['./ratefactorset-dialog.component.scss'],
})
export class RateFactorSetDialogComponent implements OnInit {
  id: ID;
  rateFactorSetAddForm: FormGroup;
  pageTitle = 'Add rate factor set ';
  buttonVisibility: boolean;
  rateFactorSetActiveValues$: Observable<Array<ListChoice>>;
  @ViewChild('rateFactorSetAddFormDirective')
  rateFactorSetAddFormDirective: FormGroupDirective;
  constructor(
    private errorService: ErrorService,
    private notifyService: NotificationService,
    private configService: ConfigService,
    private fb: FormBuilder,
    private lookupService: LookupService,
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<RateFactorSetDialogComponent>,
    private rateFactorSetService: RateFactorSetService
  ) {
    dialogRef.disableClose = true;
  }

  ngOnInit(): void {
    this.rateFactorSetActiveValues$ = this.lookupService.getYesNoBoth();
    if (this.data) {
      const rateFactorSetName = this.data.name != null ? this.data.name : null;
      this.pageTitle = this.data.actionType + ' Rate Factor Set ' + (rateFactorSetName ? ' : ' + rateFactorSetName : '');
    }

    this.rateFactorSetAddForm = this.fb.group({
      rateFactorSetName: [null, Validators.required],
      description: null,
      active: ['Y'],
    });
    if (this.data.rowData && this.data.rowData.id) {
      this.id = this.data.rowData.id;
      this.rateFactorSetAddForm.patchValue(this.data.rowData);
    }
    if (this.data.actionType === 'View') {
      this.rateFactorSetAddForm.disable();
      this.buttonVisibility = false
    } else {
      this.rateFactorSetAddForm.enable();
      this.buttonVisibility = true;
    }
  }

  closePopup() {
    this.dialogRef.close();
  }

  onReset() {
    if (this.id) {
      this.rateFactorSetAddForm.patchValue(this.data.rowData);
    } else if (this.rateFactorSetAddFormDirective) {
      this.rateFactorSetAddFormDirective.resetForm({ active: 'Y' });
    }
  }

  onSave() {
    if (this.rateFactorSetAddForm.invalid) {
      return;
    }
    const pForm = this.rateFactorSetAddForm.value;
    pForm.id = this.id;
    // call service here.
    this.rateFactorSetService
      .addOrUpdateRateFactorSet(pForm)
      .pipe(untilDestroyed(this))
      .pipe(
        catchError((error: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.rateFactorSetAddForm, error);
        })
      )
      .subscribe(response => {
        this.notifyService.showSuccess(
          this.configService.get('financial.constants.messages.ratefactorSetSuccessMessage')(
            pForm.id ? 'updated' : 'created',
            pForm.rateFactorSetName
          )
        );
        this.closePopup();
        this.rateFactorSetService.resetForm();
      });
  }
}
