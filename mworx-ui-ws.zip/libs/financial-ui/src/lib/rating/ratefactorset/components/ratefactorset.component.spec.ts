import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatefactorsetComponent } from './ratefactorset.component';

describe('RatefactorsetComponent', () => {
  let component: RatefactorsetComponent;
  let fixture: ComponentFixture<RatefactorsetComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatefactorsetComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatefactorsetComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
