import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { ListChoice, LookupService } from '@mworx/lookup';
import { ErrorService, EventService, NotificationService, RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { RateFactorSetService } from '../../services/ratefactorset.service';
import { RateFactorSetQuery } from '../../state/ratefactorset.query';
import { RateFactorSetState } from '../../state/ratefactorset.store';
import { RATEFACTORSET_SEARCH_PAGINATOR } from '../ratefactorset-search-paginator';
import { RateFactorSetDialogComponent } from './ratefactorset-dialog.component';
import { RatefactorsetdetailsComponent } from './ratefactorsetdetails.component';

@UntilDestroy()
@Component({
  selector: 'financial-ratefactorset',
  templateUrl: './ratefactorset.component.html',
  styleUrls: ['./ratefactorset.component.scss'],
})
export class RatefactorsetComponent implements OnInit {
  gridOptions: GridOptions;
  rateFactorSetSearchForm: FormGroup;
  gridApi: GridApi;
  rateFactorSetActiveValues$: Observable<Array<ListChoice>>;
  label = 'Factor Sets';
  id: ID;
  detailRowComponent = RatefactorsetdetailsComponent;

  constructor(
    private rateFactorSetService: RateFactorSetService,
    private lookupService: LookupService,
    private fb: FormBuilder,
    private configService: ConfigService,
    private eventService: EventService,
    @Inject(RATEFACTORSET_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<RateFactorSetState>,
    private requestService: RequestService,
    private dialog: MatDialog,
    private errorService: ErrorService,
    private notifyService: NotificationService,
    private notificationService: NotificationService,
    private rateFactorSetQuery: RateFactorSetQuery
  ) {
    const _this = this;

    _this.gridOptions = <GridOptions>{
      masterDetail: true,
      frameworkComponents: { buttonRenderer: GridActionsComponent },
      onGridReady: (event: GridReadyEvent) => {
        _this.gridApi = event.api;
      },
      pagination: true,
    };

    this.gridOptions.columnDefs = [
      { headerName: 'Name', sortable: true, field: 'rateFactorSetName', cellRenderer: 'expandCollapseCellRenderer' },
      { headerName: 'Description', sortable: true, field: 'description' },
      { headerName: 'Active', sortable: true, field: 'active' },

      {
        headerName: 'Actions',
        sortable: false,
        cellRenderer: 'buttonRenderer',
        cellRendererParams: {
          actions: [
            {
              onClick: this.onViewActionClick.bind(this),
              title: 'View',
              icon: 'remove_red_eye',
              color: 'primary',
              permissions: ['PERMIT_RATE_FACTOR_VIEW'],
            },
            {
              onClick: this.onEditActionClick.bind(this),
              label: 'Edit',
              icon: 'edit',
              color: 'primary',
              permissions: ['PERMIT_RATE_FACTOR_UPDATE'],
            },
            {
              onClick: this.onDeleteActionClick.bind(this),
              label: 'Delete',
              icon: 'delete',
              color: 'warn',
              permissions: ['PERMIT_RATE_FACTOR_UPDATE'],
            },
          ],
        },
      },
    ];
  }

  onViewActionClick(e: any) {
    this.onOpen(e.rowData, 'View');
  }

  onEditActionClick(e: any) {
    this.onOpen(e.rowData, 'Edit');
  }

  onDeleteActionClick(e: any) {
    if (e.rowData.active === 'N') {
      this.notificationService.showError(this.configService.get('defaultMessages.alreadyInactive'));

      return;
    }

    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.rateFactorSetService
            .deleteRateFactorSet(e.rowData.id)
            .pipe(
              catchError((response: HttpErrorResponse) => {
                return this.errorService.handleTableValidationErrors(response);
              }),
              untilDestroyed(this)
            )
            .subscribe(() => {
              this.notifyService.showSuccess(
                this.configService.get('defaultMessages.actionResponse')('deleted', 'ratefactorset', e.rowData.rateFactorSetName)
              );
              this.gridApi.onFilterChanged();
            });
        }
      });
  }

  onReset() {
    this.rateFactorSetQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.rateFactorSetSearchForm.reset(criteria);
      this.onSearch();
    });
  }

  ngOnInit(): void {
    this.rateFactorSetActiveValues$ = this.lookupService.getYesNoBoth();

    this.rateFactorSetService.onRateFactorSetFormReset.pipe(untilDestroyed(this)).subscribe(() => {
      this.onSearch();
    });

    this.rateFactorSetSearchForm = this.fb.group({
      rateFactorSetName: [],
      active: ['Y'],
    });

    this.rateFactorSetQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.rateFactorSetSearchForm.patchValue(criteria);
    });

    this.requestService
      .selectNavigationExtras()
      .pipe(untilDestroyed(this))
      .subscribe(res => {
        this.id = res.data != null ? res.data.id : null;
      });

    this.eventService
      .on('onOpenSearchForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'rateFactorSetEventForm')
      )
      .subscribe(() => {
        this.onSearch();
      });

    this.eventService
      .on('onResetSearchForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'rateFactorSetEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });

    this.eventService
      .on('onOpenAddForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'rateFactorSetEventForm')
      )
      .subscribe(() => {
        this.onOpen(null, 'Add');
      });

    this.paginatorRef.requestFunction = () => this.rateFactorSetService.search();
    this.paginatorRef.filtersUpdateFunction = criteria => this.rateFactorSetService.updateSearchCriteria(criteria);
  }

  onOpen(rowData: any, actionType: string) {
    this.dialog.open(RateFactorSetDialogComponent, {
      minWidth: '60%',
      data: { rowData: rowData, actionType: actionType, name: rowData != null ? rowData.rateFactorSetName : null },
    });
  }

  onSearch() {
    const clientQuery = this.rateFactorSetSearchForm.value;
    this.rateFactorSetService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }
}
