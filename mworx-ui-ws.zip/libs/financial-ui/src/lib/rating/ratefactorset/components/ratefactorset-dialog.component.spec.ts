import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatefactorsetDialogComponent } from './ratefactorset-dialog.component';

describe('RatefactorsetDialogComponent', () => {
  let component: RatefactorsetDialogComponent;
  let fixture: ComponentFixture<RatefactorsetDialogComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatefactorsetDialogComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatefactorsetDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
