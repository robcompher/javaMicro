import { HttpErrorResponse } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { AuthorizationService } from '@mworx/session';
import { ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { catchError, filter, take } from 'rxjs/operators';
import { LinkRateFactorSetAddEditComponent } from '../../link-rate-factor-set-add-edit/components/link-rate-factor-set-add-edit.component';
import { RateFactorSearchCriteria } from '../../models/ratefactor-search.model';
import { RateFactorService } from '../../services/ratefactor.service';
import { RateFactorSetService } from '../../services/ratefactorset.service';
import { LnkRateFactorSearchState, LnkRateFactorSearchStore } from '../../state/lnk-ratefactor-search.store';
import { RateFactorSetQuery } from '../../state/ratefactorset.query';

@UntilDestroy()
@Component({
  selector: 'financial-ratefactorsetdetails',
  templateUrl: './ratefactorsetdetails.component.html',
  styleUrls: ['./ratefactorsetdetails.component.scss'],
})
export class RatefactorsetdetailsComponent implements OnInit {
  gridOptions: GridOptions;
  public paginatorRef: GridPaginatorPlugin<LnkRateFactorSearchState>;
  public lnkRateFactorSearchStore: LnkRateFactorSearchStore;
  gridApi: GridApi;
  rateFactorsForm: FormGroup;
  rfsId: number;
  viewOnly: boolean;
  showAddButton: boolean;

  @Input()
  parentRowParams: any;
  constructor(
    private rateFactorSetQuery: RateFactorSetQuery,
    private fb: FormBuilder,
    private rateFactorService: RateFactorService,
    private rateFactorSetService: RateFactorSetService,
    public dialog: MatDialog,
    private errorService: ErrorService,
    private notificationService: NotificationService,
    private configService: ConfigService,
    private authService: AuthorizationService
  ) {
    const _this = this;

    _this.gridOptions = <GridOptions>{
      frameworkComponents: { buttonRenderer: GridActionsComponent },
      onGridReady: (event: GridReadyEvent) => {
        _this.gridApi = event.api;
      },
      pagination: true,
    };
  }

  ngOnInit(): void {
    this.rfsId = this.parentRowParams.data.rateFactorSetId ? this.parentRowParams.data.rateFactorSetId : this.parentRowParams.data.id;
    this.viewOnly = this.parentRowParams.data.viewOnly ? this.parentRowParams.data.viewOnly : false;
    const state = this.rateFactorService.getSearchState(this.rfsId);
    this.lnkRateFactorSearchStore = state.store;
    this.paginatorRef = state.paginatorRef;
    this.paginatorRef.requestFunction = () => this.rateFactorService.searchLinkRateFactors(this.rfsId);
    this.paginatorRef.filtersUpdateFunction = criteria => this.rateFactorService.updateLnkRateFactorSearchCriteria(criteria);
    this.lnkRateFactorSearchStore
      .getInitialState()
      .pipe(take(1), untilDestroyed(this))
      .subscribe(criteria =>
        this.rateFactorService.updateLnkRateFactorSearchCriteria({ ...criteria, ...{ rfsId: this.rfsId, active: 'Y' } })
      );

    this.rateFactorSetQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.rateFactorsForm = this.fb.group(criteria, {
        rateFactorSetName: [''],
      });
    });
    this.rateFactorService.updateSearchCriteria({ rfsId: this.rfsId } as RateFactorSearchCriteria);
    this.initGrid();

    this.showAddButton = false;
    if (!this.viewOnly) {
      this.authService
        .hasAccess(['PERMIT_RATE_FACTOR_UPDATE'])
        .pipe(untilDestroyed(this),
          filter(resp => resp))
        .subscribe(access => this.showAddButton = access);
    }
  }

  private initGrid() {
    this.gridOptions.columnDefs = [
      {
        headerName: 'Type',
        field: 'rateFactor.rateFactorType',
        sortable: false,
        valueGetter: 'category:rateFactorType',
      },
      { headerName: 'Name', field: 'rateFactor.rateFactorName', sortable: false },
      { headerName: 'Description', field: 'rateFactor.description', sortable: false },
      {
        headerName: 'Level',
        field: 'rateFactor.rateLevel',
        sortable: false,
        valueGetter: 'category:rateLevel',
      },
      { headerName: 'Value', field: 'rateFactor.factorValue', sortable: false, type: 'currencyColumn' },
      {
        headerName: 'Percentage',
        field: 'rateFactor.factorValueInPercentage',
        sortable: false,
        type: 'percentColumn'
      },
      { headerName: 'Active', field: 'rateFactor.active', sortable: false },
      {
        headerName: 'Actions',
        colId: 'Actions',
        minWidth: 150,
        sortable: false,
        cellRenderer: 'buttonRenderer',
        cellRendererParams: {
          actions: [
            {
              onClick: this.onDeleteActionClick.bind(this),
              title: 'Delete',
              icon: 'delete',
              color: 'warn',
              show: this.showAction.bind(this),
              permissions: ['PERMIT_RATE_FACTOR_UPDATE'],
            },
          ],
        },
      },
    ];
  }

  showAction(action: any, data: any) {
    if (this.viewOnly) return false;

    return data.rateFactor.active !== 'N';
  }

  openLinkRateFActorFormForm(linkId: ID, rfsId: number, actionType: string) {
    const dialogRef = this.dialog.open(LinkRateFactorSetAddEditComponent, {
      minWidth: '60%',
      data: { id: linkId, rfsId: rfsId, actionType: actionType },
    });
    dialogRef
      .afterClosed()
      .pipe(untilDestroyed(this))
      .subscribe(result => {
        if (result?.event !== 'Cancel') {
          this.gridApi.onFilterChanged();
        }
      });
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }
  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.rateFactorSetService
            .deleteLinkRateFactorSet(e.rowData.linkId)
            .pipe(
              untilDestroyed(this),
              catchError((error: HttpErrorResponse) => {
                return this.errorService.handleTableValidationErrors(error);
              })
            )
            .subscribe(() => {
              this.notificationService.showSuccess(
                this.configService.get('defaultMessages.actionResponse')('deleted', 'Rate Factor From Set', e.rowData.rateFactor.rateFactorName)
              );
              this.gridApi.onFilterChanged();
            });
        }
      });
  }
}
