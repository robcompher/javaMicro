import { inject, InjectionToken } from '@angular/core';

import { GridPaginatorPlugin } from '@mworx/grid';
import { RateFactorSetQuery } from '../state/ratefactorset.query';

export const RATEFACTORSET_SEARCH_PAGINATOR = new InjectionToken('RATEFACTORSET_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const rateFactorSetSearchQuery = inject(RateFactorSetQuery);

    return new GridPaginatorPlugin(rateFactorSetSearchQuery);
  },
});
