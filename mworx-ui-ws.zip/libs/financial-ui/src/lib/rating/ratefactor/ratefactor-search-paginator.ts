import { inject, InjectionToken } from '@angular/core';

import { GridPaginatorPlugin } from '@mworx/grid';
import { RateFactorSearchQuery } from '../state/ratefactor-search.query';

export const RATEFACTOR_SEARCH_PAGINATOR = new InjectionToken('RATEFACTOR_SEARCH_PAGINATOR', {
  providedIn: 'root',
  factory: () => {
    const rateFactorSearchQuery = inject(RateFactorSearchQuery);

    return new GridPaginatorPlugin(rateFactorSearchQuery);
  },
});
