import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ConfirmDialogComponent } from '@mworx/confirm-dialog';
import { GridActionsComponent, GridPaginatorPlugin } from '@mworx/grid';
import { LibList, ListChoice, LookupService } from '@mworx/lookup';
import { AppInjector, ErrorService, EventService, FormatCurrencyPipe, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { GridApi, GridOptions, GridReadyEvent } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { RateFactorAddEditComponent } from '../../ratefactor-add-edit/components/ratefactor-add-edit.component';
import { RateFactorService } from '../../services/ratefactor.service';
import { RateFactorSearchQuery } from '../../state/ratefactor-search.query';
import { RateFactorSearchState } from '../../state/ratefactor-search.store';
import { RATEFACTOR_SEARCH_PAGINATOR } from '../ratefactor-search-paginator';

@UntilDestroy()
@Component({
  selector: 'financial-ratefactor',
  templateUrl: './ratefactor.component.html',
  styleUrls: ['./ratefactor.component.scss'],
})
export class RatefactorComponent implements OnInit {
  rateFactorSearchForm: FormGroup;
  gridApi: GridApi;
  rateFactorActiveValues$: Observable<Array<ListChoice>>;
  rateFactorTypeValues$: Observable<Array<LibList>>;
  rateFactorRateLevelValues$: Observable<Array<LibList>>;
  @ViewChild('rateFactorSearchDirective')
  rateFactorSearchDirective: FormGroupDirective;
  formatCurrencyPipe: FormatCurrencyPipe;
  columnDefs = [
    {
      headerName: 'Type',
      field: 'rateFactorType',
      valueGetter: 'category:rateFactorType',
    },
    { headerName: 'Name', field: 'rateFactorName' },
    { headerName: 'Description', field: 'description' },
    {
      headerName: 'Rate level',
      field: 'rateLevel',
      valueGetter: 'category:rateLevel',
    },
    {
      headerName: 'Value',
      field: 'factorValue',
      type: 'currencyColumn',
    },
    {
      headerName: 'Percentage',
      field: 'factorValueInPercentage',
      sortable: false,
      type: 'percentColumn'
    },

    { headerName: 'Active', field: 'active' },
    {
      headerName: 'Actions',
      colId: 'Actions',
      minWidth: 150,
      sortable: false,
      cellRenderer: 'buttonRenderer',
      cellRendererParams: {
        actions: [
          {
            onClick: this.onViewActionClick.bind(this),
            title: 'View',
            icon: 'remove_red_eye',
            color: 'primary',
            permissions: ['PERMIT_RATE_FACTOR_VIEW'],
          },
          {
            onClick: this.onEditActionClick.bind(this),
            title: 'Edit',
            icon: 'edit',
            color: 'primary',
            permissions: ['PERMIT_RATE_FACTOR_UPDATE'],
          },
          {
            onClick: this.onDeleteActionClick.bind(this),
            title: 'Delete',
            icon: 'delete',
            color: 'warn',
            show: this.showAction.bind(this),
            permissions: ['PERMIT_RATE_FACTOR_UPDATE'],
          },
        ],
      },
    },
  ];

  gridOptions: GridOptions = {
    frameworkComponents: { buttonRenderer: GridActionsComponent },
    onGridReady: (event: GridReadyEvent) => {
      this.gridApi = event.api;
    },
  };

  private fb: FormBuilder;
  private rateFactorService: RateFactorService;
  private rateFactorSearchQuery: RateFactorSearchQuery;
  private lookupService: LookupService;
  private dialog: MatDialog;
  private notificationService: NotificationService;
  private errorService: ErrorService;
  private configService: ConfigService;
  private eventService: EventService;
  constructor(@Inject(RATEFACTOR_SEARCH_PAGINATOR) public paginatorRef: GridPaginatorPlugin<RateFactorSearchState>) {
    this.fb = AppInjector.get(FormBuilder);
    this.lookupService = AppInjector.get(LookupService);
    this.rateFactorService = AppInjector.get(RateFactorService);
    this.rateFactorSearchQuery = AppInjector.get(RateFactorSearchQuery);
    this.dialog = AppInjector.get(MatDialog);
    this.notificationService = AppInjector.get(NotificationService);
    this.errorService = AppInjector.get(ErrorService);
    this.configService = AppInjector.get(ConfigService);
    this.eventService = AppInjector.get(EventService);
  }

  ngOnInit(): void {
    this.initForm();
    this.initEventSubscribers();
  }

  initForm() {
    this.formatCurrencyPipe = new FormatCurrencyPipe();
    this.rateFactorActiveValues$ = this.lookupService.getYesNoBoth();
    this.rateFactorTypeValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.rateFactorType'));
    this.rateFactorRateLevelValues$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.rateLevel'));

    this.rateFactorSearchForm = this.fb.group({
      rateFactorType: [],
      rateFactorName: [],
      rateLevel: [],
      active: ['Y'],
    });

    this.rateFactorSearchQuery.filters$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.rateFactorSearchForm.patchValue(criteria);
    });

    this.paginatorRef.requestFunction = () => this.rateFactorService.search();

    this.paginatorRef.filtersUpdateFunction = criteria => this.rateFactorService.updateSearchCriteria(criteria);
  }

  initEventSubscribers() {
    this.eventService
      .on('onOpenSearchForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'rateFactorEventForm')
      )
      .subscribe(() => {
        this.onSearch();
      });

    this.eventService
      .on('onOpenAddForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'rateFactorEventForm')
      )
      .subscribe(() => {
        this.onAddActionClick();
      });

    this.eventService
      .on('onResetSearchForm')
      .pipe(
        untilDestroyed(this),
        filter(res => res === 'rateFactorEventForm')
      )
      .subscribe(() => {
        this.onReset();
      });
  }

  openRateFactorAddEditForm(rowData: any, actionType: string) {
    this.dialog
      .open(RateFactorAddEditComponent, {
        width: '60%',
        data: {
          rowData: rowData,
          actionType: actionType,
        },
        disableClose: true,
      })
      .afterClosed()
      .pipe(
        untilDestroyed(this),
        filter(refreshParent => refreshParent)
      )
      .subscribe(refreshParent => (refreshParent ? this.onReset() : null));
  }

  onAddActionClick() {
    this.openRateFactorAddEditForm(null, 'Add');
  }

  onViewActionClick(e: any) {
    this.openRateFactorAddEditForm(e.rowData, 'View');
  }

  onEditActionClick(e: any) {
    this.openRateFactorAddEditForm(e.rowData, 'Edit');
  }

  onDeleteActionClick(e: any) {
    this.openConfirmDialog(this.configService.get('defaultMessages.confirmDelete'))
      .afterClosed()
      .subscribe(res => {
        if (res) {
          this.rateFactorService
            .deleteByID(e.rowData.id)
            .pipe(
              untilDestroyed(this),
              catchError((error: HttpErrorResponse) => {
                return this.errorService.handleValidationErrors(this.rateFactorSearchForm, error);
              })
            )
            .subscribe(() => {
              this.notificationService.showSuccess(
                this.configService.get('defaultMessages.actionResponse')('deleted', 'Rate Factor', e.rowData.rateFactorName)
              );
              this.onReset();
            });
        }
      });
  }

  onSearch() {
    const clientQuery = this.rateFactorSearchForm.value;
    this.rateFactorService.updateSearchCriteria(clientQuery);
    this.gridApi.onFilterChanged();
  }

  onReset() {
    this.rateFactorSearchQuery.initialState$.pipe(untilDestroyed(this)).subscribe(criteria => {
      this.rateFactorSearchDirective.resetForm(criteria);
      this.onSearch();
    });
  }

  showAction(action: any, data: any) {
    return data.active !== 'N';
  }

  openConfirmDialog(msg) {
    return this.dialog.open(ConfirmDialogComponent, {
      disableClose: true,
      data: {
        message: msg,
      },
    });
  }
}
