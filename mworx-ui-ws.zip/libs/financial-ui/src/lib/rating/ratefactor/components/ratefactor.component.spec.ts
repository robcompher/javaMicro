import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatefactorComponent } from './ratefactor.component';

describe('RatefactorComponent', () => {
  let component: RatefactorComponent;
  let fixture: ComponentFixture<RatefactorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatefactorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatefactorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
