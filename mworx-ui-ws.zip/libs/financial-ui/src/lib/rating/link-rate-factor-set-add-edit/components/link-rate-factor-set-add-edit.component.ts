import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { LibList, ListChoice, LookupService } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable, of, Subject } from 'rxjs';
import { catchError, filter, map, mergeMap, switchMap, toArray } from 'rxjs/operators';
import { RateFactor } from '../../models/ratefactor.model';
import { RateFactorService } from '../../services/ratefactor.service';
import { RateFactorSetService } from '../../services/ratefactorset.service';

@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'financial-link-rate-factor-set-add-edit',
  templateUrl: './link-rate-factor-set-add-edit.component.html',
  styleUrls: ['./link-rate-factor-set-add-edit.component.scss'],
})
export class LinkRateFactorSetAddEditComponent implements OnInit {
  constructor(@Inject(MAT_DIALOG_DATA) public data, private dialogRef: MatDialogRef<LinkRateFactorSetAddEditComponent>) {
    this.fb = AppInjector.get(FormBuilder);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.configService = AppInjector.get(ConfigService);
    this.lookupService = AppInjector.get(LookupService);
    this.rateFactorService = AppInjector.get(RateFactorService);
    this.rateFactorSetService = AppInjector.get(RateFactorSetService);
  }
  linkRateFactorAddForm: FormGroup;
  @ViewChild('linkRateFactorAddFormDirective')
  linkRateFactorAddFormDirective: FormGroupDirective;
  rateFactorTypes$: Observable<Array<LibList>>;
  rateLevels$: Observable<Array<LibList>>;
  genderList$: Observable<Array<LibList>>;
  rateFactorList$: Observable<Array<RateFactor>>;

  pageTitle: string;
  rateFactorType: string;
  rateFactorSubject: Subject<void> = new Subject<void>();
  rateFactorTypeSelectionReset = {
    area: null,
    minAge: null,
    maxAge: null,
    smoker: 'N',
    active: 'N',
    genderLibListValue: null,
  };

  private fb: FormBuilder;
  private errorService: ErrorService;
  private notifyService: NotificationService;
  private configService: ConfigService;
  private lookupService: LookupService;
  private rateFactorService: RateFactorService;
  private rateFactorSetService: RateFactorSetService;
  f;

  ngOnInit(): void {
    this.pageTitle = this.data.actionType + ' Rate Factor To Set';

    this.initForm();
    this.initData();
    this.linkRateFactorAddForm.disable();
    this.linkRateFactorAddForm.get('rfId').enable();
  }

  initForm() {
    this.rateLevels$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.rateLevel'));
    this.rateFactorTypes$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.rateFactorType'));
    this.genderList$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.gender'));

    this.linkRateFactorAddForm = this.fb.group({
      rateLevel: [],
      rfId: [null, Validators.required],
      rateFactorType: [],
      description: [],
      active: ['N'],
      area: [],
      minAge: [],
      maxAge: [],
      smoker: ['N'],
      genderLibListValue: [],
      factorValue: [],
      factorValueInPercentage: []
    });

    this.rateFactorList$ = this.linkRateFactorAddForm.get('rfId').valueChanges.pipe(
      switchMap((searchValue: ListChoice) => {
        if (searchValue) {
          if (searchValue.label !== null && searchValue.value === null) {
            return this.getRateFactors(searchValue.label);
          } else if (searchValue.value !== null) {
            const rateFactor = searchValue.value as RateFactor;
            this.linkRateFactorAddForm.patchValue(rateFactor);

            return this.getRateFactors(searchValue.label);
          }
        }

        return of([]);
      })
    );
  }

  getRateFactors(rateFactorName: string, periodCycleId?: number): Observable<Array<ListChoice>> {
    return this.rateFactorService.getRateFactors(rateFactorName).pipe(
      filter(data => data && data.length > 0),
      mergeMap((items: RateFactor[]) => items),
      map((item: any) => {
        const rateFactorValue =  (item.factorValueInPercentage !== null && item.factorValueInPercentage > 0) ? (' - ' + item.factorValueInPercentage + '%') : (' - $' + item.factorValue);

        return {
          value: item,
          label: item.rateFactorName + rateFactorValue,
        } as ListChoice;
      }),
      toArray()
    );
  }

  initData() {
    this.rateFactorType = null;
    if (this.linkRateFactorAddFormDirective) {
      this.linkRateFactorAddFormDirective.resetForm({ active: 'N', smoker: 'N' });
    }
  }

  onSubmit() {
    if (this.linkRateFactorAddForm.invalid) {
      return;
    }

    const linkRateFactorAddFormRequest = this.linkRateFactorAddForm.value;
    linkRateFactorAddFormRequest.rfsId = this.data.rfsId;
    const rateFactor = linkRateFactorAddFormRequest.rfId?.value;
    linkRateFactorAddFormRequest.rfId = linkRateFactorAddFormRequest.rfId.value.id;

    this.rateFactorService
      .addLinkRateFactorSet(linkRateFactorAddFormRequest)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.linkRateFactorAddForm, response);
        })
      )
      .subscribe(resp => {
        this.notifyService.showSuccess(
          this.configService.get('defaultMessages.actionResponse')('Added', ' Rate Factor Set link to ', rateFactor ? rateFactor.rateFactorName : '')
        );
        this.closePopup("Save");
        this.rateFactorSetService.resetForm();
      });
  }

  onReset() {
    this.initData();
  }

  onClose() {
    this.closePopup("Cancel")
  }
  closePopup(event: string): void {
    this.dialogRef.close({event: event});
  }

  selectionChange(value: string, event: MatOptionSelectionChange) {
    if (event.source.selected && value) {
      if (event.isUserInput && this.rateFactorType && this.rateFactorType !== value.toLowerCase()) {
        const customReset = Object.assign({}, this.rateFactorTypeSelectionReset);
        this.linkRateFactorAddForm.patchValue(customReset, { emitEvent: false });
      }
      this.rateFactorType = value.toLowerCase();
    }
  }
}
