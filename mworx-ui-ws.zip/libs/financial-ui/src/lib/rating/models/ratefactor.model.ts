import { ID } from '@datorama/akita';

export interface RateFactor {
  id: ID;
  rateFactorType: number;
  rateFactorName: string;
  description: string;
  rateLevel: number;
  factorValue: number;
  active: string;
  area: string;
  minAge: number;
  maxAge: number;
  genderLibListValue: number;
  tierLibListValue: number;
  smoker: string;
}

export function createRateFactor(params: Partial<RateFactor>) {
  return {
    id: null,
    rateFactorType: null,
    rateFactorName: null,
    description: null,
    rateLevel: null,
    factorValue: null,
    active: null,
    area: null,
    minAge: null,
    maxAge: null,
    genderLibListValue: null,
    tierLibListValue: null,
    smoker: null,
    ...params,
  } as RateFactor;
}
