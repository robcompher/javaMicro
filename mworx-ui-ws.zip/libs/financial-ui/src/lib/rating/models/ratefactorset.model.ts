import { ID } from '@datorama/akita';

export interface RateFactorSet {
  id: ID;
  rateFactorSetName: string;
  description: string;
  active: string;
}

export function createRateFactorSet(params: Partial<RateFactorSet>) {
  return {
    id: null,
    rateFactorSetName: null,
    description: null,
    active: null,
    ...params,
  } as RateFactorSet;
}
