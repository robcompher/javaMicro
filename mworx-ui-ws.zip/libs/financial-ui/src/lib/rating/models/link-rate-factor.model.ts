import { ID } from '@datorama/akita';
import { RateFactor } from './ratefactor.model';

export interface LnkRateFactor {
  linkId: ID;
  rateFactor: RateFactor;
  rfId: number;
  rfsId: number;
}

export function createLnkRateFactor(params: Partial<LnkRateFactor>) {
  return {
    linkId: null,
    rfId: null,
    rfsId: null,
    rateFactor: null,
    ...params,
  } as LnkRateFactor;
}
