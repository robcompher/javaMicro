import { ID } from '@datorama/akita';
import { SearchCriteria } from '@mworx/grid';

export interface RateFactorSearchCriteria extends SearchCriteria {
  rateFactorType: number;
  rateFactorName: string;
  rateLevel: number;
  active: string;
  rfsId: ID;
}
