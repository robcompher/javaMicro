export * from './components/ratefactor-add-edit.component';
export * from './ratefactor-add-edit.module';
