import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RateFactorAddEditComponent } from './ratefactor-add-edit.component';

describe('RateFactorAddEditComponent', () => {
  let component: RateFactorAddEditComponent;
  let fixture: ComponentFixture<RateFactorAddEditComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [RateFactorAddEditComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RateFactorAddEditComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
