import { HttpErrorResponse } from '@angular/common/http';
import { Component, Inject, OnInit, ViewChild } from '@angular/core';
import { FormBuilder, FormGroup, FormGroupDirective, Validators } from '@angular/forms';
import { MatOptionSelectionChange } from '@angular/material/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ConfigService } from '@common/config';
import { ID } from '@datorama/akita';
import { LibList, LookupService, Tier } from '@mworx/lookup';
import { AppInjector, ErrorService, NotificationService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable, of } from 'rxjs';
import { catchError, filter } from 'rxjs/operators';
import { RateFactorService } from '../../services/ratefactor.service';

@UntilDestroy({ checkProperties: true })
@Component({
  selector: 'financial-ratefactor-add-edit',
  templateUrl: './ratefactor-add-edit.component.html',
  styleUrls: ['./ratefactor-add-edit.component.scss'],
})
export class RateFactorAddEditComponent implements OnInit {
  rateFactorAddForm: FormGroup;
  @ViewChild('rateFactorAddFormDirective')
  rateFactorAddFormDirective: FormGroupDirective;
  rateFactorTypes$: Observable<Array<LibList>>;
  rateLevels$: Observable<Array<LibList>>;
  genderList$: Observable<Array<LibList>>;
  tiers$: Observable<Array<Tier>>;

  id: ID;
  pageTitle: string;
  buttonVisibility: boolean;
  rateFactorType: string;
  action: string;
  rateFactorTypeSelectionReset = {
    area: null,
    minAge: null,
    maxAge: null,
    smoker: 'N',
    genderLibListValue: null,
    tierLibListValue: null,
  };
  refreshParent = false;

  private fb: FormBuilder;
  private errorService: ErrorService;
  private notifyService: NotificationService;
  private configService: ConfigService;
  private lookupService: LookupService;
  private rateFactorService: RateFactorService;
  constructor(@Inject(MAT_DIALOG_DATA) public data, private dialogRef: MatDialogRef<RateFactorAddEditComponent>) {
    this.fb = AppInjector.get(FormBuilder);
    this.errorService = AppInjector.get(ErrorService);
    this.notifyService = AppInjector.get(NotificationService);
    this.configService = AppInjector.get(ConfigService);
    this.lookupService = AppInjector.get(LookupService);
    this.rateFactorService = AppInjector.get(RateFactorService);
  }

  ngOnInit(): void {
    this.pageTitle = this.data.actionType + ' Rate Factor';
    if (this.data.rowData) {
      this.pageTitle = this.pageTitle + (this.data.rowData.rateFactorName ? ' : ' + this.data.rowData.rateFactorName : '');
      this.id = Number(this.data.rowData.id);
    } else {
      this.id = null;
    }
    this.initForm();
    this.initData();
    if (this.data.actionType === 'View') {
      this.rateFactorAddForm.disable();
      this.buttonVisibility = false;
    } else {
      this.rateFactorAddForm.enable();
      this.buttonVisibility = true;
    }
    this.id ? (this.action = 'updated') : (this.action = 'created');
  }

  initForm() {
    this.rateLevels$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.rateLevel'));
    this.rateFactorTypes$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.rateFactorType'));
    this.genderList$ = this.lookupService.getLibListByCategory(this.configService.get('metadata.constants.categories.gender'));

    this.rateFactorAddForm = this.fb.group({
      rateLevel: [null, Validators.required],
      rateFactorType: [null, Validators.required],
      description: [],
      active: ['Y'],
      area: [],
      minAge: [],
      maxAge: [],
      smoker: ['N'],
      genderLibListValue: [],
      tierLibListValue: [],
      factorValue: [null],
      factorValueInPercentage: [null]
    });
    this.updateValueValidity(['area', 'minAge', 'maxAge', 'smoker', 'genderLibListValue', 'tierLibListValue'], 'rateFactorType');
  }

  private updateValueValidity(subscribeArray: Array<string>, fieldToUpdate: string) {
    for (const value of subscribeArray) {
      this.rateFactorAddForm.get(value).valueChanges.subscribe(() => this.rateFactorAddForm.get(fieldToUpdate).updateValueAndValidity());
    }
  }

  initData() {
    this.rateFactorType = null;
    if (this.id) {
      this.rateFactorService
        .getRateFactorById(this.id)
        .pipe(
          untilDestroyed(this),
          filter(response => response != null)
        )
        .subscribe(response => {
          this.rateFactorAddForm.patchValue(response);
          this.lookupService
            .getLibListByCategoryAndId(this.configService.get('metadata.constants.categories.rateFactorType'), response.rateFactorType)
            .pipe(
              untilDestroyed(this),
              filter(libList => libList != null)
            )
            .subscribe(libList => {
              this.rateFactorType = libList.value.toString().toLowerCase();
              this.setOrClearValidators(this.getFormFieldValidatorsForFactorType(this.rateFactorType), 'set');
            });
        });
    } else if (this.rateFactorAddFormDirective) {
      this.rateFactorAddFormDirective.resetForm({ active: 'Y', smoker: 'N' });
    }
    this.lookupService
      .getAllTiers()
      .pipe(
        untilDestroyed(this),
        filter(response => response != null)
      )
      .subscribe(response => {
        this.tiers$ = of(response);
      });
  }

  onSubmit() {
    if (this.rateFactorAddForm.invalid) {
      return;
    }

    const rateFactorAddFormRequest = this.rateFactorAddForm.value;
    rateFactorAddFormRequest.id = this.id;

    this.rateFactorService
      .addOrUpdateRateFactor(rateFactorAddFormRequest)
      .pipe(
        untilDestroyed(this),
        catchError((response: HttpErrorResponse) => {
          return this.errorService.handleValidationErrors(this.rateFactorAddForm, response);
        })
      )
      .subscribe(resp => {
        this.refreshParent = true;
        this.notifyService.showSuccess(
          this.configService.get('defaultMessages.actionResponse')(this.action, 'Rate Factor', resp.rateFactorName ? resp.rateFactorName : 'Unknown')
        );
        this.onReset();
      });
  }

  onReset() {
    this.setOrClearValidators(this.getFormFieldValidatorsForFactorType(this.rateFactorType), 'clear');
    this.initData();
  }

  closePopup(): void {
    this.dialogRef.close(this.refreshParent);
  }

  setOrClearValidators(validatorArray: Array<string>, action: string) {
    for (const value of validatorArray) {
      if (action === 'set') {
        this.rateFactorAddForm.get(value).setValidators([Validators.required]);
      } else {
        this.rateFactorAddForm.get(value).clearValidators();
      }
    }
  }

  getFormFieldValidatorsForFactorType(formField: string): Array<string> {
    if (formField === 'agegroup') {
      return ['minAge', 'maxAge'];
    } else if (formField === 'area') {
      return ['area'];
    } else if (formField === 'gender') {
      return ['genderLibListValue'];
    } else if (formField === 'tier') {
      return ['tierLibListValue'];
    } else if (formField === 'riskpop') {
      return ['smoker'];
    } else {
      return [];
    }
  }

  selectionChange(value: string, event: MatOptionSelectionChange) {
    if (event.source.selected && value) {
      if (event.isUserInput && this.rateFactorType && this.rateFactorType !== value.toLowerCase()) {
        this.setOrClearValidators(this.getFormFieldValidatorsForFactorType(this.rateFactorType), 'clear');
        const customReset = Object.assign({}, this.rateFactorTypeSelectionReset);
        this.rateFactorAddForm.patchValue(customReset, { emitEvent: false });
      }
      this.rateFactorType = value.toLowerCase();
      this.setOrClearValidators(this.getFormFieldValidatorsForFactorType(this.rateFactorType), 'set');
    }
  }
}
