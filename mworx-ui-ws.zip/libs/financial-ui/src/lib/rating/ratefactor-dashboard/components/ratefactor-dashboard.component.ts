import { Component, OnInit } from '@angular/core';
import { MatTabChangeEvent } from '@angular/material/tabs';
import { EventService } from '@mworx/util';

@Component({
  selector: 'financial-ratefactor-dashboard',
  templateUrl: './ratefactor-dashboard.component.html',
  styleUrls: ['./ratefactor-dashboard.component.scss'],
})
export class RatefactorDashboardComponent implements OnInit {
  tabs = [];
  loadedStatus: Array<number>;
  pageTitle: string;
  showSaveAndResetButtons = true;
  tabIndex = 0;

  constructor(private eventService: EventService) {}

  ngOnInit() {
    this.loadedStatus = new Array<number>();
    this.initTabs();
    //default load first tab
    this.loadedStatus.push(0);
  }

  protected initTabs() {
    this.tabs.push({
      tabName: 'Rate Factor',
      index: 0,
      content: import('../../ratefactor/components/ratefactor.component').then(({ RatefactorComponent }) => RatefactorComponent),
    });
    this.tabs.push({
      tabName: 'Factor Sets',
      index: 1,
      content: import('../../ratefactorset/components/ratefactorset.component').then(({ RatefactorsetComponent }) => RatefactorsetComponent),
    });
    this.loadedStatus.push(0);
  }

  onTabChange(tabChangeEvent: MatTabChangeEvent): void {
    this.tabIndex = tabChangeEvent.index;
    if (this.loadedStatus.indexOf(tabChangeEvent.index) === -1) {
      this.loadedStatus.push(tabChangeEvent.index);
    }
  }

  whichForm(tabName: string): string {
    if (tabName === 'Rate Factor') return 'rateFactorEventForm';
    if (tabName === 'Factor Sets') return 'rateFactorSetEventForm';

    return tabName;
  }

  onResetRateForm($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onResetSearchForm', formName);
    }
  }

  onSearch($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onOpenSearchForm', formName);
    }
  }

  onAdd($event) {
    if ($event) {
      const formName = this.whichForm(this.tabs[this.tabIndex].tabName);
      this.eventService.dispatch('onOpenAddForm', formName);
    }
  }
}
