import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RatefactorDashboardComponent } from './ratefactor-dashboard.component';

describe('RatefactorDashboardComponent', () => {
  let component: RatefactorDashboardComponent;
  let fixture: ComponentFixture<RatefactorDashboardComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RatefactorDashboardComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RatefactorDashboardComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
