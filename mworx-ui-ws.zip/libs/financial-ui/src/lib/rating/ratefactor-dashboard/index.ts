export * from './components/ratefactor-dashboard.component';
export * from './ratefactor-dashboard.module';
