import { HttpClient } from '@angular/common/http';
import { Injectable, OnDestroy } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse, withTransaction } from '@datorama/akita';
import { GridPaginatorPlugin } from '@mworx/grid';
import { AppInjector } from '@mworx/util';
import { Observable } from 'rxjs';
import { map, switchMap, tap } from 'rxjs/operators';
import { LnkRateFactor } from '../models/link-rate-factor.model';
import { RateFactorSearchCriteria } from '../models/ratefactor-search.model';
import { RateFactor } from '../models/ratefactor.model';
import { LnkRateFactorSearchCriteria } from '../state/lnk-ratefactor-search-criteria.model';
import { LnkRateFactorSearchQuery } from '../state/lnk-ratefactor-search-query';
import { LnkRateFactorSearchStore } from '../state/lnk-ratefactor-search.store';
import { RateFactorSearchStore } from '../state/ratefactor-search.store';
import { RateFactorQuery } from '../state/ratefactor.query';
import { RateFactorStore } from '../state/ratefactor.store';

@Injectable({
  providedIn: 'root',
})
export class RateFactorService implements OnDestroy {
  private lnkRateFactorSearchStores = new Map();
  private rateFactorSearchStore: RateFactorSearchStore;
  private httpClient: HttpClient;
  private configService: ConfigService;
  private rateFactorQuery: RateFactorQuery;
  private rateFactorStore: RateFactorStore;

  constructor() {
    this.rateFactorSearchStore = AppInjector.get(RateFactorSearchStore);
    this.httpClient = AppInjector.get(HttpClient);
    this.configService = AppInjector.get(ConfigService);
    this.rateFactorQuery = AppInjector.get(RateFactorQuery);
    this.rateFactorStore = AppInjector.get(RateFactorStore);
  }

  public search(): Observable<PaginationResponse<RateFactor>> {
    const criteria = { ...this.rateFactorSearchStore.getValue().ui.filters };

    return this.httpClient
      .post<PaginationResponse<RateFactor>>(this.configService.get('financial.constants.url.getRateFactorsBySearchCriteria'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<RateFactor>;
        })
      );
  }

  private createSearchState(rfsId: number) {
    const store = new LnkRateFactorSearchStore(rfsId);
    const query = new LnkRateFactorSearchQuery(store);
    const paginatorRef = new GridPaginatorPlugin(query);
    const state = { store, query, paginatorRef };
    this.lnkRateFactorSearchStores.set(rfsId, state);

    return state;
  }

  getSearchState(rfsId: number) {
    let state = this.lnkRateFactorSearchStores.get(rfsId);
    if (!state) {
      state = this.createSearchState(rfsId);
    }

    return state;
  }

  public searchLinkRateFactors(rfsId: number): Observable<PaginationResponse<LnkRateFactor>> {
    const criteria = this.getSearchState(rfsId).store.getValue().ui.filters;

    return this.httpClient
      .post<PaginationResponse<LnkRateFactor>>(this.configService.get('financial.constants.url.getRateFactorLinksBySearchCriteria'), criteria)
      .pipe(
        map(searchResponse => {
          return {
            currentPage: criteria.pagination.page + 1,
            perPage: criteria.pagination.pageSize,
            lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
            ...searchResponse,
          } as PaginationResponse<LnkRateFactor>;
        })
      );
  }

  public updateLnkRateFactorSearchCriteria(criteria: LnkRateFactorSearchCriteria) {
    const lnkRateFactorSearchStore = this.getSearchState(criteria.rfsId).store;
    const prevCriteria = lnkRateFactorSearchStore.getValue().ui.filters;
    lnkRateFactorSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public updateSearchCriteria(criteria: RateFactorSearchCriteria) {
    const prevCriteria = this.rateFactorSearchStore.getValue().ui.filters;
    this.rateFactorSearchStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  public getRateFactorById(id: ID): Observable<RateFactor> {
    return this.rateFactorQuery.selectEntity(id).pipe(
      switchMap(cacheEntry => {
        const apiCall = this.httpClient
          .post<any>(this.configService.get('financial.constants.url.getByRateFactorId'), { id: id })
          .pipe(
            withTransaction(response => {
              if (response) {
                this.rateFactorStore.upsert(id, response);
                this.rateFactorStore.setHasCache(true);
              }
            }),
            switchMap(res => this.rateFactorQuery.selectEntity(id))
          );

        return cacheEntry ? this.rateFactorQuery.selectEntity(id) : apiCall;
      })
    );
  }

  public addOrUpdateRateFactor(rateFactorDTO: RateFactor): Observable<any> {
    if (this.rateFactorQuery.hasEntity(rateFactorDTO.id) && Boolean(rateFactorDTO.id)) {
      return this.httpClient.put<RateFactor>(this.configService.get('financial.constants.url.rateFactor'), rateFactorDTO).pipe(
        tap(currentRateFactor => {
          this.rateFactorStore.upsert(currentRateFactor.id, currentRateFactor);
          this.rateFactorSearchStore.upsert(currentRateFactor.id, currentRateFactor);
        })
      );
    } else {
      return this.httpClient.post<RateFactor>(this.configService.get('financial.constants.url.rateFactor'), rateFactorDTO).pipe(
        tap(currentRateFactor => {
          this.rateFactorStore.upsert(currentRateFactor.id, currentRateFactor);
          this.rateFactorSearchStore.upsert(currentRateFactor.id, currentRateFactor);
        })
      );
    }
  }

  public addLinkRateFactorSet(linkRateFactor: LnkRateFactor): Observable<LnkRateFactor> {
    return this.httpClient.post<LnkRateFactor>(this.configService.get('financial.constants.url.addLinkRateFactor'), linkRateFactor);
  }

  public deleteByID(id: ID): Observable<any> {
    return this.httpClient
      .put<any>(this.configService.get('financial.constants.url.deleteByRateFactorId'), { id: id })
      .pipe(
        tap(resp => {
          this.rateFactorSearchStore.remove(id);
          this.rateFactorStore.remove(id);
        })
      );
  }

  getRateFactors(rateFactorName: string): Observable<RateFactor[]> {
    const data = {
      rateFactorName,
    };

    return this.httpClient.post<RateFactor[]>(this.configService.get('financial.constants.url.getActiveRateFactors'), data).pipe(map(res => res));
  }

  ngOnDestroy() {
    Array.from(this.lnkRateFactorSearchStores.values()).forEach(v => {
      v.store.destroy();
      v.paginatorRef.destroy();
    });

    this.lnkRateFactorSearchStores.clear();
  }
}
