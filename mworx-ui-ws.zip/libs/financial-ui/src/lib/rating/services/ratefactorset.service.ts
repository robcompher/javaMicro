import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { ConfigService } from '@common/config';
import { ID, PaginationResponse } from '@datorama/akita';
import { EventService } from '@mworx/util';
import { Observable, Subject } from 'rxjs';
import { map, switchMap } from 'rxjs/operators';

import { RateFactorSet } from '../models/ratefactorset.model';
import { RateFactorSetSearchCriteria } from '../state/ratefactor-search-criteria.model';
import { RateFactorSetQuery } from '../state/ratefactorset.query';
import { RateFactorSetStore } from '../state/ratefactorset.store';

@Injectable({ providedIn: 'root' })
export class RateFactorSetService {
  constructor(
    private rateFactorSetStore: RateFactorSetStore,
    private rateFactorSetQuery: RateFactorSetQuery,
    private http: HttpClient,
    private configService: ConfigService,
    private eventService: EventService
  ) {}
  ratefactorSetSearchCriteria: RateFactorSetSearchCriteria;
  onRateFactorSetFormReset = new Subject<void>();

  search(): Observable<PaginationResponse<RateFactorSet>> {
    const criteria = this.rateFactorSetStore.getValue().ui.filters;

    return this.http.post<PaginationResponse<RateFactorSet>>(this.configService.get('financial.constants.url.ratingSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.page,
          perPage: criteria.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pageSize),
          ...searchResponse,
        } as PaginationResponse<RateFactorSet>;
      })
    );
  }

  updateSearchCriteria(criteria: RateFactorSetSearchCriteria) {
    const prevCriteria = this.rateFactorSetStore.getValue().ui.filters;
    this.rateFactorSetStore.update({ ui: { filters: { ...prevCriteria, ...criteria } } });
  }

  addOrUpdateRateFactorSet(rateFactorSet: RateFactorSet): Observable<RateFactorSet> {
    let url = this.configService.get('financial.constants.url.addRateFactorSet');
    if (rateFactorSet.id) {
      url = this.configService.get('financial.constants.url.updateRateFactorSet');

      return this.http.put<RateFactorSet>(url, rateFactorSet).pipe(
        switchMap(response => {
          return this.updateStore(response);
        })
      );
    }

    return this.http.post<RateFactorSet>(url, rateFactorSet).pipe(
      switchMap(response => {
        return this.updateStore(response);
      })
    );
  }

  deleteRateFactorSet(id: ID) {
    return this.http.put(this.configService.get('financial.constants.url.deleteRateFactorSet'), { id: id }).pipe(
      map(response => {
        this.rateFactorSetStore.remove(id);
        this.resetForm();

        return response;
      })
    );
  }

  deleteLinkRateFactorSet(id: ID) {
    return this.http.put(this.configService.get('financial.constants.url.deleteLinkRateFactorSet'), { id: id }).pipe(
      map(response => {
        this.resetForm();

        return response;
      })
    );
  }

  private updateStore(response: RateFactorSet) {
    this.rateFactorSetStore.upsert(response.id, response);
    this.eventService.dispatch('onOpenSearchForm', 'rateFactorSetEventForm');

    return this.rateFactorSetQuery.selectEntity(response);
  }

  resetForm() {
    this.onRateFactorSetFormReset.next();
  }
}
