import { async, TestBed } from '@angular/core/testing';
import { FinancialUiModule } from './financial-ui.module';

describe('FinancialUiModule', () => {
  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [FinancialUiModule],
    }).compileComponents();
  }));

  it('should create', () => {
    expect(FinancialUiModule).toBeDefined();
  });
});
