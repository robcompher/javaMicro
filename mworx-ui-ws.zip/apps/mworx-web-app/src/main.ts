import { enableProdMode } from '@angular/core';
import { platformBrowserDynamic } from '@angular/platform-browser-dynamic';
import { akitaConfig, enableAkitaProdMode, persistState } from '@datorama/akita';
import { debounceTime } from 'rxjs/operators';
import { AppModule } from './app/app.module';
import { environment } from './environments/environment';

if (environment.production) {
  enableProdMode();
  enableAkitaProdMode();
}

akitaConfig({
  resettable: true,
  ttl: 3600000,
});

export const mworxStorage = persistState({
  //include: [((storeName: string) => !storeName.endsWith('-search'))],
  preStorageUpdateOperator: () => debounceTime(2000),
});

const providers = [{ provide: 'persistStorage', useValue: mworxStorage }];

platformBrowserDynamic(providers)
  .bootstrapModule(AppModule)
  // tslint:disable-next-line: no-console
  .catch(err => console.error(err));
