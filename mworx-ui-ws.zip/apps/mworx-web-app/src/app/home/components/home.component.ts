import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ConfigService } from '@common/config';
import { HeaderEventService, NavEntryConfig } from '@mworx/layout';
import { SessionQuery } from '@mworx/session';
import { Observable } from 'rxjs';

@Component({
  selector: 'mworx-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class HomeComponent implements OnInit {
  firstName$: Observable<string>;
  navItems: Array<NavEntryConfig>;
  noOfDays$: Observable<number>;
  showWarningMsg = false;
  daysToExpire: number;

  constructor(
    private authQuery: SessionQuery,
    private configService: ConfigService,
    private eventService: HeaderEventService
  ) {}

  ngOnInit(): void {
    this.firstName$ = this.authQuery.select(state => state.firstName);
    this.setPasswordExpiryInfo();
    this.navItems = this.configService.get('menuItems').filter(item => item.title !== 'Home');

    this.navItems?.forEach(navItem => {
      navItem.children?.sort((a, b) => a.title?.localeCompare(b.title));
    });
  }

  showChangePasswordDialog() {
    this.eventService.emitMyProfileClickedEvent(true);
  }

  private setPasswordExpiryInfo(): void {
    this.noOfDays$ = this.authQuery.noOfDaysToPasswordExpire$;
    this.noOfDays$.subscribe(daysToExpire => {
      if (daysToExpire != null && daysToExpire <= this.configService.get('auth.constants.passwordWarnDays')) {
        this.showWarningMsg = true;
        this.daysToExpire = daysToExpire;
      }
    });
  }
}
