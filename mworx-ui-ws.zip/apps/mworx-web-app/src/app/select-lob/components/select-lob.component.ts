import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ListChoice, LookupService } from '@mworx/lookup';
import { SessionService } from '@mworx/session';
import { RequestService } from '@mworx/util';
import { UntilDestroy, untilDestroyed } from '@ngneat/until-destroy';
import { Observable } from 'rxjs';

@UntilDestroy()
@Component({
  selector: 'mworx-select-lob',
  templateUrl: './select-lob.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class SelectLobComponent implements OnInit {
  userLobs$: Observable<ListChoice[]>;

  constructor(private requestService: RequestService, private authenticationService: SessionService, private lookupService: LookupService) {}

  ngOnInit(): void {
    this.userLobs$ = this.lookupService.getUserLineOfBusinesses();
  }

  selectLob(lobValue: string) {
    this.authenticationService
      .switchLob(lobValue)
      .pipe(untilDestroyed(this))
      .subscribe(() => {
        this.requestService.navigate(['/']);
      });
  }
}
