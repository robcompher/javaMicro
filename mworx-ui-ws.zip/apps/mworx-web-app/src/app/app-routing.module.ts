import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AppLayoutComponent } from '@mworx/layout';
import { AuthGuard } from '@mworx/session';
import { AccessDeniedComponent } from './access-denied/access-denied.component';
import { SwaggerUiComponent } from './api-docs/components/swagger-ui.component';
import { HomeComponent } from './home/components/home.component';
import { LogConfigComponent } from './log-config/components/log-config.component';
import { LoginPageComponent } from './login/components/login-page.component';
import { MasterDetailComponent } from './master-detail/master-detail.component';
import { PasswordExpireComponent } from './password-expire/components/password-expire.component';
import { SelectLobComponent } from './select-lob/components/select-lob.component';

const routes: Routes = [
  // App routes goes here here
  {
    path: 'auth',
    component: AppLayoutComponent,
    loadChildren: () => import('@mworx/auth-ui').then(m => m.AuthUiModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'staging',
    component: AppLayoutComponent,
    loadChildren: () => import('@mworx/staging-ui').then(m => m.StagingUiModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'metadata',
    component: AppLayoutComponent,
    loadChildren: () => import('@mworx/metadata-ui').then(m => m.MetadataUiModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'workflow',
    component: AppLayoutComponent,
    loadChildren: () => import('@mworx/workflow-ui').then(m => m.WorkflowUiModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'membership',
    component: AppLayoutComponent,
    loadChildren: () => import('@mworx/membership-ui').then(m => m.MembershipUiModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'api-docs',
    component: AppLayoutComponent,
    children: [{ path: '', component: SwaggerUiComponent }],
    canActivate: [AuthGuard],
  },
  {
    path: 'master-detail',
    component: AppLayoutComponent,
    children: [{ path: '', component: MasterDetailComponent }],
    canActivate: [AuthGuard],
  },
  {
    path: 'financial',
    component: AppLayoutComponent,
    loadChildren: () => import('@mworx/financial-ui').then(m => m.FinancialUiModule),
    canActivate: [AuthGuard],
  },
  {
    path: 'correspondence',
    component: AppLayoutComponent,
    loadChildren: () => import('@mworx/correspondence-ui').then(m => m.CorrespondenceUiModule),
    canActivate: [AuthGuard],
  },
  { path: '', component: HomeComponent, canActivate: [AuthGuard] },
  { path: 'login', component: LoginPageComponent },
  { path: 'password-expire', component: PasswordExpireComponent },
  { path: 'select-lob', component: SelectLobComponent },
  { path: 'log-config', component: LogConfigComponent },
  { path: 'restricted', component: AppLayoutComponent, children: [{ path: '', component: AccessDeniedComponent }] },

  // otherwise redirect to home
  { path: '**', redirectTo: '' },
];

@NgModule({
  imports: [RouterModule.forRoot(routes, { useHash: true })],
  exports: [RouterModule],
})
export class AppRoutingModule {}
