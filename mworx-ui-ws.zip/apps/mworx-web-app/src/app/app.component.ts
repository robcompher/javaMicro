import { coerceBooleanProperty } from '@angular/cdk/coercion';
import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatInput } from '@angular/material/input';
import { MatSelect } from '@angular/material/select';
import { HeaderEventService } from '@mworx/layout';
import { Subscription } from 'rxjs';

@Component({
  selector: 'mworx-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AppComponent implements OnInit, OnDestroy {
  private subscription: Subscription;

  constructor(public dialog: MatDialog, private eventService: HeaderEventService) {}

  ngOnDestroy(): void {
    this.subscription.unsubscribe();
  }

  ngOnInit() {
    this.subscription = this.eventService.myProfileClickedEventListener().subscribe(open => {
      if (open) this.openMyProfile();
    });

    /**
     * Fix for the MatInput required asterisk. (see https://github.com/angular/components/issues/2574#issuecomment-486656158)
     */
    const requiredImplementation = {
      get: function (): boolean {
        if (this._required) {
          return this._required;
        }

        // The required attribute is set
        // when the control return an error from validation with an empty value
        if (this.ngControl && this.ngControl.control && this.ngControl.control.validator) {
          const emptyValueControl = Object.assign({}, this.ngControl.control);
          (emptyValueControl as any).value = null;

          return 'required' in (this.ngControl.control.validator(emptyValueControl) || {});
        }

        return false;
      },
      set: function (value: boolean) {
        this._required = coerceBooleanProperty(value);
      },
    };
    Object.defineProperty(MatInput.prototype, 'required', requiredImplementation);
    Object.defineProperty(MatSelect.prototype, 'required', requiredImplementation);
  }

  async openMyProfile() {
    const { UserProfileComponent } = await import('@mworx/auth-ui');
    this.dialog.open(UserProfileComponent, {
      width: '60%',
      data: {},
    });
  }
}
