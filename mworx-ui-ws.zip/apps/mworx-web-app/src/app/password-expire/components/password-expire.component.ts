import { OnInit, ViewChild } from '@angular/core';
import { Component, ComponentFactoryResolver, ViewContainerRef, ViewEncapsulation } from '@angular/core';
import { EventService } from '@mworx/util';

@Component({
  selector: 'mworx-password-expire',
  templateUrl: './password-expire.component.html',
  encapsulation: ViewEncapsulation.None,
})
export class PasswordExpireComponent implements OnInit {
  @ViewChild('changePwdContainer', { read: ViewContainerRef, static: true })
  viewContainerRef: ViewContainerRef;

  constructor(private cfr: ComponentFactoryResolver, private eventService: EventService) {}

  ngOnInit(): void {
    this.getPasswordComp();
  }

  async getPasswordComp() {
    this.viewContainerRef.clear();
    const { ChangePasswordComponent } = await import('@mworx/auth-ui');
    const componentFactory = this.cfr.resolveComponentFactory(ChangePasswordComponent);
    const compRef = this.viewContainerRef.createComponent(componentFactory);
    compRef.instance.passwordExpired = true;
  }

  onSave() {
    this.eventService.dispatch('submitPasswordChange', 'expired');
  }
}
