import { AfterViewInit, Component, ElementRef, OnDestroy, ViewEncapsulation } from '@angular/core';
import { SessionService } from '@mworx/session';
import { SwaggerUIBundle, SwaggerUIStandalonePreset } from 'swagger-ui-dist';
import { ApiDocsService } from '../services/api-docs.service';

@Component({
  selector: 'mworx-swagger-ui',
  templateUrl: './swagger-ui.component.html',
  styleUrls: ['./swagger-ui.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class SwaggerUiComponent implements AfterViewInit, OnDestroy {
  constructor(private apiDocsService: ApiDocsService, private session: SessionService, private element: ElementRef) {}

  ngAfterViewInit(): void {
    this.attachSwaggerUiComponent();
  }

  ngOnDestroy(): void {
    this.element.nativeElement.querySelector('#swagger-ui').remove();
  }

  async getSwaggerConfig(): Promise<any> {
    return this.apiDocsService.getSwaggerConfig().toPromise();
  }

  async attachSwaggerUiComponent() {
    const swaggerSpec = await this.getSwaggerConfig();
    const urls: Array<object> = swaggerSpec['urls'];

    const me = this;

    const ui = SwaggerUIBundle({
      dom_id: '#swagger-ui',
      presets: [SwaggerUIBundle.presets.apis, SwaggerUIStandalonePreset],
      urls: urls,
      docExpansion: 'none',
      operationsSorter: 'alpha',
      validatorUrl: 'none',
      layout: 'StandaloneLayout',
      plugins: [SwaggerUIBundle.plugins.DownloadUrl],
      responseInterceptor: function(response) {
        if (response) {
          if (response.status === 401) {
            me.session.refreshAccessToken().subscribe(data => ui.preauthorizeApiKey('bearer-jwt', me.session.getAccessToken()));
          }
        }

        return response;
      },
      onComplete: function() {
        ui.preauthorizeApiKey('bearer-jwt', me.session.getAccessToken());
        me.element.nativeElement.querySelectorAll('.information-container')[0].parentElement.classList.add('wrapper');
      },
    });
  }
}
