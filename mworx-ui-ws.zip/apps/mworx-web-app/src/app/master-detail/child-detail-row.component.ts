import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { ConfigService } from '@common/config';
import { PaginationResponse } from '@datorama/akita';
import { DetailRowComponent } from '@mworx/grid';
import { GridApi, GridOptions } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Component({
  selector: 'mworx-detail-cell',
  templateUrl: './child-detail-row.component.html',
})
export class ChildDetailRowComponent implements OnInit, DetailRowComponent {
  @Input() parentRowParams: any;

  gridOptions: GridOptions;
  paginatorRef: Function;
  rowData: any;
  gridApi: GridApi;

  constructor(private httpClient: HttpClient, private configService: ConfigService) {
    this.gridOptions = <GridOptions>{
      pagination: false,
      onGridReady: function(params) {
        this.gridApi = params.api;
      },
    };

    this.gridOptions.columnDefs = [
      {
        headerName: 'Username',
        field: 'userName',
      },
      { headerName: 'First Name', field: 'firstName' },
      { headerName: 'Last Name', field: 'lastName' },
      { headerName: 'Active', field: 'active' },
    ];
  }

  ngOnInit(): void {
    this.paginatorRef = () => this.getData();
  }

  getData(): Observable<PaginationResponse<any>> {
    const criteria = {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'userName',
        sortOrder: 'asc',
      },
      firstName: null,
      lastName: null,
      userName: null,
      loggedInUsers: false,
      active: 'Y',
    };

    return this.httpClient.post<PaginationResponse<any>>(this.configService.get('auth.constants.url.userSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<any>;
      })
    );
  }
}
