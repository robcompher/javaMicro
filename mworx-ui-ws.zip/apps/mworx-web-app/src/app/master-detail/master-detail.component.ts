import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { ConfigService } from '@common/config';
import { PaginationResponse } from '@datorama/akita';
import { GridApi, GridOptions } from 'ag-grid-community';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { ChildDetailRowComponent } from './child-detail-row.component';

@Component({
  selector: 'mworx-master-detail',
  templateUrl: './master-detail.component.html',
  styleUrls: ['./master-detail.component.scss'],
})
export class MasterDetailComponent implements OnInit {
  gridOptions: GridOptions;
  paginatorRef: Function;
  rowData: any;
  gridApi: GridApi;
  detailRowComponent = ChildDetailRowComponent;

  constructor(private httpClient: HttpClient, private configService: ConfigService) {
    this.gridOptions = <GridOptions>{
      masterDetail: true,
      onGridReady: function(params) {
        this.gridApi = params.api;
      },
      //detailRowHeight: 500
    };

    this.gridOptions.columnDefs = [
      {
        headerName: 'Username',
        field: 'userName',
        cellRenderer: 'expandCollapseCellRenderer'
      },
      { headerName: 'First Name', field: 'firstName' },
      { headerName: 'Last Name', field: 'lastName' },
      { headerName: 'Active', field: 'active' },
    ];
  }

  ngOnInit(): void {
    this.paginatorRef = () => this.getData();
  }

  getData(): Observable<PaginationResponse<any>> {
    const criteria = {
      pagination: {
        page: 0,
        pageSize: 10,
        sortBy: 'userName',
        sortOrder: 'asc',
      },
      firstName: null,
      lastName: null,
      userName: null,
      loggedInUsers: false,
      active: 'Y',
    };

    return this.httpClient.post<PaginationResponse<any>>(this.configService.get('auth.constants.url.userSearch'), criteria).pipe(
      map(searchResponse => {
        return {
          currentPage: criteria.pagination.page + 1,
          perPage: criteria.pagination.pageSize,
          lastPage: Math.ceil(searchResponse.total / criteria.pagination.pageSize),
          ...searchResponse,
        } as PaginationResponse<any>;
      })
    );
  }
}
