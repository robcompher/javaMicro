import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { ConfigService } from '@common/config';
import { Creds, KeepAliveService, SessionService, SessionTimerConnection } from '@mworx/session';
import { ErrorService, NotificationService, RequestService } from '@mworx/util';
import { NGXLogger } from 'ngx-logger';
import { of } from 'rxjs';
import { catchError } from 'rxjs/operators';

@Component({
  selector: 'mworx-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class LoginComponent implements OnInit {
  loginForm: FormGroup;
  returnUrl: string;
  loading = false;
  error = '';

  constructor(
    private fb: FormBuilder,
    private requestService: RequestService,
    private authService: SessionService,
    private logger: NGXLogger,
    private errorService: ErrorService,
    private keepAliveService: KeepAliveService,
    private sessionTimerConnection: SessionTimerConnection,
    private notifyService: NotificationService,
    private configService: ConfigService
  ) {}

  ngOnInit(): void {
    this.loginForm = this.fb.group({
      username: new FormControl('', [Validators.required]),
      password: ['', Validators.required],
    });

    // get return url from route parameters or default to '/'
    this.returnUrl = this.requestService.getQueryParams['returnUrl'] || '/';
  }

  submit() {
    this.logger.debug('this.loginForm.invalid', this.loginForm.invalid);
    // stop here if form is invalid
    if (this.loginForm.invalid) {
      return;
    }
    this.loading = true;
    this.authService
      .login(this.loginForm.value as Creds)
      .pipe(
        catchError((error: HttpErrorResponse) => {
          this.loading = false;
          if ([401, 403, 400].indexOf(error.status) !== -1) {
            this.error = this.errorService.getServerMessage(error);

            return of();
          }

          return this.errorService.handleValidationErrors(this.loginForm, error);
        })
      )
      .subscribe(() => this.onLoginSuccess());
  }

  onLoginSuccess() {
    if (this.authService.currentUser().lineOfBusinesses && this.authService.currentUser().lineOfBusinesses.length <= 0) {
      this.notifyService.showError(this.configService.get('auth.messages.errors.noLobConfig'));

      return;
    }

    this.loading = false;
    // Subscribing the events to keep alive the session or logout based on idle timeout.
    this.sessionTimerConnection.subscribeSessionTimeoutEventBus();
    /**
     * Setting the allowed idle time to be ten minutes and displays the warning popup
     * in last two minutes by giving the option of continue the session or logout.
     * If user is not responded then it will automatically logout the user after this time.
     */
    this.keepAliveService.startBeingAlive(600);
    this.requestService.navigate([this.returnUrl]);
  }
}
