import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ErrorHandler, Injector, NgModule } from '@angular/core';
import { ReactiveFormsModule } from '@angular/forms';
import { MatMomentDateModule, MAT_MOMENT_DATE_ADAPTER_OPTIONS, MomentDateAdapter } from '@angular/material-moment-adapter';
import { DateAdapter, MAT_DATE_FORMATS, MAT_DATE_LOCALE } from '@angular/material/core';
import { MAT_DIALOG_DEFAULT_OPTIONS } from '@angular/material/dialog';
import { MatFormFieldDefaultOptions, MAT_FORM_FIELD_DEFAULT_OPTIONS } from '@angular/material/form-field';
// Depending on whether rollup is used, moment needs to be imported differently.
// Since Moment.js doesn't have a default export, we normally need to import using the `* as`
// syntax. However, rollup creates a synthetic default module and we thus need to import it using
// the `default as` syntax.
import { MatSelectConfig, MAT_SELECT_CONFIG } from '@angular/material/select';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { ConfigModule } from '@common/config';
import { AkitaNgRouterStoreModule } from '@datorama/akita-ng-router-store';
import { AkitaNgDevtools } from '@datorama/akita-ngdevtools';
import { SharedUiFormsModule } from '@mworx/forms';
import { SharedUiGridModule } from '@mworx/grid';
import { SharedUiLayoutModule } from '@mworx/layout';
import { LoaderInterceptor, SharedUiLoaderModule } from '@mworx/loader';
import {
  BaseUrlInterceptor,
  DialogService,
  GlobalErrorHandler,
  JwtInterceptor,
  ManageHttpInterceptor,
  RefreshNavStateService,
  ServerErrorInterceptor,
  setAppInjector,
  StoresResetService,
} from '@mworx/util';
import { AgGridModule } from 'ag-grid-angular';
import { LoggerModule, NgxLoggerLevel } from 'ngx-logger';
import { environment } from '../environments/environment';
import { SwaggerUiComponent } from './api-docs/components/swagger-ui.component';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/components/home.component';
import { LogConfigComponent } from './log-config/components/log-config.component';
import { LoginPageComponent } from './login/components/login-page.component';
import { LoginComponent } from './login/components/login.component';
import { ChildDetailRowComponent } from './master-detail/child-detail-row.component';
import { MasterDetailComponent } from './master-detail/master-detail.component';
import { MaterialModule } from './material.module';
import { PasswordExpireComponent } from './password-expire/components/password-expire.component';
import { SelectLobComponent } from './select-lob/components/select-lob.component';

// See the Moment.js docs for the meaning of these formats:
// https://momentjs.com/docs/#/displaying/format/
export const APP_DATE_FORMATS = {
  parse: {
    dateInput: 'MM/DD/YYYY',
  },
  display: {
    dateInput: 'MM/DD/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

const appearance: MatFormFieldDefaultOptions = {
  appearance: 'outline',
};

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    LoginPageComponent,
    LogConfigComponent,
    LoginComponent,
    PasswordExpireComponent,
    SelectLobComponent,
    SwaggerUiComponent,
    MasterDetailComponent,
    ChildDetailRowComponent,
  ],
  imports: [
    ReactiveFormsModule,
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    MaterialModule,
    MatMomentDateModule,
    BrowserAnimationsModule,
    SharedUiLayoutModule,
    SharedUiLoaderModule,
    SharedUiFormsModule,
    SharedUiGridModule,
    AgGridModule,
    AkitaNgRouterStoreModule,
    [environment.production ? [] : AkitaNgDevtools.forRoot()],
    LoggerModule.forRoot({
      level: !environment.production ? NgxLoggerLevel.DEBUG : NgxLoggerLevel.OFF,
      serverLogLevel: NgxLoggerLevel.OFF,
    }),
    ConfigModule.forRoot({
      config: environment,
    }),
  ],
  providers: [
    { provide: MAT_MOMENT_DATE_ADAPTER_OPTIONS, useValue: { useUtc: true } },
    { provide: MAT_DATE_LOCALE, useValue: 'en-US' },
    { provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS },
    { provide: DateAdapter, useClass: MomentDateAdapter, deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS] },
    { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: appearance },
    {
      provide: MAT_SELECT_CONFIG,
      useValue: {
        disableOptionCentering: true,
        typeaheadDebounceInterval: 1000,
      } as MatSelectConfig,
    },
    { provide: MAT_DIALOG_DEFAULT_OPTIONS, useValue: { autoFocus: false, panelClass: 'mat-dialog-override', hasBackdrop: true } },
    { provide: ErrorHandler, useClass: GlobalErrorHandler },
    { provide: HTTP_INTERCEPTORS, useClass: ManageHttpInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: BaseUrlInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: ServerErrorInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: JwtInterceptor, multi: true },
    { provide: HTTP_INTERCEPTORS, useClass: LoaderInterceptor, multi: true },
  ],
  bootstrap: [AppComponent],
})
export class AppModule {
  constructor(
    injector: Injector,
    private refreshNavStateService: RefreshNavStateService,
    private storeResetService: StoresResetService,
    private dialogService: DialogService
  ) {
    setAppInjector(injector);
    this.refreshNavStateService.init();
    this.storeResetService.init();
    this.dialogService.init();
  }
}
