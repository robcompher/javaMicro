export const environment = {
  auth: {
    constants: {
      systemLob: 'SYSTEM',
      passwordWarnDays: 5,
      url: {
        userSearch: '/auth/api/user/getUsers',
        userLogout: '/auth/oauth/logout',
        authenticate: '/api/user/authenticate',
        refreshToken: '/auth/oauth/token',
        userInfo: '/auth/oauth/userinfo',
        getToken: '/auth/oauth/token',
        lockUnlockUser: '/auth/api/user/lockUnlockUser',
        addUser: '/auth/api/user',
        changePassword: '/auth/api/user/changePassword',
        myprofileChangePassword: '/auth/api/user/myprofile/changePassword',
        updateUser: '/auth/api/user/updateUser',
        getUserByUserName: '/auth/api/user/getUserByUserName',
        userContact: '/auth/api/user/userContact',
        deleteUserContact: '/auth/api/user/userContact/delete',
        deleteUsername: '/auth/api/user/delete',
        role: {
          getRoleNameAndTypes: '/auth/api/role/getRoleNameAndTypes',
          roleSearch: '/auth/api/role/findBySearchCriteria',
          addRole: '/auth/api/role',
          updateRole: '/auth/api/role',
          deleteRole: '/auth/api/role/delete',
          getRoleById: '/auth/api/role/getRoleById',
          findByPermitSearchCriteria: '/auth/api/role/findByPermitSearchCriteria',
          addPermit: '/auth/api/role/permit',
          deletePermit: '/auth/api/role/permit/delete',
        },
      },
      meta: {
        categories: {
          contactType: 'CONTACTTYPE',
        },
      },
    },
    messages: {
      confirmLock: 'Are you sure you want to lock the user?',
      errors: {
        lockUnlockOwnAccount: 'Cannot lock or unlock own account',
        noLobConfig: 'No Line Business Configured for the user. Please configure line of business',
      },
      success: {
        lockUnlock: (action: string, username: string) => `Successfully ${action} the User : ${username}`,
        addOrUpdateUser: (action: string, username: string) => `Successfully ${action} the User : ${username}`,
        addOrUpdateRole: (action: string, rolename: string) => `Successfully ${action} the role : ${rolename}`,
        userContact: (action: string, contactType: string) => `Successfully ${action} the User Contact : ${contactType}`,
        delete: (type: string, info: string, secondaryInfo: string) => `Successfully deleted ${type} - ${info}:${secondaryInfo}`,
      },
    },
  },
};
