import * as AuthUI from './auth-ui';
import * as CorrespondeceUI from './correspondence-ui';
import * as FinancialUI from './financial-ui';
import * as MembershipUI from './membership-ui';
import * as MenuItems from './menu-items';
import * as MetadataUI from './metadata-ui';
import * as StagingUI from './staging-ui';
import * as WorkflowUI from './workflow-ui';

export const environment = {
  defaultErrors: {
    required: error => `This field is required`,
    minlength: ({ requiredLength, actualLength }) => `Expect ${requiredLength} but got ${actualLength}`,
    matDatepickerParse: error => 'Invalid date',
    autocompleteValueTypedIn: error => 'This field has not been selected',
    autocompleteValueNotFound: error => 'Value is not found',
  },
  defaultMessages: {
    alreadyInactive: 'Cannot delete record when it is already inactive',
    confirmDelete: 'Are you sure you want to delete?',
    actionResponse: (action: string, itemType: string, itemName: string) => `Successfully ${action} the ${itemType}: ${itemName}`,
    unExpectedError: 'Unexpected Error occurred.',
    noInternet: 'No Internet Connection',
    sessionExpired: 'Your session has expired. Please login.',
  },
  help: {
    baseUrl: '/webjars/mworx-help/MemberWoRx/CompiledHelp/MemberWoRx_HTML5/index.htm#t=',
    overviewPage: 'MemberWoRx_Overview.htm',
    homePage: 'Understanding_the_User_Inferface.htm',
    contextPage: (prefix: string, page: string) => `mergedProjects%2F${prefix}%2F${page}.htm`,
  },
  ...MenuItems.environment,
  ...AuthUI.environment,
  ...MetadataUI.environment,
  ...StagingUI.environment,
  ...WorkflowUI.environment,
  ...MembershipUI.environment,
  ...FinancialUI.environment,
  ...CorrespondeceUI.environment,
};
