export const environment = {
  correspondence: {
    constants: {
      url: {
        findBySearch: '/correspondence/api/extract',
        getAllCorrespondenceTypes: '/correspondence/api/letter/getAllLetterTypes',
        getCorrespondenceCodes: '/correspondence/api/letter/getLetterCodesByTypeAndBenefitName',
        getCorrespondenceNames: '/correspondence/api/letter/getLetterNamesByCodes',
        getBenefitNames: '/correspondence/api/letter/getBenefitNamesByType',
        scheduleCorrespondence: '/correspondence/api/request',
        letterSearch: '/correspondence/api/letter/findBySearchCriteria',
        letterDelete: '/correspondence/api/letter/delete',
        letterById: '/correspondence/api/letter/getLetterById',
        addUpdateLetter: '/correspondence/api/letter',
        tagSearch: '/correspondence/api/letterTag/findLetterTagBySearch',
        tagDelete: '/correspondence/api/letterTag/delete',
        tagById: '/correspondence/api/letterTag/getLetterTagById',
        addUpdateTag: '/correspondence/api/letterTag',
        letterTagSearch: '/correspondence/api/letter/lnkLetterTag/getLnkLetterTagsBySearchCriteria',
        letterTagDelete: '/correspondence/api/letter/lnkLetterTag/delete',
        letterTagAdd: '/correspondence/api/letter/lnkLetterTag',
        findBySearchCorrespondenceRequest: '/correspondence/api/request/findBySearchMemberRequests',
        correspondenceRequestById: '/correspondence/api/request/getMemberRequestById',
        deleteCorrespondenceRequestById: '/correspondence/api/request/deleteLetterRequest',
        tagAttributeSearch: '/correspondence/api/lnkTagAttribute/getLnkTagAttributeBySearchCriteria',
        tagAttributeDelete: '/correspondence/api/lnkTagAttribute/delete',
        getAllAttributesByTypeAndTag: '/correspondence/api/lnkTagAttribute/getAttributesByTypeAndTag',
        addTagAttributes: '/correspondence/api/lnkTagAttribute/addOrUpdateByAttributeType',
      },
      messages: {
        jobSuccess: 'Correspondence job submitted successfully',
        scheduleCorrespondenceSuccess: 'Correspondence Request scheduled successfully',
        letterMsg: (action: string, letterName: string) => `Successfully ${action} Letter : ${letterName}`,
        tagMsg: (action: string, tagName: string) => `Successfully ${action} Tag : ${tagName}`,
        correspondenceRequestMsg: (action: string) => `Successfully ${action} Correspondence Request`,
        deleteRequestMsg: 'Successfully deleted Correspondence Request',
        tagAttributeDeleteMsg: (tagName: string, libAttributeType: string, libAttributeName: string) =>
          `Successfully deleted ${libAttributeType} ${libAttributeName} for ${tagName} `,
      },
      resultName: {
        requested: 'Requested',
      },
      resultType: {
        cancelled: 'Correspondence_Cancelled',
      },
    },
  },
};
