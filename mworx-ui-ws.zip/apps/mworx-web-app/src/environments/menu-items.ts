export const environment = {
  menuItems: [
    {
      title: 'Home',
      path: '/',
      iconClass: 'material-icons-outlined',
      iconContent: 'home',
    },
    {
      title: 'Membership',
      iconClass: 'material-icons-outlined',
      iconContent: 'recent_actors',
      ignoreHeaderClick: true,
      children: [
        {
          title: 'Persons',
          path: '/membership/persons/dashboard',
        },
      ],
    },
    {
      title: 'Metadata',
      iconClass: 'material-icons-outlined',
      iconContent: 'settings',
      ignoreHeaderClick: true,
      lock: false,
      children: [
        {
          title: 'Zip Codes',
          path: '/metadata/zipcodes/dashboard',
        },
        {
          title: 'Providers',
          path: '/metadata/providers/dashboard',
        },
        {
          title: 'Business Entities',
          path: '/metadata/bizEntities/dashboard',
        },
        {
          title: 'Codes',
          path: '/metadata/codes/dashboard',
        },
        {
          title: 'Events',
          path: '/metadata/event/dashboard',
        },
        {
          title: 'ID Generators',
          path: '/metadata/idgenerator/dashboard',
        },
        {
          title: 'Groups',
          path: '/metadata/group/dashboard',
        },
        {
          title: 'Locations',
          path: '/metadata/location/dashboard',
        },
        {
          title: 'Products',
          path: '/metadata/product/dashboard',
        },
        {
          title: 'Tiers',
          path: '/metadata/tier/dashboard',
        },
        {
          title: 'Trading Partners',
          path: '/metadata/trading-partner/dashboard',
        },
        {
          title: 'Membership Filters',
          path: '/metadata/membershipfilter/dashboard',
        },
        {
          title: 'Period Cycles',
          path: '/metadata/period-cycle/dashboard',
        },
        {
          title: 'User-Defined Code Configurations',
          path: '/metadata/usercode-config/dashboard',
        },
        {
          title: 'Age Policy',
          path: '/metadata/age/dashboard',
        },
        {
          title: 'New Hire Policy',
          path: '/metadata/newhire/dashboard',
        },
        {
          title: 'Banks',
          path: '/metadata/bank/dashboard',
        },
        {
          title: 'Line Of Business',
          path: '/metadata/lob/dashboard',
        },
        {
          title: 'Ledger Accounts',
          path: '/metadata/ledger/dashboard',
        },
        {
          title: 'Receivables',
          path: '/metadata/receivable/dashboard',
        },
        {
          title: 'Welcome Kit',
          path: '/metadata/welcomeKit/dashboard',
        }
      ],
    },
    {
      title: 'Staging',
      iconClass: 'material-icons-outlined',
      iconContent: 'layers',
      ignoreHeaderClick: true,
      lock: false,
      children: [
        {
          title: 'Imports',
          path: '/staging/dashboard',
        },

        {
          title: 'Exports',
          path: '/staging/exportJobs/dashboard',
        },
      ],
    },
    {
      title: 'User Management',
      iconClass: 'material-icons-outlined',
      iconContent: 'group',
      ignoreHeaderClick: true,
      lock: false,
      children: [
        {
          title: 'Users',
          path: '/auth/users/dashboard',
        },
        {
          title: 'Roles',
          path: '/auth/roles/dashboard',
        },
      ],
    },
    {
      title: 'Workflow',
      iconClass: 'material-icons-outlined',
      iconContent: 'cached',
      ignoreHeaderClick: true,
      lock: false,
      children: [
        {
          title: 'Get WorkItem',
          path: '/workflow/workflow/dashboard',
        },
      ],
    },
    {
      title: 'Financials',
      iconClass: 'material-icons-outlined',
      iconContent: 'receipt',
      ignoreHeaderClick: true,
      lock: false,
      children: [
        {
          title: 'Invoicing Jobs',
          path: '/financial/invoice-job/dashboard',
        },
        {
          title: 'Invoices',
          path: '/financial/invoice/dashboard',
        },
        {
          title: 'Rating',
          path: '/financial/rating/dashboard',
        },
        {
          title: 'Fees',
          path: '/financial/fees/dashboard',
        },
        {
          title: 'Adjustments',
          path: '/financial/adjustment/dashboard',
        }
      ],
    },
    {
      title: 'Correspondence',
      iconClass: 'material-icons-outlined',
      iconContent: 'contact_mail',
      ignoreHeaderClick: true,
      lock: false,
      children: [
        {
          title: 'Correspondences',
          path: '/correspondence/letter/dashboard',
        },
        {
          title: 'Extract',
          path: '/correspondence/extract',
        },
        {
          title: 'Schedule',
          path: '/correspondence/schedule',
        },
        {
          title: 'Tags',
          path: '/correspondence/tag/dashboard',
        },
      ],
    },
    {
      title: 'Reports',
      iconClass: 'material-icons-outlined',
      iconContent: 'pageview',
      ignoreHeaderClick: true,
      lock: false,
      children: [],
    },
  ],
};
