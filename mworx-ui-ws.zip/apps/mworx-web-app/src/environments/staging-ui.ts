export const environment = {
  staging: {
    constants: {
      url: {
        getBatchJobNames: '/staging/api/batch/jobNames',
        getBatchJobStatuses: '/staging/api/batch/allJobStatus',
        uploadAndScheduleJob: '/staging/api/batch/import/uploadAndScheduleImportJob',
        batchJobSearch: '/staging/api/batch/findBySearchCriteria',
        jobSubmittedUsers: '/staging/api/getjobSubmittedUsers',
        errorFileDownload: '/staging/api/batch/errorReport',
        fileDownload: '/staging/api/batch/download',
        resolveAllErrorsByJobId: '/staging/api/batch/import/resolveAllRecordsByJobId',
        getViewErrors: '/staging/api/batch/import/getUnresolvedRecordsByJobId',
        getFieldDefinitions: '/staging/api/batch/import/getJobDisplayFields',
        resolveRecordByRecordId: '/staging/api/batch/import/resolveRecordByRecordId',
        getUnresolvedRecordByRecordId: '/staging/api/batch/import/getUnresolvedRecordByRecordId',
        resolveRecordErrors: '/staging/api/batch/import/resolveRecordErrors',
        resubmitJob: '/staging/api/batch/import/resubmitJob',
        getLatestErrorsByParentRecordId: '/staging/api/batch/import/getLatestErrorsByParentRecordId',
        resubmitErrorsByRecordId: '/staging/api/batch/import/resubmitErrorsByRecordId',
        correspondenceExtractJob: '/staging/api/batch/correspondence/extract',
        exportJobFileSearch: '/staging/api/batch/outputFiles',
      },
      messages: {
        jobSuccessMsg: (jobName: string, jobId: string) => `${jobName} submitted successfully. Job id is ${jobId}`,
        resubmitJobSuccessMsg: (jobName: string, jobId: string) => `${jobName} Resubmit submitted successfully. Job id is ${jobId}`,
        resolveErrorSuccessMsg: 'Error resolved successfully',
        resubmitErrorsByRecordIdSucessMsg: 'Resubmitted the errors successfully',
        noMemberShipFiltersAreFound: 'No membership filters are found',
      },
      removedJobNamesFromDisplay: ['invoiceJob', 'resubmitImportProductInfo', 'resubmitImportMembership', 'resubmitImportProviderInfo'],
    },
  },
};
