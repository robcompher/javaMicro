import * as Global from './global';

export const environment = {
  ...Global.environment,
  production: true
};
