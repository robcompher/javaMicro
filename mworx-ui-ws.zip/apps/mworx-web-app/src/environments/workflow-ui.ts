export const environment = {
  workflow: {
    constants: {
      eventId: 'UpdateMembership',
      sourceSystem: 'MWorxUI',
      url: {
        getLoggedUserWork: '/workflow/api/workflow/getWorkForLoggedInUser',
        releaseWorkItem: '/workflow/api/workflow/release',
        suspendWorkItem: '/workflow/api/workflow/suspend',
        moveWorkItem: '/workflow/api/workflow/update',
        commentsWorkItem: '/workflow/api/workflow/getComments',
        lockUnlockWorkItem: '/workflow/api/workflow/lockUnlock',
      },
      messages: {
        noWorkFound: 'No Work Found',
        released: 'Successfully Released the Item',
        suspended: 'Successfully Suspended the Item',
        moved: 'Successfully Moved the Item',
        releasing: (workflowId: string) => `You are releasing ${workflowId}`,
        suspending: (workflowId: string) => `You are suspending ${workflowId}`,
        assignUser: 'Assigning to User',
        assignSupervisor: 'Assigning to Supervisor',
        zeroHoursMins: 'Either hour or minute should be non zero',
        notEditable: 'Unable to edit as Error Record is missing',
        noErrorRecordFound: 'No Error record found',
      },
    },
  },
};
