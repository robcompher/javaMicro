package com.ssnc.health.mworx.services.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.oauth2.client.registration.InMemoryReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository;
import org.springframework.security.oauth2.jwt.ReactiveJwtDecoder;
import org.springframework.test.context.ActiveProfiles;

@SpringBootTest()
@ActiveProfiles({"test"})
class GatewayServiceApplicationTests {
  
  @Configuration
  class Config {
    @Bean
    ReactiveClientRegistrationRepository clientRegistrationRepository() {
      return new InMemoryReactiveClientRegistrationRepository();
    };
  }

  @MockBean private ServerOAuth2AuthorizedClientRepository authRepository;

  @MockBean private ReactiveJwtDecoder reactiveJwtDecoder;

  @Test
  void contextLoads() {}
}
