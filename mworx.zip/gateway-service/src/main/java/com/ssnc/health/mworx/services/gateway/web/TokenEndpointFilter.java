package com.ssnc.health.mworx.services.gateway.web;

import org.apache.commons.lang3.StringUtils;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.security.oauth2.client.registration.ClientRegistration;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.core.endpoint.OAuth2ParameterNames;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyExtractors;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/**
 * Created by DT214743 on 1/22/2020.
 */
public class TokenEndpointFilter implements WebFilter {
  private WebClient webClient;
  private ClientRegistration clientRegistration;
  private boolean preserveHost = false;

  public TokenEndpointFilter(ReactiveClientRegistrationRepository clientRegistrationRepository,
      WebClient oAuthWebClient) {
    this.webClient = oAuthWebClient;
    String clientRegistrationId = "mworx";
    clientRegistrationRepository.findByRegistrationId(clientRegistrationId)
        .switchIfEmpty(Mono.error(() -> new IllegalArgumentException(
            "Client Registration with id " + clientRegistrationId + " was not found")))
        .subscribe(v -> this.clientRegistration = v);
  }

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain webFilterChain) {
    ServerHttpResponse response = exchange.getResponse();
    ServerHttpRequest request = exchange.getRequest();
    HttpMethod method = request.getMethod();
    if (StringUtils.endsWith(clientRegistration.getProviderDetails().getTokenUri(),
        exchange.getRequest().getPath().value()) && method != null) {
      String tokenUri = clientRegistration.getProviderDetails().getTokenUri();
      MultiValueMap<String, String> formParameters = new LinkedMultiValueMap<>();

      WebClient.RequestBodySpec bodySpec =
          this.webClient.method(method).uri(tokenUri).headers(httpHeaders -> {
            httpHeaders.addAll(request.getHeaders());
            if (ClientAuthenticationMethod.BASIC
                .equals(clientRegistration.getClientAuthenticationMethod())) {
              httpHeaders.setBasicAuth(clientRegistration.getClientId(),
                  clientRegistration.getClientSecret());
            } else {
              formParameters.add(OAuth2ParameterNames.CLIENT_ID, clientRegistration.getClientId());
              formParameters.add(OAuth2ParameterNames.CLIENT_SECRET,
                  clientRegistration.getClientSecret());
            }
            // Will either be set below, or later by Netty
            httpHeaders.remove(HttpHeaders.HOST);
            if (preserveHost) {
              String host = request.getHeaders().getFirst(HttpHeaders.HOST);
              httpHeaders.add(HttpHeaders.HOST, host);
            }
            // the new content type will be computed by bodyInserter
            httpHeaders.remove(HttpHeaders.CONTENT_LENGTH);
          });

      WebClient.RequestHeadersSpec<?> headersSpec;
      if (requiresBody(method)) {
        Flux<MultiValueMap<String, String>> modifiedBody =
            exchange.getFormData().concatWith(Mono.just(formParameters));
        headersSpec = bodySpec.body(BodyInserters.fromPublisher(modifiedBody,
            new ParameterizedTypeReference<MultiValueMap<String, String>>() {}));
      } else {
        headersSpec = bodySpec;
      }

      return headersSpec.exchangeToMono(clientResponse -> {
        response.getHeaders().addAll(clientResponse.headers().asHttpHeaders());
        response.setStatusCode(clientResponse.statusCode());
        return response.writeWith(clientResponse.body(BodyExtractors.toDataBuffers()));
      });
    }
    return webFilterChain.filter(exchange);
  }

  private boolean requiresBody(HttpMethod method) {
    switch (method) {
      case PUT:
      case POST:
      case PATCH:
        return true;
      default:
        return false;
    }
  }
}
