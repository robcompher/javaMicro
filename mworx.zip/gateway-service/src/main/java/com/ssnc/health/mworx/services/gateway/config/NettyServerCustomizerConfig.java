package com.ssnc.health.mworx.services.gateway.config;

import java.time.Duration;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.embedded.netty.NettyServerCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Revisit after https://github.com/spring-cloud/spring-cloud-gateway/issues/1985 is resolved
 * 
 * @author DT214743
 *
 */
@Configuration
public class NettyServerCustomizerConfig {

  @Bean
  public NettyServerCustomizer nettyServerCustomizer(
      @Value("${spring.cloud.gateway.httpserver.idle-timeout:60000}") int idleTimeout) {
    return httpServer -> httpServer.idleTimeout(Duration.ofMillis(idleTimeout));
  }
}
