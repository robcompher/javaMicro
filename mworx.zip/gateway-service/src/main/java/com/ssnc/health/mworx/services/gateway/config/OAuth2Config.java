package com.ssnc.health.mworx.services.gateway.config;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import org.springframework.cloud.gateway.handler.predicate.PredicateDefinition;
import org.springframework.cloud.gateway.route.RouteDefinition;
import org.springframework.cloud.gateway.route.RouteDefinitionLocator;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableReactiveMethodSecurity;
import org.springframework.security.config.annotation.web.reactive.EnableWebFluxSecurity;
import org.springframework.security.config.web.server.SecurityWebFiltersOrder;
import org.springframework.security.config.web.server.ServerHttpSecurity;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.reactive.function.client.ServerOAuth2AuthorizedClientExchangeFilterFunction;
import org.springframework.security.oauth2.client.web.server.ServerOAuth2AuthorizedClientRepository;
import org.springframework.security.web.server.SecurityWebFilterChain;
import org.springframework.security.web.server.header.XFrameOptionsServerHttpHeadersWriter;
import org.springframework.web.reactive.function.client.WebClient;
import com.ssnc.health.mworx.services.gateway.web.TokenEndpointFilter;

/**
 * Created by DT214743 on 1/18/2020.
 *
 * remove session and use stateless auth
 * https://github.com/spring-projects/spring-security/issues/6552
 * https://github.com/spring-projects/spring-security/issues/7157
 */
@EnableWebFluxSecurity
@EnableReactiveMethodSecurity
public class OAuth2Config {
  @Bean
  public SecurityWebFilterChain springSecurityFilterChain(ServerHttpSecurity http,
      ReactiveClientRegistrationRepository clientRegistrationRepository, WebClient oAuthWebClient,
      RouteDefinitionLocator locator) {
    http.addFilterBefore(
        new TokenEndpointFilter(clientRegistrationRepository, oAuthWebClient),
        SecurityWebFiltersOrder.OAUTH2_AUTHORIZATION_CODE);

    http.authorizeExchange().pathMatchers(getPermitList(locator)).permitAll();

    // Authenticate through configured OpenID Provider
    http.oauth2Login();

    // Resource server
    http.oauth2ResourceServer().jwt();

    // Require authentication for all requests
    http.authorizeExchange().anyExchange().authenticated();
    http.requestCache().disable();

    // Disable CSRF in the gateway to prevent conflicts with proxied service CSRF
    http.csrf().disable();
    
    // To allow help to load in iframe
    http.headers().frameOptions().mode(XFrameOptionsServerHttpHeadersWriter.Mode.SAMEORIGIN);
    
    return http.build();
  }

  private String[] getPermitList(RouteDefinitionLocator locator) {
    List<String> permitList = new ArrayList<>();
    permitList.add("/");
    permitList.add("/favicon.ico");
    permitList.add("/*.png");
    permitList.add("/*.gif");
    permitList.add("/*.svg");
    permitList.add("/*.jpg");
    permitList.add("/*.html");
    permitList.add("/*.css");
    permitList.add("/*.js");
    permitList.add("/assets/**");
    permitList.add("/api/user/authenticate");
    permitList.add("/metadata/api/lob/getLOBById");
    permitList.add("/v3/api-docs/**");
    permitList.add("/api-docs**");
    permitList.add("/swagger-resources/**");
    permitList.add("/swagger-ui**");
    permitList.add("/webjars/**");
    permitList.add("/help/**");

    List<RouteDefinition> definitions = locator.getRouteDefinitions().collectList().block();
    Objects.requireNonNull(definitions);
    definitions.stream().filter(routeDefinition -> routeDefinition.getId().matches(".*-service"))
        .forEach(routeDefinition -> {
          Optional<PredicateDefinition> pOptional = routeDefinition.getPredicates().stream()
              .filter(def -> def.getName().equalsIgnoreCase("path")).findFirst();

          String name = routeDefinition.getId().replace("-service", "");
          String path = String.format("/%s", name);

          if (pOptional.isPresent()) {
            path = pOptional.get().getArgs().values().stream().findFirst().get();
            path = path.replaceAll("[/\\*]", "");
          }
          permitList.add(String.format("/%s/v3/api-docs/**", path));
        });

    return permitList.toArray(new String[permitList.size()]);
  }

  @Bean
  WebClient oAuthWebClient(ReactiveClientRegistrationRepository clientRegistrations,
      ServerOAuth2AuthorizedClientRepository authorizedClientRepo,
      WebClient.Builder webClientBuilder) {

    // Provides support for an unauthenticated user such as an application
    ServerOAuth2AuthorizedClientExchangeFilterFunction oauth =
        new ServerOAuth2AuthorizedClientExchangeFilterFunction(clientRegistrations,
            authorizedClientRepo);

    oauth.setDefaultOAuth2AuthorizedClient(true);
    return webClientBuilder.filter(oauth).build();
  }
}
