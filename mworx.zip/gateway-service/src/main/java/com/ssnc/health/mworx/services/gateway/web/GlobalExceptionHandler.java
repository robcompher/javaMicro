package com.ssnc.health.mworx.services.gateway.web;

import java.net.ConnectException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssnc.health.core.common.error.ApiError;

@RestControllerAdvice
public class GlobalExceptionHandler {
  private static final Logger LOG = LoggerFactory.getLogger(GlobalExceptionHandler.class);

  @Autowired
  ObjectMapper objectMapper;
  
  @ExceptionHandler(WebClientResponseException.class)
  public ResponseEntity<Object> handleWebClientResponseException(WebClientResponseException ex) {
    if (ex.getRawStatusCode() == HttpStatus.UNAUTHORIZED.value()) {
      return handleException(HttpStatus.UNAUTHORIZED.name(), ex, HttpStatus.UNAUTHORIZED);
    } else {
      return handleException(
          ex.getResponseBodyAsString(), ex, HttpStatus.valueOf(ex.getRawStatusCode()));
    }
  }

  @ExceptionHandler(ConnectException.class)
  public ResponseEntity<Object> handleConnectionExceptio(ConnectException ex) {
    return handleException(
        "Unable to connect to downstream server.", ex, HttpStatus.INTERNAL_SERVER_ERROR);
  }

  @ExceptionHandler(Exception.class)
  public ResponseEntity<Object> handleExceptio(Exception ex) {
    return handleException(
        "Unknown error occured while processing the request.",
        ex,
        HttpStatus.INTERNAL_SERVER_ERROR);
  }

  protected ResponseEntity<Object> handleException(
      String message, Exception ex, HttpStatus status) {
    ApiError apiError = null;
    try {
      if(message.contains("apierror")) {
        apiError = objectMapper.readValue(message, ApiError.class);
      } else {
        apiError = objectMapper.readValue("{\"apierror\":"+message+"}", ApiError.class);
      }
    } catch (JsonProcessingException e) {}
    if(apiError == null || apiError.getMessage() == null) {
      apiError = new ApiError(status);
      apiError.setMessage(message);
      apiError.setDebugMessage(ex.getMessage());
    }
    LOG.error(ex.getMessage(), ex);
    return buildResponseEntity(apiError);
  }

  private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
    return new ResponseEntity<>(apiError, apiError.getStatus());
  }
}
