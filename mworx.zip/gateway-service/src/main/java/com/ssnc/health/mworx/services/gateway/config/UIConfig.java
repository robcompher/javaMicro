package com.ssnc.health.mworx.services.gateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.MediaType;
import org.springframework.util.ResourceUtils;
import org.springframework.web.reactive.config.ResourceHandlerRegistry;
import org.springframework.web.reactive.config.WebFluxConfigurer;
import org.springframework.web.reactive.function.server.RouterFunction;
import org.springframework.web.reactive.function.server.ServerResponse;
import static org.springframework.web.reactive.function.server.RequestPredicates.GET;
import static org.springframework.web.reactive.function.server.RouterFunctions.route;
import static org.springframework.web.reactive.function.server.ServerResponse.ok;
import org.springframework.beans.factory.annotation.Value;

@Configuration
public class UIConfig implements WebFluxConfigurer {
  private static final String UI_RESOURCES_PATH =
      ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/webjars/mworx-web-app/";
  private static final String HELP_RESOURCES_PATH =
      ResourceUtils.CLASSPATH_URL_PREFIX + "/META-INF/resources/webjars/mworx-help/";
  
  private static final String[] CLASSPATH_RESOURCE_LOCATIONS = {
      "classpath:/META-INF/resources/", "classpath:/resources/",
      "classpath:/static/", "classpath:/public/", UI_RESOURCES_PATH, HELP_RESOURCES_PATH };

  @Override
  public void addResourceHandlers(ResourceHandlerRegistry registry) {
    registry.addResourceHandler("/**").addResourceLocations(CLASSPATH_RESOURCE_LOCATIONS);
  }

  //https://github.com/spring-projects/spring-boot/issues/9785
  @Bean
  public RouterFunction<ServerResponse> indexRouter(
      @Value(UI_RESOURCES_PATH + "index.html") final Resource indexHtml) {
    return route(GET("/"), request -> ok().contentType(MediaType.TEXT_HTML).bodyValue(indexHtml));
  }

  @Bean
  public RouterFunction<ServerResponse> helpRouter(
      @Value(HELP_RESOURCES_PATH + "index.html") final Resource indexHtml) {
    return route(GET("/help"), request -> ok().contentType(MediaType.TEXT_HTML).bodyValue(indexHtml));
  }
}
