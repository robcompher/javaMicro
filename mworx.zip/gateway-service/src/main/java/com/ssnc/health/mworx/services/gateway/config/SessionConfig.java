package com.ssnc.health.mworx.services.gateway.config;

import java.util.concurrent.ConcurrentHashMap;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.session.ReactiveMapSessionRepository;
import org.springframework.session.config.annotation.web.server.EnableSpringWebSession;
import org.springframework.web.server.session.CookieWebSessionIdResolver;
import org.springframework.web.server.session.WebSessionIdResolver;

/**
 * Created by DT214743 on 1/27/2020.
 *
 * FIXME: remove session and use stateless auth
 */
@Configuration
@EnableSpringWebSession
public class SessionConfig {

  @Bean
  public ReactiveMapSessionRepository reactiveSessionRepository() {
    return new ReactiveMapSessionRepository(new ConcurrentHashMap<>());
  }

  @Bean
  public WebSessionIdResolver headerWebSessionIdResolver() {
    CookieWebSessionIdResolver resolver= new CookieWebSessionIdResolver();
    resolver.setCookieName("MWORXSESSION");
    return resolver;
  }
}
