package com.ssnc.health.mworx.services.gateway.web;

import org.springframework.security.core.context.ReactiveSecurityContextHolder;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.oauth2.client.registration.ReactiveClientRegistrationRepository;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/**
 * Created by DT214743 on 1/22/2020.
 */
public class CookieTokenFilter implements WebFilter {
  WebClient webClient;
  ReactiveClientRegistrationRepository clientRegistrationRepository;
  String filterUrl;

  public CookieTokenFilter(ReactiveClientRegistrationRepository clientRegistrationRepository) {
    this.clientRegistrationRepository = clientRegistrationRepository;
  }

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain webFilterChain) {
    ReactiveSecurityContextHolder.getContext()
        .map(SecurityContext::getAuthentication).map(authentication -> {
      return authentication.isAuthenticated();
    });
    return webFilterChain.filter(exchange);
  }


}
