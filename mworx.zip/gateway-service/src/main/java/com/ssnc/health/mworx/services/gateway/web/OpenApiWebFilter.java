/*
 * FILE : OpenApiWebFilter.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2019- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.gateway.web;

import java.net.URI;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import org.springframework.web.server.WebFilter;
import org.springframework.web.server.WebFilterChain;
import reactor.core.publisher.Mono;

/**
 * Created by DT214743 on 6/29/2020.
 */
@Component
public class OpenApiWebFilter implements WebFilter {
  
  @Override
  public Mono<Void> filter(ServerWebExchange exchange, WebFilterChain webFilterChain) {
    String originalUri = exchange.getRequest().getPath().value();
    if (originalUri.endsWith("/swagger-ui/index.html") && 
        !exchange.getRequest().getQueryParams().containsKey("configUrl")) {
      exchange.getResponse().setStatusCode(HttpStatus.TEMPORARY_REDIRECT);
      exchange.getResponse().getHeaders().setLocation(URI.create("/swagger-ui.html"));
      return exchange.getResponse().setComplete();
    }
    return webFilterChain.filter(exchange);
  }

}
