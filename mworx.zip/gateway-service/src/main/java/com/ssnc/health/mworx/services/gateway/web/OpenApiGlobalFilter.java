/*
 * FILE : OpenApiGlobalFilter.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2019- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.gateway.web;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URL;
import java.net.UnknownHostException;
import java.nio.charset.StandardCharsets;
import org.reactivestreams.Publisher;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.core.Ordered;
import org.springframework.core.io.buffer.DataBuffer;
import org.springframework.core.io.buffer.DataBufferFactory;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpResponse;
import org.springframework.http.server.reactive.ServerHttpResponseDecorator;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

/** Created by DT214743 on 6/29/2020. */
@Component
public class OpenApiGlobalFilter implements GlobalFilter, Ordered {

  @Value("${server.port}")
  private int port;

  @Override
  public int getOrder() {
    return -2; // -1 is response write filter, must be called before that
  }

  @Override
  public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {
    String originalUri = exchange.getRequest().getPath().value();
    if (originalUri.endsWith("/v3/api-docs")) {
      ServerHttpResponse originalResponse = exchange.getResponse();
      DataBufferFactory bufferFactory = originalResponse.bufferFactory();
      ServerHttpResponseDecorator decoratedResponse =
          new ServerHttpResponseDecorator(originalResponse) {
            @Override
            public Mono<Void> writeWith(Publisher<? extends DataBuffer> body) {
              if (body instanceof Flux) {
                Flux<? extends DataBuffer> flux = (Flux<? extends DataBuffer>) body;
                ObjectMapper mapper = new ObjectMapper();
                return super.writeWith(
                    flux.buffer()
                        .map(
                            dataBuffers -> {
                              StringBuilder builder = new StringBuilder();

                              dataBuffers.forEach(
                                  i -> {
                                    byte[] array = new byte[i.readableByteCount()];
                                    i.read(array);
                                    builder.append(new String(array, StandardCharsets.UTF_8));
                                  });

                              try {
                                JsonNode rootNode =
                                    mapper.readTree(
                                        builder.toString().getBytes(StandardCharsets.UTF_8));
                                change(rootNode, "url", exchange.getRequest());
                                byte[] res = mapper.writeValueAsBytes(rootNode);
                                this.getHeaders().setContentLength(res.length);
                                return bufferFactory.wrap(res);
                              } catch (IOException e) {
                                return bufferFactory.wrap(
                                    builder.toString().getBytes(StandardCharsets.UTF_8));
                              }
                            }));
              }
              return super.writeWith(body); // if body is not a flux. never got there.
            }
          };
      return chain.filter(
          exchange.mutate().response(decoratedResponse).build()); // replace response with decorator
    }

    return chain.filter(exchange);
  }

  private void change(JsonNode parent, String fieldName, ServerHttpRequest serverHttpRequest)
      throws MalformedURLException, UnknownHostException {
    if (parent.has(fieldName)) {
      try {
        URL url = URI.create(parent.get(fieldName).asText()).toURL();
        URL newURL =
            new URL(
                serverHttpRequest.getURI().getScheme(),
                serverHttpRequest.getURI().getHost(),
                serverHttpRequest.getURI().getPort(),
                url.getFile());
        ((ObjectNode) parent).put(fieldName, newURL.toExternalForm());
      } catch (IllegalArgumentException e) {
        // Ignore
      }
      return;
    }

    // Now, recursively invoke this method on all properties
    for (JsonNode child : parent) {
      change(child, fieldName, serverHttpRequest);
    }
  }
}
