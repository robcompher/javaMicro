/*
 * FILE : OpenApiWebFilter.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.gateway.config;

import java.util.ArrayList;
import java.util.List;
import org.springdoc.core.GroupedOpenApi;
import org.springdoc.core.SpringDocConfigProperties;
import org.springdoc.core.SpringDocConfiguration;
import org.springdoc.core.SwaggerUiConfigParameters;
import org.springframework.cloud.gateway.route.RouteDefinition;
import org.springframework.cloud.gateway.route.RouteDefinitionLocator;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;

/** Created by DT214743 on 6/28/2020. */
@Configuration
public class OpenApiConfig {
  @Bean
  SpringDocConfiguration springDocConfiguration() {
    return new SpringDocConfiguration();
  }

  @Bean
  SpringDocConfigProperties springDocConfigProperties() {
    return new SpringDocConfigProperties();
  }

  @Bean
  @Lazy(false)
  public List<GroupedOpenApi> apis(SwaggerUiConfigParameters swaggerUiConfigParameters,
      RouteDefinitionLocator locator) {
    List<GroupedOpenApi> groups = new ArrayList<>();
    List<RouteDefinition> definitions = locator.getRouteDefinitions().collectList().block();

    definitions.stream().filter(rd -> rd.getId().matches(".*-service")).forEach(routeDefinition -> {
      String name = routeDefinition.getId().replace("-service", "");
      swaggerUiConfigParameters.addGroup(name);
      GroupedOpenApi.builder().pathsToMatch("/" + name + "/**").group(name).build();
    });
    return groups;
  }
}
