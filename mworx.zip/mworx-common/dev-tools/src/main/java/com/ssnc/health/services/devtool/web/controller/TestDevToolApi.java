/*
 * FILE : TestDevToolApi.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.devtool.web.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * Created by dt216896.
 */
@RestController
public class TestDevToolApi {

	@GetMapping(path = "/devtool")
	@PreAuthorize("hasAuthority('PERMIT_USER')")
	public ResponseEntity<String> testDevToolApiUser() {
		return new ResponseEntity<>("Hello World!", HttpStatus.OK);
	}

}
