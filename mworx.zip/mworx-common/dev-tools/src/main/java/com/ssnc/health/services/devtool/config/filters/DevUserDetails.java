/*
 * FILE : UserDetails.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.devtool.config.filters;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Profile;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;

@Component
@Profile({"mock", "test"})
public class DevUserDetails {
  @Value("${spring.security.user.id}")
  private Long userId;

  @Value("${spring.security.user.name}")
  private String userName;

  @Value("${spring.security.user.password}")
  private String userPassword;

  @Value("${spring.security.user.authorities}")
  private List<String> authoritiesList;

  @Value("${spring.security.user.currentLobId}")
  private Long currentLobId;

  @Value("${spring.security.user.currentLobName}")
  private String currentLobName;

  @Value("${spring.security.user.currentOrganizationName}")
  private String currentOrganizationName;

  public Long getUserId() {
    return userId;
  }

  public String getUserName() {
    return userName;
  }

  public String getUserPassword() {
    return userPassword;
  }

  public String getCurrentLobName() {
    return currentLobName;
  }

  public Long getCurrentLobId() {
    return currentLobId;
  }

  public void setCurrentLobId(Long currentLobId) {
    this.currentLobId = currentLobId;
  }

  public void setCurrentLobName(String currentLobName) {
    this.currentLobName = currentLobName;
  }

  public String getCurrentOrganizationName() {
    return currentOrganizationName;
  }

  public void setCurrentOrganizationName(String currentOrganizationName) {
    this.currentOrganizationName = currentOrganizationName;
  }

  public List<GrantedAuthority> getAuthorities() {

    if (CollectionUtils.isEmpty(authoritiesList)) {
      return Collections.emptyList();
    }
    List<GrantedAuthority> authorities = new ArrayList<>();
    for (String auth : authoritiesList) {
      Assert.isTrue(
          !auth.startsWith("PERMIT_"),
          () -> auth + " cannot start with PERMIT_ (it is automatically added)");
      authorities.add(new SimpleGrantedAuthority("PERMIT_" + auth));
    }
    return authorities;
  }
}
