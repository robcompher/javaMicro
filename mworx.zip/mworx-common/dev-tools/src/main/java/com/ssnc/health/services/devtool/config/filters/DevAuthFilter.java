/*
 * FILE : DevAuthFilter.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.devtool.config.filters;

import java.io.IOException;
import java.time.temporal.ChronoUnit;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.filter.GenericFilterBean;

/**
 * Created by dt216896 on 1/20/2020.
 */
public class DevAuthFilter extends GenericFilterBean {

	private static final Logger LOG = LoggerFactory.getLogger(DevAuthFilter.class);

	private static final int EXPIRE_HOURS = 5;

	@Autowired
	DevUserDetails userDetails;

	public DevAuthFilter() {
		LOG.info("Inside DevAuthFilter");

	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		if (isAuthenticationRequired(request.getRequestURI())) {
			Map<String, Object> headersMap = new HashMap<>();
			headersMap.put("LocalDevHeader", "LocalDevHeaderValue");
			Map<String, Object> claimsMap = new HashMap<>();
			claimsMap.put("authority", userDetails.getAuthorities());
			claimsMap.put("user_id", userDetails.getUserId());
			claimsMap.put("sub", userDetails.getUserName());
			claimsMap.put("currentLobId",userDetails.getCurrentLobId());
			claimsMap.put("currentLobName",userDetails.getCurrentLobName());	
			claimsMap.put("currentOrganizationId",2L);	
			claimsMap.put("currentOrganizationName",userDetails.getCurrentOrganizationName());	
			Jwt jwt = new Jwt("localdevtoken", new Date().toInstant(),
					new Date().toInstant().plus(EXPIRE_HOURS, ChronoUnit.HOURS), headersMap, claimsMap);
			JwtAuthenticationToken token = new JwtAuthenticationToken(jwt, userDetails.getAuthorities());
			SecurityContextHolder.getContext().setAuthentication(token);
		}
		chain.doFilter(request, response);
	}

	private boolean isAuthenticationRequired(String uri) {
		return !uri.equalsIgnoreCase("/logout") && !uri.equalsIgnoreCase("/error")
				&& (SecurityContextHolder.getContext().getAuthentication() == null
						|| !SecurityContextHolder.getContext().getAuthentication().isAuthenticated());

	}

}
