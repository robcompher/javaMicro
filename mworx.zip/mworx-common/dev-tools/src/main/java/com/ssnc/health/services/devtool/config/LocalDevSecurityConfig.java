/*
 * FILE : LocalDevSecurityConfig.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.devtool.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.ssnc.health.services.devtool.config.filters.DevAuthFilter;
import com.ssnc.health.services.devtool.config.filters.DevSpringOAuth2Filter;
import com.ssnc.health.services.devtool.config.filters.DevUserDetails;

/**
 * Created by dt216896
 */
@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(securedEnabled = true)
@Profile({"mock", "test"})
@Order(Ordered.HIGHEST_PRECEDENCE)
public class LocalDevSecurityConfig extends WebSecurityConfigurerAdapter {

  @Autowired
  DevUserDetails userDetails;

  @Autowired
  ApplicationContext ctx;

  @Bean(name = BeanIds.AUTHENTICATION_MANAGER)
  @Override
  public AuthenticationManager authenticationManagerBean() throws Exception {
    return super.authenticationManagerBean();
  }

  @Bean
  @ConditionalOnClass(name = {
      "org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken",
      "org.springframework.security.oauth2.jwt.Jwt"})
  public DevAuthFilter devAuthFilter() {
    return new DevAuthFilter();
  }

  @Bean
  @ConditionalOnMissingBean(DevAuthFilter.class)
  @ConditionalOnClass(name = {"org.springframework.security.oauth2.provider.OAuth2Authentication"})
  public DevSpringOAuth2Filter devSpringOAuth2Filter() {
    return new DevSpringOAuth2Filter();
  }

  @Override
  protected void configure(AuthenticationManagerBuilder auth) throws Exception {
    auth.inMemoryAuthentication().withUser(userDetails.getUserName())
        .password("{noop}" + userDetails.getUserPassword())
        .authorities(userDetails.getAuthorities());
  }

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    if (ctx.containsBean("devAuthFilter")) {
      http.requestMatchers().and()
          .addFilterBefore(devAuthFilter(), UsernamePasswordAuthenticationFilter.class).csrf()
          .disable();
    } else if (ctx.containsBean("devSpringOAuth2Filter")) {
      http.requestMatchers().and()
          .addFilterBefore(devSpringOAuth2Filter(), UsernamePasswordAuthenticationFilter.class)
          .csrf().disable();
    }
  }
}
