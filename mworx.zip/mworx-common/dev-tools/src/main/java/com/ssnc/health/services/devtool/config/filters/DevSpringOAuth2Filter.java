/*
 * FILE : DevSpringOAuth2Filter.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.devtool.config.filters;

import java.io.IOException;
import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.OAuth2Request;
import org.springframework.web.filter.GenericFilterBean;

/** Created by dt216896 on 1/20/2020. */
public class DevSpringOAuth2Filter extends GenericFilterBean {

	private static final Logger LOG = LoggerFactory.getLogger(DevSpringOAuth2Filter.class);

	@Autowired
	DevUserDetails userDetails;

	public DevSpringOAuth2Filter() {
		LOG.info("Inside DevSpringOAuth2Filter");
	}

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;
		if (isAuthenticationRequired(request.getRequestURI())) {
			Map<String, String> requestParameters = new HashMap<>();
			Map<String, Serializable> extensionProperties = new HashMap<>();

			boolean approved = true;
			Set<String> responseTypes = new HashSet<>();
			responseTypes.add("code");

			OAuth2Request oauth2Request = new OAuth2Request(requestParameters, "clientIdTest",
					userDetails.getAuthorities(), approved, new HashSet<String>(Arrays.asList("all")),
					new HashSet<String>(Arrays.asList("resourceIdTest")), null, responseTypes, extensionProperties);

			UsernamePasswordAuthenticationToken authenticationToken = new UsernamePasswordAuthenticationToken(
					userDetails.getUserName(), "N/A", userDetails.getAuthorities());

			OAuth2Authentication auth = new OAuth2Authentication(oauth2Request, authenticationToken);

			SecurityContextHolder.getContext().setAuthentication(auth);
		}
		chain.doFilter(request, response);
	}

	private boolean isAuthenticationRequired(String uri) {
		return !uri.equalsIgnoreCase("/logout") && !uri.equalsIgnoreCase("/error")
				&& (SecurityContextHolder.getContext().getAuthentication() == null
						|| !SecurityContextHolder.getContext().getAuthentication().isAuthenticated());
	}
}
