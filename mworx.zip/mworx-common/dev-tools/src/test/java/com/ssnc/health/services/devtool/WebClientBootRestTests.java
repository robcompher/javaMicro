/*
 * FILE : WebClientBootRestTests.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.devtool;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;

/**
 * Created by dt216896
 */
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class WebClientBootRestTests {

  @Autowired
  private WebTestClient webTestClient;

  @Test
  void TestHelloMethod() {
    EntityExchangeResult<String> result = webTestClient.get().uri("/devtool").exchange()
        .expectStatus().isOk().expectBody(String.class).returnResult();
    
    assertEquals("Hello World!", result.getResponseBody(), "Response is wrong");
  }

}
