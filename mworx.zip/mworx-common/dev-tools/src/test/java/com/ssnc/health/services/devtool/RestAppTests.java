/*
 * FILE : RestAppTests.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.devtool;

import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class RestAppTests {

	@Test
	void contextLoads() {
	  Assertions.assertTrue(true);
	}

}
