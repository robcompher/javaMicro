# common


*  core-common: Framework classes which will be used across different services like ApiError or Exception.
*  dev-tools: Classes to ease micro services development. Only needed during development.
*  test-common: Framework classes which are needed for building test cases.