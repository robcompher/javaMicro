/*
 * FILE : RuleValidatorTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.validator;

import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Service;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.validation.annotation.Validated;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import com.ssnc.health.core.common.validation.model.ObjectType;
import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.repository.RulesRepository;
import javassist.NotFoundException;
import lombok.Getter;
import lombok.Setter;

/**
 * Initial class to verify that the fieldvalues converts the list correctly
 *
 * @author dt64106
 */
@ExtendWith(SpringExtension.class) 
@ContextConfiguration(classes = ContextConfig.class)
class RuleValidatorTest {
  @MockBean private RulesRepository repository;

  @Autowired TestUserService userService;

  @Autowired ObjectMapper objectMapper;
  
  private AutoCloseable closeable;

  @BeforeEach
  public void init() {
    closeable = MockitoAnnotations.openMocks(this);
  }

  @AfterEach
  public void releaseMocks() throws Exception {
    closeable.close();
  }

  @Test
  void testJsonValidSupervisor() throws Exception {
    String requestString =
        "{\n"
            + "   \"header\": { \n"
            + "     \"eventId\": \"231334\", \n"
            + "     \"eventName\": \"UpdateMembership\",\n"
            + "     \"createEventName\": \"CreateMembership\",\n"
            + "     \"sourceSystem\": \"Enrollment\",\n"
            + "     \"lobName\": \"1\",\n"
            + "     \"organizationName\": \"Organization\"\n"
            + "   },\n"
            + "   \"data\": {\n"
            + "      \"id\": \"2020-05-18-12.41.03.529280T01\",\n"
            + "      \"comment\": \"Moved to member\",\n"
            + "      \"supervisor\": \"Nil\"\n"
            + "   }\n"
            + "}\n";

    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();

    rule.setPropertyName("data.supervisor,data.id");
    rule.setRuleType("SpELAssert");
    rule.setRule(
        "value=\"#this.data.supervisor eq 'Y' || #this.data.supervisor eq 'N'\", applyIf=\"data.id != null\", rootBean=true");
    rule.setRuleOrder(1);
    rule.setRuleset("jsonSupervisor");
    rule.setMessage("if id exists supervisor value needed");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);

    Mockito.when(repository.findByRuleset("jsonSupervisor")).thenReturn(rules);
    try {
      userService.newJsonSupervisor(requestString);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(1, constraintViolations.size());
    }
  }
  
  @Test
  void testJsonValidWorkflow() throws Exception {
    String requestString =
        "{\n"
            + "   \"header\": { \n"
            + "     \"eventId\": \"231334\", \n"
            + "     \"eventName\": \"UpdateMembership\",\n"
            + "     \"createEventName\": \"CreateMembership\",\n"
            + "     \"sourceSystem\": \"\",\n"
            + "     \"lobName\": \"1\",\n"
            + "     \"organizationName\": \"Organization\"\n"
            + "   },\n"
            + "   \"data\": null "
            + "}\n";

    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();

    rule.setPropertyName("data");
    rule.setRuleType("JSON_NOTNULL_VALIDATION");
    rule.setRule("true");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have data as elements");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);
    
    rule = new ValidationRule();
    rule.setPropertyName("header.eventId");
    rule.setRuleType("NotBlank");
    rule.setRule("true");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have eventId");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("header.eventName");
    rule.setRuleType("NotBlank");
    rule.setRule("true");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have event name");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);
    
    rule = new ValidationRule();
    rule.setPropertyName("header.sourceSystem");
    rule.setRuleType("NotBlank");
    rule.setRule("true");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have Source System");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);
    
    Mockito.when(repository.findByRuleset("createWorkRule")).thenReturn(rules);
    try {
      userService.createWork(requestString);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(2, constraintViolations.size());
    }
  }
  
  @Test
  void testJsonValidWorkflowDataNotNull() throws Exception {
    String requestString =
        "{\n"
            + "   \"header\": { \n"
            + "     \"eventId\": \"231334\", \n"
            + "     \"eventName\": \"UpdateMembership\",\n"
            + "     \"createEventName\": \"CreateMembership\",\n"
            + "     \"sourceSystem\": \"\",\n"
            + "     \"lobName\": \"1\",\n"
            + "     \"organizationName\": \"Organization\"\n"
            + "   },\n"
            + "   \"data\": {\n"
            + "      \"id\": \"2020-05-18-12.41.03.529280T01\",\n"
            + "      \"comment\": \"Moved to member\",\n"
            + "      \"supervisor\": \"Nil\"\n"
            + "   }\n"
            + "}\n";

    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();

    rule.setPropertyName("data");
    rule.setRuleType("NotNull");
    rule.setRule("jsonSchema={\"data\": {\"type\": \"object\"}}");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have data as elements");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);
    
    rule = new ValidationRule();
    rule.setPropertyName("header.eventId");
    rule.setRuleType("NotBlank");
    rule.setRule("jsonSchema={\"header\": {\"type\": \"object\", \"properties\": {\"eventId\":{ \"type\": \"string\" }}}}");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have eventId");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("header.eventName");
    rule.setRuleType("NotBlank");
    rule.setRule("true");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have event name");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);
    
    rule = new ValidationRule();
    rule.setPropertyName("header.sourceSystem");
    rule.setRuleType("NotBlank");
    rule.setRule("true");
    rule.setRuleOrder(1);
    rule.setRuleset("createWorkRule");
    rule.setMessage("Incoming JSON request did not pass validation.Request should have Source System");
    rule.setObjectType(ObjectType.JSON);
    rules.add(rule);
    
    Mockito.when(repository.findByRuleset("createWorkRule")).thenReturn(rules);
    try {
      userService.createWork(requestString);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(1, constraintViolations.size());
    }
  }

  @Test
  void testIsValidProviderInfo() throws Exception {

    StringBuilder builder = new StringBuilder();

    builder.append(
        "{\"provider\":{\"npiNumber\":\"955026789\",\"legacyNumber\":\"123435\",\"birthDate\":\"2001-01-01\",");
    builder.append(
        "\"providerType\":\"Dental\",\"providerName\":{\"firstName\":\"SATISH20\",\"lastName\":\"SATISH20\",");
    builder.append(
        "\"gender\":\"male\"},\"providerPeriod\":[{\"startDate\":\"2012-02-03\",\"termDate\":\"2011-02-27\",");
    builder.append("\"languages\":[\"english\", \"spanish\"],");
    builder.append(
        "\"instituationInd\":\"false\",\"address\":{\"type\":\"BUSINESS\",\"addressLine1\":\"123 test ln\",");
    builder.append(
        "\"city\":\"SAINT PAUL\",\"state\":\"MN\",\"zip\":\"55114\"},\"providerNetwork\":\"providerNetwork\"},");
    builder.append("{\"startDate\":\"2012-02-03\",\"termDate\":\"2011-02-27\",");
    builder.append("\"languages\":[\"english\", \"spanish\"],");
    builder.append(
        "\"instituationInd\":\"false\",\"address\":{\"type\":\"BUSINESS\",\"addressLine1\":\"123 test ln\",");
    builder.append(
        "\"city\":\"SAINT PAUL\",\"state\":\"MN\",\"zip\":\"55114\"},\"providerNetwork\":\"providerNetwork\"}]},");
    builder.append("\"organizationName\":\"ARKANSAS\",\"lobName\":\"Medicare\"}");

    ProviderInfo providerInfo = objectMapper.readValue(builder.toString(), ProviderInfo.class);
    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();
    rule.setPropertyName("provider.legacyNumber");
    rule.setRuleType("PATTERN_VALIDATION");
    rule.setRule("value=\"^[a-zA-Z0-9]{12}[0-9]{4}$\", rootBean=true");
    rule.setRuleOrder(1);
    rule.setRuleset("loadProvider");
    rule.setMessage("Legacy number should be twelve alpha numeric and four numeric digits");
    rule.setObjectType(ObjectType.BEAN);
    rule.setPriorityType("Low");
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("provider.npiNumber");
    rule.setRuleType("PATTERN_VALIDATION");
    rule.setRule("[0-9]{9}");
    rule.setRuleOrder(1);
    rule.setRuleset("loadProvider");
    rule.setMessage("npiNumber has to be 9 digits");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("provider.providerPeriod[]");
    rule.setRuleType("CUSTOM_VALIDATION");
    rule.setRule(CustomProviderValidator.class.getTypeName());
    rule.setRuleOrder(1);
    rule.setRuleset("loadProvider");
    rule.setMessage(
        "**Provider Period does not exist with the given period and provider {providerPeriod}");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName(
        "provider.providerPeriod[].termDate,provider.providerPeriod[].startDate");
    rule.setRuleType("CUSTOM_VALIDATION");
    rule.setRule(CustomProviderTermValidator.class.getTypeName());
    rule.setRuleOrder(1);
    rule.setRuleset("loadProvider");
    rule.setMessage("Term date should be greater than effective date");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("provider.providerPeriod[].languages[]");
    rule.setRuleType("SpELAssert");
    rule.setRule("value=\"#this eq 'testlang'\"");
    rule.setRuleOrder(1);
    rule.setRuleset("loadProvider");
    rule.setMessage("Invalid laguage");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName(
        "provider.providerPeriod[].termDate,provider.providerPeriod[].startDate");
    rule.setRuleType("CUSTOM_VALIDATION");
    rule.setRule(
        "validatorClass="
            + CustomProviderRooBeanValidator.class.getTypeName()
            + ",rootBean=true");
    rule.setRuleOrder(1);
    rule.setRuleset("loadProvider");
    rule.setMessage("Term date should be greater than effective date");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    Mockito.when(repository.findByRuleset("loadProvider")).thenReturn(rules);
    
    try {
      userService.loadProvider(providerInfo, null);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(11, constraintViolations.size());
    }
  }

  public List<ValidationRule> createValidationBeanRules() {
    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();
    rule.setPropertyName("firstName");
    rule.setRuleType("NotBlank");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("firstName is required");
    rule.setObjectType(ObjectType.BEAN);
    rule.setRule("jsonSchema={\"firstName\":{\"type\": \"string\" }}");
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("endDate,startDate");
    rule.setRuleType("AfterDate");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("End date must be after Start date");
    rule.setObjectType(ObjectType.BEAN);
    rule.setRule(
        "jsonSchema={\"endDate\": {\"type\": \"date\"}, \"startDate\": {\"type\": \"date\"}}");
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("endDate,startDate");
    rule.setRuleType("SameOrAfterDate");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("End date must be same or after Start date");
    rule.setObjectType(ObjectType.BEAN);
    rule.setRule(
        "jsonSchema={\"endDate\": {\"type\": \"date\"}, \"startDate\": {\"type\": \"date\"}}");
    rules.add(rule);
    
    rule = new ValidationRule();
    rule.setPropertyName("startDate,endDate");
    rule.setRuleType("BeforeDate");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("Start date must be before end date");
    rule.setObjectType(ObjectType.BEAN);
    rule.setRule(
        "jsonSchema={\"endDate\": {\"type\": \"date\"}, \"startDate\": {\"type\": \"date\"}}");
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("pwd,pwdVerify");
    rule.setRuleType("spelassert");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("password is not matching");
    rule.setRule(
        "value=\"pwd.equals(pwdVerify)\", jsonSchema={\"pwd\": "
            + "{\"type\": \"string\"}, \"pwdVerify\": {\"type\": \"string\"}}");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("roles.roleName");
    rule.setRuleType("NotBlank");
    rule.setRuleOrder(2);
    rule.setRuleset("newUser");
    rule.setMessage("roleName is required");
    rule.setObjectType(ObjectType.BEAN);
    rule.setRule(
        "jsonSchema={\"roles\": {\"type\": \"array\"}, "
            + "\"properties\": {\"roleName\": {\"type\": \"string\"}}}");
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("roles.permits");
    rule.setRuleType("NotEmpty");
    rule.setRuleOrder(2);
    rule.setRuleset("newUser");
    rule.setMessage("permits are required");
    rule.setObjectType(ObjectType.BEAN);
    rule.setRule(
        "jsonSchema={\"roles\": {\"type\": \"object\"}, "
            + "\"properties\": {\"permits\": {\"type\": \"array\"}}}");
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("roles.permits.permitName");
    rule.setRuleType("NotEmpty");
    rule.setRuleOrder(2);
    rule.setRuleset("newUser");
    rule.setMessage("permitName is required");
    rule.setObjectType(ObjectType.BEAN);
    rule.setRule(
        "jsonSchema={\"roles\": {\"type\": \"object\"}, "
            + "\"properties\": {\"permits\": {\"type\": \"array\", "
            + "\"items\": {\"permitName\":{\"type\": \"string\"}}}}}");
    rules.add(rule);
    return rules;
  }

  @Test
  void testIsValidBean() throws Exception {
    Mockito.when(repository.findByRuleset("newUser")).thenReturn(createValidationBeanRules());

    User user = new User();
    user.setStartDate(LocalDate.of(2020, 11, 1));
    user.setEndDate(LocalDate.of(2019, 11, 1));
    user.setPwd("");
    user.setPwdVerify("ask");
    user.setRoles(new ArrayList<>());
    user.getRoles().add(new Role());
    user.getRoles().add(new Role());
    user.getRoles().get(1).setPermits(new ArrayList<>());
    user.getRoles().get(1).getPermits().add(new Permit());
    
    try {
      userService.newBeanUser(user);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(9, constraintViolations.size());
    }
  }

  @Test
  void testIsValidBeanClassConstraint() throws Exception {

    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();
    rule.setPropertyName("firstName,id");
    rule.setRuleType("CUSTOM_VALIDATION");
    rule.setRule("com.ssnc.health.core.common.validation.validator.CustomValidator");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("firstName,id is not valid");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("department.category");
    rule.setRuleType("CUSTOM_VALIDATION");
    rule.setRule(
        "validatorClass=com.ssnc.health.core.common.validation.validator.RootBeanCustomValidator, rootBean=true");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("RootBeanCustomValidator is not valid");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("department.category");
    rule.setRuleType("CUSTOM_VALIDATION");
    rule.setRule(
        "validatorClass=com.ssnc.health.core.common.validation.validator.CustomDepartmentValidator");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("CustomDepartmentValidator is not valid");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("id");
    rule.setRuleType("CUSTOM_FIELD_VALIDATION");
    rule.setRule("com.ssnc.health.core.common.validation.validator.CustomFieldValidator");
    rule.setRuleOrder(1);
    rule.setRuleset("newUser");
    rule.setMessage("id is not valid");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    Mockito.when(repository.findByRuleset("newUserCustomValidators")).thenReturn(rules);

    User user = new User();
    user.setDepartment(new Department());
    user.setRoles(new ArrayList<>());
    user.getRoles().add(new Role());
    user.getRoles().add(new Role());
    user.getRoles().get(1).setPermits(new ArrayList<>());
    user.getRoles().get(1).getPermits().add(new Permit());
    
    try {
      userService.newUserCustomValidators(user);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(4, constraintViolations.size());
    }
  }

  @Test
  void testIsValidSuperClassConstraint() throws Exception {
    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();
    rule.setPropertyName("firstName");
    rule.setRuleType("NotBlank");
    rule.setRuleOrder(1);
    rule.setRuleset("superClassFields");
    rule.setMessage("firstName is required");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    rule = new ValidationRule();
    rule.setPropertyName("roles[].roleName");
    rule.setRuleType("NotBlank");
    rule.setRuleOrder(2);
    rule.setRuleset("superClassFields");
    rule.setMessage("roleName is required");
    rule.setObjectType(ObjectType.BEAN);
    rules.add(rule);

    Mockito.when(repository.findByRuleset("superClassFields")).thenReturn(rules);

    SubUser user = new SubUser();
    user.setDepartment(new Department());
    user.setRoles(new ArrayList<>());
    user.getRoles().add(new SubRole());
    user.getRoles().add(new SubRole());
    user.getRoles().get(1).setPermits(new ArrayList<>());
    user.getRoles().get(1).getPermits().add(new Permit());
    
    try {
      userService.superClassFields(user);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(3, constraintViolations.size());
    }
  }

  @Test
  void testIsValidJson() throws IOException, NotFoundException {
    List<ValidationRule> rules = createValidationBeanRules();
    rules.forEach(rule -> rule.setObjectType(ObjectType.JSON));
    Mockito.when(repository.findByRuleset("jsonUser")).thenReturn(rules);

    User user = new User();
    user.setId(23l);

    user.setStartDate(LocalDate.of(2020, 11, 1));
    user.setEndDate(LocalDate.of(2019, 11, 1));
    user.setPwd("");
    user.setPwdVerify("ask");

    user.setDepartment(new Department());
    user.setRoles(new ArrayList<>());
    user.getRoles().add(new Role());
    user.getRoles().add(new Role());
    user.getRoles().get(1).setPermits(new ArrayList<>());
    user.getRoles().get(1).getPermits().add(new Permit());

    String strUserString = objectMapper.writeValueAsString(user);
    try {
      userService.newJsonUser(strUserString);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(9, constraintViolations.size());
    }
  }

  @Test
  void testIsValidParam() throws IOException, NotFoundException {
    List<ValidationRule> rules = new ArrayList<>();
    ValidationRule rule = new ValidationRule();
    rule.setPropertyName("firstName");
    rule.setRuleType("NotBlank");
    rule.setRuleOrder(1);
    rule.setRuleset("paramsFirstName");
    rule.setMessage("firstName is required");
    rule.setObjectType(ObjectType.PARAM);
    rules.add(rule);
    Mockito.when(repository.findByRuleset("paramsFirstName")).thenReturn(rules);

    List<ValidationRule> rules1 = new ArrayList<>();

    rule = new ValidationRule();
    rule.setPropertyName("lastName");
    rule.setRuleType("NotBlank");
    rule.setRuleOrder(2);
    rule.setRuleset("paramsLastName");
    rule.setMessage("lastName is required");
    rule.setObjectType(ObjectType.PARAM);
    rules1.add(rule);

    Mockito.when(repository.findByRuleset("paramsLastName")).thenReturn(rules1);
    
    try {
      userService.params(null, null);
      Assertions.fail();
    } catch (ConstraintViolationException e) {
      final Set<ConstraintViolation<?>> constraintViolations = e.getConstraintViolations();
      Assertions.assertNotNull(constraintViolations);
      Assertions.assertEquals(2, constraintViolations.size());
    }
  }
}

@Configuration
@ComponentScan(basePackages = "com.ssnc.health.core.common.validation")
class ContextConfig {
  @Bean
  public ObjectMapper objectMapper() {
    ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.registerModule(new JavaTimeModule());
    objectMapper.configure(DeserializationFeature.ACCEPT_SINGLE_VALUE_AS_ARRAY, true);
    objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    return objectMapper;
  }
}

@Service
@Validated
class TestUserService {
  public void newBeanUser(@ValidRuleset(name = "newUser") User user) {}

  public void loadProvider(
      @ValidRuleset(name = "loadProvider") ProviderInfo providerInfo,
      ConstraintViolationException exception) {}

  public void newUserCustomValidators(@ValidRuleset(name = "newUserCustomValidators") User user) {}

  public void superClassFields(@ValidRuleset(name = "superClassFields") User user) {}

  public void newJsonUser(@ValidRuleset(name = "jsonUser") String user) {}

  public void newJsonSupervisor(@ValidRuleset(name = "jsonSupervisor") String user) {}
  
  public void createWork(@ValidRuleset(name = "createWorkRule") String work) {}

  public void params(
      @ValidRuleset(name = "paramsFirstName") String firstName,
      @ValidRuleset(name = "paramsLastName") String lastName) {}
}

@Getter
@Setter
class User {
  String firstName;
  Long id;
  Department department;

  LocalDate startDate;
  LocalDate endDate;

  String pwd;
  String pwdVerify;

  List<Role> roles;
}

@Getter
@Setter
class SubUser extends User {
  String middleName;
}

@Getter
@Setter
class Role {
  String roleName;

  List<Permit> permits;
}

@Getter
@Setter
class SubRole extends Role {
  String roleType;
}

@Getter
@Setter
class Permit {
  String permitName;
}

@Getter
@Setter
class Department {
  String departmentName;
  String category;
}

class CustomValidator implements ConstraintValidator<ValidRuleset, User> {

  @Override
  public boolean isValid(User value, ConstraintValidatorContext context) {
    return value.getFirstName() != null && value.getId() != null;
  }
}

class CustomFieldValidator implements ConstraintValidator<ValidRuleset, Long> {

  @Override
  public boolean isValid(Long value, ConstraintValidatorContext context) {
    return value != null;
  }
}

class RootBeanCustomValidator implements ConstraintValidator<ValidRuleset, User> {

  @Override
  public boolean isValid(User value, ConstraintValidatorContext context) {
    return false;
  }
}

class CustomDepartmentValidator implements ConstraintValidator<ValidRuleset, Department> {

  @Override
  public boolean isValid(Department value, ConstraintValidatorContext context) {
    return value != null && value.getCategory() != null;
  }
}

class CustomProviderValidator implements ConstraintValidator<ValidRuleset, Provider> {

  @Override
  public boolean isValid(Provider value, ConstraintValidatorContext context) {
    ValidationUtil.addInvalidIndex(context, 0);
    ValidationUtil.addInvalidIndex(context, 1);
    HibernateConstraintValidatorContext hibernateConstraintValidatorContext =
        context.unwrap(HibernateConstraintValidatorContext.class);
    hibernateConstraintValidatorContext.addMessageParameter("providerPeriod", "REPLACED VALUE");

    return false;
  }
}

class CustomProviderTermValidator implements ConstraintValidator<ValidRuleset, ProviderPeriod> {

  @Override
  public boolean isValid(ProviderPeriod value, ConstraintValidatorContext context) {
    if (value.getStartDate() != null
        && value.getTermDate() != null
        && (!value.getTermDate().isAfter(value.getStartDate()))) {
      return false;
    }
    return true;
  }
}

class CustomProviderRooBeanValidator implements ConstraintValidator<ValidRuleset, ProviderInfo> {

  @Override
  public boolean isValid(ProviderInfo value, ConstraintValidatorContext context) {
    boolean result = true;
    int i = 0;
    for (ProviderPeriod pp : value.getProvider().getProviderPeriod()) {
      if (pp.getStartDate() != null
          && pp.getTermDate() != null
          && (!pp.getTermDate().isAfter(pp.getStartDate()))) {
        ValidationUtil.addInvalidIndex(context, i, 1);
        result = false;
      }

      i++;
    }
    return result;
  }
}
