package com.ssnc.health.core.common.log4j;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.cloud.config.client.ConfigClientProperties.AUTHORIZATION;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Configuration;

@SpringBootTest(classes = TestConfig.class, properties = {"spring.cloud.config.username=cloudtest",
    "spring.cloud.config.password=cloudtest"})
class CloudConfigAuthorizationProviderTest {
  @Test
  void testCloudConfigProps() throws Exception {
    System.setProperty("spring.cloud.config.token", "test-token");
    CloudConfigAuthorizationProvider provider = new CloudConfigAuthorizationProvider();
    HttpURLConnection conn = new MockHttpURLConnection(new URL("http://localhost/"));
    provider.addAuthorization(conn);
    System.clearProperty("spring.cloud.config.token");
    assertEquals("Basic Y2xvdWR0ZXN0OmNsb3VkdGVzdA==", conn.getRequestProperty(AUTHORIZATION));
  }

  @Test
  void testLoggingAuthProps() throws Exception {
    System.setProperty("logging.auth.username", "test");
    System.setProperty("logging.auth.password", "test");
    
    CloudConfigAuthorizationProvider provider = new CloudConfigAuthorizationProvider();
    HttpURLConnection conn = new MockHttpURLConnection(new URL("http://localhost/"));
    provider.addAuthorization(conn);
    
    System.clearProperty("logging.auth.username");
    System.clearProperty("logging.auth.password");
    
    assertEquals("Basic dGVzdDp0ZXN0", conn.getRequestProperty(AUTHORIZATION));
  }
}


class MockHttpURLConnection extends HttpURLConnection {
  Map<String, String> props = new HashMap<>();

  public MockHttpURLConnection(URL u) {
    super(null);
  }

  @Override
  public void disconnect() {}

  @Override
  public boolean usingProxy() {
    return false;
  }

  @Override
  public void connect() throws IOException {}

  public void setRequestProperty(String key, String value) {
    props.put(key, value);
  }

  public String getRequestProperty(String key) {
    return props.get(key);
  }
}


@Configuration
class TestConfig {
}
