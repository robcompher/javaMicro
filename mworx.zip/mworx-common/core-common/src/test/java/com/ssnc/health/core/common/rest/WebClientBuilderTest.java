package com.ssnc.health.core.common.rest;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.TestConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.web.reactive.function.client.WebClient;
import com.fasterxml.jackson.databind.ObjectMapper;

@ExtendWith(SpringExtension.class)
@ContextConfiguration(classes = WEBConfig.class)
class WebClientBuilderTest {
  @SuppressWarnings("removal")
  @Test
  void createWebClient() {
    WebClient.Builder builder =
        WebClientBuilder.getDefaultWebClientBuilder("http://localhost:8080", "TestClient");
    WebClient client = builder.build();
    assertNotNull(client);
  }
}

@TestConfiguration
@ComponentScan(
    basePackages = {"com.ssnc.health.core.common.rest", "com.ssnc.health.core.common.utils"})
class WEBConfig {
  @Bean
  public ObjectMapper objectMapper() {
    return new ObjectMapper();
  }
}
