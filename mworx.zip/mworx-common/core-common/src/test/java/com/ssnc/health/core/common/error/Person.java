/*
 * FILE : Person.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2019- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.error;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import lombok.Data;

@Data
public class Person {

    @NotNull
    @Size(min = 4, max = 60)
    private String firstName;

    @NotNull
    @Size(min = 4, max = 60)
    private String lastName;

    @NotNull
    @Size(min = 1, max = 1)
    private String gender;

    private String group;

    private String identifier;


}
