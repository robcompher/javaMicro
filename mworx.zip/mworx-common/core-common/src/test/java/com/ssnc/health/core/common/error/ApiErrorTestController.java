package com.ssnc.health.core.common.error;

import javax.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by dt216896 on 2/2/2020.
 */
@Controller
@RequestMapping("/test")
public class ApiErrorTestController {


    @GetMapping(value = "/notfoundexception")
    public @ResponseBody String notFoundException()
    {
       throw new EntityNotFoundException(Person.class, "first Name", "Alex");
    }

    @GetMapping(value = "/exception")
    public @ResponseBody String exception()
    {
        throw new RuntimeException("error");
    }

    @PostMapping(path="/getmemberpost/{firstName}")
    public Person getMemberPost(@PathVariable String firstName)
    {
        Person person = new Person();
        person.setFirstName(firstName);
        person.setLastName("Lastname");
        person.setGender("M");
        return person;
    }

    @GetMapping(path="/getmember/{firstName}")
    public Person getMember(@PathVariable String firstName)
    {
        Person person = new Person();
        person.setFirstName(firstName);
        person.setLastName("Lastname");
        person.setGender("M");
        return person;
    }


    @PostMapping(path="/savemember", produces = {MediaType.APPLICATION_JSON_VALUE})
    public ResponseEntity<Person> save(@Valid @RequestBody Person person) {
       return new ResponseEntity<Person>(person, HttpStatus.OK);
    }

}