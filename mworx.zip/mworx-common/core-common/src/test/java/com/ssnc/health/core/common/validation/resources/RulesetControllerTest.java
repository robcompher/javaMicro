/*
 * FILE : RulesetControllerTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.resources;

import static org.junit.Assert.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import java.util.ArrayList;
import java.util.List;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Pageable;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssnc.health.core.common.error.RestExceptionHandler;
import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.service.RulesService;

/** Created by dt214746 */
@RunWith(SpringRunner.class)
@EnableWebMvc
@SpringBootTest
@ContextConfiguration(classes = {RulesetController.class})
public class RulesetControllerTest {

  private MockMvc mockMvc;

  @Autowired WebApplicationContext wac;

  @Autowired RulesetController rulesetController;
  @MockBean private RulesService ruleService;
  private AutoCloseable closeable;
  
  @BeforeEach
  public void setup() {
    closeable = MockitoAnnotations.openMocks(this);
    mockMvc =
        MockMvcBuilders.standaloneSetup(rulesetController)
            .setControllerAdvice(new RestExceptionHandler())
            .build();
  }
  
  @AfterEach
  public void releaseMocks() throws Exception {
    closeable.close();
  }

  @Test
  public void testWrongMethod() throws Exception {
    mockMvc.perform(get("api/rule/getRulesByRuleset")).andExpect(status().is4xxClientError());
  }

  @Test
  public void testGetAllRulesByRuleset() throws Exception {
    String reqRuleset = "addRuleset";
    List<ValidationRule> mockrules = new ArrayList<ValidationRule>();
    ValidationRule mockrule = new ValidationRule();
    mockrule.setPropertyName("fieldname");
    mockrule.setRule("rule pattern");
    mockrule.setRuleType("NOT_NULL_RULE");
    mockrule.setRuleOrder(1);
    mockrule.setRuleset("addRuleset");
    mockrules.add(mockrule);
    Mockito.when(ruleService.findRulesByRuleset(reqRuleset)).thenReturn(mockrules);

    mockMvc
        .perform(MockMvcRequestBuilders.get("/api/validation/getAllRulesByRuleset/addRuleset"))
        .andExpect(status().isOk())
        .andExpect(
            new ResultMatcher() {
              @Override
              public void match(MvcResult result) throws Exception {
                ObjectMapper mapper = new ObjectMapper();
                List<ValidationRule> rules =
                    mapper.readValue(
                        result.getResponse().getContentAsString(),
                        new TypeReference<List<ValidationRule>>() {});
                assertNotNull(rules);
                assertEquals(1, rules.get(0).getRuleOrder());
                assertEquals("rule pattern", rules.get(0).getRule());
              }
            });
  }

  @Test
  public void testGetRulesByRuleset() throws Exception {
    List<ValidationRule> mockrules = new ArrayList<ValidationRule>();
    ValidationRule mockrule = new ValidationRule();
    mockrule.setPropertyName("fieldname");
    mockrule.setRule("rule pattern");
    mockrule.setRuleType("NOT_NULL_RULE");
    mockrule.setRuleOrder(1);
    mockrule.setRuleset("addRuleset");
    mockrules.add(mockrule);
    Mockito.when(ruleService.findRulesByRuleset(Mockito.anyString(), Mockito.any(Pageable.class)))
        .thenReturn(mockrules);

    mockMvc
        .perform(MockMvcRequestBuilders.get("/api/validation/getRulesByRuleset/addRuleset/0/10"))
        .andExpect(status().isOk())
        .andExpect(
            new ResultMatcher() {
              @Override
              public void match(MvcResult result) throws Exception {
                ObjectMapper mapper = new ObjectMapper();
                List<ValidationRule> rules =
                    mapper.readValue(
                        result.getResponse().getContentAsString(),
                        new TypeReference<List<ValidationRule>>() {});
                assertNotNull(rules);
                assertEquals(1, rules.get(0).getRuleOrder());
                assertEquals("rule pattern", rules.get(0).getRule());
              }
            });
  }

  @Test
  public void testInvalidRequest() throws Exception {

    mockMvc
        .perform(
            MockMvcRequestBuilders.post("/api/validation/getRulesByRuleset")
                .param("page", "0")
                .param("pageSize", "10")
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().is4xxClientError());
  }
}
