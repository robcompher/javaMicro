/*
 * FILE : ValidationUtilTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.validator;

import javax.validation.ConstraintViolation;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import com.ssnc.health.core.common.error.ApiValidationError;

/** Created by dt208075 */
class ValidationUtilTest {

  @Test
  void testCreateConstraintViolation() {

    @SuppressWarnings("unchecked")
    ConstraintViolation<Object> constraintViolation =
        ValidationUtil.createConstraintViolation(new Object(), "import834Membership",
            "Prefix is required", "membershipInfo.family.members[0].prefixName", "Low",
            (Class<Object>) ((Object) this).getClass());

    ApiValidationError apiValidationError =
        ValidationUtil.toApiValidationError(constraintViolation);
    Assertions.assertNotNull(constraintViolation);
    Assertions.assertEquals("Low", apiValidationError.getPriority());
  }
}
