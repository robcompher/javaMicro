/*
 * FILE : ApiErrorTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.error;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import org.junit.Assert;
import org.junit.Test;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import com.fasterxml.jackson.databind.ObjectMapper;

/**
 * Created by dt216896
 */
@RunWith(SpringRunner.class)
@EnableWebMvc
@SpringBootTest
@ContextConfiguration(classes = {ApiErrorTestController.class})
public class ApiErrorTest {

  private MockMvc mockMvc;

  @Autowired
  WebApplicationContext wac;

  @Autowired
  ApiErrorTestController apiErrorTestController;

  private AutoCloseable closeable;

  @BeforeEach
  public void setup() {
    closeable = MockitoAnnotations.openMocks(this);
    mockMvc = MockMvcBuilders.standaloneSetup(apiErrorTestController)
        .setControllerAdvice(new RestExceptionHandler()).build();
  }

  @AfterEach
  public void releaseMocks() throws Exception {
    closeable.close();
  }

  @Test
  public void testException() throws Exception {
    mockMvc.perform(get("/test/exception")).andExpect(status().isInternalServerError());
  }

  @Test
  public void testNotFoundException() throws Exception {
    mockMvc.perform(get("/test/notfoundexception")).andExpect(status().isNotFound())
        .andExpect(MockMvcResultMatchers.jsonPath("apierror.status").value("NOT_FOUND"))
        .andExpect(MockMvcResultMatchers.jsonPath("apierror.message")
            .value("Person was not found for parameters {first Name=Alex}"));
  }


  @Test
  public void testWrongMethod() throws Exception {
    mockMvc.perform(get("/test/getmemberpost/srichand")).andExpect(status().isBadRequest())
        .andExpect(new ResultMatcher() {
          @Override
          public void match(MvcResult result) throws Exception {
            ObjectMapper mapper = new ObjectMapper();
            ApiError errorResponse =
                mapper.readValue(result.getResponse().getContentAsString(), ApiError.class);
            Assert.assertEquals(HttpStatus.BAD_REQUEST, errorResponse.getStatus());
            Assert.assertEquals("Request method 'GET' not supported", errorResponse.getMessage());
          }
        });
  }



  @Test
  public void testMethodArgumentNotValidException() throws Exception {
    Person person = new Person();
    person.setFirstName("S");
    person.setLastName("Last");
    person.setGender("M");
    ObjectMapper mapper = new ObjectMapper();

    mockMvc
        .perform(MockMvcRequestBuilders.post("/test/savemember")
            .content(mapper.writeValueAsString(person)).contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON))
        .andExpect(status().isUnprocessableEntity()).andExpect(new ResultMatcher() {
          @Override
          public void match(MvcResult result) throws Exception {
            ObjectMapper mapper = new ObjectMapper();
            ApiError errorResponse =
                mapper.readValue(result.getResponse().getContentAsString(), ApiError.class);
            Assert.assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, errorResponse.getStatus());
            Assert.assertEquals("Validation error", errorResponse.getMessage());
            Assert.assertEquals("size must be between 4 and 60",
                errorResponse.getSubErrors().get(0).getMessage());
            Assert.assertEquals("person", errorResponse.getSubErrors().get(0).getObject());
            Assert.assertEquals("firstName", errorResponse.getSubErrors().get(0).getField());
            Assert.assertEquals("S", errorResponse.getSubErrors().get(0).getRejectedValue());
          }
        });
  }
}
