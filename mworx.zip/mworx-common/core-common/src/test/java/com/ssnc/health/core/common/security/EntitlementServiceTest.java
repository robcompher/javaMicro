/*
 * FILE : EntitlementServiceTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.security;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ssnc.health.core.common.model.LobInfo;

/** @author dt216896 */
@ExtendWith(SpringExtension.class)
@TestInstance(Lifecycle.PER_CLASS)
@ActiveProfiles("test")
public class EntitlementServiceTest {

  EntitlementService entitlementService;

  @BeforeEach
  public void setUp() throws Exception {
    SecurityContext ctx = SecurityContextHolder.createEmptyContext();
    Map<String, Object> headersMap = new HashMap<>();
    headersMap.put("header", "HeaderValue");
    Map<String, Object> claimsMap = new HashMap<>();
    claimsMap.put("currentOrganizationName", "ALPHA");
    claimsMap.put("currentOrganizationId", Long.valueOf("1"));
    claimsMap.put("currentLobId", Long.valueOf("2"));
    claimsMap.put("currentLobName", "COMMERCIAL");
    Jwt jwt =
        new Jwt(
            "BatchJobToken",
            new Date().toInstant(),
            new Date().toInstant().plus(3, ChronoUnit.HOURS),
            headersMap,
            claimsMap);
    List<GrantedAuthority> authoritues = new ArrayList<>();
    JwtAuthenticationToken token = new JwtAuthenticationToken(jwt, authoritues);
    ctx.setAuthentication(token);
    SecurityContextHolder.setContext(ctx);
    entitlementService = new EntitlementService();
  }

  @AfterEach
  public void done() {
    SecurityContextHolder.clearContext();
  }

  @Test
  public void validEntitlementServiceTest() {
    LobInfo lobInfo = new LobInfo();
    lobInfo.setLobId(Long.valueOf("2"));
    lobInfo.setOrganizationId(Long.valueOf("1"));
    lobInfo.setOrganizationName("ALPHA");
    lobInfo.setLobName("COMMERCIAL");
    assertTrue(entitlementService.hasLobAccess(lobInfo));
  }
  @Test
  public void validOrgIdEntitlementServiceTest() {

    LobInfo lobInfo = new LobInfo();
    lobInfo.setOrganizationId(Long.valueOf("1"));
    lobInfo.setOrganizationName("invalidorg");
    lobInfo.setLobName("COMMERCIAL");
    assertTrue(entitlementService.hasLobAccess(lobInfo));
  }

  @Test
  public void invalidLobIdEntitlementServiceTest() {

    LobInfo lobInfo = new LobInfo();
    lobInfo.setLobId(Long.valueOf("3"));
    lobInfo.setOrganizationId(Long.valueOf("1"));
    lobInfo.setOrganizationName("ALPHA");
    lobInfo.setLobName("COMMERCIAL");
    assertFalse(entitlementService.hasLobAccess(lobInfo));
  }

  @Test
  public void invalidOrgnameEntitlementServiceTest() {

    LobInfo lobInfo = new LobInfo();
    lobInfo.setOrganizationName("invalidorg");
    lobInfo.setLobName("COMMERCIAL");
    assertFalse(entitlementService.hasLobAccess(lobInfo));
  }

  @Test
  public void invalidOrgIdEntitlementServiceTest() {

    LobInfo lobInfo = new LobInfo();
    lobInfo.setOrganizationId(Long.valueOf("5"));
    lobInfo.setOrganizationName("OrganizationName");
    lobInfo.setLobName("COMMERCIAL");
    assertFalse(entitlementService.hasLobAccess(lobInfo));
  }
  

  @Test
  public void validSystemEntitlementServiceTest() {
	    SecurityContextHolder.clearContext();
	  SecurityContext ctx = SecurityContextHolder.createEmptyContext();
	    Map<String, Object> headersMap = new HashMap<>();
	    headersMap.put("header", "HeaderValue");
	    Map<String, Object> claimsMap = new HashMap<>();
	    claimsMap.put("currentOrganizationName", "Organization");
	    claimsMap.put("currentOrganizationId", Long.valueOf("1"));
	    claimsMap.put("currentLobId", Long.valueOf("2"));
	    claimsMap.put("currentLobName", "SYSTEM");
	    Jwt jwt =
	        new Jwt(
	            "BatchJobToken",
	            new Date().toInstant(),
	            new Date().toInstant().plus(3, ChronoUnit.HOURS),
	            headersMap,
	            claimsMap);
	    List<GrantedAuthority> authoritues = new ArrayList<>();
	    JwtAuthenticationToken token = new JwtAuthenticationToken(jwt, authoritues);
	    ctx.setAuthentication(token);
	    SecurityContextHolder.setContext(ctx);
    LobInfo lobInfo = new LobInfo();
    lobInfo.setLobId(Long.valueOf("2"));
    lobInfo.setOrganizationId(Long.valueOf("1"));
    lobInfo.setOrganizationName("Organization2");
    lobInfo.setLobName("COMMERCIAL");
    assertTrue(entitlementService.hasLobAccess(lobInfo));
  }
}
