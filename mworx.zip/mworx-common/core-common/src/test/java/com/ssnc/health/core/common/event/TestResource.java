package com.ssnc.health.core.common.event;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import javax.validation.ConstraintViolationException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.ssnc.health.core.common.error.EntityNotFoundException;
import com.ssnc.health.core.common.event.model.EventDTO;
import com.ssnc.health.core.common.event.model.WebhookDTO;
import com.ssnc.health.core.common.validation.config.CustomConstraintViolationException;
import com.ssnc.health.core.common.validation.validator.ValidationUtil;
import lombok.Data;

@RestController
public class TestResource {
  @Autowired
  Environment env;

  @RequestMapping(value = "/auth/oauth/token", produces = {MediaType.APPLICATION_JSON_VALUE},
      consumes = {MediaType.APPLICATION_FORM_URLENCODED_VALUE}, method = RequestMethod.POST)
  public Map<String, Object> token() {
    return Map.ofEntries(Map.entry("access_token", "token"), Map.entry("expires_in", 100));
  }

  @RequestMapping(value = "/auth/api/user/getUserByUserName",
      produces = {MediaType.APPLICATION_JSON_VALUE}, consumes = {MediaType.APPLICATION_JSON_VALUE},
      method = RequestMethod.POST)
  public Map<String, Object> getUserByUserName() {
    return Map.ofEntries(Map.entry("userId", 9999));
  }

  @SuppressWarnings("unchecked")
  @RequestMapping(value = "/workflow", produces = {MediaType.APPLICATION_JSON_VALUE},
      consumes = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.POST)
  public Map<String, Object> workflow(@RequestBody String requestBody) {
    if (requestBody.contains("APPLICANT_NEW")) {
      return Map.ofEntries(Map.entry("result", "success"), Map.entry("requestBody", requestBody));
    } else if (requestBody.contains("APPLICANT_422")) {
      TestMember member = new TestMember(1234l);
      ConstraintViolationException exception = new CustomConstraintViolationException();
      exception.getConstraintViolations()
          .add(ValidationUtil.createConstraintViolation(member, "ruleSet", "Test Error Message",
              "name", "HIGH", (Class<Object>) ((Object) member).getClass()));
      throw exception;
    } else if (requestBody.contains("APPLICANT_404")) {
      throw new EntityNotFoundException(TestMember.class, "id", "1234");
    }
    throw new IllegalStateException(
        "{ \"apierror\": {" + "    \"status\": \"UNPROCESSABLE_ENTITY\","
            + "    \"timestamp\": \"2020-10-21T18:54:37.1306\","
            + "    \"message\": \"Validation error\",  \"debugMessage\": null,"
            + "    \"subErrors\": [   {"
            + "        \"object\": \"CreateMemberEnrollmentRestController\","
            + "        \"field\": \"family.members[0].emails[0].emailType\","
            + "        \"rejectedValue\": null,"
            + "        \"message\": \"Email Type is required for the given Person Email\","
            + "        \"resolved\": false, \"hint\": null,      \"priority\": \"HIGH\", "
            + "        \"severity\": \"Error\"      },      {"
            + " \"object\": \"CreateMemberEnrollmentRestController\","
            + "        \"field\": \"family.members[0].phones[0].phoneType\","
            + "        \"rejectedValue\": null,"
            + "        \"message\": \"Phone Type is required for the given Person Phone\","
            + "        \"resolved\": false, \"hint\": null,"
            + "        \"priority\": \"HIGH\", \"severity\": \"Error\"   },     {"
            + " \"object\": \"CreateMemberEnrollmentRestController\","
            + "        \"field\": \"family.members[0].memberDateSpans[0].spanId\","
            + "        \"rejectedValue\": null,"
            + "        \"message\": \"Span Id is required for Member Date span\","
            + "        \"resolved\": false, \"hint\": null,"
            + "        \"priority\": \"HIGH\", \"severity\": \"Error\"      }    ]}}");
  }

  @RequestMapping(value = "/correspondence", produces = {MediaType.APPLICATION_JSON_VALUE},
      consumes = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.POST)
  public ResponseEntity<Void> correspondence(@RequestBody String requestBody) {
    return ResponseEntity.ok().build();
  }

  @RequestMapping(value = "/webhooks/by-event-names", produces = {MediaType.APPLICATION_JSON_VALUE},
      consumes = {MediaType.APPLICATION_JSON_VALUE}, method = RequestMethod.POST)
  public List<WebhookDTO> getWebhooksByEventNames(@RequestBody ByEventName byEventName) {
    List<WebhookDTO> webhooks = new ArrayList<>();
    WebhookDTO webhook = new WebhookDTO();
    webhook.setId(1l);
    webhook.setWebhookName("Workflow");
    webhook.setAuthType("OAUTH");
    webhook.setUnwrapPayload("N");
    webhook.setTargetUrl(String.format("http://localhost:%s/workflow",
        env.getProperty("local.server.port", Integer.class)));

    List<EventDTO> events = new ArrayList<>();
    EventDTO eventDTO = new EventDTO();
    eventDTO.setId(1l);
    eventDTO.setEventId(134l);
    eventDTO.setEventType("APPLICANT");
    eventDTO.setEventName("NEW");
    events.add(eventDTO);

    eventDTO = new EventDTO();
    eventDTO.setId(2l);
    eventDTO.setEventId(135l);
    eventDTO.setEventType("APPLICANT");
    eventDTO.setEventName("ERROR");
    events.add(eventDTO);

    eventDTO = new EventDTO();
    eventDTO.setId(2l);
    eventDTO.setEventId(135l);
    eventDTO.setEventType("APPLICANT");
    eventDTO.setEventName("422");
    events.add(eventDTO);

    eventDTO = new EventDTO();
    eventDTO.setId(2l);
    eventDTO.setEventId(135l);
    eventDTO.setEventType("APPLICANT");
    eventDTO.setEventName("404");
    events.add(eventDTO);

    webhook.setEvents(events);
    webhooks.add(webhook);

    webhook = new WebhookDTO();
    webhook.setId(2l);
    webhook.setWebhookName("Correspondence");
    webhook.setAuthType("OAUTH");
    webhook.setTargetUrl(String.format("http://localhost:%s/correspondence",
        env.getProperty("local.server.port", Integer.class)));

    events = new ArrayList<>();
    eventDTO = new EventDTO();
    eventDTO.setId(12l);
    eventDTO.setEventId(140l);
    eventDTO.setEventType("CORRESPONDENCE");
    eventDTO.setEventName("NEW");
    events.add(eventDTO);
    webhook.setEvents(events);
    webhooks.add(webhook);
    return webhooks;
  }

  @RequestMapping(value = "/ping", method = RequestMethod.GET)
  public String ping() {
    return "ok";
  }
}


@Data
class ByEventName {
  List<String> eventNames;
}
