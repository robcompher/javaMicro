/*
 * FILE : PaginationUtilTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.utils;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ssnc.health.core.common.model.Pagination;

@ExtendWith(SpringExtension.class)
class PaginationUtilTest {

  @Test
  void paginationTests() {
    Pagination pagination = null;

    // pagination null, no mappings passed - expected default pagination values - no sort
    Pageable pageable = PaginationUtil.getPageable(pagination);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // pagination null, mappings null - expected default pagination values - no sort
    pageable = PaginationUtil.getPageable(pagination, null);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // Pagination with no sort, mappings null - expected body pagination values - no sort
    pagination = new Pagination();
    pagination.setPageSize(5);
    pagination.setPage(1);
    pageable = PaginationUtil.getPageable(pagination, null);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // Pagination with empty sort, mappings null - expected body pagination values - no sort
    pagination = new Pagination();
    pagination.setPageSize(5);
    pagination.setPage(1);
    pagination.setSortBy("");
    pagination.setSortOrder("asc");
    pageable = PaginationUtil.getPageable(pagination, null);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // Pagination with null sort, mappings null- expected body pagination values - no sort
    pagination = new Pagination();
    pagination.setPageSize(5);
    pagination.setPage(1);
    pagination.setSortBy(null);
    pagination.setSortOrder("asc");
    pageable = PaginationUtil.getPageable(pagination, null);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // Pagination with null sort order, mappings null - expected default sort order with given
    // sortby
    pagination = new Pagination();
    pagination.setPageSize(5);
    pagination.setPage(1);
    pagination.setSortBy("test");
    pagination.setSortOrder(null);
    pageable = PaginationUtil.getPageable(pagination, null);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertEquals("test: ASC", pageable.getSort().toString());

    // Pagination with no page details, mappings null - expected default page size and sort order
    // with default order
    pagination = new Pagination();
    pagination.setSortBy("test");
    pageable = PaginationUtil.getPageable(pagination, null);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertEquals("test: ASC", pageable.getSort().toString());

    Map<String, String> properties = new HashMap<String, String>();
    properties.put("jobName", "jobName");
    properties.put("fileName", "fileName");
    properties.put("status", "status");
    properties.put("submittedBy", "submittedBy");
    properties.put("jobRunDate", "jobRunDate");

    // pagination with invalid sortby and no map for id - expected given page no sort
    pagination.setPageSize(5);
    pagination.setPage(1);
    pagination.setSortBy("");
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // no pagination with mappings(no map for id) - expected default page size and sort order with
    // default order
    pageable = PaginationUtil.getPageable(null, properties);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertNotNull(pageable.getSort());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // pagination with null sortby and no map for id - expected given page no sort
    pagination.setSortBy(null);
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // pagination with null sortby and no map for id - expected given page and no sort
    pagination.setSortBy("test");
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // mapping with all empty values and mapping with no id map - expected default page no sort
    pagination = new Pagination();
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertNotNull(pageable.getSort());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // pagination with sortby empty string- expected default page no sort
    pagination.setSortBy("");
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // no pagination with invalid sortby (with id mapped) - expected default page with id asc
    properties.put("id", "jobId");
    pagination.setSortBy("test");
    pageable = PaginationUtil.getPageable(null, properties);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertNotNull(pageable.getSort());
    assertEquals("jobId: ASC", pageable.getSort().toString());

    // pagination with only sort order set, no mappings passed - expected default page with no sort
    pagination = new Pagination();
    pagination.setSortOrder("desc");
    pageable = PaginationUtil.getPageable(pagination, null);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertEquals(Sort.unsorted(), pageable.getSort());

    // pagination with only sort and mappings - expected default page with id sort
    pagination = new Pagination();
    pagination.setSortOrder("desc");
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertNotNull(pageable.getSort());
    assertEquals("jobId: DESC", pageable.getSort().toString());

    // pagination with only sort and mappings - expected default page with id sort
    pagination = new Pagination();
    pagination.setSortOrder("desc");
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(0, pageable.getPageNumber());
    assertEquals(10, pageable.getPageSize());
    assertNotNull(pageable.getSort());
    assertEquals("jobId: DESC", pageable.getSort().toString());

    // pagination and properties - expect given page and sort with default order
    pagination.setPageSize(5);
    pagination.setPage(1);
    pagination.setSortBy("jobName");
    pagination.setSortOrder(null);
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertNotNull(pageable.getSort());
    assertEquals("jobName: ASC", pageable.getSort().toString());

    // pagination and properties - expect given page and sort order
    pagination.setPageSize(5);
    pagination.setPage(1);
    pagination.setSortBy("jobName");
    pagination.setSortOrder("desc");
    pageable = PaginationUtil.getPageable(pagination, properties);
    assertNotNull(pageable);
    assertEquals(1, pageable.getPageNumber());
    assertEquals(5, pageable.getPageSize());
    assertNotNull(pageable.getSort());
    assertEquals("jobName: DESC", pageable.getSort().toString());
  }
}
