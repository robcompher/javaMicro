/*
 * FILE : TemplateServiceApplicationTests.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.mock.mockito.SpyBean;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.messaging.Message;
import org.springframework.messaging.SubscribableChannel;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.transaction.support.TransactionTemplate;
import org.springframework.util.concurrent.SettableListenableFuture;
import com.ssnc.health.core.common.event.config.ServiceAccountContextHolder;
import com.ssnc.health.core.common.event.config.WebhookInitializerController;
import com.ssnc.health.core.common.event.model.EventQ;
import com.ssnc.health.core.common.event.model.EventQResponse;
import com.ssnc.health.core.common.event.model.WebhookDTO;
import com.ssnc.health.core.common.event.repository.EventQRepository;
import com.ssnc.health.core.common.event.repository.EventQResponseRepository;
import com.ssnc.health.core.common.event.service.EventService;
import com.ssnc.health.services.test.common.EmbeddedDatabaseTest;

@EmbeddedDatabaseTest(classes = {TestConfiguration.class}, beanName = "ds",
    webEnvironment = WebEnvironment.RANDOM_PORT,
    properties = {"spring.application.name=webhook-test",
        "spring.main.allow-bean-definition-overriding=true", "spring.liquibase.enabled=true",
        "logging.level.root=ERROR", //"logging.level.reactor.netty.http.client=DEBUG",
        "webhook.agent.enabled=true", "webhook.agent.poller.number-of-events-per-poll=5",
        "webhook.agent.poller.poll-seconds=2", "webhook.agent.channel.thread-count=5",
        "webhook.agent.request-handler.logging.enabled=true",
        "gateway.base.url=http://localhost:${local.server.port}",
        "access.token.url=lb://webhook-test/auth/oauth/token",
        "user.by.username.url=lb://webhook-test/auth/api/user/getUserByUserName", 
        "service-account.username=test",
        "service-account.password=test",
        "metadata.webhooks.by-event-names.url=lb://webhook-test/webhooks/by-event-names",
        "event.applicant.new = APPLICANT_NEW",
        "event.applicant.effectuated = APPLICANT_EFFECTUATED",
        "event.applicant.updated = APPLICANT_UPDATED", "event.member.updated = MEMBER_UPDATED",
        "event.member.terminated = MEMBER_TERMINATED", "event.inprogress.event = INPROGRESS_EVENT",
        "event.completed.event = COMPLETED_EVENT", "event.applicant.422 = APPLICANT_422",
        "event.applicant.404 = APPLICANT_404", "event.applicant.error = APPLICANT_ERROR",
        "event.correspondence.new = CORRESPONDENCE_NEW"})
@ActiveProfiles("test")
@Transactional(propagation = Propagation.NOT_SUPPORTED)
class EventServiceDBTests {
  @Autowired
  private PlatformTransactionManager transactionManager;
  @Autowired
  EventPublisher publisher;
  @Autowired
  EventQRepository repository;
  @Autowired
  EventQResponseRepository responseRepository;
  @Autowired
  private ServiceAccountContextHolder serviceAccountContext;

  @SpyBean
  EventService eventService;
  @LocalServerPort
  int port;

  @Autowired
  SubscribableChannel outboundWebhookEventChannel;
  @Autowired
  SubscribableChannel webhookResponseChannel;

  @Autowired
  DirectChannel updateEventQResponseChannel;
  @Autowired
  WebhookInitializerController webhookInitializer;

  private TransactionTemplate transactionTemplate;

  @BeforeEach
  public void setup() {
    transactionTemplate = new TransactionTemplate(transactionManager);
  }

  @Test
  void publishEventTestInProgress()
      throws InterruptedException, ExecutionException, TimeoutException {
    String eventName = "INPROGRESS_EVENT";
    CountDownLatch latch = new CountDownLatch(1);

    SettableListenableFuture<Message<?>> outboudMessageFuture = new SettableListenableFuture<>();
    this.outboundWebhookEventChannel.subscribe((message) -> outboudMessageFuture.set(message));

    publishEvent(eventName);

    Optional<EventQ> eventQOptional = getEventQByEventName(eventName);
    assertTrue(eventQOptional.isPresent());

    assertEquals(eventName, eventQOptional.get().getPayload().getEventName());
    assertNotNull(eventQOptional.get().getPayload().getData());

    Message<?> messageToAssert = outboudMessageFuture.get(10, TimeUnit.SECONDS);
    assertNotNull(messageToAssert);
    latch.await(100, TimeUnit.MILLISECONDS);
    eventQOptional = getEventQByEventName(eventName);
    assertEquals(Status.INPROCESS, eventQOptional.get().getStatus());
  }

  @Test
  void updateStatusEventTest() throws InterruptedException {
    String eventName = "COMPLETED_EVENT";

    publishEvent(eventName);

    Optional<EventQ> eventQOptional = getEventQByEventName(eventName);

    assertTrue(eventQOptional.isPresent());

    serviceAccountContext.set();
    transactionTemplate.executeWithoutResult(status -> {
      EventQ eventQ = eventQOptional.get();
      eventQ.setStatus(Status.COMPLETED);
      eventService.updateEventQ(eventQ);
    });
    serviceAccountContext.clear();
    CountDownLatch latch = new CountDownLatch(1);
    latch.await(10, TimeUnit.SECONDS);
    Optional<EventQ> eventQOptional1 = getEventQByEventName(eventName);
    assertEquals(Status.COMPLETED, eventQOptional1.get().getStatus());
  }

  @Test
  void publishEventTestFullCycleSuccess()
      throws InterruptedException, ExecutionException, TimeoutException {
    publishEventTestFullCycle("APPLICANT_NEW", Status.COMPLETED);
  }

  @Test
  void publishEventTestFullCycleError()
      throws InterruptedException, ExecutionException, TimeoutException {
    publishEventTestFullCycle("APPLICANT_ERROR", Status.ERROR);
  }

  @Test
  void publishEventTestFullCycle422()
      throws InterruptedException, ExecutionException, TimeoutException {
    publishEventTestFullCycle("APPLICANT_422", Status.ERROR);
  }

  @Test
  void publishEventTestFullCycle404()
      throws InterruptedException, ExecutionException, TimeoutException {
    publishEventTestFullCycle("APPLICANT_404", Status.ERROR);
  }

  @Test
  void publishEventTestFullCycleVoidResponse()
      throws InterruptedException, ExecutionException, TimeoutException {
    publishEventTestFullCycle("CORRESPONDENCE_NEW", Status.COMPLETED);
  }

  void publishEventTestFullCycle(String eventName, Status responseStatus)
      throws InterruptedException, ExecutionException, TimeoutException {
    CountDownLatch latch = new CountDownLatch(1);

    SettableListenableFuture<Message<?>> responseMessageFuture = new SettableListenableFuture<>();
    this.webhookResponseChannel.subscribe((message) -> responseMessageFuture.set(message));

    publishEvent(eventName);

    Optional<EventQ> eventQOptional = getEventQByEventName(eventName);
    assertTrue(eventQOptional.isPresent());

    assertEquals(eventName, eventQOptional.get().getPayload().getEventName());
    assertNotNull(eventQOptional.get().getPayload().getData());

    Message<?> messageToAssert = responseMessageFuture.get(15, TimeUnit.SECONDS);
    assertNotNull(messageToAssert);

    latch.await(5, TimeUnit.SECONDS);
    eventQOptional = getEventQByEventName(eventName);
    assertEquals(Status.COMPLETED, eventQOptional.get().getStatus());

    List<EventQResponse> responses = responseRepository.findByEventQEventNameAndWebhookName(
        eventName, ((WebhookDTO) messageToAssert.getHeaders().get(Constants.WEBHOOK_KEY.name()))
            .getWebhookName());
    assertEquals(responseStatus, responses.get(0).getStatus());
  }

  private void publishEvent(String eventName) {
    // set context with service account
    serviceAccountContext.set();
    transactionTemplate.executeWithoutResult(status -> {
      EventQEvent<TestMember> event = new EventQEvent<>(eventName);
      event.setData(new TestMember(1L));

      publisher.publish(event);
    });
    // remove service account
    serviceAccountContext.clear();
  }

  Optional<EventQ> getEventQByEventName(String eventName) {
    return repository.findOne((root, query, criteriaBuilder) -> {
      return criteriaBuilder.equal(root.get("eventName"), eventName);
    });
  }
}
