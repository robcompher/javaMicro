/*
 * FILE : EclipseLinkJPAConfiguration.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event;

import java.util.Arrays;
import java.util.List;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.flyway.FlywayAutoConfiguration;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.JpaBaseConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.cloud.client.DefaultServiceInstance;
import org.springframework.cloud.client.ServiceInstance;
import org.springframework.cloud.loadbalancer.core.ServiceInstanceListSupplier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.messaging.Message;
import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;
import com.ssnc.health.core.common.event.config.ServiceAccountMethodInterceptor;
import com.ssnc.health.core.common.model.AuditorAwareImpl;
import liquibase.integration.spring.SpringLiquibase;
import reactor.core.publisher.Flux;

@Configuration
@EnableAutoConfiguration(
    exclude = {DataSourceAutoConfiguration.class, FlywayAutoConfiguration.class})
@EnableTransactionManagement
@EnableJpaRepositories("com.ssnc.health.core.common.event")
@EntityScan("com.ssnc.health.core.common.event")
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
@ComponentScan(
    basePackages = {"com.ssnc.health.core.common.error", "com.ssnc.health.core.common.event",
        "com.ssnc.health.core.common.rest", "com.ssnc.health.core.common.utils"})
public class TestConfiguration extends JpaBaseConfiguration {

  protected TestConfiguration(DataSource dataSource, JpaProperties properties,
      ObjectProvider<JtaTransactionManager> jtaTransactionManager) {
    super(dataSource, properties, jtaTransactionManager);
  }

  @Override
  protected AbstractJpaVendorAdapter createJpaVendorAdapter() {
    return new EclipseLinkJpaVendorAdapter();
  }

  @Override
  public Map<String, Object> getVendorProperties() {
    return Map.ofEntries(Map.entry("eclipselink.weaving", "false"),
        Map.entry("eclipselink.cache.shared.default", "false"));
  }

  @Bean
  public AuditorAware<Long> auditorAware() {
    return new AuditorAwareImpl();
  }

  @Bean
  public SpringLiquibase liquibase(DataSource dataSource) {
    SpringLiquibase liquibase = new SpringLiquibase();
    liquibase.setChangeLog("classpath:/db/changelog/event.changelog-master.xml");
    liquibase.setDataSource(dataSource);
    return liquibase;
  }

  @Bean
  public IntegrationFlow applicantNewFlow(
      ServiceAccountMethodInterceptor serviceAccountMethodInterceptor) {
    return IntegrationFlows.from("webhookResponseChannel")
        .filter(Message.class, m -> m.getHeaders().get("EVENT_NAME").equals("APPLICANT_NEW"))
        .handle(new ApplicantNewResponseHandler())//, s -> s.advice(serviceAccountMethodInterceptor))
        .get();
  }

  @Bean
  public JwtDecoder nimbusJwtDecoder() {
    return new JwtDecoder() {
      @Override
      public Jwt decode(String token) throws JwtException {
        return Jwt.withTokenValue("test").header("alg", "none").claim("user_id", 999L).build();
      }
    };
  }
  
  @Bean
  @Primary
  ServiceInstanceListSupplier serviceInstanceListSupplier(Environment env) {
      return new ServiceInstanceListSupplier() {

        @Override
        public Flux<List<ServiceInstance>> get() {
          return Flux.just(Arrays
              .asList(new DefaultServiceInstance(getServiceId() + "1", getServiceId(), "localhost", Integer.valueOf(env.getProperty("local.server.port", "8080")), false)));
        }

        @Override
        public String getServiceId() {
          return "webhook-test";
        }
        
      };
  }
}


@EnableWebSecurity
@Order(Ordered.HIGHEST_PRECEDENCE)
class TestSecurityConfig extends WebSecurityConfigurerAdapter {

  @Override
  public void configure(WebSecurity web) throws Exception {
    web.ignoring().antMatchers("/**");
  }

}
