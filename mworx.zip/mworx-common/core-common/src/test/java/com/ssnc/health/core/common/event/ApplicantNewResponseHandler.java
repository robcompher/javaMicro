package com.ssnc.health.core.common.event;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.integration.handler.AbstractMessageHandler;
import org.springframework.messaging.Message;
import org.springframework.security.core.context.SecurityContextHolder;

public class ApplicantNewResponseHandler extends AbstractMessageHandler {
  private static final Logger LOG = LogManager.getLogger(ApplicantNewResponseHandler.class);

  @Override
  protected void handleMessageInternal(Message<?> message) {
    String payloadString = (String) message.getPayload();
    LOG.debug(payloadString);
    LOG.debug("SecurityContext: {}", SecurityContextHolder.getContext().getAuthentication());
    if (message.getHeaders().get(Constants.RESPONSE_STATUS_CODE.name(), Integer.class) == 200) {
      LOG.debug("SUCCESS {}", message.getHeaders().get(Constants.RESPONSE_STATUS_CODE.name()));
    } else {
      LOG.debug("ERROR  {}", message.getHeaders().get(Constants.RESPONSE_STATUS_CODE.name()));
    }

    if (message.getHeaders().get(Constants.STATUS.name(), Status.class).equals(Status.COMPLETED)) {
      LOG.debug("SUCCESS");
    } else {
      LOG.debug("ERROR");
    }
  }
}
