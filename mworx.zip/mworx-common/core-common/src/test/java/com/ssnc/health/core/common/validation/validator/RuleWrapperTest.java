/*
 * FILE : RuleValidatorTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.validator;

import org.hibernate.validator.cfg.ConstraintDef;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.CsvSource;
import com.ssnc.health.core.common.validation.internal.RuleWrapper;
import com.ssnc.health.core.common.validation.model.ValidationRule;

class RuleWrapperTest {

  @ParameterizedTest
  @CsvSource({
      "AssertFalse, 'propertyName1,prop2'",
      "AssertTrue, propertyName",
      "Email, propertyName",
      "Future, propertyName",
      "FutureOrPresent, propertyName",
      "PastOrPresent, propertyName",
      "BeforeDate, 'startDate,endDate'",
      "AfterDate, 'startDate,endDate'",
      "SameOrAfterDate, 'startDate,endDate'",
  })
  void testAnnotationTypeAndProps(String type, String props) {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType(type);
    rule.setPropertyName(props);
    Assertions.assertNotNull(new RuleWrapper(rule).getConstraintDef());
  }
  
  @ParameterizedTest
  @CsvSource({
      "Negative",
      "NegativeOrZero",
      "NotBlank",
      "notempty",
      "NotNull",
      "Null",
      "Past",
      "Positive",
      "PositiveOrZero"
  })
  void testAnnotationType(String type) {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType(type);
    Assertions.assertNotNull(new RuleWrapper(rule).getConstraintDef());
  }
  
  @ParameterizedTest
  @CsvSource({
      "DecimalMax, 'value=\"123\", inclusive=true', value=123",
      "DecimalMin, 'value=\"123\", inclusive=true', value=123",
      "Email, 'regexp=\"[a-z]*\"', regexp=[a-z]*",
      "Max, 'value=34', value=34",
      "Min, 'value=34', value=34",
  })
  void testAnnotationTypeAndRule(String type, String ruleParam, String contains) {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType(type);
    rule.setRule(ruleParam);
    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(constraintDef.toString().contains(contains));
  }

  @Test
  void testDigitsAnnotation() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("Digits");
    rule.setRule("fraction=123, integer=23");
    Assertions.assertNotNull(new RuleWrapper(rule).getConstraintDef());

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(constraintDef.toString().contains("fraction=123"));
    Assertions.assertTrue(constraintDef.toString().contains("integer=23"));
  }

  @Test
  void testEmailAnnotation() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("Email");
    rule.setRule("regexp=\"[a-z]*\",flags=\"CASE_INSENSITIVE\"");

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(constraintDef.toString().contains("regexp=[a-z]*"));
    Assertions.assertTrue(
        constraintDef.toString().contains("javax.validation.constraints.Pattern$Flag"));
  }

  @Test
  void testPatternAnnotation() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("Pattern");
    rule.setRule("regexp=\"[a-z]*\", flags=\"CASE_INSENSITIVE\"");

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(constraintDef.toString().contains("regexp=[a-z]*"));
    Assertions.assertTrue(
        constraintDef.toString().contains("javax.validation.constraints.Pattern$Flag"));
  }

  @Test
  void testSizeAnnotation() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("Size");
    rule.setRule("min=1,max=20");

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);

    Assertions.assertTrue(constraintDef.toString().contains("min=1"));
    Assertions.assertTrue(constraintDef.toString().contains("max=20"));
  }

  @Test
  void testSizeAnnotationNoMax() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("Size");
    rule.setRule("min=1");

    RuleWrapper ruleWrapper = new RuleWrapper(rule);
    Assertions.assertNull(ruleWrapper.getConstraintDef());
    Assertions.assertTrue(
        ruleWrapper.getRule().getMessage().startsWith("Error occured while configuring rule"));
  }

  @Test
  void testRangeAnnotation() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("Range");
    rule.setRule("min=1,max=20");

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(constraintDef.toString().contains("min=1"));
    Assertions.assertTrue(constraintDef.toString().contains("max=20"));
  }

  @Test
  void testScriptAssertAnnotation() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("ScriptAssert");
    rule.setRule("lang=\"javascript\",script=\"_this.startDate.before(_this.endDate)\"");

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(constraintDef.toString().contains("lang=javascript"));
    Assertions.assertTrue(
        constraintDef.toString().contains("script=_this.startDate.before(_this.endDate)"));
  }

  @Test
  void testSpELAnnotation() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("SpELAssert");
    rule.setPropertyName("pwd,pwdVerify");
    rule.setRule("value=\"password.equals(passwordVerify)\"");

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(
        constraintDef.toString().contains("value=password.equals(passwordVerify)"));

    rule.setRule(
        "value=\"password.equals(passwordVerify)\",applyIf=\"firstName != null\",helpers=\"com.ssnc.health.core.common.validation.validator.Phone\"");
    Assertions.assertNotNull(new RuleWrapper(rule).getConstraintDef());
  }

  @Test
  void testSpELAnnotationApplyIfHelpers() {
    ValidationRule rule = new ValidationRule();
    rule.setRuleType("SpELAssert");
    rule.setPropertyName("pwd,pwdVerify");
    rule.setRule(
        "value=\"password.equals(passwordVerify)\",applyIf=\"firstName != null\",helpers=\"com.ssnc.health.core.common.validation.validator.Phone\"");

    ConstraintDef<?, ?> constraintDef = new RuleWrapper(rule).getConstraintDef();
    Assertions.assertNotNull(constraintDef);
    Assertions.assertTrue(
        constraintDef.toString().contains("value=password.equals(passwordVerify)"));
    Assertions.assertTrue(constraintDef.toString().contains("applyIf=firstName != null"));
    Assertions.assertTrue(constraintDef.toString().contains("helpers=class com.ssnc.health.core.common.validation.validator.Phone"));
  }
}
