/*
 * FILE : RulesServiceTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.service;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.repository.RulesRepository;
import com.ssnc.health.core.common.validation.serviceimpl.RulesServiceImpl;

/**
 * This is to test RuleService
 *
 * @author dt214746
 */
@ExtendWith(SpringExtension.class)
class RulesServiceTest {

  @InjectMocks
  private RulesServiceImpl ruleService;

  @Mock
  private RulesRepository mockRulesRepository;

  private AutoCloseable closeable;

  @BeforeEach
  public void init() {
    closeable = MockitoAnnotations.openMocks(this);
  }

  @AfterEach
  public void releaseMocks() throws Exception {
    closeable.close();
  }

  @Test
  void testFindByRuleset() {
    ValidationRule rule = createValidationRule();
    Mockito.when(mockRulesRepository.save(Mockito.any(ValidationRule.class))).thenReturn(rule);

    List<ValidationRule> rulesList = ruleService.findRulesByRuleset("addRuleset");
    assertNotNull(rulesList);
  }

  @Test
  void testFindByRulesetWithPagination() {
    ValidationRule rule = createValidationRule();
    Mockito.when(mockRulesRepository.save(Mockito.any(ValidationRule.class))).thenReturn(rule);
    PageRequest pageRequest = PageRequest.of(0, 10);
    List<ValidationRule> rulesList = ruleService.findRulesByRuleset("addRuleset", pageRequest);
    assertNotNull(rulesList);
  }

  public ValidationRule createValidationRule() {
    ValidationRule rule = new ValidationRule();
    rule.setPropertyName("fieldname");
    rule.setRule("rule pattern");
    rule.setRuleType("NOT_NULL_RULE");
    rule.setRuleOrder(1);
    rule.setRuleset("addRuleset");
    return rule;
  }
}
