package com.ssnc.health.core.common.event;

import lombok.Getter;
import lombok.Setter;

public @Getter @Setter class TestMember {
  Long memberId;

  public TestMember(Long memberId) {
    this.memberId = memberId;
  }
}
