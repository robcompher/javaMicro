/*
 * FILE : EventQServiceTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import java.util.List;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.data.domain.PageRequest;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssnc.health.core.common.event.model.EventQ;
import com.ssnc.health.core.common.event.repository.EventQRepository;
import com.ssnc.health.core.common.event.service.EventServiceImpl;

@ExtendWith(SpringExtension.class)
class EventServiceTest {

  private static ObjectMapper objectMapper = new ObjectMapper();
  private static final String RECORD_TEXT =
      "{\"eventName\": \"TEST_EVENT\", \"headers\": {\"recordId\": 12325}, \"data\": {\"memberId\": 5433}}";

  @InjectMocks
  private EventServiceImpl eventQServiceImpl;

  @Mock
  private EventQRepository mockEventQRepository;
  
  private AutoCloseable closeable;

  @BeforeEach
  public void openMocks() {
    closeable = MockitoAnnotations.openMocks(this);
  }

  @AfterEach
  public void releaseMocks() throws Exception {
    closeable.close();
  }

  @Test
  void testSaveEventQ() throws Exception {
    EventQ eventQ = createEventQ();
    Mockito.when(mockEventQRepository.save(Mockito.any(EventQ.class))).thenReturn(eventQ);
    assertNotNull(eventQ);
  }

  @Test
  void testUpdateEventQ() throws Exception {
    EventQ eventQ = createEventQ();
    Mockito.when(mockEventQRepository.save(Mockito.any(EventQ.class))).thenReturn(eventQ);
    eventQ.setStatus(Status.ERROR);
    Mockito.when(mockEventQRepository.save(Mockito.any(EventQ.class))).thenReturn(eventQ);
    assertNotNull(eventQ);
    assertEquals(Status.ERROR, eventQ.getStatus());
  }

  @Test
  void testFindByEventNameWithPagination() throws Exception {
    EventQ eventQ = createEventQ();
    Mockito.when(mockEventQRepository.save(Mockito.any(EventQ.class))).thenReturn(eventQ);
    PageRequest pageRequest = PageRequest.of(0, 10);
    List<EventQ> rulesList = eventQServiceImpl.findByEventName("TEST_EVENT", pageRequest);
    assertNotNull(rulesList);
  }

  public EventQ createEventQ() throws Exception {
    EventQ eventQ = new EventQ();
    eventQ.setEventName("TEST_EVENT");
    eventQ.setStatus(Status.OPEN);
    eventQ.setPayload(
        objectMapper.readValue(RECORD_TEXT, new TypeReference<EventQEvent<Object>>() {}));
    return eventQ;
  }
}
