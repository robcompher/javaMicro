/*
 * FILE : CustomValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.internal;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;

public class CustomValidator implements ConstraintValidator<Custom, Object> {

  @Autowired private LocalValidatorFactoryBean validatorFactory;

  private ConstraintValidator<?, Object> validator;

  @Override
  public void initialize(Custom custom) {
    validator =
        validatorFactory.getConstraintValidatorFactory().getInstance(custom.validatorClass());
  }

  @Override
  public boolean isValid(Object value, ConstraintValidatorContext context) {
    if (this.validator == null) {
      return false;
    }

    return this.validator.isValid(value, context);
  }
}
