/*
 * FILE : EventQResponse.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import com.ssnc.health.core.common.event.Status;
import com.ssnc.health.core.common.model.Auditable;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity(name = "EVENTQ_RESPONSE")
@Data
@EqualsAndHashCode(callSuper = false)
public class EventQResponse extends Auditable<Long> implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(
      name = "EVENTQ_RESPONSE_SEQ",
      sequenceName = "EVENTQ_RESPONSE_SEQ",
      allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EVENTQ_RESPONSE_SEQ")
  @Column(name = "EVENTQ_RESPONSE_ID", unique = true, nullable = false)
  private Long id;

  @Column(name = "WEBHOOK_ID", nullable = false)
  private Long webhookId;

  @Column(name = "WEBHOOK_NAME")
  private String webhookName;

  @Column(name = "WEBHOOK_RESPONSE")
  @Convert(converter = com.ssnc.health.core.common.event.model.WebhookResponseConverter.class)
  private String response;

  @Column(name = "STATUS")
  @Enumerated(EnumType.STRING)
  private Status status;

  @ManyToOne(fetch = FetchType.LAZY)
  @JoinColumn(name = "EVENTQ_ID", nullable = false)
  private EventQ eventQ;
}
