/*
 * FILE : MethodValidationConfig.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.config;

import javax.validation.Validator;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;

/** Created by dt214746 on 2/10/2020. */
@Configuration
@ComponentScan({"com.ssnc.health.core.common.validation", "com.ssnc.health.core.common.error"})
@ConditionalOnClass(
    name = {"org.springframework.data.jpa.repository.JpaRepository", "javax.sql.DataSource"})
public class MethodValidationConfig {
  @Bean
  public Validator validator() {
    return new CustomLocalValidatorFactoryBean();
  }

  @Bean
  public MethodValidationPostProcessor methodValidationPostProcessor(Validator validator) {
    MethodValidationPostProcessor methodValidationPostProcessor =
        new CustomMethodValidationPostProcessor();
    methodValidationPostProcessor.setValidator(validator);
    return methodValidationPostProcessor;
  }
}
