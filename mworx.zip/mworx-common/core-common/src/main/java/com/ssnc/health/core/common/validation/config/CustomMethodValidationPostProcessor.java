/*
 * FILE : CustomMethodValidationPostProcessor.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.config;

import javax.validation.Validator;
import org.aopalliance.aop.Advice;
import org.springframework.lang.Nullable;
import org.springframework.validation.beanvalidation.MethodValidationPostProcessor;

/**
 * 
 * @author DT214743
 *
 */
public class CustomMethodValidationPostProcessor extends MethodValidationPostProcessor {
  private static final long serialVersionUID = -1344303545067807380L;

  @Override
  protected Advice createMethodValidationAdvice(@Nullable Validator validator) {
    return (validator != null
        ? new CustomMethodValidationInterceptor(validator)
        : new CustomMethodValidationInterceptor());
  }
}
