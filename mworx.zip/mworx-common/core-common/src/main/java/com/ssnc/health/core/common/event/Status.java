package com.ssnc.health.core.common.event;

public enum Status {
  OPEN,
  INPROCESS,
  COMPLETED,
  ERROR;
}
