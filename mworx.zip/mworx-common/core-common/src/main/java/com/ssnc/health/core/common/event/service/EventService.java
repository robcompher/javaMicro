/*
 * FILE : EventQService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */

package com.ssnc.health.core.common.event.service;

import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import com.ssnc.health.core.common.event.EventQEvent;
import com.ssnc.health.core.common.event.model.EventQ;

public interface EventService {

  List<EventQ> findByEventName(String eventName, Pageable pageable);

  EventQ addEventQ(EventQ eventQ);

  Optional<EventQ> updateEventQ(EventQ eventQ);

  void queueEvent(EventQEvent<?> event);

}
