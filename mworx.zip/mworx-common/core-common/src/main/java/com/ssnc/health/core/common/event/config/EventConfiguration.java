/*
 * FILE : EventConfiguration.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.config;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executors;
import javax.persistence.EntityManagerFactory;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.cloud.client.loadbalancer.reactive.LoadBalancedExchangeFilterFunction;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.ConfigurableEnvironment;
import org.springframework.core.env.EnumerablePropertySource;
import org.springframework.core.env.Environment;
import org.springframework.integration.config.EnableIntegration;
import org.springframework.integration.dsl.ConsumerEndpointSpec;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.MessageChannels;
import org.springframework.integration.dsl.Pollers;
import org.springframework.integration.handler.LoggingHandler;
import org.springframework.integration.jpa.dsl.Jpa;
import org.springframework.integration.jpa.support.parametersource.ParameterSource;
import org.springframework.integration.scheduling.PollerMetadata;
import org.springframework.integration.transaction.DefaultTransactionSynchronizationFactory;
import org.springframework.integration.transaction.ExpressionEvaluatingTransactionSynchronizationProcessor;
import org.springframework.integration.transaction.TransactionInterceptorBuilder;
import org.springframework.integration.transaction.TransactionSynchronizationFactory;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessagingException;
import org.springframework.security.concurrent.DelegatingSecurityContextExecutor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.interceptor.TransactionInterceptor;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import com.ssnc.health.core.common.event.Constants;
import com.ssnc.health.core.common.event.Status;
import com.ssnc.health.core.common.event.model.EventQ;
import com.ssnc.health.core.common.event.model.EventQResponse;
import com.ssnc.health.core.common.event.model.WebhookDTO;
import com.ssnc.health.core.common.event.service.WebhookService;
import com.ssnc.health.core.common.event.service.WebhookServiceImpl;
import com.ssnc.health.core.common.rest.AccessTokenFilter;
import com.ssnc.health.core.common.rest.AccessTokenHelper;

/**
 * EventConfiguration: Configuration related to webhook processing - event publishing, event
 * processing and response processing.
 *
 * @author dt214743
 */
@Configuration
@ConditionalOnProperty(name = "webhook.agent.enabled", havingValue = "true")
@EnableIntegration
@EntityScan("com.ssnc.health.core.common.event")
@Order(Ordered.LOWEST_PRECEDENCE - 100)
public class EventConfiguration {
  @Autowired
  private EntityManagerFactory entityManagerFactory;
  @Autowired
  private PlatformTransactionManager txManager;

  @Value("${webhook.agent.poller.poll-seconds:5}")
  private int pollTime;

  @Value("${webhook.agent.poller.number-of-events-per-poll:5}")
  private int maxResults;

  @Value("${webhook.agent.channel.thread-count:5}")
  private int channelThreadCount;

  @Bean
  public AccessTokenFilter serviceAccountTokenFilter() {
    return new AccessTokenFilter(serviceAccountTokenHelper());
  }

  @Bean
  @ConfigurationProperties(prefix = "service-account")
  public AccessTokenHelper serviceAccountTokenHelper() {
    return new AccessTokenHelper();
  }

  @Bean
  public WebClient serviceAccountWebClient(WebClient.Builder webClientBuilder,
      LoadBalancedExchangeFilterFunction lbFunction) {
    return webClientBuilder.filter(lbFunction).filter(serviceAccountTokenFilter()).build();
  }

  @Bean
  public IntegrationFlow readEventQFlow(Environment env) {
    Map<String, String> serviceEvents = serviceEvents(env);
    return IntegrationFlows
        .from(Jpa.inboundAdapter(this.entityManagerFactory).entityClass(EventQ.class)
            .jpaQuery("from com.ssnc.health.core.common.event.model.EventQ q "
                + "where q.status = com.ssnc.health.core.common.event.Status.OPEN"
                + " AND upper(q.eventName) IN :eventNames")
            .maxResults(maxResults).parameterSource(new ParameterSource() {
              @Override
              public boolean hasValue(String paramName) {
                return true;
              }

              @Override
              public Object getValue(String paramName) {
                return serviceEvents.values();
              }
            }), e -> e.poller(pollerMetadata()).autoStartup(false).id("readEventQInboundAdaptor"))
        .split().enrich(payload -> payload.property("status", Status.INPROCESS))
        .channel(outboundWebhookEventChannel()).get();
  }

  @Bean
  public IntegrationFlow webhookResponseProcessingFlow() {
    return f -> f
        .publishSubscribeChannel(
            new DelegatingSecurityContextExecutor(Executors.newFixedThreadPool(channelThreadCount)),
            sc -> sc.id("webhookResponseChannel").interceptor(serviceAccountChannelInterceptor())
                .subscribe(sf -> sf.log(LoggingHandler.Level.INFO))
                .subscribe(
                    sf -> sf
                        .transform(Message.class,
                            m -> m.getHeaders().get(Constants.REQUEST_PAYLOAD_KEY.name(),
                                EventQ.class))
                        .enrich(e -> e.property("status", Status.COMPLETED))
                        .channel(updateEventQChannel()))
                .subscribe(sf -> sf.transform(Message.class, m -> {
                  EventQ eventQ =
                      m.getHeaders().get(Constants.REQUEST_PAYLOAD_KEY.name(), EventQ.class);
                  WebhookDTO webhook =
                      m.getHeaders().get(Constants.WEBHOOK_KEY.name(), WebhookDTO.class);
                  EventQResponse response = new EventQResponse();
                  response.setEventQ(eventQ);
                  response.setWebhookId(webhook.getId());
                  response.setWebhookName(webhook.getWebhookName());
                  if (m.getPayload() instanceof String) {
                    response.setResponse((String) m.getPayload());
                  }
                  response.setStatus(m.getHeaders().get(Constants.STATUS.name(), Status.class));
                  return response;
                }).channel(updateEventQResponseChannel())));
  }

  @Bean
  public IntegrationFlow webhookResponseErrorProcessingFlow() {
    return f -> f.channel(webhookResponseErrorChannel()).log(LoggingHandler.Level.ERROR)
        .enrichHeaders(h -> h
            .headerExpression(Constants.EVENT_NAME.name(),
                extractHeader(Constants.EVENT_NAME.name()))
            .headerExpression(Constants.REQUEST_PAYLOAD_KEY.name(),
                extractHeader(Constants.REQUEST_PAYLOAD_KEY.name()))
            .headerExpression(Constants.WEBHOOK_KEY.name(),
                extractHeader(Constants.WEBHOOK_KEY.name()))
            .headerExpression(Constants.RESPONSE_STATUS_CODE.name(),
                "payload.cause instanceof T(org.springframework.web.reactive.function.client.WebClientResponseException) "
                    + "? payload.cause.rawStatusCode : 500")
            .header(Constants.STATUS.name(), Status.ERROR))
        .<MessagingException, String>transform(ex -> {
          if (ex.getCause() instanceof WebClientResponseException) {
            return ((WebClientResponseException) ex.getCause()).getResponseBodyAsString();
          }
          return ExceptionUtils.getRootCauseMessage(ex.getCause());
        }).channel("webhookResponseChannel");
  }

  private String extractHeader(String key) {
    return String.format("payload.failedMessage.headers.%s", key);
  }

  @Bean
  public IntegrationFlow updateEventQFlow() {
    return IntegrationFlows.from(updateEventQChannel())
        .handle(Jpa.outboundAdapter(this.entityManagerFactory).entityClass(EventQ.class),
            ConsumerEndpointSpec::transactional)
        .get();
  }

  @Bean
  public IntegrationFlow updateEventQResponseFlow() {
    return IntegrationFlows.from(updateEventQResponseChannel())
        .handle(Jpa.outboundAdapter(this.entityManagerFactory).entityClass(EventQResponse.class),
            ConsumerEndpointSpec::transactional)
        .get();
  }

  @Bean
  public MessageChannel outboundWebhookEventChannel() {
    return MessageChannels.publishSubscribe(Executors.newFixedThreadPool(channelThreadCount)).get();
  }

  @Bean
  public PollerMetadata pollerMetadata() {
    return Pollers.fixedDelay(pollTime * 1_000l).advice(serviceAccountMethodInterceptor())
        .advice(transactionInterceptor())
        .transactionSynchronizationFactory(outboundTransactionSynchronizationFactory()).get();
  }

  private TransactionInterceptor transactionInterceptor() {
    return new TransactionInterceptorBuilder().transactionManager(this.txManager).build();
  }

  @Bean
  public MessageChannel updateEventQChannel() {
    return MessageChannels.direct().get();
  }

  @Bean
  public MessageChannel updateEventQResponseChannel() {
    return MessageChannels.direct().get();
  }

  @Bean
  public MessageChannel webhookResponseErrorChannel() {
    return MessageChannels.executor(Executors.newFixedThreadPool(channelThreadCount)).get();
  }

  @Bean
  public TransactionSynchronizationFactory outboundTransactionSynchronizationFactory() {
    ExpressionEvaluatingTransactionSynchronizationProcessor processor =
        new ExpressionEvaluatingTransactionSynchronizationProcessor();

    processor.setBeforeCommitChannel(updateEventQChannel());

    return new DefaultTransactionSynchronizationFactory(processor);
  }

  @Bean
  public ServiceAccountChannelInterceptor serviceAccountChannelInterceptor() {
    return new ServiceAccountChannelInterceptor();
  }

  @Bean
  public ServiceAccountMethodInterceptor serviceAccountMethodInterceptor() {
    return new ServiceAccountMethodInterceptor();
  }

  @Bean
  public ServiceAccountContextHolder serviceAccountContextHolder() {
    return new ServiceAccountContextHolder();
  }

  @SuppressWarnings("rawtypes")
  @Bean
  public Map<String, String> serviceEvents(Environment env) {
    Map<String, String> properties = new HashMap<>();
    if (env instanceof ConfigurableEnvironment) {
      ((ConfigurableEnvironment) env).getPropertySources().stream()
          .filter(propertySource -> propertySource instanceof EnumerablePropertySource)
          .forEach(propertySource -> Arrays
              .stream(((EnumerablePropertySource) propertySource).getPropertyNames())
              .filter(key -> (key.startsWith("event.") && propertySource.getProperty(key) != null))
              .forEach(key -> properties.put(key,
                  String.valueOf(propertySource.getProperty(key)).toUpperCase())));
    }

    return properties;
  }

  @Bean
  @ConditionalOnMissingBean
  @Lazy
  public WebhookService webhookService() {
    return new WebhookServiceImpl();
  }
}
