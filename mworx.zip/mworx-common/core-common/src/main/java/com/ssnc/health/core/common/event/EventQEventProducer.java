package com.ssnc.health.core.common.event;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;
import com.ssnc.health.core.common.event.service.EventService;

@Component
public class EventQEventProducer {
  private static final Logger LOG = LogManager.getLogger(EventQEventProducer.class);

  @Autowired EventService eventService;

  @TransactionalEventListener(phase = TransactionPhase.BEFORE_COMMIT)
  public void onApplicationEvent(EventQEvent<?> event) {
    LOG.debug("Event published: {}", event);

    eventService.queueEvent(event);
  }
}
