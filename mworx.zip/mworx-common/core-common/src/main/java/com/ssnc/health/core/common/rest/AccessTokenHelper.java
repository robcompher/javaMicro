/*
 * FILE : AccessTokenHelper.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.rest;

import java.time.Instant;
import java.util.Collections;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.reactive.LoadBalancedExchangeFilterFunction;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * AccessTokenFilter: Helper class centralizes getting access-token based property file
 * configuration
 *
 * @author dt214743
 */
public class AccessTokenHelper {
  private WebClient authWebClient;
  private AuthToken authToken;

  @Autowired
  private Environment env;

  @Autowired
  private WebClient.Builder webClientBuilder;
  
  @Autowired
  private LoadBalancedExchangeFilterFunction lbFunction;

  @Autowired
  private JwtDecoder jwtDecoder;

  @Getter
  @Setter
  private String usernameKey = "username";

  // This is not a password. It is the key field to send the password.
  // suppress "squid:S2068"
  @Getter
  @Setter
  private String passwordKey = "password"; // NOSONAR

  @Getter
  @Setter
  private String grantTypeKey = "grant_type";

  @Getter
  @Setter
  private String scopeKey = "scope";

  @Getter
  @Setter
  private String username;

  @Getter
  @Setter
  private String password;

  @Getter
  @Setter
  private String grantType = "password";

  @Getter
  @Setter
  private String scope = "all";

  public String getAccessToken() {
    if (this.authToken == null || this.authToken.isExpired()) {
      MultiValueMap<String, String> data = new LinkedMultiValueMap<>();
      data.add(usernameKey, username);
      data.add(passwordKey, password);
      data.add(grantTypeKey, grantType);
      data.add(scopeKey, scope);
      this.authToken = authWebClient().post().uri(env.getProperty("access.token.url"))
          .body(BodyInserters.fromFormData(data)).retrieve().bodyToMono(AuthToken.class).block();
    }

    return this.authToken.getAccessToken();
  }

  public JwtAuthenticationToken getJwtAuthenticationToken() {
    return new JwtAuthenticationToken(jwtDecoder.decode(getAccessToken()), Collections.emptyList());
  }

  protected WebClient authWebClient() {
    if (authWebClient == null) {
      this.authWebClient = webClientBuilder.filter(lbFunction)
          .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE)
          .build();
    }

    return authWebClient;
  }
}


@Getter
@Setter
class AuthToken {
  @JsonProperty("access_token")
  private String accessToken;

  @JsonProperty("refresh_token")
  private String refreshToken;

  @JsonProperty("token_type")
  private String tokenType;

  @JsonProperty("expires_in")
  private Integer expiresInSeconds;

  private Instant expiresInstant;

  private String scope;

  private String jti;

  public void setExpiresInSeconds(Integer expiresInSeconds) {
    this.expiresInSeconds = expiresInSeconds;
    this.setExpiresInstant(Instant.now().plusSeconds(this.getExpiresInSeconds() - 1));
  }

  public boolean isExpired() {
    return Instant.now().isAfter(getExpiresInstant());
  }
}
