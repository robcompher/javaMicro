/*
 * FILE : AbstractJsonConverter.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.utils;

import java.lang.reflect.Type;
import javax.persistence.Converter;
import org.postgresql.util.PGobject;

@Converter(autoApply = true)
public abstract class AbstractJsonConverter<T>
    implements javax.persistence.AttributeConverter<T, Object> {

  @Override
  public Object convertToDatabaseColumn(T objectValue) {
    try {
      PGobject out = new PGobject();
      out.setType("jsonb");
      out.setValue(
          objectValue != null
              ? ObjectMapperProvider.getObjectMapper().writeValueAsString(objectValue)
              : null);
      return out;
    } catch (Exception e) {
      throw new IllegalArgumentException("Unable to serialize to json field ", e);
    }
  }

  @SuppressWarnings("unchecked")
  @Override
  public T convertToEntityAttribute(Object dataValue) {
    try {
      if (dataValue instanceof PGobject && ((PGobject) dataValue).getType().equals("jsonb")) {
        return ObjectMapperProvider.getObjectMapper()
            .readValue(((PGobject) dataValue).getValue(), (Class<T>) getFieldType());
      }
      return null;
    } catch (Exception e) {
      throw new IllegalArgumentException("Unable to deserialize to json field ", e);
    }
  }

  protected abstract Type getFieldType();
}
