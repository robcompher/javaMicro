/*
 * FILE : PaginationUtil.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.utils;

import java.util.Map;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.util.CollectionUtils;
import org.springframework.util.StringUtils;
import com.ssnc.health.core.common.model.Pagination;

public class PaginationUtil {

  private static final String DEFAULT_SORT_BY = "id";

  private PaginationUtil() {}

  public static Pageable getPageable(Pagination body) {
    return getPageable(body, null);
  }

  public static Pageable getPageable(
      Pagination body, Map<String, String> dtoToEntityFieldMappings) {
    PageRequest pageRequest;
    Integer page;
    Integer pageSize;
    String sortBy = null;
    if (body != null) {
      page = body.getPage() != null ? body.getPage() : 0;
      pageSize = body.getPageSize() != null ? body.getPageSize() : 10;
      sortBy = resolveSortBy(body, dtoToEntityFieldMappings);
      Sort.Direction direction = getSortDirection(body);
      pageRequest =
          sortBy == null
              ? PageRequest.of(page, pageSize)
              : PageRequest.of(page, pageSize, Sort.by(direction, sortBy));
    } else {
      pageRequest = getDefaultPageable(dtoToEntityFieldMappings);
    }
    return pageRequest;
  }

  private static String resolveSortBy(Pagination body,
      Map<String, String> dtoToEntityFieldMappings) {
    String sortBy;
    if (CollectionUtils.isEmpty(dtoToEntityFieldMappings)) {
      sortBy = !StringUtils.hasText(body.getSortBy()) ? null : body.getSortBy();
    } else {
      sortBy =
          ((!StringUtils.hasText(body.getSortBy())
                      && dtoToEntityFieldMappings.get(DEFAULT_SORT_BY) == null)
                  || (StringUtils.hasText(body.getSortBy())
                      && dtoToEntityFieldMappings.get(body.getSortBy()) == null))
              ? null
              : getSortBy(body, dtoToEntityFieldMappings);
    }
    return sortBy;
  }

  private static String getSortBy(Pagination body, Map<String, String> dtoToEntityFieldMappings) {
    return !StringUtils.hasText(body.getSortBy())
        ? dtoToEntityFieldMappings.get(DEFAULT_SORT_BY)
        : dtoToEntityFieldMappings.get(body.getSortBy());
  }

  private static Sort.Direction getSortDirection(Pagination body) {
    return body.getSortOrder() == null
        ? Sort.DEFAULT_DIRECTION
        : Direction.fromString(body.getSortOrder());
  }

  private static PageRequest getDefaultPageable(Map<String, String> dtoToEntityFieldMappings) {
    return (CollectionUtils.isEmpty(dtoToEntityFieldMappings)
            || dtoToEntityFieldMappings.get(DEFAULT_SORT_BY) == null)
        ? PageRequest.of(0, 10)
        : PageRequest.of(
            0, 10, Sort.DEFAULT_DIRECTION, dtoToEntityFieldMappings.get(DEFAULT_SORT_BY));
  }
}
