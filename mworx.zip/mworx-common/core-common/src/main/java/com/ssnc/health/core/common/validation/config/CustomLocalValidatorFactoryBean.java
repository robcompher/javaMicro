/*
 * FILE : CustomLocalValidatorFactoryBean.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.config;

import java.io.IOException;
import java.lang.reflect.Constructor;
import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import javax.validation.Configuration;
import javax.validation.ConstraintValidatorFactory;
import javax.validation.MessageInterpolator;
import javax.validation.ParameterNameProvider;
import javax.validation.TraversableResolver;
import javax.validation.Validation;
import javax.validation.ValidationProviderResolver;
import javax.validation.ValidatorFactory;
import javax.validation.bootstrap.GenericBootstrap;
import org.hibernate.validator.messageinterpolation.ResourceBundleMessageInterpolator;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.core.DefaultParameterNameDiscoverer;
import org.springframework.core.ParameterNameDiscoverer;
import org.springframework.core.io.Resource;
import org.springframework.lang.Nullable;
import org.springframework.util.CollectionUtils;
import org.springframework.util.ReflectionUtils;
import org.springframework.validation.beanvalidation.LocalValidatorFactoryBean;
import org.springframework.validation.beanvalidation.LocaleContextMessageInterpolator;
import org.springframework.validation.beanvalidation.MessageSourceResourceBundleLocator;
import org.springframework.validation.beanvalidation.SpringConstraintValidatorFactory;

/**
 * Customized Spring LocalValidatorFactoryBean to expose configuration to create validator in
 * RuleValidator
 *
 * @author DT214743
 */
public class CustomLocalValidatorFactoryBean extends LocalValidatorFactoryBean {
  @SuppressWarnings("rawtypes")
  @Nullable
  private Class providerClass;

  @Nullable private ValidationProviderResolver validationProviderResolver;

  @Nullable private MessageInterpolator messageInterpolator;

  @Nullable private TraversableResolver traversableResolver;

  @Nullable private ConstraintValidatorFactory constraintValidatorFactory;

  @Nullable
  private ParameterNameDiscoverer parameterNameDiscoverer = new DefaultParameterNameDiscoverer();

  @Nullable private Resource[] mappingLocations;

  private final Map<String, String> validationPropertyMap = new HashMap<>();

  @Nullable private ApplicationContext applicationContext;

  @Nullable private ValidatorFactory validatorFactory;

  /**
   * Specify the desired provider class, if any.
   *
   * <p>If not specified, JSR-303's default search mechanism will be used.
   *
   * @see javax.validation.Validation#byProvider(Class)
   * @see javax.validation.Validation#byDefaultProvider()
   */
  @SuppressWarnings("rawtypes")
  public void setProviderClass(Class providerClass) {
    this.providerClass = providerClass;
    super.setProviderClass(providerClass);
  }

  /**
   * Specify a JSR-303 {@link ValidationProviderResolver} for bootstrapping the provider of choice,
   * as an alternative to {@code META-INF} driven resolution.
   *
   * @since 4.3
   */
  public void setValidationProviderResolver(ValidationProviderResolver validationProviderResolver) {
    this.validationProviderResolver = validationProviderResolver;
    super.setValidationProviderResolver(validationProviderResolver);
  }

  /**
   * Specify a custom MessageInterpolator to use for this ValidatorFactory and its exposed default
   * Validator.
   */
  public void setMessageInterpolator(MessageInterpolator messageInterpolator) {
    this.messageInterpolator = messageInterpolator;
    super.setMessageInterpolator(messageInterpolator);
  }

  /**
   * Specify a custom Spring MessageSource for resolving validation messages, instead of relying on
   * JSR-303's default "ValidationMessages.properties" bundle in the classpath. This may refer to a
   * Spring context's shared "messageSource" bean, or to some special MessageSource setup for
   * validation purposes only.
   *
   * <p><b>NOTE:</b> This feature requires Hibernate Validator 4.3 or higher on the classpath. You
   * may nevertheless use a different validation provider but Hibernate Validator's {@link
   * ResourceBundleMessageInterpolator} class must be accessible during configuration.
   *
   * <p>Specify either this property or {@link #setMessageInterpolator "messageInterpolator"}, not
   * both. If you would like to build a custom MessageInterpolator, consider deriving from Hibernate
   * Validator's {@link ResourceBundleMessageInterpolator} and passing in a Spring-based {@code
   * ResourceBundleLocator} when constructing your interpolator.
   *
   * <p>In order for Hibernate's default validation messages to be resolved still, your {@link
   * MessageSource} must be configured for optional resolution (usually the default). In particular,
   * the {@code MessageSource} instance specified here should not apply {@link
   * org.springframework.context.support.AbstractMessageSource#setUseCodeAsDefaultMessage
   * "useCodeAsDefaultMessage"} behavior. Please double-check your setup accordingly.
   *
   * @see ResourceBundleMessageInterpolator
   */
  public void setValidationMessageSource(MessageSource messageSource) {
    this.messageInterpolator =
        new ResourceBundleMessageInterpolator(
            new MessageSourceResourceBundleLocator(messageSource));
  }

  /**
   * Specify a custom TraversableResolver to use for this ValidatorFactory and its exposed default
   * Validator.
   */
  public void setTraversableResolver(TraversableResolver traversableResolver) {
    this.traversableResolver = traversableResolver;
    super.setTraversableResolver(traversableResolver);
  }

  /**
   * Specify a custom ConstraintValidatorFactory to use for this ValidatorFactory.
   *
   * <p>Default is a {@link SpringConstraintValidatorFactory}, delegating to the containing
   * ApplicationContext for creating autowired ConstraintValidator instances.
   */
  public void setConstraintValidatorFactory(ConstraintValidatorFactory constraintValidatorFactory) {
    this.constraintValidatorFactory = constraintValidatorFactory;
    super.setConstraintValidatorFactory(constraintValidatorFactory);
  }

  /**
   * Set the ParameterNameDiscoverer to use for resolving method and constructor parameter names if
   * needed for message interpolation.
   *
   * <p>Default is a {@link org.springframework.core.DefaultParameterNameDiscoverer}.
   */
  public void setParameterNameDiscoverer(ParameterNameDiscoverer parameterNameDiscoverer) {
    this.parameterNameDiscoverer = parameterNameDiscoverer;
    super.setParameterNameDiscoverer(parameterNameDiscoverer);
  }

  /** Specify resource locations to load XML constraint mapping files from, if any. */
  public void setMappingLocations(Resource... mappingLocations) {
    this.mappingLocations = mappingLocations;
    super.setMappingLocations(mappingLocations);
  }

  /**
   * Specify bean validation properties to be passed to the validation provider.
   *
   * <p>Can be populated with a String "value" (parsed via PropertiesEditor) or a "props" element in
   * XML bean definitions.
   *
   * @see javax.validation.Configuration#addProperty(String, String)
   */
  public void setValidationProperties(Properties jpaProperties) {
    CollectionUtils.mergePropertiesIntoMap(jpaProperties, this.validationPropertyMap);
    super.setValidationProperties(jpaProperties);
  }

  /**
   * Specify bean validation properties to be passed to the validation provider as a Map.
   *
   * <p>Can be populated with a "map" or "props" element in XML bean definitions.
   *
   * @see javax.validation.Configuration#addProperty(String, String)
   */
  public void setValidationPropertyMap(@Nullable Map<String, String> validationProperties) {
    if (validationProperties != null) {
      this.validationPropertyMap.putAll(validationProperties);
    }
    super.setValidationPropertyMap(validationProperties);
  }

  /**
   * Allow Map access to the bean validation properties to be passed to the validation provider,
   * with the option to add or override specific entries.
   *
   * <p>Useful for specifying entries directly, for example via "validationPropertyMap[myKey]".
   */
  public Map<String, String> getValidationPropertyMap() {
    return this.validationPropertyMap;
  }

  @Override
  public void setApplicationContext(ApplicationContext applicationContext) {
    this.applicationContext = applicationContext;
    super.setApplicationContext(applicationContext);
  }

  public Configuration<?> getConfiguation() {
    GenericBootstrap bootstrap = Validation.byDefaultProvider();

    Configuration<?> configuration = bootstrap.configure();

    // Try Hibernate Validator 5.2's externalClassLoader(ClassLoader) method
    if (this.applicationContext != null) {
      try {
        Method eclMethod =
            configuration.getClass().getMethod("externalClassLoader", ClassLoader.class);
        ReflectionUtils.invokeMethod(
            eclMethod, configuration, this.applicationContext.getClassLoader());
      } catch (NoSuchMethodException ex) {
        // Ignore - no Hibernate Validator 5.2+ or similar provider
      }
    }

    MessageInterpolator targetInterpolator = this.messageInterpolator;
    if (targetInterpolator == null) {
      targetInterpolator = configuration.getDefaultMessageInterpolator();
    }
    targetInterpolator = new CustomMessageInterpolator(targetInterpolator);
    configuration.messageInterpolator(new LocaleContextMessageInterpolator(targetInterpolator));

    if (this.traversableResolver != null) {
      configuration.traversableResolver(this.traversableResolver);
    }

    ConstraintValidatorFactory targetConstraintValidatorFactory = this.constraintValidatorFactory;
    if (targetConstraintValidatorFactory == null && this.applicationContext != null) {
      targetConstraintValidatorFactory =
          new SpringConstraintValidatorFactory(
              this.applicationContext.getAutowireCapableBeanFactory());
    }
    if (targetConstraintValidatorFactory != null) {
      configuration.constraintValidatorFactory(targetConstraintValidatorFactory);
    }

    if (this.parameterNameDiscoverer != null) {
      configParameterNameProvider(this.parameterNameDiscoverer, configuration);
    }

    if (this.mappingLocations != null) {
      for (Resource location : this.mappingLocations) {
        try {
          configuration.addMapping(location.getInputStream());
        } catch (IOException ex) {
          throw new IllegalStateException("Cannot read mapping resource: " + location);
        }
      }
    }

    this.validationPropertyMap.forEach(configuration::addProperty);

    return configuration;
  }

  private void configParameterNameProvider(
      ParameterNameDiscoverer discoverer, Configuration<?> configuration) {
    final ParameterNameProvider defaultProvider = configuration.getDefaultParameterNameProvider();
    configuration.parameterNameProvider(
        new ParameterNameProvider() {
          @Override
          public List<String> getParameterNames(Constructor<?> constructor) {
            String[] paramNames = discoverer.getParameterNames(constructor);
            return (paramNames != null
                ? Arrays.asList(paramNames)
                : defaultProvider.getParameterNames(constructor));
          }

          @Override
          public List<String> getParameterNames(Method method) {
            String[] paramNames = discoverer.getParameterNames(method);
            return (paramNames != null
                ? Arrays.asList(paramNames)
                : defaultProvider.getParameterNames(method));
          }
        });
  }
}
