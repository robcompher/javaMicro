/*
 * FILE : CustomMethodValidationInterceptor.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.config;

import java.lang.reflect.Method;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import javax.validation.executable.ExecutableValidator;
import org.aopalliance.intercept.MethodInvocation;
import org.springframework.aop.framework.ReflectiveMethodInvocation;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.SmartFactoryBean;
import org.springframework.core.BridgeMethodResolver;
import org.springframework.core.MethodParameter;
import org.springframework.lang.Nullable;
import org.springframework.util.Assert;
import org.springframework.util.ClassUtils;
import org.springframework.validation.beanvalidation.MethodValidationInterceptor;

/**
 * Customized Spring framework MethodValidationInterceptor to have a logic to pass errors to method
 * to continue method execution instead of throwing exception
 *
 * @author DT214743
 */
public class CustomMethodValidationInterceptor extends MethodValidationInterceptor {
  private Validator validator;

  /** Create a new MethodValidationInterceptor using a default JSR-303 validator underneath. */
  public CustomMethodValidationInterceptor() {
    super();
  }

  /**
   * Create a new MethodValidationInterceptor using the given JSR-303 ValidatorFactory.
   *
   * @param validatorFactory the JSR-303 ValidatorFactory to use
   */
  public CustomMethodValidationInterceptor(ValidatorFactory validatorFactory) {
    super(validatorFactory);
  }
  /**
   * Create a new MethodValidationInterceptor using the given JSR-303 Validator.
   *
   * @param validator the JSR-303 Validator to use
   */
  public CustomMethodValidationInterceptor(Validator validator) {
    super(validator);
    this.validator = validator;
  }

  @Override
  @Nullable
  public Object invoke(MethodInvocation invocation) throws Throwable {
    // Avoid Validator invocation on FactoryBean.getObjectType/isSingleton
    if (isBeanFactoryMetadataMethod(invocation.getMethod())) {
      return invocation.proceed();
    }

    Class<?>[] groups = determineValidationGroups(invocation);

    // Standard Bean Validation 1.1 API
    ExecutableValidator execVal = this.validator.forExecutables();
    Method methodToValidate = invocation.getMethod();
    Set<ConstraintViolation<Object>> result;

    Object target = invocation.getThis();
    Assert.state(target != null, "Target must not be null");

    try {
      result =
          execVal.validateParameters(target, methodToValidate, invocation.getArguments(), groups);
    } catch (IllegalArgumentException ex) {
      // Probably a generic type mismatch between interface and impl as reported in SPR-12237 /
      // HV-1011
      // Let's try to find the bridged method on the implementation class...
      methodToValidate =
          BridgeMethodResolver.findBridgedMethod(
              ClassUtils.getMostSpecificMethod(invocation.getMethod(), target.getClass()));
      result =
          execVal.validateParameters(target, methodToValidate, invocation.getArguments(), groups);
    }

    CustomConstraintViolationException exception = null;
    if (!result.isEmpty()) {
      exception = new CustomConstraintViolationException(result);

      // check if ConstraintViolationException param exists
      Optional<MethodParameter> errorsOptional =
          getMethodParameters(invocation.getMethod())
              .stream()
              .filter(
                  param ->
                      ConstraintViolationException.class.isAssignableFrom(param.getParameterType()))
              .findFirst();

      // if ConstraintViolationException param exists pass the value
      if (errorsOptional.isPresent()) {
        Object[] arguments = invocation.getArguments();

        ConstraintViolationException methodException =
            ConstraintViolationException.class.cast(
                arguments[errorsOptional.get().getParameterIndex()]);
        if (methodException != null) {
          exception.getConstraintViolations().addAll(methodException.getConstraintViolations());
        }
        
        arguments[errorsOptional.get().getParameterIndex()] = exception;
        if (invocation instanceof ReflectiveMethodInvocation) {
          ReflectiveMethodInvocation methodInvocation = (ReflectiveMethodInvocation) invocation;
          methodInvocation.setArguments(arguments);
        }
      } else {
        // throw exception, default spring framework logic
        throw exception;
      }
    }

    
    Object returnValue = invocation.proceed();

    // if previous error exists
    if (exception != null) {
      exception.setResponse(returnValue);
      throw exception;
    }

    result = execVal.validateReturnValue(target, methodToValidate, returnValue, groups);
    if (!result.isEmpty()) {
      throw new ConstraintViolationException(result);
    }

    return returnValue;
  }

  private List<MethodParameter> getMethodParameters(Method method) {
    return IntStream.range(0, method.getParameters().length)
        .mapToObj(i -> new MethodParameter(method, i))
        .collect(Collectors.toList());
  }

  private boolean isBeanFactoryMetadataMethod(Method method) {
    Class<?> clazz = method.getDeclaringClass();

    // Call from interface-based proxy handle, allowing for an efficient check?
    if (clazz.isInterface()) {
      return ((clazz == FactoryBean.class || clazz == SmartFactoryBean.class)
          && !method.getName().equals("getObject"));
    }

    // Call from CGLIB proxy handle, potentially implementing a FactoryBean method?
    Class<?> factoryBeanType = null;
    if (SmartFactoryBean.class.isAssignableFrom(clazz)) {
      factoryBeanType = SmartFactoryBean.class;
    } else if (FactoryBean.class.isAssignableFrom(clazz)) {
      factoryBeanType = FactoryBean.class;
    }
    return (factoryBeanType != null
        && !method.getName().equals("getObject")
        && ClassUtils.hasMethod(factoryBeanType, method));
  }
}
