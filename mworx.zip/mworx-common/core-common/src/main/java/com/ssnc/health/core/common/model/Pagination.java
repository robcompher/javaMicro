/**
 * FILE : Pagination.java
 *
 * <p>COPYRIGHT:
 *
 * <p>The computer systems, procedures, data bases and programs created and maintained by SS&C
 * Health, are proprietary in nature and as such are confidential. Any unauthorized use or
 * disclosure of such information may result in civil liabilities.
 *
 * <p>Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 */
package com.ssnc.health.core.common.model;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class Pagination {
  private Integer page;
  private Integer pageSize;
  private String sortBy;
  private String sortOrder;
}
