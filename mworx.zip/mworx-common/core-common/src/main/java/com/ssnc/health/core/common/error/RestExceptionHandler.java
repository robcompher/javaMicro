/*
 * FILE : RestExceptionHandler.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2019- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.error;

import static org.springframework.http.HttpStatus.BAD_REQUEST;
import static org.springframework.http.HttpStatus.INTERNAL_SERVER_ERROR;
import static org.springframework.http.HttpStatus.NOT_FOUND;
import static org.springframework.http.HttpStatus.UNAUTHORIZED;
import static org.springframework.http.HttpStatus.UNPROCESSABLE_ENTITY;
import org.hibernate.exception.ConstraintViolationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.Ordered;
import org.springframework.core.annotation.Order;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.http.converter.HttpMessageNotWritableException;
import org.springframework.lang.Nullable;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import org.springframework.web.servlet.NoHandlerFoundException;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;

/** Created by dt216896. */
@Order(Ordered.HIGHEST_PRECEDENCE)
@ControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

  private static final Logger LOG = LoggerFactory.getLogger(RestExceptionHandler.class);
  private static final String VALIDATION_ERROR = "Validation error";

  /**
   * Handle MissingServletRequestParameterException. Triggered when a 'required' request parameter
   * is missing.
   *
   * @param ex MissingServletRequestParameterException
   * @param headers HttpHeaders
   * @param status HttpStatus
   * @param request WebRequest
   * @return the ApiError object
   */
  @Override
  protected ResponseEntity<Object> handleHttpRequestMethodNotSupported(
      HttpRequestMethodNotSupportedException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    LOG.error(ex.getMessage(), ex);
    return buildResponseEntity(new ApiError(BAD_REQUEST, ex.getMessage(), ex));
  }

  /**
   * Handle MissingServletRequestParameterException. Triggered when a 'required' request parameter
   * is missing.
   *
   * @param ex MissingServletRequestParameterException
   * @param headers HttpHeaders
   * @param status HttpStatus
   * @param request WebRequest
   * @return the ApiError object
   */
  @Override
  protected ResponseEntity<Object> handleMissingServletRequestParameter(
      MissingServletRequestParameterException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    String error = ex.getParameterName() + " parameter is missing";
    LOG.error(error, ex);
    return buildResponseEntity(new ApiError(BAD_REQUEST, error, ex));
  }

  /**
   * Handle HttpMediaTypeNotSupportedException. This one triggers when JSON is invalid as well.
   *
   * @param ex HttpMediaTypeNotSupportedException
   * @param headers HttpHeaders
   * @param status HttpStatus
   * @param request WebRequest
   * @return the ApiError object
   */
  @Override
  protected ResponseEntity<Object> handleHttpMediaTypeNotSupported(
      HttpMediaTypeNotSupportedException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    StringBuilder builder = new StringBuilder();
    builder.append(ex.getContentType());
    builder.append(" media type is not supported. Supported media types are ");
    ex.getSupportedMediaTypes().forEach(t -> builder.append(t).append(", "));
    LOG.error(ex.getMessage(), ex);
    return buildResponseEntity(
        new ApiError(
            HttpStatus.UNSUPPORTED_MEDIA_TYPE, builder.substring(0, builder.length() - 2), ex));
  }

  /**
   * Handle MethodArgumentNotValidException. Triggered when an object fails @Valid validation.
   *
   * @param ex the MethodArgumentNotValidException that is thrown when @Valid validation fails
   * @param headers HttpHeaders
   * @param status HttpStatus
   * @param request WebRequest
   * @return the ApiError object
   */
  @Override
  protected ResponseEntity<Object> handleMethodArgumentNotValid(
      MethodArgumentNotValidException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ApiError apiError = new ApiError(UNPROCESSABLE_ENTITY);
    apiError.setMessage(VALIDATION_ERROR);
    apiError.addValidationErrors(ex.getBindingResult().getFieldErrors());
    apiError.addValidationError(ex.getBindingResult().getGlobalErrors());
    LOG.error(VALIDATION_ERROR, ex);
    return buildResponseEntity(apiError);
  }

  /**
   * Handle HttpMessageNotReadableException. Happens when request JSON is malformed.
   *
   * @param ex HttpMessageNotReadableException
   * @param headers HttpHeaders
   * @param status HttpStatus
   * @param request WebRequest
   * @return the ApiError object
   */
  @Override
  protected ResponseEntity<Object> handleHttpMessageNotReadable(
      HttpMessageNotReadableException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    String error = "Malformed JSON request";
    LOG.error(error, ex);
    return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, error, ex));
  }

  /**
   * Handle HttpMessageNotWritableException.
   *
   * @param ex HttpMessageNotWritableException
   * @param headers HttpHeaders
   * @param status HttpStatus
   * @param request WebRequest
   * @return the ApiError object
   */
  @Override
  protected ResponseEntity<Object> handleHttpMessageNotWritable(
      HttpMessageNotWritableException ex,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    String error = "Error writing JSON output";
    LOG.error(error, ex);
    return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, error, ex));
  }

  @Override
  protected ResponseEntity<Object> handleNoHandlerFoundException(
      NoHandlerFoundException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {
    ApiError apiError = new ApiError(BAD_REQUEST);
    apiError.setMessage(
        String.format(
            "Could not find the %s method for URL %s", ex.getHttpMethod(), ex.getRequestURL()));
    apiError.setDebugMessage(ex.getMessage());
    LOG.error("Handler Not found", ex);
    return buildResponseEntity(apiError);
  }

  /**
   * Handles javax.validation.ConstraintViolationException. Thrown when @Validated fails.
   *
   * @param ex the ConstraintViolationException
   * @return the ApiError object
   */
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "422",
            description = "The request was invalid or cannot be otherwise served.",
            content =
                @Content(
                    schema = @Schema(implementation = ApiError.class),
                    mediaType = "application/json"))
      })
  @ExceptionHandler(javax.validation.ConstraintViolationException.class)
  @ResponseStatus(UNPROCESSABLE_ENTITY)
  protected ResponseEntity<Object> handleConstraintViolation(
      javax.validation.ConstraintViolationException ex) {
    ApiError apiError = new ApiError(UNPROCESSABLE_ENTITY);
    apiError.setMessage(VALIDATION_ERROR);
    apiError.addValidationErrors(ex.getConstraintViolations());
    LOG.error(VALIDATION_ERROR, ex);
    return buildResponseEntity(apiError);
  }

  /**
   * Handles EntityNotFoundException. Created to encapsulate errors with more detail than
   * javax.persistence.EntityNotFoundException.
   *
   * @param ex the EntityNotFoundException
   * @return the ApiError object
   */
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "404",
            description = "The URI requested is invalid or the resource requested does not exists.",
            content =
                @Content(
                    schema = @Schema(implementation = ApiError.class),
                    mediaType = "application/json"))
      })
  @ExceptionHandler(EntityNotFoundException.class)
  @ResponseStatus(NOT_FOUND)
  protected ResponseEntity<Object> handleEntityNotFound(EntityNotFoundException ex) {
    ApiError apiError = new ApiError(NOT_FOUND);
    apiError.setMessage(ex.getMessage());
    LOG.error("Not Found", ex);
    return buildResponseEntity(apiError);
  }

  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "404",
            description = "The URI requested is invalid or the resource requested does not exists.",
            content =
                @Content(
                    schema = @Schema(implementation = ApiError.class),
                    mediaType = "application/json"))
      })
  /** Handle javax.persistence.EntityNotFoundException */
  @ExceptionHandler(javax.persistence.EntityNotFoundException.class)
  @ResponseStatus(NOT_FOUND)
  protected ResponseEntity<Object> handleEntityNotFound(
      javax.persistence.EntityNotFoundException ex) {
    LOG.error("Not Found", ex);
    return buildResponseEntity(new ApiError(NOT_FOUND, ex));
  }

  /**
   * Handle DataIntegrityViolationException, inspects the cause for different DB causes.
   *
   * @param ex the DataIntegrityViolationException
   * @return the ApiError object
   */
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "409",
            description = "Conflict. The request was invalid or cannot be otherwise served.",
            content =
                @Content(
                    schema = @Schema(implementation = ApiError.class),
                    mediaType = "application/json"))
      })
  @ExceptionHandler(DataIntegrityViolationException.class)
  @ResponseStatus(BAD_REQUEST)
  protected ResponseEntity<Object> handleDataIntegrityViolation(
      DataIntegrityViolationException ex, WebRequest request) {
    if (ex.getCause() instanceof ConstraintViolationException) {
      return buildResponseEntity(
          new ApiError(HttpStatus.BAD_REQUEST, "Database error", ex.getCause()));
    }
    LOG.error("Database Error", ex);
    return buildResponseEntity(new ApiError(HttpStatus.BAD_REQUEST, ex));
  }

  /**
   * Handle Exception, handle generic Exception.class
   *
   * @param ex the Exception
   * @return the ApiError object
   */
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "400",
            description = "The request was invalid or cannot be otherwise served.",
            content =
                @Content(
                    schema = @Schema(implementation = ApiError.class),
                    mediaType = "application/json"))
      })
  @ExceptionHandler(MethodArgumentTypeMismatchException.class)
  @ResponseStatus(BAD_REQUEST)
  protected ResponseEntity<Object> handleMethodArgumentTypeMismatch(
      MethodArgumentTypeMismatchException ex, WebRequest request) {
    ApiError apiError = new ApiError(BAD_REQUEST);
    apiError.setMessage(
        String.format(
            "The parameter '%s' of value '%s' could not be converted to type '%s'",
            ex.getName(), ex.getValue(), ex.getRequiredType().getSimpleName()));
    apiError.setDebugMessage(ex.getMessage());
    LOG.error("Bad Request", ex);
    return buildResponseEntity(apiError);
  }

  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "401",
            description = "Unauthorized to access the resource",
            content =
                @Content(
                    schema = @Schema(implementation = ApiError.class),
                    mediaType = "application/json"))
      })
  @ExceptionHandler(AccessDeniedException.class)
  @ResponseStatus(UNAUTHORIZED)
  protected ResponseEntity<Object> handleAccessDeniedException(
      AccessDeniedException ex, WebRequest request) {
    ApiError apiError = new ApiError(UNAUTHORIZED);
    apiError.setMessage(ex.getMessage());
    apiError.setDebugMessage(ex.getMessage());
    LOG.error("UNAUTHORIZED", ex);
    return buildResponseEntity(apiError);
  }

  /**
   * Handle Exception. Triggered when a Exception is thrown.
   *
   * @param ex Exception
   * @return the ApiError object
   */
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "500",
            description = "Returns when unknown error occured while processing the request",
            content =
                @Content(
                    schema = @Schema(implementation = ApiError.class),
                    mediaType = "application/json"))
      })
  @ExceptionHandler(value = {Exception.class})
  @ResponseStatus(INTERNAL_SERVER_ERROR)
  protected ResponseEntity<Object> handleExceptionInternal(Exception ex) {
    LOG.error(ex.getMessage(), ex);
    return buildResponseEntity(new ApiError(HttpStatus.INTERNAL_SERVER_ERROR, ex.getMessage(), ex));
  }

  @ExceptionHandler(ApiErrorException.class)
  @ResponseStatus(UNPROCESSABLE_ENTITY)
  public ResponseEntity<Object> handleApiErrorException(ApiErrorException ex) {
    LOG.error("Error from WebClient", ex);
    ApiError apiError = new ApiError(UNPROCESSABLE_ENTITY, ex);
    
    ex.getApiError().ifPresent(optApiError -> {
      apiError.setMessage(optApiError.getMessage());
      apiError.setDebugMessage(optApiError.getDebugMessage());
      apiError.setSubErrors(optApiError.getSubErrors());
    });

    return buildResponseEntity(apiError);
  }

  @ExceptionHandler(WebClientResponseException.class)
  public ResponseEntity<String> handleWebClientResponseException(WebClientResponseException ex) {
    LOG.error(
        "Error from WebClient - Status {}, Body {}",
        ex.getRawStatusCode(),
        ex.getResponseBodyAsString(),
        ex);
    return ResponseEntity.status(ex.getRawStatusCode()).body(ex.getResponseBodyAsString());
  }

  @Override
  protected ResponseEntity<Object> handleExceptionInternal(
      Exception ex,
      @Nullable Object body,
      HttpHeaders headers,
      HttpStatus status,
      WebRequest request) {
    ApiError apiError = new ApiError(status);
    apiError.setMessage(ex.getMessage());
    apiError.setDebugMessage(ex.getMessage());
    LOG.error(ex.getMessage(), ex);
    return buildResponseEntity(apiError);
  }

  private ResponseEntity<Object> buildResponseEntity(ApiError apiError) {
    return new ResponseEntity<>(apiError, apiError.getStatus());
  }
}
