/*
 * FILE : RulesService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */

package com.ssnc.health.core.common.validation.service;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.ssnc.health.core.common.validation.model.ValidationRule;

public interface RulesService {
  List<ValidationRule> findRulesByRuleset(String ruleset);

  List<ValidationRule> findRulesByRuleset(String ruleset, Pageable pageable);
}
