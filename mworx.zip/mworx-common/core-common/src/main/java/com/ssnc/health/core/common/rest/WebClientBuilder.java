/*
 * FILE : WebClientBuilder.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.rest;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.web.reactive.function.client.WebClient;
import io.netty.channel.ChannelOption;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import reactor.netty.http.client.HttpClient;
import reactor.netty.tcp.TcpClient;
import reactor.netty.transport.logging.AdvancedByteBufFormat;

/**
 * 
 * @deprecated Use directly spring provider WebClient.Builder and add additional properties needed.
 * 
 *             <pre>
 *             public WebClient webClient(WebClient.Builder webClientBuilder) {
 *               return webClientBuilder.baseUrl(gatewayUrl).build();
 *             }
 *             </pre>
 */
@Deprecated(forRemoval = true)
public class WebClientBuilder {

  private static final int TIME_OUT_SECONDS = 4;

  private WebClientBuilder() {}

  public static WebClient.Builder getDefaultWebClientBuilder(String baseUrl, String clientId) {
    TcpClient tcpClient = TcpClient.create()
        .wiretap("reactor.netty.http.client.HttpClient", LogLevel.DEBUG,
            AdvancedByteBufFormat.TEXTUAL)
        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, 2_000).doOnConnected(
            connection -> connection.addHandlerLast(new ReadTimeoutHandler(TIME_OUT_SECONDS))
                .addHandlerLast(new WriteTimeoutHandler(TIME_OUT_SECONDS)));

    return WebClient.builder().baseUrl(baseUrl)
        .clientConnector(new ReactorClientHttpConnector(HttpClient.from(tcpClient).compress(true)))
        .defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
        .defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE)
        .defaultHeader("clientId", clientId).filter(WebClientFilters.logRequest())
        .filter(WebClientFilters.logResponse());
  }
}
