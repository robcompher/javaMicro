/*
 * FILE : RulesRepository.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.repository;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;

import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.model.ValidationRuleId;

/** Created by dt214746 on 1/28/2020. */
@Repository
public interface RulesRepository
    extends JpaRepository<ValidationRule, ValidationRuleId>,
        JpaSpecificationExecutor<ValidationRule> {
  List<ValidationRule> findByRuleset(String ruleset);
  List<ValidationRule> findByRuleset(String ruleset, Pageable pageable);
}
