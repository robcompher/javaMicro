/*
 * FILE : RuleValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.validator;

import static com.ssnc.health.core.common.validation.internal.RuleWrapper.COMMA;
import static com.ssnc.health.core.common.validation.internal.RuleWrapper.DOT;
import java.io.IOException;
import java.lang.reflect.Field;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import javax.validation.Validator;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.reflect.FieldUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.validator.cfg.ConstraintMapping;
import org.hibernate.validator.cfg.context.PropertyConstraintMappingContext;
import org.hibernate.validator.cfg.context.TypeConstraintMappingContext;
import org.hibernate.validator.engine.HibernateConstraintViolation;
import org.hibernate.validator.internal.engine.ConfigurationImpl;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.PropertyAccessor;
import org.springframework.beans.PropertyAccessorFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.util.CollectionUtils;
import com.ssnc.health.core.common.validation.config.CustomLocalValidatorFactoryBean;
import com.ssnc.health.core.common.validation.internal.DynamicBeanBuilder;
import com.ssnc.health.core.common.validation.internal.FieldInfo;
import com.ssnc.health.core.common.validation.internal.JsonHelper;
import com.ssnc.health.core.common.validation.internal.MultiGroup;
import com.ssnc.health.core.common.validation.internal.RuleWrapper;
import com.ssnc.health.core.common.validation.internal.SingleGroup;
import com.ssnc.health.core.common.validation.model.ObjectType;
import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.service.RulesService;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;

/**
 * Created by dt214746 on 1/28/2020. The steps done in this validator are 1. Get all the rules from
 * the validation_rule table based on given rule set name. 2. Group the rules based on field name.
 * 3. Execute the rule. Based on rule type, appropriate action is done. 4. If validation failed, add
 * the error message from DB to Constraint violation. 5. If type is CUSTOM_VALIDATOR, custom
 * validators are expected to be written as another validator with business logic.
 */
public class RuleValidator implements ConstraintValidator<ValidRuleset, Object> {
  private static final Logger LOG = LogManager.getLogger(RuleValidator.class);

  @Autowired private RulesService rulesService;

  @Autowired private CustomLocalValidatorFactoryBean validatorFactory;

  @Autowired private JsonHelper jsonHelper;

  private String ruleset;
  private Set<ObjectType> objectTypes;
  private Class<?> objectClass;

  private List<RuleWrapper> validationRules;

  private List<RuleWrapper> invalidValidationRules;

  private Validator validator;

  @Override
  public void initialize(ValidRuleset validRuleset) {
    this.ruleset = validRuleset.name();
    this.validationRules = new ArrayList<>();

    LOG.info("Ruleset: {}", ruleset);

    List<ValidationRule> validationRuleList = rulesService.findRulesByRuleset(ruleset);

    if (!CollectionUtils.isEmpty(validationRuleList)) {
      this.objectTypes =
          validationRuleList.stream().map(ValidationRule::getObjectType).collect(Collectors.toSet());

      validationRuleList
          .stream()
          .sorted(
              Comparator.comparing(ValidationRule::getPropertyName)
                  .thenComparing(ValidationRule::getRuleOrder))
          .forEach(rule -> this.validationRules.add(new RuleWrapper(rule)));

      // generally should empty caused by config issue
      this.invalidValidationRules =
          this.validationRules
              .stream()
              .filter(rule -> !rule.isValidRule())
              .collect(Collectors.toList());
    }
  }

  @SuppressWarnings("unchecked")
  @Override
  public boolean isValid(Object entityObj, ConstraintValidatorContext context) {
    if (CollectionUtils.isEmpty(this.validationRules)) {
      context.disableDefaultConstraintViolation();
      context
          .buildConstraintViolationWithTemplate(
              String.format("No validation rules found for ruleset [%s]", this.ruleset))
          .addConstraintViolation();
      return false;
    }

    Object objectToValidate = transform(entityObj);

    if (this.validator == null) {
      initializeValidator(objectToValidate.getClass());
    }

    Set<ConstraintViolation<Object>> constraintViolations =
        this.validator.validate(objectToValidate, SingleGroup.class, MultiGroup.class);

    Iterator<ConstraintViolation<Object>> iterator = constraintViolations.iterator();
    while (iterator.hasNext()) {
      HibernateConstraintViolation<?> hibernateConstraintViolation =
          iterator.next().unwrap(HibernateConstraintViolation.class);
      final String property =
          StringUtils.substringBefore(
              hibernateConstraintViolation.getPropertyPath().toString(), ".<list element>");

      String message = hibernateConstraintViolation.getMessage();

      ValidationRule rule = ValidationUtil.stringToValidationRule(message);

      List<Integer[]> invalidIndexes = new ArrayList<>();
      invalidIndexes = hibernateConstraintViolation.getDynamicPayload(invalidIndexes.getClass());
      // There is no way to pass multiple property names to context, appending to messages and
      if (invalidIndexes != null && !invalidIndexes.isEmpty()) {
        invalidIndexes.forEach(
            invalidIndex -> {
              String resolvedProperty =
                  resolveErrorFieldNames(property, rule.getPropertyName(), invalidIndex);
              context.disableDefaultConstraintViolation();
              context
                  .buildConstraintViolationWithTemplate(message)
                  .addPropertyNode(resolvedProperty)
                  .addConstraintViolation();
            });
      } else {
        String resolvedProperty = resolveErrorFieldNames(property, rule.getPropertyName(), null);
        context.disableDefaultConstraintViolation();
        context
            .buildConstraintViolationWithTemplate(message)
            .addPropertyNode(resolvedProperty)
            .addConstraintViolation();
      }
    }

    // generally should empty caused by config issue
    this.invalidValidationRules
        .stream()
        .forEach(
            rule -> {
              context.disableDefaultConstraintViolation();
              context
                  .buildConstraintViolationWithTemplate(rule.getRule().getMessage())
                  .addConstraintViolation();
            });
    
    return constraintViolations.isEmpty() && invalidValidationRules.isEmpty();
  }

  private String fixPropertyForIndex(String property, Integer[] invalidIndexes) {
    if (invalidIndexes != null && invalidIndexes.length > 0) {
      for (int i = 0; i < invalidIndexes.length; i++) {
        property = property.replaceFirst("\\[\\]", "[" + invalidIndexes[i] + "]");
      }
    }
    return property;
  }

  private String resolveErrorFieldNames(
      String prefix, String fieldNames, Integer[] invalidIndexes) {
    StringBuilder builder = new StringBuilder();
    String prefixNoIndexes = prefix.replaceAll("\\d", "");
    String prefixNoIndexesNoArray = prefixNoIndexes.replaceAll("[\\[\\]]", "");
    Arrays.stream(fieldNames.split(COMMA))
        .forEach(
            fieldName -> {
              fieldName = fixPropertyForIndex(fieldName, invalidIndexes);

              if (builder.length() > 0) builder.append(COMMA);

              if (fieldName.contains(DOT)
                  && StringUtils.isNotBlank(prefix)
                  && (fieldName.startsWith(prefixNoIndexes)
                      || fieldName.startsWith(prefixNoIndexesNoArray))) {
                if (fieldName.equals(prefixNoIndexes) || fieldName.equals(prefixNoIndexesNoArray)) {
                  builder.append(prefix);
                } else {
                  builder
                      .append(prefix)
                      .append(DOT)
                      .append(StringUtils.substringAfterLast(fieldName, DOT));
                }
              } else {
                builder.append(fieldName);
              }
            });

    return builder.toString();
  }

  private ObjectType getObjectType() {
    if (this.objectTypes.isEmpty() || this.objectTypes.size() > 1)
      throw new IllegalStateException(
          String.format(
              "Unable to derive object type based on defined ruleset [%s]", this.ruleset));

    return this.objectTypes.iterator().next();
  }

  private synchronized Class<?> getObjectClass(Object value) throws IOException {
    if (this.objectClass == null) {
      ObjectType objectType = this.getObjectType();

      if (objectType.equals(ObjectType.JSON)) {
        List<FieldInfo> fields = jsonHelper.extractFieldInfos(this.validationRules);
        if (this.objectClass == null) {
          this.objectClass = DynamicBeanBuilder.generateClass(this.ruleset, fields);
        }
      } else if (objectType.equals(ObjectType.PARAM)) {
        getParamClass(value);
      } else {
        this.objectClass = value.getClass();
      }
    }
    
    return this.objectClass;
  }

  private void getParamClass(Object value) {
    RuleWrapper ruleWrapper = validationRules.get(0);

    if (this.objectClass == null) {
      FieldInfo fieldInfo = new FieldInfo().name(ruleWrapper.getRule().getPropertyName());
      if (value != null) {
        fieldInfo = fieldInfo.type(value.getClass());
      } else {
        fieldInfo = fieldInfo.type(String.class);
      }

      this.objectClass =
          DynamicBeanBuilder.generateClass(this.ruleset, Arrays.asList(fieldInfo));
    }
  }

  private Object transform(Object value) {
    try {
      ObjectType objectType = this.getObjectType();

      if (objectType.equals(ObjectType.JSON)) {
        return jsonHelper.getAsObject((String) value, getObjectClass(value));
      } else if (objectType.equals(ObjectType.PARAM)) {
        RuleWrapper ruleWrapper = validationRules.get(0);

        Object object = BeanUtils.instantiateClass(getObjectClass(value));
        PropertyAccessor myAccessor = PropertyAccessorFactory.forBeanPropertyAccess(object);
        myAccessor.setPropertyValue(ruleWrapper.getRule().getPropertyName(), value);

        return object;
      }

      return value;
    } catch (IOException e) {
      throw new IllegalStateException("Validation failed with error", e);
    }
  }

  private void initializeValidator(Class<?> clazz) {
    ConfigurationImpl configuration = ((ConfigurationImpl) validatorFactory.getConfiguation());
    ConstraintMapping constraintMapping = configuration.createConstraintMapping();
    Map<String, TypeConstraintMappingContext<? extends Object>> typeContextsMap = new HashMap<>();
    Map<String, PropertyConstraintMappingContext> propertyContextsMap = new HashMap<>();

    TypeConstraintMappingContext<? extends Object> typeConstraintMappingContext =
        constraintMapping
            .type(clazz)
            .ignoreAllAnnotations()
            .defaultGroupSequence(clazz, SingleGroup.class, MultiGroup.class);

    typeContextsMap.put(clazz.getName(), typeConstraintMappingContext);

    this.validationRules
        .stream()
        .filter(RuleWrapper::isValidRule)
        .forEach(
            ruleWrapper -> {
              LOG.debug("setting up rule {}", ruleWrapper);

              addConstraint(
                  clazz,
                  StringUtils.substringBefore(ruleWrapper.getRule().getPropertyName(), COMMA),
                  ruleWrapper,
                  constraintMapping,
                  typeContextsMap,
                  propertyContextsMap);
            });

    configuration.addMapping(constraintMapping);
    this.validator = configuration.buildValidatorFactory().getValidator();
  }

  private void addConstraint(
      Class<?> rootBeanClass,
      String propertyName,
      RuleWrapper ruleWrapper,
      ConstraintMapping constraintMapping,
      Map<String, TypeConstraintMappingContext<? extends Object>> typeContextsMap,
      Map<String, PropertyConstraintMappingContext> propertyContextsMap) {

    if (propertyName.indexOf(DOT) != -1 && !ruleWrapper.isRootBean()) {
      String fieldName = StringUtils.substringBefore(propertyName, DOT);
      if (fieldName.contains("[")) {
        fieldName = StringUtils.substringBefore(fieldName, "[");
      }

      Class<?> fieldType = populateField(rootBeanClass, constraintMapping, typeContextsMap,
          propertyContextsMap, fieldName);

      addConstraint(
          fieldType,
          StringUtils.substringAfter(propertyName, DOT),
          ruleWrapper,
          constraintMapping,
          typeContextsMap,
          propertyContextsMap);
    } else {
      addSingleConstraint(
          rootBeanClass,
          propertyName,
          ruleWrapper,
          constraintMapping,
          typeContextsMap,
          propertyContextsMap);
    }
  }

  private Class<?> populateField(Class<?> rootBeanClass, ConstraintMapping constraintMapping,
      Map<String, TypeConstraintMappingContext<? extends Object>> typeContextsMap,
      Map<String, PropertyConstraintMappingContext> propertyContextsMap, String fieldName) {
    FieldDef fieldDef = getFieldDef(rootBeanClass, fieldName);

    Class<?> currentClass = fieldDef.getBeanClass();
    Field field = fieldDef.getField();
    Class<?> fieldType = getFieldGenricType(field);

    if (typeContextsMap.get(currentClass.getName()) == null) {
      typeContextsMap.put(
          currentClass.getName(), constraintMapping.type(currentClass).ignoreAllAnnotations());
    }

    if (!typeContextsMap.containsKey(fieldType.getName())) {
      typeContextsMap.put(
          fieldType.getName(), constraintMapping.type(fieldType).ignoreAllAnnotations());

      String rootBeanClassName = currentClass.getName();
      String propertyContextMapKey = rootBeanClassName + '#' + fieldName;

      if (!propertyContextsMap.containsKey(propertyContextMapKey)) {
        propertyContextsMap.put(
            propertyContextMapKey, typeContextsMap.get(rootBeanClassName).field(fieldName));
      }
      if (field.getGenericType().getTypeName().equals(fieldType.getTypeName())) {
        propertyContextsMap.get(propertyContextMapKey).valid();
      } else {
        propertyContextsMap.get(propertyContextMapKey).containerElementType(0).valid();
      }
    }
    return fieldType;
  }

  private void addSingleConstraint(
      Class<?> rootBeanClass,
      String propertyName,
      RuleWrapper ruleWrapper,
      ConstraintMapping constraintMapping,
      Map<String, TypeConstraintMappingContext<? extends Object>> typeContextsMap,
      Map<String, PropertyConstraintMappingContext> propertyContextsMap) {

    if (ruleWrapper.isMultiRule()) {
      TypeConstraintMappingContext<? extends Object> typeConstraintMappingContext =
          typeContextsMap.get(rootBeanClass.getName());

      typeConstraintMappingContext.constraint(ruleWrapper.getConstraintDef());
    } else {
      String fieldName = propertyName;
      if (fieldName.contains("[")) {
        fieldName = StringUtils.substringBefore(fieldName, "[");
      }

      FieldDef fieldDef = getFieldDef(rootBeanClass, fieldName);
      Field field = fieldDef.getField();
      Class<?> currentClass = fieldDef.getBeanClass();

      TypeConstraintMappingContext<? extends Object> typeConstraintMappingContext =
          typeContextsMap.get(currentClass.getName());
      if (typeConstraintMappingContext == null) {
        typeConstraintMappingContext = constraintMapping.type(currentClass).ignoreAllAnnotations();
        typeContextsMap.put(currentClass.getName(), typeConstraintMappingContext);
      }

      String propertyContextMapKey = currentClass.getName() + '#' + fieldName;

      if (!propertyContextsMap.containsKey(propertyContextMapKey)) {
        propertyContextsMap.put(
            propertyContextMapKey, typeConstraintMappingContext.field(fieldName));
      }

      Class<?> fieldType = getFieldGenricType(field);

      if (!field.getGenericType().getTypeName().equals(fieldType.getTypeName())
          && propertyName.contains("[")) {
        propertyContextsMap
            .get(propertyContextMapKey)
            .ignoreAnnotations(true)
            .containerElementType()
            .constraint(ruleWrapper.getConstraintDef());
      } else {
        propertyContextsMap
            .get(propertyContextMapKey)
            .ignoreAnnotations(true)
            .constraint(ruleWrapper.getConstraintDef());
      }
    }
  }

  private Class<?> getFieldGenricType(final Field field) {
    return getFieldGenricType(field, 0);
  }

  @SuppressWarnings("rawtypes")
  private Class getFieldGenricType(final Field field, final int index) {
    Assert.notNull(field, "Parameter 'field' must be not null!");
    Assert.state(index > -1, "Parameter 'index' must be > -1!");
    Type type = field.getGenericType();
    if (type instanceof ParameterizedType) {
      ParameterizedType ptype = (ParameterizedType) type;
      type = ptype.getActualTypeArguments()[index];
      if (type instanceof ParameterizedType) {
        return (Class) ((ParameterizedType) type).getRawType();
      } else {
        return (Class) type;
      }
    } else {
      return (Class) type;
    }
  }

  private FieldDef getFieldDef(Class<?> rootBeanClass, String fieldName) {
    Field field = null;
    Class<?> currentClass = rootBeanClass;
    while (currentClass != null) {
      field = FieldUtils.getDeclaredField(currentClass, fieldName, true);
      if (field != null) break;

      currentClass = currentClass.getSuperclass();
    }

    return new FieldDef(field, currentClass);
  }
}

@Getter
@Setter
@AllArgsConstructor
class FieldDef {
  private Field field;
  private Class<?> beanClass;
}
