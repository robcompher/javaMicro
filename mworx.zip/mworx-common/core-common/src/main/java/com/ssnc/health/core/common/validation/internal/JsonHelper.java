/*
 * FILE : JsonHelper.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.internal;

import static com.ssnc.health.core.common.validation.internal.RuleWrapper.COMMA;
import static com.ssnc.health.core.common.validation.internal.RuleWrapper.DOT;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class JsonHelper {

  private static final String ARRAY_TYPE = "array";

  private static final String OBJECT_TYPE = "object";

  private static final Logger LOGGER = LogManager.getLogger(JsonHelper.class);

  @Autowired
  private ObjectMapper mapper;

  public final Object getAsObject(String jsonString, Class<?> clazz) throws IOException {
    return mapper.readValue(jsonString, clazz);
  }

  public final List<FieldInfo> extractFieldInfos(List<RuleWrapper> validationRules)
      throws IOException {
    LOGGER.debug("-> extractFieldInfos");

    List<FieldInfo> fieldInfos = extractRuleFieldInfo(validationRules);
    LOGGER.debug("<- extractFieldInfos");
    return fieldInfos;
  }

  private List<FieldInfo> extractRuleFieldInfo(List<RuleWrapper> validationRules)
      throws IOException {
    List<FieldInfo> fields = new ArrayList<>();
    Iterator<RuleWrapper> iterator = validationRules.iterator();

    while (iterator.hasNext()) {
      RuleWrapper rule = iterator.next();

      String[] propertyNames = rule.getRule().getPropertyName().split(COMMA);
      for (int i = 0; i < propertyNames.length; i++) {
        if (propertyNames[i] != null) {
          extractRuleFieldInfo(propertyNames[i].trim(), rule, fields, null);
        }
      }
    }
    return fields;
  }

  private void extractRuleFieldInfo(final String propertyName, final RuleWrapper rule,
      final List<FieldInfo> fields, String type) throws IOException {
    if (propertyName.contains(DOT)) {
      String fieldName = StringUtils.substringBefore(propertyName, DOT);
      String fieldType = OBJECT_TYPE;
      if (fieldName.contains("[")) {
        fieldType = ARRAY_TYPE;
        fieldName = StringUtils.substringBefore(fieldName, "[");
      }
      final String fieldName1 = fieldName;

      // get json type for first property from path
      extractRuleFieldInfo(fieldName1, rule, fields, fieldType);

      Optional<FieldInfo> field =
          fields.stream().filter(f -> f.getName().equalsIgnoreCase(fieldName1)).findFirst();

      // navigate other paths
      extractRuleFieldInfo(StringUtils.substringAfter(propertyName, DOT), rule,
          field.isPresent() ? field.get().getSubFields() : new ArrayList<>(), null);
    } else {
      Optional<FieldInfo> field =
          fields.stream().filter(f -> f.getName().equalsIgnoreCase(propertyName)).findFirst();

      FieldInfo fieldInfo = null;

      // get json type from rule and set type
      if (field.isPresent()) {
        fieldInfo = field.get();
      } else {
        // add missing property
        fieldInfo = new FieldInfo().name(propertyName);
        fields.add(fieldInfo);
      }
      populateFieldInfo(rule, fieldInfo, type);
    }
  }

  private void populateFieldInfo(final RuleWrapper rule, FieldInfo fieldInfo, String fieldType)
      throws JsonProcessingException {
    String jsonSchemaString = rule.getJsonSchema();
    LOGGER.debug("fieldName={}, jsonSchema={} ", fieldInfo.getName(), jsonSchemaString);
    if (StringUtils.isNotBlank(jsonSchemaString)) {
      JsonNode rootNode = mapper.readTree(jsonSchemaString);
      JsonNode fieldNode = rootNode.findValue(fieldInfo.getName());
      if (fieldNode != null && fieldNode.findValue("type") != null) {
        String type = fieldNode.findValue("type").asText();
        LOGGER.debug("fieldName={}, type={}", fieldInfo.getName(), type);
        populateType(fieldInfo, type);
      }
    } else if (fieldType != null && fieldType.equals(ARRAY_TYPE)) {
      fieldInfo.list(true);
    } else if (fieldType != null && fieldType.equals(OBJECT_TYPE)) {
      fieldInfo.object(true);
    }
  }

  private void populateType(FieldInfo fieldInfo, String type) {
    if (type.equals("date")) {
      fieldInfo.type(LocalDate.class);
      fieldInfo.object(false);
      fieldInfo.list(false);
    } else if (type.equals("integer")) {
      fieldInfo.type(Long.class);
      fieldInfo.object(false);
      fieldInfo.list(false);
    } else if (type.equals("number")) {
      fieldInfo.type(Double.class);
      fieldInfo.object(false);
      fieldInfo.list(false);
    } else if (type.equals("boolean")) {
      fieldInfo.type(Boolean.class);
      fieldInfo.object(false);
    } else if (type.equals(OBJECT_TYPE)) {
      fieldInfo.object(true);
    } else if (type.equals(ARRAY_TYPE)) {
      fieldInfo.list(true);
    }
  }
}
