/*
 * FILE : EntitlementService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.security;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.util.FieldUtils;
import org.springframework.web.reactive.function.client.WebClient;
import com.ssnc.health.core.common.model.LobInfo;

/**
 * Validate lob information in given object. Assuming lob information will be in following names in
 * the object. Lob Id - lobId Organization Id - organizationId Organization Name - organizationName
 * Lob Name - lobName
 *
 * @author dt216896
 */
public class EntitlementService {
  @Autowired WebClient webClient;

  private static final Logger LOG = LoggerFactory.getLogger(EntitlementService.class);

  public final boolean hasLobAccess(Object lobInfo) {
    Long lobId = null;
    Long orgId = null;
    String orgName = null;
    String lobName = null;
    try {
      lobId = (Long) FieldUtils.getFieldValue(lobInfo, "lobId");
      orgId = (Long) FieldUtils.getFieldValue(lobInfo, "organizationId");
      lobName = (String) FieldUtils.getFieldValue(lobInfo, "lobName");
      orgName = (String) FieldUtils.getFieldValue(lobInfo, "organizationName");
    } catch (IllegalArgumentException | IllegalAccessException e) {
      LOG.debug(e.getMessage(), e);
      return false;
    }
    return validateLobInfo(lobId, orgId, lobName, orgName);
  }

  protected boolean validateLobInfo(Long lobId, Long orgId, String lobName, String orgName) {
    LobInfo lobInfoFromToken = getLobDetailsFromToken();
    if (lobInfoFromToken.getLobName().equalsIgnoreCase("SYSTEM")
        && lobInfoFromToken.getOrganizationName().equalsIgnoreCase("Organization")) {
      return true;
    }
    if (lobId != null) {
      if (lobInfoFromToken.getLobId().equals(lobId)) {
        return true;
      }
    } else if (lobName != null
        && orgId != null
        && lobName.equalsIgnoreCase(lobInfoFromToken.getLobName())
        && lobInfoFromToken.getOrganizationId().equals(orgId)) {
      return true;
    } else if (lobName != null
        && orgName != null
        && lobName.equalsIgnoreCase(lobInfoFromToken.getLobName())
        && orgName.equalsIgnoreCase(lobInfoFromToken.getOrganizationName())) {
      return true;
    }
    return false;
  }

  protected LobInfo getLobDetailsFromToken() {
    LobInfo lobDetails = new LobInfo();
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication != null
        && authentication.isAuthenticated()
        && authentication instanceof JwtAuthenticationToken) {
      Jwt jwtToken = ((JwtAuthenticationToken) authentication).getToken();
      lobDetails.setLobId(jwtToken.getClaim("currentLobId"));
      lobDetails.setOrganizationId(jwtToken.getClaim("currentOrganizationId"));
      lobDetails.setOrganizationName(jwtToken.getClaimAsString("currentOrganizationName"));
      lobDetails.setLobName(jwtToken.getClaimAsString("currentLobName"));
    }
    return lobDetails;
  }

  protected boolean isSystemLob(LobInfo lobInfo) {
    return lobInfo != null && lobInfo.getLobName() != null && lobInfo.getLobName().equalsIgnoreCase("SYSTEM")
        && lobInfo.getOrganizationName() != null && lobInfo.getOrganizationName().equalsIgnoreCase("Organization");
  }

  public boolean hasAccess(String permit) {
    boolean authorized = false;
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    if (authentication != null
        && authentication.isAuthenticated()
        && authentication instanceof JwtAuthenticationToken) {
      authorized =
          ((JwtAuthenticationToken) authentication)
              .getAuthorities()
              .stream()
              .anyMatch(node -> node.getAuthority().equalsIgnoreCase(permit));
    }
    return authorized;
  }
}
