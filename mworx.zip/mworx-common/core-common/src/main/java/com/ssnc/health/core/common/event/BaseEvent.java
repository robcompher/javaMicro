package com.ssnc.health.core.common.event;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.ssnc.health.core.common.error.ApiValidationError;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
public abstract class BaseEvent<T> {
  private String eventName;

  private T data;

  private Map<String, Object> headers;

  private List<ApiValidationError> errors;

  public BaseEvent() {
    this(null);
  }

  public BaseEvent(String eventName) {
    this.eventName = eventName;
    this.headers = new HashMap<>();
    this.errors = new ArrayList<>();
  }
}
