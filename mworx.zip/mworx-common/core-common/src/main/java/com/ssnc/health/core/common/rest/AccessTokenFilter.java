/*
 * FILE : AccessTokenFilter.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.rest;

import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ClientResponse;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.ExchangeFunction;
import reactor.core.publisher.Mono;

/**
 * AccessTokenFilter: WebClient filter to get access-token based property file configuration
 *
 * @author dt214743
 */
public class AccessTokenFilter implements ExchangeFilterFunction {

  private AccessTokenHelper tokenHelper;

  public AccessTokenFilter(AccessTokenHelper tokenHelper) {
    this.tokenHelper = tokenHelper;
  }

  @Override
  public Mono<ClientResponse> filter(ClientRequest request, ExchangeFunction next) {
    return next.exchange(ClientRequest.from(request).headers(headers -> {
      String authToken = tokenHelper.getAccessToken();
      if (authToken != null) {
        headers.setBearerAuth(authToken);
      }
    }).build());
  }
}
