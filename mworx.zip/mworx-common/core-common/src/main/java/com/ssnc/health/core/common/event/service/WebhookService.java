package com.ssnc.health.core.common.event.service;

import java.util.List;
import com.ssnc.health.core.common.event.model.WebhookDTO;

public interface WebhookService {
  WebhookDTO[] getWebhooksByEventNames(List<String> eventNames);
}
