/*
 * FILE : DefaultWebClientCustomizer.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.rest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.web.reactive.function.client.WebClientCustomizer;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.http.client.reactive.ReactorClientHttpConnector;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import io.netty.channel.ChannelOption;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.timeout.ReadTimeoutHandler;
import io.netty.handler.timeout.WriteTimeoutHandler;
import reactor.netty.http.client.HttpClient;
import reactor.netty.transport.logging.AdvancedByteBufFormat;

/**
 * DefaultWebClientCustomizer: WebClientBuilder customization
 * 
 * @author dt214743
 *
 */
@Component
public class DefaultWebClientCustomizer implements WebClientCustomizer {
  @Value("${web-client.read-write.timeout.seconds:4}")
  private int timeout;

  @Value("${web-client.compress:true}")
  private boolean compress;

  @Value("${spring.application.name}")
  private String clientId;

  @Override
  public void customize(WebClient.Builder webClientBuilder) {
    HttpClient httpClient = HttpClient.create()
        .wiretap("reactor.netty.http.client.HttpClient", LogLevel.DEBUG,
            AdvancedByteBufFormat.TEXTUAL)
        .option(ChannelOption.CONNECT_TIMEOUT_MILLIS, timeout * 1000)
        .doOnConnected(connection -> connection.addHandlerLast(new ReadTimeoutHandler(timeout))
            .addHandlerLast(new WriteTimeoutHandler(timeout)))
        .compress(compress);

    webClientBuilder.clientConnector(new ReactorClientHttpConnector(httpClient));
    webClientBuilder.filter(WebClientFilters.logRequest());
    webClientBuilder.filter(WebClientFilters.logResponse());
    webClientBuilder.defaultHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
    webClientBuilder.defaultHeader(HttpHeaders.ACCEPT, MediaType.APPLICATION_JSON_VALUE);
    webClientBuilder.defaultHeader("clientId", clientId);
  }
}
