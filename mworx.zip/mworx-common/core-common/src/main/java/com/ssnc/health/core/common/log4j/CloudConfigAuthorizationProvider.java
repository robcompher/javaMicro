package com.ssnc.health.core.common.log4j;

import static org.springframework.cloud.bootstrap.TextEncryptorConfigBootstrapper.keysConfigured;
import static org.springframework.cloud.config.client.ConfigClientProperties.AUTHORIZATION;
import static org.springframework.cloud.config.client.ConfigClientProperties.TOKEN_HEADER;
import java.net.URLConnection;
import java.util.Objects;
import org.apache.logging.log4j.Logger;
import org.apache.logging.log4j.core.util.AuthorizationProvider;
import org.apache.logging.log4j.spring.cloud.config.client.SpringLookup;
import org.apache.logging.log4j.status.StatusLogger;
import org.springframework.boot.context.properties.bind.Bindable;
import org.springframework.boot.context.properties.bind.Binder;
import org.springframework.cloud.bootstrap.TextEncryptorConfigBootstrapper.FailsafeTextEncryptor;
import org.springframework.cloud.bootstrap.encrypt.AbstractEnvironmentDecrypt;
import org.springframework.cloud.bootstrap.encrypt.EncryptionBootstrapConfiguration;
import org.springframework.cloud.bootstrap.encrypt.KeyProperties;
import org.springframework.cloud.bootstrap.encrypt.RsaProperties;
import org.springframework.cloud.config.client.ConfigClientProperties;
import org.springframework.cloud.context.encrypt.EncryptorFactory;
import org.springframework.core.env.Environment;
import org.springframework.security.crypto.encrypt.TextEncryptor;
import org.springframework.util.Base64Utils;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

/**
 * Custom log4j AuthorizationProvider implementation to support encryption like spring cloud config
 * 
 */
public class CloudConfigAuthorizationProvider extends SpringLookup
    implements AuthorizationProvider {
  private static Logger logger = StatusLogger.getLogger();
  private static final String AUTH_USER_NAME = "logging.auth.username";
  private static final String AUTH_PASSWORD = "logging.auth.password";
  public static final String CONFIG_USER_NAME = ConfigClientProperties.PREFIX + ".username";
  public static final String CONFIG_PASSWORD = ConfigClientProperties.PREFIX + ".password";

  private boolean failOnError = true;
  private String authString = null;
  private ConfigClientProperties clientProps;
  private boolean initialized = false;

  public CloudConfigAuthorizationProvider() {
    init();
  }
  
  private void init() {
    Environment environment = getEnvironment();
    if (environment != null) {
      initialized = true;
      TextEncryptor encryptor = getTextEncryptor(environment);
      String userName = lookup(AUTH_USER_NAME);
      String password = lookup(AUTH_PASSWORD);
      if (Objects.nonNull(userName) && Objects.nonNull(password)) {
        userName = decrypt(encryptor, AUTH_USER_NAME, userName);
        password = decrypt(encryptor, AUTH_PASSWORD, password);

        authString = getBasicToken(userName, password);
      } else {
        clientProps = new ConfigClientProperties(environment);
        Binder binder = Binder.get(environment);
        clientProps =
            binder.bind(ConfigClientProperties.PREFIX, Bindable.ofInstance(clientProps)).get();
        userName = decrypt(encryptor, CONFIG_USER_NAME, clientProps.getUsername());
        password = decrypt(encryptor, CONFIG_PASSWORD, clientProps.getPassword());
        authString = prepareAuthorizationToken(clientProps, userName, password);
      }
    }
  }

  @Override
  public void addAuthorization(URLConnection urlConnection) {
    if(!initialized) {
      init();
    }
    if (StringUtils.hasText(authString)) {
      urlConnection.setRequestProperty(AUTHORIZATION, authString);
    }

    if (clientProps != null && StringUtils.hasText(clientProps.getToken())) {
      urlConnection.setRequestProperty(TOKEN_HEADER, clientProps.getToken());
    }
  }

  private TextEncryptor getTextEncryptor(Environment environment) {
    Binder binder = Binder.get(environment);
    KeyProperties keyProperties =
        binder.bind(KeyProperties.PREFIX, KeyProperties.class).orElseGet(KeyProperties::new);
    if (keysConfigured(keyProperties)) {
      failOnError = keyProperties.isFailOnError();
      if (ClassUtils.isPresent("org.springframework.security.rsa.crypto.RsaSecretEncryptor",
          null)) {
        RsaProperties rsaProperties =
            binder.bind(RsaProperties.PREFIX, RsaProperties.class).orElseGet(RsaProperties::new);
        return EncryptionBootstrapConfiguration.createTextEncryptor(keyProperties, rsaProperties);
      }
      return new EncryptorFactory(keyProperties.getSalt()).create(keyProperties.getKey());
    }

    // no keys configured
    return new FailsafeTextEncryptor();
  }

  private String decrypt(TextEncryptor encryptor, String key, String original) {
    if (original == null
        || !original.startsWith(AbstractEnvironmentDecrypt.ENCRYPTED_PROPERTY_PREFIX)) {
      return original;
    }
    String value =
        original.substring(AbstractEnvironmentDecrypt.ENCRYPTED_PROPERTY_PREFIX.length());
    try {
      value = encryptor.decrypt(value);
      if (logger.isDebugEnabled()) {
        logger.debug("Decrypted: key={}", key);
      }
      return value;
    } catch (Exception e) {
      String message = "Cannot decrypt: key=" + key;
      if (logger.isDebugEnabled()) {
        logger.warn(message, e);
      } else {
        logger.warn(message);
      }
      if (this.failOnError) {
        throw new IllegalStateException(message, e);
      }
      return "";
    }
  }

  private String prepareAuthorizationToken(ConfigClientProperties configClientProperties,
      String username, String password) {
    String authorization = configClientProperties.getHeaders().get(AUTHORIZATION);

    if (password != null && authorization != null) {
      throw new IllegalStateException("You must set either 'password' or 'authorization'");
    }

    if (password != null) {
      return getBasicToken(username, password);
    } else if (authorization != null) {
      return authorization;
    }
    return null;
  }

  private String getBasicToken(String username, String password) {
    return "Basic " + new String(Base64Utils.encode((username + ":" + password).getBytes()));
  }
}
