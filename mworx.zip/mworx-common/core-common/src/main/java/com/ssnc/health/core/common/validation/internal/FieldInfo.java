/*
 * FILE : FieldInfo.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.internal;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import lombok.Getter;

@Getter
public class FieldInfo {
  private String name;
  private Class<?> type;
  private boolean isList;
  private boolean isObject;  

  private List<FieldInfo> subFields = new ArrayList<>();

  public FieldInfo name(String name) {
    this.name = name;
    return this;
  }
  
  public FieldInfo type(Class<?> type) {
    this.type = type;
    if(type.getTypeName().equals(LocalDate.class.getTypeName())
        || type.getTypeName().equals(Long.class.getTypeName())
        || type.getTypeName().equals(Double.class.getTypeName())
        || type.getTypeName().equals(Boolean.class.getTypeName())) {
      object(false);
      list(false);
    }
    return this;
  }
  
  public FieldInfo list(boolean isList) {
    this.isList = isList;
    return this;
  }
  
  public FieldInfo object(boolean isObject) {
    this.isObject = isObject;
    return this;
  }
}
