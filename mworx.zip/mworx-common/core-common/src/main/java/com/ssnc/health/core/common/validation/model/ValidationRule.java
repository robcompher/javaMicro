/*
 * FILE : ValidationRule.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.Id;
import javax.persistence.IdClass;
import javax.persistence.Transient;

import lombok.Getter;
import lombok.Setter;

/** Created by dt214746 on 1/28/2020. */
@Getter
@Setter
@Entity(name = "validation_rule")
@IdClass(ValidationRuleId.class)
public class ValidationRule {
  @Id
  @Column(name = "ruleset")
  private String ruleset;

  @Id
  @Column(name = "field_name")
  private String propertyName;

  @Column(name = "rule")
  private String rule;

  @Column(name = "message")
  private String message;

  @Column(name = "rule_type")
  private String ruleType;

  @Column(name = "object_type")
  @Enumerated(EnumType.STRING)
  private ObjectType objectType;

  @Column(name = "priority_type")
  private String priorityType;

  @Id
  @Column(name = "rule_order")
  private int ruleOrder;

  @Column(name = "hint_text")
  private String hint;
  
  @Transient private boolean rootBean;

  @Override
  public int hashCode() {
    final int prime = 31;
    int result = 1;
    result = prime * result + ((propertyName == null) ? 0 : propertyName.hashCode());
    result = prime * result + ruleOrder;
    result = prime * result + ((ruleset == null) ? 0 : ruleset.hashCode());
    return result;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (obj == null) return false;
    if (getClass() != obj.getClass()) return false;
    ValidationRule other = (ValidationRule) obj;
    if (propertyName == null) {
      if (other.propertyName != null) return false;
    } else if (!propertyName.equals(other.propertyName)) return false;
    if (ruleOrder != other.ruleOrder) return false;
    if (ruleset == null) {
      if (other.ruleset != null) return false;
    } else if (!ruleset.equals(other.ruleset)) return false;
    return true;
  }

  @Override
  public String toString() {
    return "ValidationRule [ruleset="
        + ruleset
        + ", propertyName="
        + propertyName
        + ", rule="
        + rule
        + ", message="
        + message
        + ", ruleType="
        + ruleType
        + ", objectType="
        + objectType
        + ", ruleOrder="
        + ruleOrder
        + ", priorityType="
        + priorityType
        + ", hint="
        + hint
        + "]";
  }
}
