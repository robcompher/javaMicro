/*
 * FILE : WebClientFilters.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.rest;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.util.StringUtils;
import org.springframework.web.reactive.function.client.ClientRequest;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssnc.health.core.common.error.ApiError;
import com.ssnc.health.core.common.error.ApiErrorException;
import io.netty.buffer.ByteBuf;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.ChannelPromise;
import io.netty.handler.logging.LoggingHandler;
import reactor.core.publisher.Mono;

/** Created by DT214743 on 02/13/2020. */
public class WebClientFilters {

  static final String CANNOT_ACCESS_THE_API_WITHOUT_AN_ACCESS_TOKEN =
      "Can't access the API (%s) without an access token";

  static final String UNAUTHENTICATED_URL = "/metadata/api/lob/getLOBById";

  static final ObjectMapper MAPPER = new ObjectMapper();

  private static final Logger LOG = LogManager.getLogger(WebClientFilters.class);

  private WebClientFilters() {}

  /**
   * Gets the access token from JwtAuthenticationToken from SecurityContext and adds to outgoing
   * request header
   *
   * <p>
   * Usage: WebClient.builder().filter(WebClientFilters.tokenRelayFilterFunction()).build();
   */
  public static ExchangeFilterFunction tokenRelayFilterFunction() {

    return (request, next) -> next.exchange(ClientRequest.from(request).headers(headers -> {
      Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
      String accessToken = null;
      if (authentication != null && authentication.isAuthenticated()
          && authentication instanceof JwtAuthenticationToken) {
        accessToken = ((JwtAuthenticationToken) authentication).getToken().getTokenValue();
      }
      if (accessToken != null) {
        headers.setBearerAuth(accessToken);
      } else if (!request.url().getPath().equalsIgnoreCase(UNAUTHENTICATED_URL)) {
        throw new IllegalStateException(
            String.format(CANNOT_ACCESS_THE_API_WITHOUT_AN_ACCESS_TOKEN, request.url()));
      }
    }).build());
  }

  public static ExchangeFilterFunction logRequest() {
    return (clientRequest, next) -> {
      LOG.info("----------------Request Begin--------------------------------------");
      LOG.info("Request: {} {}", clientRequest.method(), clientRequest.url());
      LOG.info("--- Http Headers: ---");
      clientRequest.headers().forEach(WebClientFilters::logHeader);
      LOG.info("--- Http Cookies: ---");
      clientRequest.cookies().forEach(WebClientFilters::logHeader);
      LOG.info("----------------Request End--------------------------------------");
      return next.exchange(clientRequest);
    };
  }

  public static ExchangeFilterFunction logResponse() {
    return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
      LOG.info("----------------Response Begin--------------------------------------");
      LOG.info("Response: {}", clientResponse.statusCode());
      clientResponse.headers().asHttpHeaders()
          .forEach((name, values) -> values.forEach(value -> LOG.info("{}={}", name, value)));
      LOG.info("----------------Response End--------------------------------------");
      return Mono.just(clientResponse);
    });
  }

  private static void logHeader(String name, List<String> values) {
    values.forEach(value -> LOG.info("{}={}", name, value));
  }

  public static ExchangeFilterFunction errorHandler() {
    return ExchangeFilterFunction.ofResponseProcessor(clientResponse -> {
      if (clientResponse.statusCode() != null && (clientResponse.statusCode().isError())) {
        return clientResponse.createException().flatMap(ex -> {
          if (clientResponse.statusCode().equals(HttpStatus.UNPROCESSABLE_ENTITY)) {
            try {
              ApiError apiError = MAPPER.readValue(ex.getResponseBodyAsByteArray(), ApiError.class);
              return Mono.error(new ApiErrorException(apiError, ex));
            } catch (IOException e) {
              // Ignore and let's return WebClient response exception
            }
          } else if (clientResponse.statusCode().equals(HttpStatus.NOT_FOUND)) {
            return Mono.error(new ApiErrorException(new ApiError(HttpStatus.NOT_FOUND), ex));
          }
          return Mono.error(ex);
        });
      } else {
        return Mono.just(clientResponse);
      }
    });
  }

  public static class WebClientLogger extends LoggingHandler {
    public WebClientLogger() {
      super(WebClientFilters.class);
    }

    @Override
    protected String format(ChannelHandlerContext ctx, String event, Object arg) {
      if (arg instanceof ByteBuf) {
        ByteBuf msg = (ByteBuf) arg;
        return msg.toString(StandardCharsets.UTF_8);
      }
      return super.format(ctx, event, arg);
    }

    @Override
    public void channelRead(ChannelHandlerContext ctx, Object msg) throws Exception {
      log("postlog", ctx, msg);
      ctx.fireChannelRead(msg);
    }

    @Override
    public void write(ChannelHandlerContext ctx, Object msg, ChannelPromise promise)
        throws Exception {
      log("prelog", ctx, msg);
      ctx.write(msg, promise);
    }

    private void log(String logKey, ChannelHandlerContext ctx, Object msg) {
      String content = ((ByteBuf) msg).toString(StandardCharsets.UTF_8);
      if (StringUtils.hasText(content)) {
        LOG.debug("{} [{}] : {}", logKey, ctx.channel().id(), content);
      }
    }
  }
}
