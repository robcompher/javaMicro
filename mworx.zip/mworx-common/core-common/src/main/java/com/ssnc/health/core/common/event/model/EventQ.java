/*
 * FILE : EventQ.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Convert;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import com.ssnc.health.core.common.event.EventQEvent;
import com.ssnc.health.core.common.event.Status;
import com.ssnc.health.core.common.model.Auditable;
import lombok.Data;
import lombok.EqualsAndHashCode;

@Entity(name = "EVENTQ")
@Data
@EqualsAndHashCode(callSuper = false)
public class EventQ extends Auditable<Long> implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  @SequenceGenerator(name = "EVENTQ_GENERATOR", sequenceName = "EVENTQ_SEQ", allocationSize = 1)
  @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "EVENTQ_GENERATOR")
  @Column(name = "EVENTQ_ID", unique = true, nullable = false)
  private Long eventQId;

  @Column(name = "EVENT_NAME")
  private String eventName;

  @Column(name = "EVENT_PAYLOAD")
  @Convert(converter = com.ssnc.health.core.common.event.model.EventQEventConverter.class)
  private EventQEvent<?> payload;

  @Column(name = "STATUS")
  @Enumerated(EnumType.STRING)
  private Status status;
}
