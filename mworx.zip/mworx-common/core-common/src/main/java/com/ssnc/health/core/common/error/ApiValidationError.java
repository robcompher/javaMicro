/*
 * FILE : ApiValidationError.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2019- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.error;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

/** Created by dt216896. */
@Data
@EqualsAndHashCode(callSuper = false)
public class ApiValidationError implements Serializable {

  private static final long serialVersionUID = 1L;
  
  private String object;
  private String field;
  private Object rejectedValue;
  private String message;
  private boolean resolved;
  private String severity;
  private String priority;
  private String hint;

  @JsonCreator
  public ApiValidationError(
      @JsonProperty("object") String object,
      @JsonProperty("field") String field,
      @JsonProperty("rejectedValue") Object rejectedValue,
      @JsonProperty("message") String message,
      @JsonProperty("resolved") boolean resolved,
      @JsonProperty("hint") String hint,
      @JsonProperty("priority") String priority) {
    this.object = object;
    this.field = field;
    this.rejectedValue = rejectedValue;
    this.message = message;
    this.resolved = resolved;
    this.severity = "Error";
    this.priority = priority;
    this.hint = hint;
  }

  public ApiValidationError(String object, String message) {
    this.object = object;
    this.message = message;
  }
}
