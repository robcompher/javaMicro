/*
 * FILE : ValidationRuleId.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.model;

import java.io.Serializable;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/** Created by dt214746 on 2/6/2020. */
@Getter
@ToString
@EqualsAndHashCode
public class ValidationRuleId implements Serializable {
  /**
   * 
   */
  private static final long serialVersionUID = 1L;
  
  private String ruleset;
  private String propertyName;
  private int ruleOrder;

  ValidationRuleId() {}

  ValidationRuleId(String ruleset, String propertyName, int ruleOrder) {
    this.ruleset = ruleset;
    this.propertyName = propertyName;
    this.ruleOrder = ruleOrder;
  }
}
