/*
 * FILE : ServiceAccountContextHolder.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Lazy;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import com.ssnc.health.core.common.rest.AccessTokenHelper;
import lombok.Getter;
import lombok.Setter;

public class ServiceAccountContextHolder {
  private static final Logger LOG = LogManager.getLogger(ServiceAccountContextHolder.class);
  
  private static final SecurityContext EMPTY_CONTEXT = SecurityContextHolder.createEmptyContext();
  private static final ThreadLocal<SecurityContext> ORIGINAL_CONTEXT = new ThreadLocal<>();

  // @Lazy
  // @Autowired(required = false)
  // @Qualifier("serviceAccountWebClient")
  // private WebClient serviceAccountWebClient;

  @Lazy
  @Autowired(required = false)
  @Qualifier("serviceAccountTokenHelper")
  AccessTokenHelper serviceAccountTokenHelper;

//  @Value("${user.by.username.url:/auth/api/user/getUserByUserName}")
//  private String usernameUrl;

//  @Value("${service-account.username}")
//  private String username;

  //private Long userId;

  public void set() {
    LOG.debug("set context");
    SecurityContext currentContext = SecurityContextHolder.getContext();
    ORIGINAL_CONTEXT.set(currentContext);
    if (currentContext == null || EMPTY_CONTEXT.equals(currentContext)) {
      SecurityContext newContext = SecurityContextHolder.createEmptyContext();
      // set context with service account
      newContext.setAuthentication(serviceAccountTokenHelper.getJwtAuthenticationToken());

      SecurityContextHolder.setContext(newContext);
    }
  }

  public void clear() {
    SecurityContext originalContext = ORIGINAL_CONTEXT.get();
    if (originalContext == null || EMPTY_CONTEXT.equals(originalContext)) {
      SecurityContextHolder.clearContext();
      ORIGINAL_CONTEXT.remove();
    }
  }

//  @EventListener(ApplicationReadyEvent.class)
//  public void initialize() {
//    LOG.debug("ServiceAccountContextHolder::initialize");
//    User user = (User) RestApiClient.builder().webClient(this.serviceAccountWebClient).build()
//        .post(this.usernameUrl, Map.ofEntries(Map.entry("userName", username)), User.class);
//
//    this.userId = user.getUserId();
//    if (this.userId == null) {
//      this.userId = -1l;
//    }
//
//    LOG.debug("ServiceAccountContextHolder::service-account-id {}", this.userId);
//  }
}


@Getter
@Setter
class User {
  private Long userId;
}
