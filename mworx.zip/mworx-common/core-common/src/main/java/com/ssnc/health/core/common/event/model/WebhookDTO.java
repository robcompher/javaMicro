package com.ssnc.health.core.common.event.model;

import java.util.List;
import lombok.Data;

@Data
public class WebhookDTO {
  private Long id;

  private String webhookName;
  private String targetUrl;
  private String authType;
  private String authData;
  private String internal;
  private String unwrapPayload;

  private List<EventDTO> events;
}
