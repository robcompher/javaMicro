/*
 * FILE : WebhookSelector.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.config;

import org.springframework.integration.core.MessageSelector;
import org.springframework.messaging.Message;
import com.ssnc.health.core.common.event.model.EventQ;
import com.ssnc.health.core.common.event.model.WebhookDTO;

/**
 * WebhookSelector: selects webhook based on event name
 *
 * @author dt214743
 */
public class WebhookSelector implements MessageSelector {
  private WebhookDTO webhook;

  public WebhookSelector(WebhookDTO webhook) {
    this.webhook = webhook;
  }

  @Override
  public boolean accept(Message<?> message) {
    if (message.getPayload() instanceof EventQ) {
      EventQ eventQ = (EventQ) message.getPayload();
      return webhook
          .getEvents()
          .stream()
          .anyMatch(
              eventDTO -> eventQ.getEventName().equalsIgnoreCase(eventDTO.getFormattedEventName()));
    }
    return false;
  }
}
