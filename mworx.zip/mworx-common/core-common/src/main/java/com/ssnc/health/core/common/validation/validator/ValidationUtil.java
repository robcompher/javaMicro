/*
 * FILE : ValidationUtil.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.validator;

import java.io.IOException;
import java.lang.annotation.ElementType;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import javax.validation.Path;
import javax.validation.metadata.ConstraintDescriptor;
import org.apache.commons.lang3.StringUtils;
import org.hibernate.validator.constraintvalidation.HibernateConstraintValidatorContext;
import org.hibernate.validator.internal.engine.ConstraintViolationImpl;
import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintValidatorContextImpl;
import org.hibernate.validator.internal.engine.constraintvalidation.ConstraintViolationCreationContext;
import org.hibernate.validator.internal.engine.path.PathImpl;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.beans.NotReadablePropertyException;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssnc.health.core.common.error.ApiValidationError;
import com.ssnc.health.core.common.validation.internal.Priority;
import com.ssnc.health.core.common.validation.model.ValidationRule;

public class ValidationUtil {
  private static final ObjectMapper objectMapper = new ObjectMapper();

  public static final void addInvalidIndex(ConstraintValidatorContext context, Integer... indexes) {
    HibernateConstraintValidatorContext hibernateContext =
        context.unwrap(HibernateConstraintValidatorContext.class);

    ConstraintViolationCreationContext creationContext =
        ((ConstraintValidatorContextImpl) hibernateContext)
            .getConstraintViolationCreationContexts()
            .get(0);
    @SuppressWarnings("unchecked")
    List<Integer[]> invalidIndexes = (List<Integer[]>) creationContext.getDynamicPayload();

    if (invalidIndexes == null) {
      invalidIndexes = new ArrayList<>();
    }
    invalidIndexes.add(indexes);

    hibernateContext.withDynamicPayload(invalidIndexes);
  }

  public static final String validationRuleToString(ValidationRule rule) {
    try {
      return objectMapper.writeValueAsString(rule);
    } catch (JsonProcessingException e) {
      return String.format(
          "Error occured while configuring rule as constraint: %s", e.getMessage());
    }
  }

  /**
   * messageMap.get("message"); - message to display messageMap.get("hint"); - hint to show to user
   * for resolving error
   *
   * @param message
   * @return
   */
  public static final ValidationRule stringToValidationRule(String message) {
    if (message == null || !message.startsWith("{")) {
      ValidationRule rule = new ValidationRule();
      rule.setMessage(message);

      return rule;
    }

    try {
      return objectMapper.readValue(message, ValidationRule.class);
    } catch (IOException e) {
      throw new RuntimeException("Error message deserialization failed:" + message, e);
    }
  }

  public static final List<ApiValidationError> toApiValidationErrors(
      Set<ConstraintViolation<?>> constraintViolations) {
    List<ApiValidationError> errors = new ArrayList<>();
    constraintViolations.forEach(cv -> errors.add(ValidationUtil.toApiValidationError(cv)));
    return errors;
  }

  /**
   * Utility method for adding error of ConstraintViolation. Usually when a @Validated validation
   * fails.
   *
   * @param cv the ConstraintViolation
   */
  public static final ApiValidationError toApiValidationError(ConstraintViolation<?> cv) {
    String invalidProperty =
        StringUtils.substringBefore(
            ((PathImpl) cv.getPropertyPath()).getLeafNode().asString(), ".<list element>");
    Object invalidPropertyValue;
    try {
      BeanWrapper beanWrapper = new BeanWrapperImpl(cv.getInvalidValue());
      if (invalidProperty.indexOf(",") != -1) {
        Map<String, Object> invalidObject = new HashMap<>();
        String[] props = invalidProperty.split(",");
        Arrays.stream(props)
            .forEach(
                property -> {
                  invalidObject.put(property, beanWrapper.getPropertyValue(property));
                });
        invalidPropertyValue = invalidObject;
      } else {
        invalidPropertyValue = beanWrapper.getPropertyValue(invalidProperty);
      }
    } catch (NotReadablePropertyException e) {
      invalidPropertyValue = cv.getInvalidValue();
    }

    ValidationRule rule = stringToValidationRule(cv.getMessage());

    String priorityString = Priority.classToString(Priority.High.class);

    if (StringUtils.isNotEmpty(rule.getPriorityType())) {
      priorityString = rule.getPriorityType();
    }

    return new ApiValidationError(
        cv.getRootBeanClass().getSimpleName(),
        invalidProperty,
        invalidPropertyValue,
        rule.getMessage() != null ? rule.getMessage().trim() : rule.getMessage(),
        false,
        rule.getHint(),
        priorityString);
  }

  /**
   * Create a ConstraintViolation.
   *
   * @param Object
   * @param ruleSet
   * @param message
   * @param field
   * @param priority
   * @param rootBeanClass
   * @return ConstraintViolationImpl
   */
  public static ConstraintViolationImpl<Object> createConstraintViolation(
      Object object,
      String ruleSet,
      String message,
      String field,
      String priority,
      final Class<Object> rootBeanClass) {

    ValidationRule validationRule = new ValidationRule();
    String convertedJsonString = null;

    validationRule.setRuleset(ruleSet);
    validationRule.setMessage(message);
    validationRule.setPropertyName(field);
    validationRule.setPriorityType(priority);
    convertedJsonString = validationRuleToString(validationRule);

    PathImpl pathImpl = PathImpl.createRootPath();
    pathImpl.addPropertyNode(field);

    final String messageTemplate = convertedJsonString;
    final String interpolatedMessage = convertedJsonString;
    final Object rootBean = null;
    final Object leafBeanInstance = null;
    final Object value = object;
    final Path propertyPath = pathImpl;
    final ConstraintDescriptor<?> constraintDescriptor = null;
    final ElementType elementType = null;
    final Map<String, Object> messageParameters = new HashMap<>();
    final Map<String, Object> expressionVariables = new HashMap<>();
    return (ConstraintViolationImpl<Object>)
        ConstraintViolationImpl.forReturnValueValidation(
            messageTemplate,
            messageParameters,
            expressionVariables,
            interpolatedMessage,
            rootBeanClass,
            rootBean,
            leafBeanInstance,
            value,
            propertyPath,
            constraintDescriptor,
            elementType,
            null);
  }
}
