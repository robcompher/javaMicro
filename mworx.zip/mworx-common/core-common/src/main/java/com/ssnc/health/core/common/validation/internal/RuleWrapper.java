/*
 * FILE : RuleWrapper.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.internal;

import java.util.Arrays;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.validation.Payload;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.hibernate.validator.cfg.ConstraintDef;
import org.hibernate.validator.cfg.GenericConstraintDef;
import org.hibernate.validator.cfg.defs.AssertFalseDef;
import org.hibernate.validator.cfg.defs.AssertTrueDef;
import org.hibernate.validator.cfg.defs.DecimalMaxDef;
import org.hibernate.validator.cfg.defs.DecimalMinDef;
import org.hibernate.validator.cfg.defs.DigitsDef;
import org.hibernate.validator.cfg.defs.EmailDef;
import org.hibernate.validator.cfg.defs.FutureDef;
import org.hibernate.validator.cfg.defs.FutureOrPresentDef;
import org.hibernate.validator.cfg.defs.MaxDef;
import org.hibernate.validator.cfg.defs.MinDef;
import org.hibernate.validator.cfg.defs.NegativeDef;
import org.hibernate.validator.cfg.defs.NegativeOrZeroDef;
import org.hibernate.validator.cfg.defs.NotBlankDef;
import org.hibernate.validator.cfg.defs.NotEmptyDef;
import org.hibernate.validator.cfg.defs.NotNullDef;
import org.hibernate.validator.cfg.defs.NullDef;
import org.hibernate.validator.cfg.defs.PastDef;
import org.hibernate.validator.cfg.defs.PastOrPresentDef;
import org.hibernate.validator.cfg.defs.PatternDef;
import org.hibernate.validator.cfg.defs.PositiveDef;
import org.hibernate.validator.cfg.defs.PositiveOrZeroDef;
import org.hibernate.validator.cfg.defs.RangeDef;
import org.hibernate.validator.cfg.defs.ScriptAssertDef;
import org.hibernate.validator.cfg.defs.SizeDef;
import org.springframework.util.ClassUtils;
import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.validator.ValidationUtil;
import lombok.Data;

@Data
public class RuleWrapper implements Payload {
  public static final String DOT = ".";

  public static final String COMMA = ",";

  // public static final String PROPERTY_SEPERATOR = "~`~`";

  private static final Logger LOGGER = LogManager.getLogger(RuleWrapper.class);

  private static final Map<String, Pattern> PATTERNS = new ConcurrentHashMap<>();

  static {
    PATTERNS.put("min", Pattern.compile("(?=min=(\\d+))"));
    PATTERNS.put("max", Pattern.compile("(?=max=(\\d+))"));
    PATTERNS.put("value", Pattern.compile("(?=value=(\\d+))|(?=value=\"([^\"]*)\")"));
    PATTERNS.put("inclusive", Pattern.compile("(?=inclusive=([^,]*))|(?=inclusive=\"([^\"]*)\")"));
    PATTERNS.put("fraction", Pattern.compile("(?=fraction=(\\d+))"));
    PATTERNS.put("integer", Pattern.compile("(?=integer=(\\d+))"));
    PATTERNS.put("regexp", Pattern.compile("(?=regexp=\"([^\"]*)\")"));
    PATTERNS.put("flags", Pattern.compile("(?=flags=\"([^\"]*)\")"));
    PATTERNS.put("lang", Pattern.compile("(?=lang=\"([^\"]*)\")"));
    PATTERNS.put("script", Pattern.compile("(?=script=\"([^\"]*)\")"));
    PATTERNS.put("reportOn", Pattern.compile("(?=reportOn=\"([^\"]*)\")"));
    PATTERNS.put("alias", Pattern.compile("(?=alias=\"([^\"]*)\")"));
    PATTERNS.put("applyIf", Pattern.compile("(?=applyIf=\"([^\"]*)\")"));
    PATTERNS.put("helpers", Pattern.compile("(?=helpers=\"([^\"]*)\")"));
    PATTERNS.put(
        "validatorClass",
        Pattern.compile("(?=validatorClass=([^,]*))|(?=validatorClass=\"([^\"]*)\")"));
    PATTERNS.put("rootBean", Pattern.compile("(?=rootBean=([^,]*))|(?=rootBean=\"([^\"]*)\")"));
    PATTERNS.put(
        "jsonSchema",
        Pattern.compile(
            "(?=jsonSchema=\"(.+?(?=(?:\",[\\s]\\w+=)|"
                + "(?:\",\\w+=)|(?:\")$)))|(?=jsonSchema="
                + "(.+?(?=(?:,[\\s]\\w+=)|(?:\",\\w+=)|$)))"));
  }

  private boolean isValidRule;
  private boolean isMultiRule;
  private String jsonSchema;

  private ValidationRule rule;
  private ConstraintDef<?, ?> constraintDef;
  private boolean rootBean;

  @SuppressWarnings("unchecked")
  public RuleWrapper(ValidationRule rule) {
    this.rule = rule;
    this.constraintDef = convertRuleToAnnotationDef();
    if (this.constraintDef != null) {
      this.rootBean = Boolean.valueOf(extractValue("rootBean", true));
      this.rule.setRootBean(rootBean);
      this.isValidRule = true;

      if (rule.getPropertyName() != null
              && (rule.getPropertyName().indexOf(',') != -1
                  || rule.getRuleType().equalsIgnoreCase("CUSTOM_VALIDATION"))
          || rootBean) {
        this.isMultiRule = true;
        this.constraintDef.groups(MultiGroup.class);
      } else {
        this.constraintDef.groups(SingleGroup.class);
      }
      // there is not way to pass additional data to validator. So serialize
      // and pass as message and retrieve later to check on additional data from processing
      this.constraintDef.message(ValidationUtil.validationRuleToString(rule));
      this.constraintDef.payload(Priority.stringToClass(this.rule.getPriorityType()));
    }
    this.jsonSchema = extractValue("jsonSchema", true);
  }

  @SuppressWarnings("deprecation")
  private ConstraintDef<?, ?> convertRuleToAnnotationDef() {
    try {
      if (rule.getRuleType().equalsIgnoreCase("assertfalse")) {
        return new AssertFalseDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("asserttrue")) {
        return new AssertTrueDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("decimalmax")) {
        DecimalMaxDef definition = new DecimalMaxDef();
        definition.value(extractValue("value", false));
        String inclusive = extractValue("inclusive", true);
        if (inclusive != null) definition.inclusive(Boolean.valueOf(inclusive));
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("decimalmin")) {
        DecimalMinDef definition = new DecimalMinDef();
        definition.value(extractValue("value", false));
        String inclusive = extractValue("inclusive", true);
        if (inclusive != null) definition.inclusive(Boolean.valueOf(inclusive));
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("digits")) {
        DigitsDef definition = new DigitsDef();
        definition.fraction(Integer.valueOf(extractValue("fraction", false)));
        definition.integer(Integer.valueOf(extractValue("integer", false)));
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("email")) {
        EmailDef definition = new EmailDef();
        String regex = extractValue("regexp", true);
        if (regex != null) {
          definition.regexp(regex);

          javax.validation.constraints.Pattern.Flag[] flags = extractFlags();
          if (flags != null && flags.length > 0) {
            definition.flags(flags);
          }
        }
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("future")) {
        return new FutureDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("futureorpresent")) {
        return new FutureOrPresentDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("max")) {
        MaxDef definition = new MaxDef();
        definition.value(Long.valueOf(extractValue("value", false)));
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("min")) {
        MinDef definition = new MinDef();
        definition.value(Long.valueOf(extractValue("value", false)));
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("negative")) {
        return new NegativeDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("negativeorzero")) {
        return new NegativeOrZeroDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("notblank")) {
        return new NotBlankDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("notempty")) {
        return new NotEmptyDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("notnull")
          || rule.getRuleType().equalsIgnoreCase("NOTNULL_VALIDATION")
          || rule.getRuleType().equalsIgnoreCase("JSON_NOTNULL_VALIDATION")) {
        return new NotNullDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("null")) {
        return new NullDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("past")) {
        return new PastDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("pastorpresent")) {
        return new PastOrPresentDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("pattern")) {
        PatternDef definition = new PatternDef();
        String regex = extractValue("regexp", true);
        definition.regexp(regex);

        javax.validation.constraints.Pattern.Flag[] flags = extractFlags();
        if (flags != null && flags.length > 0) {
          definition.flags(flags);
        }

        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("PATTERN_VALIDATION")) {
        return new GenericConstraintDef<>(
                com.ssnc.health.core.common.validation.internal.Pattern.class)
            .param("regexp", rule.getRule())
            .message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("positive")) {
        return new PositiveDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("positiveorzero")) {
        return new PositiveOrZeroDef().message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("size")) {
        SizeDef definition = new SizeDef();
        definition.min(Integer.valueOf(extractValue("min", false)));
        definition.max(Integer.valueOf(extractValue("max", false)));
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("Range")) {
        RangeDef definition = new RangeDef();
        definition.min(Long.valueOf(extractValue("min", false)));
        definition.max(Long.valueOf(extractValue("max", false)));
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("ScriptAssert")) {
        ScriptAssertDef definition = new ScriptAssertDef();
        definition.lang(extractValue("lang", false));
        definition.script(extractValue("script", false));
        String value = extractValue("alias", true);
        if (StringUtils.isNoneEmpty(value)) {
          definition.alias(value);
        }
        value = extractValue("reportOn", true);
        if (StringUtils.isNoneEmpty(value)) {
          definition.reportOn(value);
        } else {
          definition.reportOn(rule.getPropertyName());
        }
        definition.message(rule.getMessage());

        return definition;
      } else if (rule.getRuleType().equalsIgnoreCase("CUSTOM_VALIDATION")
          || rule.getRuleType().equalsIgnoreCase("CUSTOM_FIELD_VALIDATION")) {
        String validatorClass = extractValue("validatorClass", true);
        if (validatorClass == null) {
          validatorClass = rule.getRule();
        }
        return new GenericConstraintDef<>(Custom.class)
            .param(
                "validatorClass",
                ClassUtils.forName(validatorClass, Thread.currentThread().getContextClassLoader()))
            .message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("BeforeDate")) {
        String[] fieldNames = rule.getPropertyName().split(COMMA);
        if (fieldNames.length != 2) {
          throw new IllegalArgumentException(
              String.format("Invalid rule definition (%s)", rule.toString()));
        }
        return new GenericConstraintDef<>(BeforeDate.class)
            .param("dateField", resolveFieldName(fieldNames[0]))
            .param("otherDateField", resolveFieldName(fieldNames[1]))
            .message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("AfterDate")) {
        String[] fieldNames = rule.getPropertyName().split(COMMA);
        if (fieldNames.length != 2) {
          throw new IllegalArgumentException(
              String.format("Invalid rule definition (%s)", rule.toString()));
        }
        return new GenericConstraintDef<>(AfterDate.class)
            .param("dateField", resolveFieldName(fieldNames[0]))
            .param("otherDateField", resolveFieldName(fieldNames[1]))
            .message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("SameOrAfterDate")) {
          String[] fieldNames = rule.getPropertyName().split(COMMA);
          if (fieldNames.length != 2) {
            throw new IllegalArgumentException(
                String.format("Invalid rule definition (%s)", rule.toString()));
          }
          return new GenericConstraintDef<>(SameOrAfterDate.class)
              .param("dateField", resolveFieldName(fieldNames[0]))
              .param("otherDateField", resolveFieldName(fieldNames[1]))
              .message(rule.getMessage());
      } else if (rule.getRuleType().equalsIgnoreCase("SpELAssert")) {
        // https://github.com/jirutka/validator-spring
        GenericConstraintDef<SpELAssert> definition = new GenericConstraintDef<>(SpELAssert.class);
        definition.param("value", extractValue("value", false));
        String value = extractValue("applyIf", true);
        if (StringUtils.isNoneEmpty(value)) {
          definition.param("applyIf", value);
        }
        value = extractValue("helpers", true);
        if (StringUtils.isNoneEmpty(value)) {
          definition.param(
              "helpers", ClassUtils.forName(value, Thread.currentThread().getContextClassLoader()));
        }
        definition.message(rule.getMessage());

        return definition;
      } else {
        rule.setMessage(String.format("Rule (%s) is not supported", rule.getRuleType()));
      }
    } catch (IllegalArgumentException | ClassNotFoundException | LinkageError e) {
      LOGGER.error(e);
      rule.setMessage(
          String.format("Error occured while configuring rule as constraint: %s", e.getMessage()));
    }

    return null;
  }

  private String resolveFieldName(String fieldName) {
    if (fieldName != null && fieldName.contains(DOT)) {
      return StringUtils.substringAfterLast(fieldName, DOT);
    }

    return fieldName;
  }

  private javax.validation.constraints.Pattern.Flag[] extractFlags() {
    String flagsString = extractValue("flags", true);
    if (flagsString != null) {
      javax.validation.constraints.Pattern.Flag[] flags =
          Arrays.asList(flagsString.split(COMMA))
              .stream()
              .map(name -> javax.validation.constraints.Pattern.Flag.valueOf(name))
              .filter(flag -> flag != null)
              .toArray(javax.validation.constraints.Pattern.Flag[]::new);

      return flags;
    }

    return null;
  }

  private String extractValue(String key, boolean optional) {
    String value = null;
    if (StringUtils.isNotEmpty(rule.getRule())) {
      Pattern pattern = PATTERNS.get(key);
      if (pattern == null) {
        pattern = Pattern.compile("(?=" + key + "=([^,]*))|(?=" + key + "=\"([^\"]*)\")");
      }
      Matcher matcher = pattern.matcher(rule.getRule());
      if (matcher.find()) {
        for (int i = 0; i <= matcher.groupCount(); i++) {
          if (StringUtils.isNotEmpty(matcher.group(i))) {
            value = matcher.group(i);
            break;
          }
        }
      }
    }
    if (!optional && value == null) {
      throw new IllegalArgumentException(
          String.format("Invalid rule definition (%s)", rule.toString()));
    }
    return value;
  }
}
