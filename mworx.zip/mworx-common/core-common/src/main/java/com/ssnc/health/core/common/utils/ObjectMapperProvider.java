package com.ssnc.health.core.common.utils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.ObjectMapper;

@Component
public class ObjectMapperProvider {
  private static ObjectMapper objectMapper;

  public static ObjectMapper getObjectMapper() {
    if(ObjectMapperProvider.objectMapper == null) {
      return new ObjectMapper();
    }
    return ObjectMapperProvider.objectMapper;
  }

  @Autowired
  public void setObjectMapper(ObjectMapper objectMapper) {
    ObjectMapperProvider.objectMapper = objectMapper;
  }
}
