/*
 * FILE : CustomConstraintViolationException.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.config;

import java.util.Set;
import javax.validation.ConstraintViolation;
import javax.validation.ConstraintViolationException;
import java.util.HashSet;

/**
 * 
 * @author DT214743
 *
 */
public class CustomConstraintViolationException extends ConstraintViolationException {

  private static final long serialVersionUID = 6035117936229308944L;

  private transient Object response;
  
  public CustomConstraintViolationException() {
      this(new HashSet<>()) ;
  }

  public CustomConstraintViolationException(
      String message, Set<? extends ConstraintViolation<?>> constraintViolations) {
    super(message, constraintViolations);
  }

  public CustomConstraintViolationException(
      Set<? extends ConstraintViolation<?>> constraintViolations) {
    super(constraintViolations);
  }

  public Object getResponse() {
    return response;
  }

  public void setResponse(Object response) {
    this.response = response;
  }
}
