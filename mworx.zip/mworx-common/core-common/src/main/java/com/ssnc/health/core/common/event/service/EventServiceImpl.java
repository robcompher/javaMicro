/*
 * FILE : EventQServiceImpl.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.ssnc.health.core.common.event.EventQEvent;
import com.ssnc.health.core.common.event.Status;
import com.ssnc.health.core.common.event.model.EventQ;
import com.ssnc.health.core.common.event.repository.EventQRepository;

@Service
public class EventServiceImpl implements EventService {
  @Autowired EventQRepository eventQRepository;

  @Override
  public List<EventQ> findByEventName(String eventName, Pageable pageable) {
    return eventQRepository.findByEventName(eventName, pageable);
  }

  @Override
  @Transactional
  public void queueEvent(EventQEvent<?> event) {
    EventQ eventQ = new EventQ();
    eventQ.setEventName(event.getEventName());
    eventQ.setPayload(event);
    eventQ.setStatus(Status.OPEN);
    this.addEventQ(eventQ);
  }

  @Override
  @Transactional
  public EventQ addEventQ(EventQ eventQ) {
    return eventQRepository.save(eventQ);
  }

  @Override
  @Transactional
  public Optional<EventQ> updateEventQ(EventQ eventQ) {
    Optional<EventQ> existingEventQ = eventQRepository.findById(eventQ.getEventQId());
    if (existingEventQ.isPresent()) {
      EventQ existingEvent = existingEventQ.get();
      eventQ.setEventQId(existingEvent.getEventQId());
      eventQ.setCreated(existingEvent.getCreated());
      eventQ.setCreateBy(existingEvent.getCreateBy());
      existingEventQ = Optional.of(eventQRepository.save(eventQ));
    }
    return existingEventQ;
  }
}
