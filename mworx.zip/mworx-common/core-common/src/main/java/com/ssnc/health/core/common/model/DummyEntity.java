package com.ssnc.health.core.common.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.Id;

/**  
 *   DO NOT USE - Workaround to fix issue with Auditable static weaving
 *   Reference - https://bugs.eclipse.org/bugs/show_bug.cgi?id=466271 
 * */

@Entity
public class DummyEntity extends Auditable<Long> implements Serializable {
  private static final long serialVersionUID = 1L;

  @Id
  private Long id;
}