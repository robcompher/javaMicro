/*
 * FILE : RulesetController.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.resources;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.service.RulesService;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@RestController
public class RulesetController {

  @Autowired RulesService ruleService;

  @GetMapping("/api/validation/getRulesByRuleset/{ruleset}/{page}/{pageSize}")
  public ResponseEntity<List<ValidationRule>> getRulesByRuleset(
      @PathVariable String ruleset, @PathVariable int page, @PathVariable int pageSize) {
    Pageable pageable = PageRequest.of(page, pageSize);
    List<ValidationRule> rules = ruleService.findRulesByRuleset(ruleset, pageable);
    return ResponseEntity.ok(rules);
  }

  @GetMapping("/api/validation/getAllRulesByRuleset/{ruleset}")
  public ResponseEntity<List<ValidationRule>> getAllRulesByRuleset(@PathVariable String ruleset) {
    List<ValidationRule> rules = ruleService.findRulesByRuleset(ruleset);
    return ResponseEntity.ok(rules);
  }
}
