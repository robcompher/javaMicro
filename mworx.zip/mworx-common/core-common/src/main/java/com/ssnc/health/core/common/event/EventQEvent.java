package com.ssnc.health.core.common.event;

import java.io.Serializable;
import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;

public class EventQEvent<T> extends BaseEvent<T> implements Serializable {
  private static final long serialVersionUID = 1L;

  @JsonCreator
  public EventQEvent(@JsonProperty("eventName") String eventName) {
    super(eventName);
  }

  @Override
  public String toString() {
    return "EventQEvent [" + super.toString() + "]";
  }
}
