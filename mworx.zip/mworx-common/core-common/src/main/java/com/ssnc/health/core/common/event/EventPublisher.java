package com.ssnc.health.core.common.event;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.stereotype.Component;

@Component
public class EventPublisher {
  private final ApplicationEventPublisher publisher;

  EventPublisher(ApplicationEventPublisher publisher) {
    this.publisher = publisher;
  }

  public void publish(BaseEvent<?> event) {
    publisher.publishEvent(event);
  }
}
