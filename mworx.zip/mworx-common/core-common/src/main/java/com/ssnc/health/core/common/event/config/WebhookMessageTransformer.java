/*
 * FILE : WebhookMessageTransformer.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.integration.support.MessageBuilder;
import org.springframework.integration.transformer.GenericTransformer;
import org.springframework.messaging.Message;
import com.ssnc.health.core.common.error.ApiValidationError;
import com.ssnc.health.core.common.event.Constants;
import com.ssnc.health.core.common.event.EventQEvent;
import com.ssnc.health.core.common.event.Status;
import com.ssnc.health.core.common.event.model.EventQ;
import com.ssnc.health.core.common.event.model.WebhookDTO;
import lombok.Getter;
import lombok.Setter;

/**
 * WebhookMessageTransformer: Transforms message to webhook endpoint
 *
 * @author dt214743
 */
public class WebhookMessageTransformer implements GenericTransformer<Message<?>, Message<?>> {
  private WebhookDTO webhook;

  public WebhookMessageTransformer(WebhookDTO webhook) {
    this.webhook = webhook;
  }

  @Override
  public Message<?> transform(Message<?> source) {
    EventQ eventQ = ((EventQ) source.getPayload());

    EventQEvent<?> event = eventQ.getPayload();

    Object payload;

    if (webhook.getUnwrapPayload() != null && webhook.getUnwrapPayload().equalsIgnoreCase("Y")) {
      payload = event.getData();
    } else {
      payload = createPayload(eventQ, event);
    }

    return MessageBuilder.withPayload(payload)
        .copyHeaders(source.getHeaders())
        .setHeader(Constants.EVENT_NAME.name(), eventQ.getEventName())
        .setHeader(Constants.REQUEST_PAYLOAD_KEY.name(), eventQ)
        .setHeader(Constants.WEBHOOK_KEY.name(), webhook)
        .setHeader(Constants.RESPONSE_STATUS_CODE.name(), 200)
        .setHeader(Constants.STATUS.name(), Status.COMPLETED)
        .setHeaderIfAbsent(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE)
        .build();
  }

  private WebhookPayload<Object> createPayload(EventQ eventQ, EventQEvent<?> event) {
    WebhookPayload<Object> payload = new WebhookPayload<>();
    payload.setHeader(new HashMap<>());
    payload.getHeader().putAll(event.getHeaders());
    payload.getHeader().putIfAbsent("eventId", eventQ.getEventQId());
    payload.getHeader().putIfAbsent("eventName", eventQ.getEventName());
    payload.getHeader().put("webhookName", webhook.getWebhookName());
    payload.setErrors(event.getErrors());
    payload.setData(event.getData());
    return payload;
  }
}

@Getter
@Setter
class WebhookPayload<T> {
  private T data;

  private Map<String, Object> header;

  private List<ApiValidationError> errors;
}
