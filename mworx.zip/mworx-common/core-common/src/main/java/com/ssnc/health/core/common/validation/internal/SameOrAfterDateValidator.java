/*
 * FILE : SameOrAfterDateValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.internal;

import java.time.LocalDate;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.BeanWrapper;
import org.springframework.beans.BeanWrapperImpl;

public class SameOrAfterDateValidator implements ConstraintValidator<SameOrAfterDate, Object> {
  private String dateField;
  private String otherDateField;

  @Override
  public void initialize(final SameOrAfterDate annotation) {
    dateField = annotation.dateField();
    otherDateField = annotation.otherDateField();
  }

  @Override
  public boolean isValid(Object value, ConstraintValidatorContext context) {
    final BeanWrapper beanWrapper = new BeanWrapperImpl(value);

    final LocalDate date = (LocalDate) beanWrapper.getPropertyValue(dateField);
    final LocalDate otherDate = (LocalDate) beanWrapper.getPropertyValue(otherDateField);

    if (date == null || otherDate == null) {
      return true;
    }

    return date.isEqual(otherDate) || date.isAfter(otherDate);
  }
}
