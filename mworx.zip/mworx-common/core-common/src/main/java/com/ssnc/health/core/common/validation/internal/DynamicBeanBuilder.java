/*
 * FILE : DynamicBeanBuilder.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.internal;

import static net.bytebuddy.description.modifier.Visibility.PUBLIC;
import java.util.Iterator;
import java.util.List;
import net.bytebuddy.ByteBuddy;
import net.bytebuddy.description.modifier.Visibility;
import net.bytebuddy.description.type.TypeDefinition;
import net.bytebuddy.description.type.TypeDescription;
import net.bytebuddy.description.type.TypeDescription.Generic;
import net.bytebuddy.dynamic.DynamicType;
import net.bytebuddy.dynamic.loading.ClassLoadingStrategy;
import net.bytebuddy.dynamic.scaffold.subclass.ConstructorStrategy;
import net.bytebuddy.implementation.FieldAccessor;

public class DynamicBeanBuilder {
  private DynamicBeanBuilder() {}

  public static Class<?> generateClass(String className, List<FieldInfo> fields) {
    DynamicType.Builder<?> objectBuilder =
        new ByteBuddy()
            .subclass(Object.class, ConstructorStrategy.Default.DEFAULT_CONSTRUCTOR)
            .name("com.ssnc.health.validation.dynamic." + cap(className))
            .modifiers(PUBLIC);
    Iterator<FieldInfo> iterator = fields.iterator();
    while (iterator.hasNext()) {
      FieldInfo field = iterator.next();
      TypeDefinition typeDefinition;
      if (field.isList()) {
        Class<?> subClass =
            DynamicBeanBuilder.generateClass(
                className + cap(field.getName()), field.getSubFields());
        typeDefinition = Generic.Builder.parameterizedType(List.class, subClass).build();
      } else if(field.isObject()) {
        Class<?> subClass =
            DynamicBeanBuilder.generateClass(
                className + cap(field.getName()), field.getSubFields());
        typeDefinition = new TypeDescription.ForLoadedType(subClass);
      } else if(field.getType() != null) {
        typeDefinition = new TypeDescription.ForLoadedType(field.getType());
      } else {
        typeDefinition = new TypeDescription.ForLoadedType(String.class);
      }
      objectBuilder = createField(objectBuilder, field, typeDefinition);
      objectBuilder = createGetter(objectBuilder, field, typeDefinition);
      objectBuilder = createSetter(objectBuilder, field, typeDefinition);
    }
    return
        objectBuilder
            .make()
            .load(
                Thread.currentThread().getContextClassLoader(),
                ClassLoadingStrategy.Default.INJECTION)
            .getLoaded();
  }

  static DynamicType.Builder<?> createField(
      DynamicType.Builder<?> builder, FieldInfo property, TypeDefinition typeDefinition) {
    return builder.defineField(property.getName(), typeDefinition, Visibility.PROTECTED);
  }

  static DynamicType.Builder<?> createGetter(
      DynamicType.Builder<?> builder, FieldInfo property, TypeDefinition typeDefinition) {
    final String methodName = buildGetterName(property.getName());
    return builder
        .defineMethod(methodName, typeDefinition, Visibility.PUBLIC)
        .intercept(FieldAccessor.ofBeanProperty());
  }

  static DynamicType.Builder<?> createSetter(
      DynamicType.Builder<?> builder, FieldInfo property, TypeDefinition typeDefinition) {
    return builder
        .defineMethod(buildSetterName(property.getName()), Void.TYPE, Visibility.PUBLIC)
        .withParameters(typeDefinition)
        .intercept(FieldAccessor.ofBeanProperty());
  }

  static String buildGetterName(String fieldName) {
    return cap("get", fieldName);
  }

  static String buildSetterName(String fieldName) {
    return cap("set", fieldName);
  }

  static String cap(String prefix, String name) {
    final int plen = prefix.length();
    StringBuilder sb = new StringBuilder(plen + name.length());
    sb.append(prefix);
    sb.append(name);
    sb.setCharAt(plen, Character.toUpperCase(name.charAt(0)));
    return sb.toString();
  }

  static String cap(String name) {
    return Character.toUpperCase(name.charAt(0)) + name.substring(1);
  }
}
