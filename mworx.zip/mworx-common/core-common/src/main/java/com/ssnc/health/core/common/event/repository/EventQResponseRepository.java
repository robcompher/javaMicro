/*
 * FILE : EventQResponseRepository.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.stereotype.Repository;
import com.ssnc.health.core.common.event.model.EventQResponse;

@Repository
public interface EventQResponseRepository
    extends JpaRepository<EventQResponse, Long>, JpaSpecificationExecutor<EventQResponse> {
  List<EventQResponse> findByEventQEventNameAndWebhookName(String eventName, String webhookName);
}
