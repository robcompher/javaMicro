/*
 * FILE : WebhookInitializerController.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.config;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.event.EventListener;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.dsl.IntegrationFlows;
import org.springframework.integration.dsl.context.IntegrationFlowContext;
import org.springframework.integration.endpoint.SourcePollingChannelAdapter;
import org.springframework.integration.webflux.outbound.WebFluxRequestExecutingMessageHandler;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.MessageHeaders;
import org.springframework.util.MimeType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.reactive.function.client.ExchangeFilterFunction;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import com.ssnc.health.core.common.event.model.WebhookDTO;
import com.ssnc.health.core.common.event.service.WebhookService;
import com.ssnc.health.core.common.rest.AccessTokenFilter;
import reactor.core.publisher.Mono;

/**
 * WebhookInitializerController: Initializes webhook's after server is started and exposes API to
 * refresh webhook's
 *
 * @author dt214743
 */
@RestController
@Lazy
@ConditionalOnProperty(name = "webhook.agent.enabled", havingValue = "true")
public class WebhookInitializerController {
  @Value("${webhook.agent.enabled:false}")
  private boolean enabled;

  @Value("${spring.application.name}")
  private String clientId;

  @Value("${webhook.agent.request-handler.logging.enabled:false}")
  private boolean loggingEnabled;

  @Autowired
  @Qualifier("serviceAccountTokenFilter")
  private AccessTokenFilter serviceAccountTokenFilter;

  @Autowired
  @Qualifier("webhookResponseChannel")
  private MessageChannel webhookResponseChannel;

  @Autowired
  @Qualifier("outboundWebhookEventChannel")
  private MessageChannel outboundWebhookEventChannel;

  @Autowired
  @Qualifier("webhookResponseErrorChannel")
  private MessageChannel webhookResponseErrorChannel;

  @Autowired
  @Qualifier("readEventQInboundAdaptor")
  private SourcePollingChannelAdapter readEventQInboundAdaptor;

  @Autowired
  private IntegrationFlowContext flowContext;
  @Autowired
  private WebhookService webhookService;
  @Autowired
  private Map<String, String> serviceEvents;
  @Autowired
  private WebClient.Builder webClientBuilder;

  private List<String> flowIds = new ArrayList<>();

  @EventListener(ApplicationReadyEvent.class)
  public void initializeWebhooks() {
    if (!serviceEvents.isEmpty() && enabled) {
      List<String> eventNames = new ArrayList<>();
      eventNames.addAll(serviceEvents.values());

      WebhookDTO[] webhooks = this.webhookService.getWebhooksByEventNames(eventNames);
      if (webhooks != null && webhooks.length > 0) {
        Arrays.stream(webhooks).forEach(webhook -> {
          // TODO: serviceAccountTokenFilter build based on webhook config
          WebClient webClient = webClientBuilder.filter(serviceAccountTokenFilter)
              .filter(ExchangeFilterFunction.ofResponseProcessor(response -> {
                HttpStatus httpStatus = response.statusCode();
                if (httpStatus.isError()) {
                  return response.bodyToMono(String.class).flatMap(errorBody -> {
                    return Mono.error(new WebClientResponseException(
                        String.format("ClientResponse has erroneous status code: %s %s",
                            httpStatus.value(), httpStatus.getReasonPhrase()),
                        httpStatus.value(), httpStatus.getReasonPhrase(),
                        response.headers().asHttpHeaders(), errorBody.getBytes(),
                        response.headers().contentType().map(MimeType::getCharset)
                            .orElse(StandardCharsets.ISO_8859_1)));
                  });
                } else {
                  return Mono.just(response);
                }
              })).build();

          WebFluxRequestExecutingMessageHandler reactiveHandler =
              new WebFluxRequestExecutingMessageHandler(webhook.getTargetUrl(), webClient);
          reactiveHandler.setOutputChannel(webhookResponseChannel);
          reactiveHandler.setHttpMethod(HttpMethod.POST);
          reactiveHandler.setLoggingEnabled(loggingEnabled);
          reactiveHandler.setExpectedResponseType(String.class);

          IntegrationFlow flow = IntegrationFlows.from(outboundWebhookEventChannel)
              .filter(new WebhookSelector(webhook))
              .transform(new WebhookMessageTransformer(webhook))
              .enrichHeaders(
                  e -> e.header(MessageHeaders.ERROR_CHANNEL, webhookResponseErrorChannel, true))
              .handle(reactiveHandler).get();

          String flowId = this.flowId(webhook);
          // register flow
          flowContext.registration(flow).id(flowId).register();

          flowIds.add(flowId);
        });

        // start inbound adaptor if webhook's are registered
        this.readEventQInboundAdaptor.start();
      }
    }
  }

  @GetMapping(value = "/webhooks/reload")
  public void refresh() {
    this.readEventQInboundAdaptor.stop();
    this.flowIds.forEach(id -> this.flowContext.remove(id));
    this.flowIds.clear();
    this.initializeWebhooks();
  }

  private String flowId(WebhookDTO webhook) {
    return String.format("%s.flow", webhook.getWebhookName());
  }
}
