package com.ssnc.health.core.common.event.service;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Lazy;
import org.springframework.web.reactive.function.client.WebClient;
import com.ssnc.health.core.common.event.model.WebhookDTO;
import com.ssnc.health.core.common.rest.RestApiClient;

public class WebhookServiceImpl implements WebhookService {
  @Lazy
  @Autowired(required = false)
  WebClient serviceAccountWebClient;

  @Value("${metadata.webhooks.by-event-names.url:/metadata/api/webhookRegistry/getByEventNames}")
  private String webhooksByEventNamesUrl;
  
  @Override
  public WebhookDTO[] getWebhooksByEventNames(List<String> eventNames) {
    return (WebhookDTO[])
        RestApiClient.builder()
            .webClient(serviceAccountWebClient)
            .build()
            .post(
                webhooksByEventNamesUrl,
                Map.ofEntries(Map.entry("eventNames", eventNames)),
                WebhookDTO[].class);
  }
}
