/*
 * FILE : PatternValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.internal;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

@Deprecated
public class PatternValidator implements ConstraintValidator<Pattern, Object> {
  private String regexp;

  @Override
  public void initialize(final Pattern annotation) {
    regexp = annotation.regexp();
  }
  
  @Override
  public boolean isValid(Object value, ConstraintValidatorContext context) {
    if(value != null) {
      return java.util.regex.Pattern.matches(regexp, value.toString());
    }
    return true;
  }
}
