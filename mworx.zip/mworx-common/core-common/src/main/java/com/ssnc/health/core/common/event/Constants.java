package com.ssnc.health.core.common.event;

public enum Constants {
  EVENTQ_ID,
  EVENT_NAME,
  WEBHOOK_KEY,
  WEBHOOK_NAME,
  REQUEST_PAYLOAD_KEY,
  RESPONSE_STATUS_CODE,
  STATUS;
}
