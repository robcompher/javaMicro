/*
 * FILE : RulesServiceImpl.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.repository.RulesRepository;
import com.ssnc.health.core.common.validation.service.RulesService;

@Service
public class RulesServiceImpl implements RulesService {
  @Autowired RulesRepository rulesRepository;

  @Override
  public List<ValidationRule> findRulesByRuleset(String ruleset) {
    return rulesRepository.findByRuleset(ruleset);
  }
  
  @Override
  public List<ValidationRule> findRulesByRuleset(String ruleset, Pageable pageable) {
    return rulesRepository.findByRuleset(ruleset, pageable);
  }
}
