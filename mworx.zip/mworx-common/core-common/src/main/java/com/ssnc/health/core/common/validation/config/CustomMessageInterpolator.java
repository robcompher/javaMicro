/*
 * FILE : CustomMessageInterpolator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.validation.config;

import java.util.Locale;
import javax.validation.MessageInterpolator;
import com.ssnc.health.core.common.validation.model.ValidationRule;
import com.ssnc.health.core.common.validation.validator.ValidationUtil;

/**
 * Custom MessageInterpolator to deal with ValidationRule JSON in message.
 *
 * @author DT214743
 */
public class CustomMessageInterpolator implements MessageInterpolator {
  private final MessageInterpolator defaultInterpolator;

  public CustomMessageInterpolator(MessageInterpolator interpolator) {
    this.defaultInterpolator = interpolator;
  }

  @Override
  public String interpolate(String messageTemplate, Context context) {
    return interpolateMessage(messageTemplate, context, null);
  }

  @Override
  public String interpolate(String messageTemplate, Context context, Locale locale) {
    return interpolateMessage(messageTemplate, context, locale);
  }

  private String interpolateMessage(String messageTemplate, Context context, Locale locale) {
    ValidationRule validationRule = ValidationUtil.stringToValidationRule(messageTemplate);
    String message = "";
    if (locale == null) {
      message = defaultInterpolator.interpolate(validationRule.getMessage(), context);
    } else {
      message = defaultInterpolator.interpolate(validationRule.getMessage(), context, locale);
    }
    validationRule.setMessage(message);

    return ValidationUtil.validationRuleToString(validationRule);
  }
}
