/*
 * FILE : ApiError.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2019- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.error;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import javax.validation.ConstraintViolation;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.validation.ObjectError;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import com.ssnc.health.core.common.validation.internal.Priority;
import com.ssnc.health.core.common.validation.validator.ValidationUtil;
import lombok.Data;

/** Created by dt216896 */
@Data
@JsonTypeInfo(include = JsonTypeInfo.As.WRAPPER_OBJECT, use = JsonTypeInfo.Id.NAME)
@JsonTypeName(value = "apierror")
public class ApiError implements Serializable {

  private static final long serialVersionUID = 1L;

  private HttpStatus status;

  @JsonSerialize(using = LocalDateTimeSerializer.class)
  @JsonDeserialize(using = LocalDateTimeDeserializer.class)
  private LocalDateTime timestamp;

  private String message;
  private String debugMessage;

  private List<ApiValidationError> subErrors;

  private ApiError() {
    timestamp = LocalDateTime.now();
  }

  public ApiError(HttpStatus status) {
    this();
    this.status = status;
  }

  public ApiError(HttpStatus status, Throwable ex) {
    this();
    this.status = status;
    this.message = "Unexpected error";
    this.debugMessage = ex.getLocalizedMessage();
  }

  public ApiError(HttpStatus status, String message, Throwable ex) {
    this();
    this.status = status;
    this.message = message;
    this.debugMessage = ex.getLocalizedMessage();
  }

  public HttpStatus getStatus() {
    return status;
  }

  public void setMessage(String message) {
    this.message = message;
  }

  public void setDebugMessage(String debugMessage) {
    this.debugMessage = debugMessage;
  }

  private void addSubError(ApiValidationError subError) {
    if (subErrors == null) {
      subErrors = new ArrayList<>();
    }
    subErrors.add(subError);
  }

  private void addValidationError(
      String object,
      String field,
      Object rejectedValue,
      String message,
      String hint,
      String priority) {
    addSubError(
        new ApiValidationError(object, field, rejectedValue, message, false, hint, priority));
  }

  private void addValidationError(String object, String message) {
    addSubError(new ApiValidationError(object, message));
  }

  private void addValidationError(FieldError fieldError) {
    this.addValidationError(
        fieldError.getObjectName(),
        fieldError.getField(),
        fieldError.getRejectedValue(),
        fieldError.getDefaultMessage(),
        null,
        Priority.classToString(Priority.High.class)); 
  }

  public void addValidationErrors(List<FieldError> fieldErrors) {
    fieldErrors.forEach(this::addValidationError);
  }

  public void addValidationError(ObjectError objectError) {
    this.addValidationError(objectError.getObjectName(), objectError.getDefaultMessage());
  }

  public void addValidationError(List<ObjectError> globalErrors) {
    globalErrors.forEach(this::addValidationError);
  }

  public void addValidationErrors(Set<ConstraintViolation<?>> constraintViolations) {
    if (subErrors == null) {
      subErrors = new ArrayList<>();
    }
    subErrors.addAll(ValidationUtil.toApiValidationErrors(constraintViolations));
  }
}
