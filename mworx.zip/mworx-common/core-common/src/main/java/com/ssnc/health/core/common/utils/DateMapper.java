/*
 * FILE : DateMapper.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.utils;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.ZoneId;

public class DateMapper {
  public java.util.Date asDate(LocalDate date) {
    if (date == null) {
      return null;
    }
    return java.util.Date.from(date.atStartOfDay(ZoneId.systemDefault()).toInstant());
  }

  public LocalDate asLocalDate(java.util.Date date) {
    if (date == null) {
      return null;
    }
    if (date instanceof java.sql.Date) {
      return ((java.sql.Date) date).toLocalDate();
    } else {
      return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
    }
  }

  public LocalDateTime asLocalDateTime(java.util.Date date) {
    if (date == null) {
      return null;
    }
    if (date instanceof java.sql.Timestamp) {
      return ((java.sql.Timestamp) date).toLocalDateTime();
    } else {
      return date.toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    }
  }
}
