/*
 * FILE : ServiceAccountChannelInterceptor.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.event.config;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.Message;
import org.springframework.messaging.MessageChannel;
import org.springframework.messaging.support.ChannelInterceptor;

/**
 * Interceptor to add security context to channels
 * 
 * @author dt214743
 */
public class ServiceAccountChannelInterceptor implements ChannelInterceptor {
  private static final Logger LOG = LogManager.getLogger(ServiceAccountChannelInterceptor.class);

  @Autowired private ServiceAccountContextHolder serviceAccountContext;

  @Override
  public void afterSendCompletion(Message<?> m, MessageChannel c, boolean sent, Exception ex) {
    LOG.debug("ServiceAccountChannelInterceptor::afterSendCompletion");
    serviceAccountContext.clear();
  }

  @Override
  public Message<?> preSend(Message<?> message, MessageChannel channel) {
    LOG.debug("ServiceAccountChannelInterceptor::preSend");
    serviceAccountContext.set();

    return message;
  }
}
