/*
 * FILE : RestApiClient.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.core.common.rest;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;
import lombok.Builder;

@Builder
public class RestApiClient<R, T> {
  private static final Logger LOG = LogManager.getLogger(RestApiClient.class);

  private WebClient webClient;

  public T post(String url, R request, Class<? extends T> responseClass) {
    LOG.debug("Calling Microservice {}", url);
    return webClient
        .post()
        .uri(url)
        .body(BodyInserters.fromValue(request))
        .retrieve()
        .bodyToMono(responseClass)
        .block();
  }

  public T put(String url, R request, Class<? extends T> responseClass) {
    LOG.debug("Calling Microservice {}", url);
    return webClient
        .put()
        .uri(url)
        .body(BodyInserters.fromValue(request))
        .retrieve()
        .bodyToMono(responseClass)
        .block();
  }
}
