package com.ssnc.health.core.common.event.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties(ignoreUnknown = true)
public class EventDTO {
  private Long id;
  private Long eventId;
  private String eventName;
  private String eventType;

  public String getFormattedEventName() {
    return String.format("%s_%s", eventType, eventName);
  }
}
