package com.ssnc.health.services.hibernate.tools;

import org.hibernate.tool.hbm2x.Cfg2JavaTool;
import org.hibernate.tool.hbm2x.POJOExporter;

public class CustomPOJOExporter extends POJOExporter {

	private Cfg2JavaTool c2j;

	public CustomPOJOExporter() {
		super();
		c2j = new CustomCfg2JavaTool();
	}

	@Override
	public Cfg2JavaTool getCfg2JavaTool() {
		return c2j;
	}

}
