package com.ssnc.health.services.hibernate.tools;

import org.hibernate.mapping.Set;
import org.hibernate.tool.hbm2x.visitor.JavaTypeFromValueVisitor;

public class CustomJavaTypeFromValueVisitor extends JavaTypeFromValueVisitor {
	@Override
	public Object accept(Set o) {
		return "java.util.List";
	}

}
