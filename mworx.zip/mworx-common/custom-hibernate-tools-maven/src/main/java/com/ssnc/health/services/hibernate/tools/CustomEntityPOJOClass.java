package com.ssnc.health.services.hibernate.tools;

import java.util.ArrayList;
import java.util.List;
import java.util.StringTokenizer;

import org.hibernate.boot.Metadata;
import org.hibernate.mapping.Array;
import org.hibernate.mapping.Bag;
import org.hibernate.mapping.Collection;
import org.hibernate.mapping.IdentifierBag;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.PrimitiveArray;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.Set;
import org.hibernate.tool.hbm2x.Cfg2JavaTool;
import org.hibernate.tool.hbm2x.MetaAttributeHelper;
import org.hibernate.tool.hbm2x.pojo.EntityPOJOClass;
import org.hibernate.tool.hbm2x.pojo.ImportContext;
import org.hibernate.tool.hbm2x.visitor.DefaultValueVisitor;

public class CustomEntityPOJOClass extends EntityPOJOClass {

	public CustomEntityPOJOClass(PersistentClass clazz, Cfg2JavaTool cfg) {
		super(clazz, cfg);
	}

	@Override
	public String getHibernateCascadeTypeAnnotation(Property property) {
		return "";
	}

	@Override
	public String[] getCascadeTypes(Property property) {
		StringTokenizer st = new StringTokenizer(property.getCascade(), ", ", false);
		List<String> types = new ArrayList<String>();
		while (st.hasMoreElements()) {
			String element = ((String) st.nextElement()).toLowerCase();
			if ("persist".equals(element)) {
				types.add(importType("javax.persistence.CascadeType") + ".PERSIST");
			} else if ("merge".equals(element)) {
				types.add(importType("javax.persistence.CascadeType") + ".MERGE");
			} else if ("delete".equals(element) || "delete-orphan".equals(element)) {
				types.add(importType("javax.persistence.CascadeType") + ".REMOVE");
			} else if ("refresh".equals(element)) {
				types.add(importType("javax.persistence.CascadeType") + ".REFRESH");
			} else if ("all".equals(element) || "all-delete-orphan".equals(element)) {
				types.add(importType("javax.persistence.CascadeType") + ".ALL");
			}
		}
		return (String[]) types.toArray(new String[types.size()]);
	}

	@Override
	public String generateCollectionAnnotation(Property property, Metadata md) {
		super.generateCollectionAnnotation(property, md);
		StringBuilder sb = new StringBuilder(super.generateCollectionAnnotation(property, md));
		StringTokenizer st = new StringTokenizer(property.getCascade(), ", ", false);
		String cascade = null;
		while (st.hasMoreElements()) {
			String element = ((String) st.nextElement()).toLowerCase();
			if ("all-delete-orphan".equals(element) || "delete-orphan".equals(element)) {
				cascade = ", orphanRemoval = true";
			}
		}
		if (cascade != null) {
			sb.insert(sb.length() - 1, cascade);
		}
		return sb.toString();
	}

	@Override
	public String getFieldInitialization(Property p, boolean useGenerics) {
		if (hasMetaAttribute(p, "default-value")) {
			return MetaAttributeHelper.getMetaAsString(p.getMetaAttribute("default-value"));
		}
		if (c2j.getJavaTypeName(p, false) == null) {
			throw new IllegalArgumentException();
		} else if (p.getValue() instanceof Collection) {
			Collection col = (Collection) p.getValue();

			DefaultInitializor initialization = (DefaultInitializor) col.accept(new DefaultValueVisitor(true) {

				public Object accept(Bag o) {
					return new DefaultInitializor("java.util.ArrayList", true);
				}

				public Object accept(org.hibernate.mapping.List o) {
					return new DefaultInitializor("java.util.ArrayList", true);
				}

				public Object accept(org.hibernate.mapping.Map o) {
					if (o.isSorted()) {
						return new DefaultInitializor("java.util.TreeMap", false);
					} else {
						return new DefaultInitializor("java.util.HashMap", true);
					}
				}

				public Object accept(IdentifierBag o) {
					return new DefaultInitializor("java.util.ArrayList", true);
				}

				public Object accept(Set o) {
					return new DefaultInitializor("java.util.ArrayList", true);
				}

				public Object accept(PrimitiveArray o) {
					return null; // TODO: default init for arrays ?
				}

				public Object accept(Array o) {
					return null;// TODO: default init for arrays ?
				}

			});

			if (initialization != null) {
				String comparator = null;
				String decl = null;

				if (col.isSorted()) {
					comparator = col.getComparatorClassName();
				}

				if (useGenerics) {
					// decl = c2j.getGenericCollectionDeclaration((Collection) p.getValue(), true,
					// importContext);
					decl = "<>";
				}
				return initialization.getDefaultValue(comparator, decl, this);
			} else {
				return null;
			}
		} else {
			return null;
		}
	}

	private static class DefaultInitializor {

		private final String type;
		private final boolean initToZero;

		public DefaultInitializor(String type, boolean initToZero) {
			this.type = type;
			this.initToZero = initToZero;
		}

		public String getDefaultValue(String comparator, String genericDeclaration, ImportContext importContext) {
			StringBuilder val = new StringBuilder("new " + importContext.importType(type));
			if (genericDeclaration != null) {
				val.append(genericDeclaration);
			}

			val.append("(");
			if (comparator != null) {
				val.append("new ");
				val.append(importContext.importType(comparator));
				val.append("()");
				if (initToZero)
					val.append(",");
			}
			if (initToZero) {
				val.append("0");
			}
			val.append(")");
			return val.toString();
		}

	}

}