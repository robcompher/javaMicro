/*
 * FILE : CustomGenerateJavaMojo.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2019- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.services.hibernate.tools;

import static org.apache.maven.plugins.annotations.LifecyclePhase.GENERATE_SOURCES;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import org.apache.maven.plugin.AbstractMojo;
import org.apache.maven.plugins.annotations.Mojo;
import org.apache.maven.plugins.annotations.Parameter;
import org.apache.tools.ant.BuildException;
import org.hibernate.cfg.reveng.OverrideRepository;
import org.hibernate.cfg.reveng.ReverseEngineeringSettings;
import org.hibernate.cfg.reveng.ReverseEngineeringStrategy;
import org.hibernate.tool.api.metadata.MetadataDescriptor;
import org.hibernate.tool.api.metadata.MetadataDescriptorFactory;
import org.hibernate.tool.hbm2x.POJOExporter;

/**
 * Custom class to override hbm2java class with our defaults, custom strategy
 * and custom templates.
 * 
 * @author DT216896
 *
 */
@Mojo(name = "hbm2java", defaultPhase = GENERATE_SOURCES)
public class CustomGenerateJavaMojo extends AbstractMojo {

	/**
	 * The class name of the reverse engineering strategy to use. Extend the
	 * DefaultReverseEngineeringStrategy and override the corresponding methods,
	 * e.g. to adapt the generate class names or to provide custom type mappings.
	 */
	// @Parameter(defaultValue =
	// "com.ssnc.health.services.hibernate.tools.CustomStrategy")
	@Parameter(defaultValue = "org.hibernate.cfg.reveng.DefaultReverseEngineeringStrategy")
	private String revengStrategy;

	/** The directory into which the JPA entities will be generated. */
	@Parameter(defaultValue = "${project.build.directory}/generated-sources/db")
	private File outputDirectory;

	/**
	 * Code will contain EJB 3 features, e.g. using annotations from
	 * javax.persistence and org.hibernate.annotations.
	 */
	@Parameter(defaultValue = "true")
	private boolean ejb3;

	/** Code will contain JDK 5 constructs such as generics and static imports. */
	@Parameter(defaultValue = "true")
	private boolean jdk5;

	/** A path used for looking up user-edited templates. */
	@Parameter
	private String templatePath;

	// For reveng strategy
	/** The default package name to use when mappings for classes are created. */
	@Parameter
	private String packageName;

	/** The name of a property file, e.g. hibernate.properties. */
	@Parameter
	private File revengFile;

	/**
	 * If true, tables which are pure many-to-many link tables will be mapped as
	 * such. A pure many-to-many table is one which primary-key contains exactly two
	 * foreign-keys pointing to other entity tables and has no other columns.
	 */
	@Parameter(defaultValue = "true")
	private boolean detectManyToMany;

	/**
	 * If true, a one-to-one association will be created for each foreignkey found.
	 */
	@Parameter(defaultValue = "true")
	private boolean detectOneToOne;

	/**
	 * If true, columns named VERSION or TIMESTAMP with appropriate types will be
	 * mapped with the appropriate optimistic locking corresponding to
	 * &lt;version&gt; or &lt;timestamp&gt;.
	 */
	@Parameter(defaultValue = "true")
	private boolean detectOptimisticLock;

	/** If true, a collection will be mapped for each foreignkey. */
	@Parameter(defaultValue = "true")
	private boolean createCollectionForForeignKey;

	/**
	 * If true, a many-to-one association will be created for each foreignkey found.
	 */
	@Parameter(defaultValue = "true")
	private boolean createManyToOneForForeignKey;

	// For configuration
	/** The name of a property file, e.g. hibernate.properties. */
	@Parameter(defaultValue = "${project.basedir}/src/main/resources/hibernate.properties")
	private File propertyFile;

	// Not exposed for now
	private boolean preferBasicCompositeIds = true;

	public void execute() {
		getLog().info("Starting " + this.getClass().getSimpleName() + "...");
		ReverseEngineeringStrategy strategy = setupReverseEngineeringStrategy();
		if (propertyFile.exists()) {
			executeExporter(createJdbcDescriptor(strategy, loadPropertiesFile()));
		} else {
			getLog().info("Property file '" + propertyFile + "' cannot be found, aborting...");
		}
		getLog().info("Finished " + this.getClass().getSimpleName() + "!");
	}

	private ReverseEngineeringStrategy setupReverseEngineeringStrategy() {
		ReverseEngineeringStrategy strategy;
		try {
			strategy = ReverseEngineeringStrategy.class.cast(Class.forName(revengStrategy).newInstance());
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException | ClassCastException e) {
			throw new BuildException(revengStrategy + " not instanced.", e);
		}

		if (revengFile != null) {
			OverrideRepository override = new OverrideRepository();
			override.addFile(revengFile);
			strategy = override.getReverseEngineeringStrategy(strategy);
		}
		strategy = new CustomStrategy(strategy);

		ReverseEngineeringSettings settings = new ReverseEngineeringSettings(strategy)
				.setDefaultPackageName(packageName).setDetectManyToMany(detectManyToMany)
				.setDetectOneToOne(detectOneToOne).setDetectOptimisticLock(detectOptimisticLock)
				.setCreateCollectionForForeignKey(createCollectionForForeignKey)
				.setCreateManyToOneForForeignKey(createManyToOneForForeignKey);

		strategy.setSettings(settings);
		return strategy;
	}

	private Properties loadPropertiesFile() {
		try (FileInputStream is = new FileInputStream(propertyFile)) {
			Properties result = new Properties();
			result.load(is);
			return result;
		} catch (FileNotFoundException e) {
			throw new BuildException(propertyFile + " not found.", e);
		} catch (IOException e) {
			throw new BuildException("Problem while loading " + propertyFile, e);
		}
	}

	private MetadataDescriptor createJdbcDescriptor(ReverseEngineeringStrategy strategy, Properties properties) {
		return MetadataDescriptorFactory.createJdbcDescriptor(strategy, properties, preferBasicCompositeIds);
	}

	protected void executeExporter(MetadataDescriptor metadataDescriptor) {
		POJOExporter pojoExporter = new CustomPOJOExporter();
		pojoExporter.setMetadataDescriptor(metadataDescriptor);
		pojoExporter.setOutputDirectory(outputDirectory);
		if (templatePath != null) {
			getLog().info("Setting template path to: " + templatePath);
			pojoExporter.setTemplatePath(new String[] { templatePath });
		}
		pojoExporter.getProperties().setProperty("ejb3", String.valueOf(ejb3));
		pojoExporter.getProperties().setProperty("jdk5", String.valueOf(jdk5));
		getLog().info("Starting POJO export to directory: " + outputDirectory + "...");
		pojoExporter.start();
	}

}
