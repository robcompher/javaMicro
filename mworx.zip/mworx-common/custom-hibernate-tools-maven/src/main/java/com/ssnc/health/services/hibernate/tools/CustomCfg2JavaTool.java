package com.ssnc.health.services.hibernate.tools;

import org.hibernate.internal.util.StringHelper;
import org.hibernate.mapping.Array;
import org.hibernate.mapping.Collection;
import org.hibernate.mapping.Component;
import org.hibernate.mapping.PersistentClass;
import org.hibernate.mapping.Property;
import org.hibernate.mapping.SimpleValue;
import org.hibernate.mapping.Value;
import org.hibernate.tool.hbm2x.Cfg2JavaTool;
import org.hibernate.tool.hbm2x.ExporterException;
import org.hibernate.tool.hbm2x.pojo.ImportContext;
import org.hibernate.tool.hbm2x.pojo.POJOClass;

public class CustomCfg2JavaTool extends Cfg2JavaTool {

	public POJOClass getPOJOClass(PersistentClass comp) {
		return new CustomEntityPOJOClass(comp, this);
	}

	public String getJavaTypeName(Property p, boolean useGenerics, ImportContext importContext) {
		String overrideType = getMetaAsString(p, "property-type");
		if (!StringHelper.isEmpty(overrideType)) {
			String importType = importContext.importType(overrideType);
			if (useGenerics && importType.indexOf("<") < 0) {
				if (p.getValue() instanceof Collection) {
					String decl = getGenericCollectionDeclaration((Collection) p.getValue(), true, importContext);
					return importType + decl;
				}
			}
			return importType;
		} else {
			String rawType = getRawTypeName(p, useGenerics, true, importContext);
			if (rawType == null) {
				throw new IllegalStateException("getJavaTypeName *must* return a value");
			}
			return importContext.importType(rawType);
		}
	}

	private String getRawTypeName(Property p, boolean useGenerics, boolean preferRawTypeNames,
			ImportContext importContext) {
		Value value = p.getValue();
		try {

			if (value instanceof Array) { // array has a string rep.inside.
				Array a = (Array) value;

				if (a.isPrimitiveArray()) {
					return toName(value.getType().getReturnedClass());
				} else if (a.getElementClassName() != null) {
					return a.getElementClassName() + "[]";
				} else {
					return getJavaTypeName(a.getElement(), preferRawTypeNames) + "[]";
				}
			}

			if (value instanceof Component) { // same for component.
				Component component = ((Component) value);
				if (component.isDynamic())
					return "java.util.Map";
				return component.getComponentClassName();
			}

			if (useGenerics) {
				if (value instanceof Collection) {
					String decl = getGenericCollectionDeclaration((Collection) value, preferRawTypeNames,
							importContext);
					return getJavaTypeName(value, preferRawTypeNames) + decl;
				}
			}

			return getJavaTypeName(value, preferRawTypeNames);
		} catch (Exception e) {
			// e.printStackTrace();
			String msg = "Could not resolve type without exception for " + p + " Value: " + value;
			if (value != null && value.isSimpleValue()) {
				String typename = ((SimpleValue) value).getTypeName();
				return typename;
			} else {
				throw new ExporterException(msg, e);
			}
		}
	}

	public String toName(Class<?> c) {

		if (c.isArray()) {
			Class<?> a = c.getComponentType();

			return a.getName() + "[]";
		} else {
			return c.getName();
		}
	}

	private String getJavaTypeName(Value value, boolean preferRawTypeNames) {
		return (String) value.accept(new CustomJavaTypeFromValueVisitor());
	}

}
