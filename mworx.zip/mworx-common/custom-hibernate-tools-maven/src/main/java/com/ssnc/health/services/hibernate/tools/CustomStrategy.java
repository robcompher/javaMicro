/*
 * FILE : CustomStrategy.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.services.hibernate.tools;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.cfg.reveng.DefaultReverseEngineeringStrategy;
import org.hibernate.cfg.reveng.DelegatingReverseEngineeringStrategy;
import org.hibernate.cfg.reveng.ReverseEngineeringSettings;
import org.hibernate.cfg.reveng.ReverseEngineeringStrategy;
import org.hibernate.cfg.reveng.TableIdentifier;
import org.hibernate.mapping.MetaAttribute;

/**
 * Hibernate Reverse Engineering Custom Strategy class. This class will do the
 * following. 1. extends If extends not configured in reveng file then default
 * extends class is added. If specified, then specified class is extended. If
 * specified an empty one then none will be added 2. If extends applied then
 * default audit columns "created", "createby", "updated", "updateby" are
 * ignored. 3. If rename attribute configured for table then custom table name
 * logic will be applied
 * 
 * @author DT216896
 *
 */
public class CustomStrategy extends DelegatingReverseEngineeringStrategy {

	List<String> auditColumnsList = Arrays.asList("created", "createby", "updated", "updateby");

	private static final String EXTENDS = "extends";
	private static final String AUDITABLE_CLASS = "com.ssnc.health.core.common.model.Auditable<Long>";

	public CustomStrategy(ReverseEngineeringStrategy delegate) {
		super(delegate);
	}

	public CustomStrategy() {
		this(new DefaultReverseEngineeringStrategy());
	}

	private ReverseEngineeringSettings settings = new ReverseEngineeringSettings(this);

	@Override
	public void setSettings(ReverseEngineeringSettings settings) {
		this.settings = settings;
		super.setSettings(settings);
	}

	@Override
	public Map<String, MetaAttribute> tableToMetaAttributes(TableIdentifier tableIdentifier) {
		Map<String, MetaAttribute> theMetaAttributes = super.tableToMetaAttributes(tableIdentifier);
		if (theMetaAttributes == null) {
			theMetaAttributes = new HashMap<>();
		} else {
			MetaAttribute isAuditable = theMetaAttributes.get("isAuditable");
			if (isAuditable != null) {
				String isAuditableValue = isAuditable.getValue();
				if (!isAuditableValue.isBlank() && isAuditableValue.equalsIgnoreCase("false")) {
					return theMetaAttributes;
				} else if (isAuditableValue.equalsIgnoreCase("true")) {
					MetaAttribute extendsAttribute = theMetaAttributes.get(EXTENDS);
					if (extendsAttribute != null) {
						return theMetaAttributes;
					}
				}
			}
		}
		MetaAttribute theMetaAttribute = new MetaAttribute(EXTENDS);
		theMetaAttribute.addValue(AUDITABLE_CLASS);
		theMetaAttributes.put(theMetaAttribute.getName(), theMetaAttribute);
		return theMetaAttributes;
	}

	@Override
	public String tableToClassName(TableIdentifier tableIdentifier) {
		Map<String, MetaAttribute> tableMetaAttributes = settings.getRootStrategy()
				.tableToMetaAttributes(tableIdentifier);
		String className = super.tableToClassName(tableIdentifier);
		if (tableMetaAttributes != null) {
			String[] classSplit = className.split("\\.");
			String finalClassName = classSplit[classSplit.length - 1];
			MetaAttribute tableFilterAttrib = tableMetaAttributes.get("tableRename");
			if (tableFilterAttrib != null) {
				String attribValue = tableFilterAttrib.getValue();
				String[] toBeReplacedString = attribValue.split(":");
				if (finalClassName.contains(toBeReplacedString[0])) {
					if (toBeReplacedString.length == 1) {
						finalClassName = className.replace(toBeReplacedString[0], "");
					} else {
						finalClassName = className.replace(toBeReplacedString[0], toBeReplacedString[1]);
					}
					finalClassName = className.replace(toBeReplacedString[0], toBeReplacedString[1]);
					return finalClassName;
				}
			}
		}
		return className;
	}

	@Override
	public boolean excludeColumn(TableIdentifier table, String columnName) {
		Map<String, MetaAttribute> tableMetaAttributes = settings.getRootStrategy().tableToMetaAttributes(table);
		if (tableMetaAttributes.containsKey(EXTENDS) && !tableMetaAttributes.get(EXTENDS).getValue().isBlank()) {
			if (auditColumnsList.contains(columnName.toLowerCase())) {
				return true;
			}
		}
		return super.excludeColumn(table, columnName);
	}

	@Override
	public String columnToPropertyName(TableIdentifier table, String column) {
		if (column.equals("createby")) {
			return "createBy";
		} else if (column.equals("updateby")) {
			return "updateBy";
		} else {
			return super.columnToPropertyName(table, column);
		}
	}

}
