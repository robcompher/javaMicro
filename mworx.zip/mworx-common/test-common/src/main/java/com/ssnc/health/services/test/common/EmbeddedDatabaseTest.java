package com.ssnc.health.services.test.common;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.core.annotation.AliasFor;
import org.springframework.test.annotation.Rollback;
import org.springframework.transaction.annotation.Transactional;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase.DatabaseProvider;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase.EmbeddedDatabaseType;
import io.zonky.test.db.AutoConfigureEmbeddedDatabase.Replace;

@Documented
@Inherited
@Target(ElementType.TYPE)
@Retention(RetentionPolicy.RUNTIME)
@SpringBootTest
@Transactional
@Rollback
@AutoConfigureEmbeddedDatabase
public @interface EmbeddedDatabaseTest {

  @AliasFor(annotation = SpringBootTest.class)
  String[] value() default {
    "spring.profiles.active=test",
    "zonky.test.database.postgres.client.properties.currentSchema=public",
    "spring.liquibase.default-schema=public",
    "spring.liquibase.liquibase-schema=public",
    "spring.liquibase.enabled=true",
    "spring.flyway.enabled=false"
  };

  @AliasFor(annotation = SpringBootTest.class)
  String[] properties() default {
    "spring.profiles.active=test",
    "zonky.test.database.postgres.client.properties.currentSchema=public",
    "spring.liquibase.default-schema=public",
    "spring.liquibase.liquibase-schema=public",
    "spring.liquibase.enabled=true",
    "spring.flyway.enabled=false"
  };

  @AliasFor(annotation = SpringBootTest.class)
  String[] args() default {};

  @AliasFor(annotation = SpringBootTest.class)
  Class<?>[] classes() default {};

  @AliasFor(annotation = SpringBootTest.class)
  WebEnvironment webEnvironment() default WebEnvironment.MOCK;

  @AliasFor(annotation = AutoConfigureEmbeddedDatabase.class)
  String beanName() default "";

  @AliasFor(annotation = AutoConfigureEmbeddedDatabase.class)
  Replace replace() default Replace.ANY;

  @AliasFor(annotation = AutoConfigureEmbeddedDatabase.class)
  EmbeddedDatabaseType type() default EmbeddedDatabaseType.POSTGRES;

  @AliasFor(annotation = AutoConfigureEmbeddedDatabase.class)
  DatabaseProvider provider() default DatabaseProvider.DEFAULT;
}
