package com.ssnc.health.services.swagger.codegen;

import java.net.URL;
import java.util.Map;
import java.util.Set;
import io.swagger.codegen.v3.CodegenConstants;
import io.swagger.codegen.v3.CodegenParameter;
import io.swagger.codegen.v3.generators.java.SpringCodegen;
import io.swagger.codegen.v3.utils.URLPathUtil;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.media.Schema;
import io.swagger.v3.oas.models.parameters.Parameter;
import io.swagger.v3.oas.models.parameters.RequestBody;

/**
 * Override SpringCodegen to generate OAS3 annotations along with custom annotation @ValidRuleset.
 * 
 * Some of the code can be removed once default SpringCodegen generates OAS3 annotations.
 * 
 * @author DT214743
 *
 */
public class OAS3SpringCodegen extends SpringCodegen {

  /**
   * Override to set useOas2 to false and import Schema
   */
  @Override
  public void processOpts() {
    super.processOpts();
    setUseOas2(false);
    additionalProperties.put(CodegenConstants.USE_OAS2, false);
    // add schema
    importMapping.put("Schema", "io.swagger.v3.oas.annotations.media.Schema");
  }

  /**
   * Override to pass vendor extensions in schema to pass on to handlebars templates
   */
  @SuppressWarnings("rawtypes")
  @Override
  public CodegenParameter fromRequestBody(
      RequestBody body,
      String name,
      Schema schema,
      Map<String, Schema> schemas,
      Set<String> imports) {
    CodegenParameter codegenParameter = super.fromRequestBody(body, name, schema, schemas, imports);
    if (body.getExtensions() != null && !body.getExtensions().isEmpty()) {
      codegenParameter.vendorExtensions.putAll(body.getExtensions());
    }
    return codegenParameter;
  }

  /**
   * Override to pass vendor extensions in schema to pass on to handlebars templates
   */
  public CodegenParameter fromParameter(Parameter parameter, Set<String> imports) {
    CodegenParameter codegenParameter = super.fromParameter(parameter, imports);
    if (parameter.getExtensions() != null && !parameter.getExtensions().isEmpty()) {
      codegenParameter.vendorExtensions.putAll(parameter.getExtensions());
    }
    return codegenParameter;
  }
  
  @Override
  public void preprocessOpenAPI(OpenAPI openAPI) {
    super.preprocessOpenAPI(openAPI);
    final URL urlInfo = URLPathUtil.getServerURL(openAPI);
    if (urlInfo != null && urlInfo.getPath() != null) {
      this.additionalProperties.put("apiBasePath", urlInfo.getPath());
    }
    this.additionalProperties.put("openapiSpecVersion", openAPI.getOpenapi());
  }
  
  

  @Override
  public String getDefaultTemplateDir() {
    return "v3templates";
  }
}
