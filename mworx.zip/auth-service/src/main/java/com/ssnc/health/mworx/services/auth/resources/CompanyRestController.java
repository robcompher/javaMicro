/*
 * FILE : CompanyRestController.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.resources;

import com.ssnc.health.core.common.model.Pagination;
import com.ssnc.health.mworx.services.auth.api.CompanyApi;
import com.ssnc.health.mworx.services.auth.api.model.Company;
import com.ssnc.health.mworx.services.auth.mappers.CompanyMapper;
import com.ssnc.health.mworx.services.auth.model.SecCompany;
import com.ssnc.health.mworx.services.auth.service.CompanyService;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@RestController
public class CompanyRestController implements CompanyApi {

  private CompanyMapper mapper = Mappers.getMapper(CompanyMapper.class);

  @Autowired CompanyService companyService;

  HashMap<Integer, Company> companies = new HashMap<>();

  @Override
  public ResponseEntity<List<Company>> getCompanyList(@RequestBody Pagination pagination) {

    return ResponseEntity.ok(new ArrayList<>(companies.values()));
  }

  @Override
  public ResponseEntity<Company> deleteCompany(@RequestBody Object body) {
    return ResponseEntity.ok(companies.get(body));
  }

  @Override
  public ResponseEntity<Company> addCompany(@RequestBody Company company) {
    SecCompany secCompany = mapper.modelToDomain(company);
    secCompany = companyService.addCompany(secCompany);
    return ResponseEntity.ok(mapper.domainToModel(secCompany));
  }

  @Override
  public ResponseEntity<Object> updateCompany(@RequestBody Company company) {
    SecCompany secCompany = mapper.modelToDomain(company);
    secCompany = companyService.updateCompany(secCompany);
    return ResponseEntity.ok(mapper.domainToModel(secCompany));
  }
}
