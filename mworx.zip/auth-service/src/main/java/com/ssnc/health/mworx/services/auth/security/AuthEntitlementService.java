/*
 * FILE : AuthEntitlementService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.security;

import com.ssnc.health.core.common.security.EntitlementService;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.api.model.Permit;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import com.ssnc.health.mworx.services.auth.service.RoleService;
import java.util.List;
import java.util.Optional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.reactive.function.client.WebClientResponseException;

/**
 * Custom implementation of EntitlementService to validate LOB information in Role and permit
 *
 * @author dt209421
 */
public class AuthEntitlementService extends EntitlementService {

  @Autowired RoleService roleService;
  @Autowired MetadataService metadataService;
  private static final Logger LOG = LoggerFactory.getLogger(AuthEntitlementService.class);

  public final boolean hasLobAccess(List<Permit> permits) {
    boolean valid = true;
    if (Optional.ofNullable(permits).isPresent()) {
      for (Permit permit : permits) {
        try {
          permit.getLob().setLobId(metadataService.getLOBId(permit.getLob()));
          valid = permit.getLob().getLobId() != null ? hasLobAccess(permit.getLob()) : false;
        } catch (NullPointerException | WebClientResponseException e) {
          LOG.debug(e.getMessage(), e);
          return false;
        }
        if (!valid) break;
      }
    }
    return valid;
  }

  public final boolean hasLobAccess(Long linkId) {
    boolean valid = true;
    if (linkId != null) {
      RoleLobPermit permit = roleService.findRoleLobPermit(linkId);
      if (Optional.ofNullable(permit).isPresent())
        valid = validateLobInfo(permit.getLobId(), null, null, null);
    }
    return valid;
  }

  public final boolean hasLobAccess(LOB lob, boolean existing) {
    if (!existing && lob == null) return false;
    else if (existing && lob == null) return true;
    else {
      try {
        lob.setLobId(metadataService.getLOBId(lob));
        if (lob.getLobId() != null) return hasLobAccess(lob);
        else return false;
      } catch (NullPointerException | WebClientResponseException e) {
        LOG.debug(e.getMessage(), e);
        return false;
      }
    }
  }
}
