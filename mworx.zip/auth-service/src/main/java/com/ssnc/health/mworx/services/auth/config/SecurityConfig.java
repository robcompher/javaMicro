/*
FILE : SecurityConfig.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.config;

import com.nimbusds.jose.shaded.json.JSONArray;
import com.ssnc.health.core.common.security.EntitlementService;
import com.ssnc.health.mworx.services.auth.security.AuthEntitlementService;
import com.ssnc.health.mworx.services.auth.security.CustomUserDetailsService;
import java.util.ArrayList;
import java.util.List;
import org.springframework.context.annotation.Bean;
import org.springframework.core.convert.converter.Converter;
import org.springframework.security.authentication.AbstractAuthenticationToken;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.BeanIds;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.factory.PasswordEncoderFactories;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationConverter;
import org.springframework.security.oauth2.server.resource.authentication.JwtGrantedAuthoritiesConverter;

/** Created by DT214743 on 1/14/2020. */
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled = true, proxyTargetClass = true)
public class SecurityConfig extends WebSecurityConfigurerAdapter {

  @Override
  protected void configure(HttpSecurity http) throws Exception {
    http.antMatcher("/api/**")
        .oauth2ResourceServer()
        .jwt()
        .jwtAuthenticationConverter(getJwtAuthenticationConverter());

    http.antMatcher("/**")
        .authorizeRequests()
        .antMatchers(
            "/oauth/authorize**",
            "/login**",
            "/error**",
            "/oauth/keys",
            "/oauth/logout",
            "/resources/**",
            "/actuator/**")
        .permitAll()
        .antMatchers(
            "/v3/api-docs/**",
            "/swagger-resources/**",
            "/swagger-ui/**",
            "/swagger-ui**",
            "/configuration/**",
            "/webjars/**",
            "favicon.ico")
        .permitAll()
        .and()
        .authorizeRequests()
        .anyRequest()
        .authenticated()
        .and()
        .formLogin()
        .loginPage("/login")
        .usernameParameter("username")
        .permitAll()
        .and()
        .csrf()
        .disable();
  }

  Converter<Jwt, AbstractAuthenticationToken> getJwtAuthenticationConverter() {
    JwtAuthenticationConverter converter = new JwtAuthenticationConverter();

    converter.setJwtGrantedAuthoritiesConverter(
        jwt -> {
          // get app authorities
          List<GrantedAuthority> authorities = new ArrayList<>();
          JSONArray jsonArray = (JSONArray) jwt.getClaims().get("authorities");
          jsonArray.forEach(node -> authorities.add(new SimpleGrantedAuthority(node.toString())));
          // add scope authorities
          authorities.addAll(new JwtGrantedAuthoritiesConverter().convert(jwt));

          return authorities;
        });
    return converter;
  }

  @Bean
  public UserDetailsService users() {
    return new CustomUserDetailsService();
  }

  @Bean
  public PasswordEncoder passwordEncoder() {
    return PasswordEncoderFactories.createDelegatingPasswordEncoder();
  }

  @Bean(name = BeanIds.AUTHENTICATION_MANAGER)
  @Override
  public AuthenticationManager authenticationManagerBean() throws Exception {
    return super.authenticationManagerBean();
  }

  @Bean
  public EntitlementService entitlementService() {
    return new AuthEntitlementService();
  }
}
