/*
 * FILE : WebClientConfiguration.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.config;

import com.ssnc.health.core.common.rest.WebClientFilters;
import org.springframework.cloud.client.loadbalancer.reactive.LoadBalancedExchangeFilterFunction;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.reactive.function.client.WebClient;

/** Created by dt216896. */
@Configuration
public class WebClientConfiguration {

  @Bean
  public WebClient webClient(
      WebClient.Builder webClientBuilder, LoadBalancedExchangeFilterFunction lbFunction) {
    return webClientBuilder
        .filter(lbFunction)
        .filter(WebClientFilters.tokenRelayFilterFunction())
        .build();
  }
}
