/*
FILE : RoleLobPermitSpecification.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.query.specification;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.jpa.domain.Specification;

/**
 * RoleLobPermit Specification class to get the criteria builder based on input parameters.
 * Dynamically constructs query based on input and creates a specification.
 *
 * @author dt204819
 */
public class RoleLobPermitSpecification {

  private static final String SEC_ROLE = "secRole";
  private static final String SEC_PERMIT = "secPermit";

  private RoleLobPermitSpecification() {}

  public static Specification<RoleLobPermit> get(SummaryPermitSearchCriteria permitSearch) {
    return (Root<RoleLobPermit> root, CriteriaQuery<?> query, CriteriaBuilder builder) -> {
      List<Predicate> predicates = new ArrayList<>();

      if (Objects.nonNull(permitSearch)) {
        predicates.add(builder.and(builder.equal(root.get("active"), "Y")));
      }

      if (Objects.nonNull(permitSearch.roleId)) {

        predicates.add(
            builder.and(builder.equal(root.get(SEC_ROLE).get("roleId"), permitSearch.getRoleId())));
      }
      if (Objects.nonNull(permitSearch.getLob())
          && Objects.nonNull(permitSearch.getLob().getLobId())) {

        predicates.add(
            builder.and(builder.equal(root.get("lobId"), permitSearch.getLob().getLobId())));
      }

      Join<Object, Object> secPermitJoin = null;

      if ((StringUtils.isNotEmpty(permitSearch.primaryPermit))
          || (StringUtils.isNotEmpty(permitSearch.secondaryPermit))) {

        secPermitJoin = root.join(SEC_PERMIT);
        predicates.add(builder.and(builder.equal(secPermitJoin.get("active"), "Y")));
      }

      if (StringUtils.isNotEmpty(permitSearch.getPrimaryPermit())) {

        predicates.add(
            builder.and(
                builder.like(
                    builder.lower(secPermitJoin.get("permitPrimary")),
                    permitSearch.getPrimaryPermit().toLowerCase() + "%")));
      }

      if (StringUtils.isNotEmpty(permitSearch.getSecondaryPermit())) {

        predicates.add(
            builder.and(
                builder.like(
                    builder.lower(secPermitJoin.get("permitSecondary")),
                    permitSearch.getSecondaryPermit().toLowerCase() + "%")));
      }
      query.distinct(true);
      Predicate[] predicatesArray = new Predicate[predicates.size()];
      return builder.and(predicates.toArray(predicatesArray));
    };
  }
}
