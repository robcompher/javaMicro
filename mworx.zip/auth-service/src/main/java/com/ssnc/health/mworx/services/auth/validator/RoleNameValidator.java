/*
 * FILE : RoleNameValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.Role;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import java.util.Optional;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

public class RoleNameValidator implements ConstraintValidator<ValidRuleset, Role> {
  @Autowired private SecRoleRepository roleRepository;

  @Override
  public boolean isValid(Role role, ConstraintValidatorContext context) {
    // Show the validation message if role name is modified.
    // if role Id is null or not passed then return true  other checks will be checking if role name
    // is in the system
    if (role.getRoleId() == null) {
      return true;
    }
    Optional<SecRole> secRole = roleRepository.findById(role.getRoleId());
    if (secRole.isPresent()) {
      return StringUtils.equalsIgnoreCase(secRole.get().getRoleName(), role.getRoleName());
    }
    return true;
  }
}
