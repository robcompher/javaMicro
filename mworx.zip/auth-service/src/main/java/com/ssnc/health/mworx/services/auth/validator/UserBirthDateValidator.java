/*
 * FILE : UserBirthDateValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import java.time.LocalDate;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UserBirthDateValidator implements ConstraintValidator<ValidRuleset, UserRequest> {

  @Override
  public boolean isValid(UserRequest userRequest, ConstraintValidatorContext context) {
    return userRequest.getBirthDate() != null
        ? (userRequest.getBirthDate().isBefore(LocalDate.now())
            || userRequest.getBirthDate().isEqual(LocalDate.now()))
        : true;
  }
}
