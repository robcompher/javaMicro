/*
 * FILE : ContactTypeValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.UserContactRequest;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.reactive.function.client.WebClientResponseException;

/**
 * Validating the contact type exists in metadata.
 *
 * @author dt64028
 */
public class ContactTypeValidator implements ConstraintValidator<ValidRuleset, UserContactRequest> {
  @Value("${metadata.category.contactType}")
  String metaContactType;

  @Autowired private MetadataService metadataService;

  @Override
  public boolean isValid(
      UserContactRequest userContactRequest, ConstraintValidatorContext context) {
    if (userContactRequest.getUserContact() == null
        || userContactRequest.getUserContact().getContactType() == null) {
      return true;
    }
    try {
      return metadataService
          .getListById(userContactRequest.getUserContact().getContactType())
          .get("category")
          .toString()
          .equalsIgnoreCase(metaContactType);
    } catch (WebClientResponseException e) {
      return false;
    }
  }
}
