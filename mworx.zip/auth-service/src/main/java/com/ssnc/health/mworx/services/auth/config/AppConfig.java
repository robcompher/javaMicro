/*
FILE : AppConfig.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;

/** Created by DT214743 on 1/2/2020. */
@Configuration
@ComponentScan(
    basePackages = {
      "com.ssnc.health.core.common.error",
      "com.ssnc.health.core.common.rest",
      "com.ssnc.health.core.common.validation",
      "com.ssnc.health.core.common.security",
      "com.ssnc.health.services.devtool",
      "com.ssnc.health.mworx.services.auth"
    })
public class AppConfig {

  @Bean
  public JdbcTemplate jdbcTemplate(@Qualifier("user-management-ds") DataSource dataSource) {
    return new JdbcTemplate(dataSource);
  }
}
