/*
FILE : UserRestController.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.resources;

import com.ssnc.health.core.common.utils.PaginationUtil;
import com.ssnc.health.mworx.services.auth.api.UserApi;
import com.ssnc.health.mworx.services.auth.api.model.AddUserRequest;
import com.ssnc.health.mworx.services.auth.api.model.ByID;
import com.ssnc.health.mworx.services.auth.api.model.ChangePasswordRequest;
import com.ssnc.health.mworx.services.auth.api.model.LockUnlockRequest;
import com.ssnc.health.mworx.services.auth.api.model.MyProfilePasswordRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserContactRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserContactResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserGetUserByUserNameRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserListResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserSearchCriteria;
import com.ssnc.health.mworx.services.auth.constants.AuthConstants;
import com.ssnc.health.mworx.services.auth.mappers.UserMapper;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserContact;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.service.UserService;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@RestController
public class UserRestController implements UserApi {

  private static final String DEFAULT_SORT_BY = "username";

  private UserMapper mapper = Mappers.getMapper(UserMapper.class);

  @Autowired UserService userService;

  @Override
  public ResponseEntity<UserResponse> getUserByUserName(
      @RequestBody UserGetUserByUserNameRequest body) {
    Optional<UserBasic> userBasic = userService.getUser(body.getUserName());
    return getUserResponse(userBasic);
  }

  private ResponseEntity<UserResponse> getUserResponse(Optional<UserBasic> userBasic) {
    UserResponse userResponse = null;
    if (userBasic.isPresent()) {
      Optional<UserLogin> userLogin = userService.getUserLogin(userBasic.get());
      if (userLogin.isPresent()) {
        userResponse = mapper.toUserResponseFromUserBasic(userBasic.get(), userLogin.get());
      }
    }
    return userResponse == null
        ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
        : ResponseEntity.ok(userResponse);
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_VIEW)
  public ResponseEntity<UserResponse> getUserById(ByID body) {
    Optional<UserBasic> userBasic = userService.getUserById(body.getId());
    return getUserResponse(userBasic);
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_VIEW)
  public ResponseEntity<UserListResponse> getUsers(
      @RequestBody UserSearchCriteria userSearchCriteria) {
    Page<UserBasic> paginationUsers =
        userService.findUsers(
            mapper.toUserBasic(userSearchCriteria),
            PaginationUtil.getPageable(userSearchCriteria.getPagination(), buildMappings()),
            userSearchCriteria.isLoggedInUsers());
    UserListResponse userListResponse = new UserListResponse();
    List<UserResponse> userResponse =
        Optional.ofNullable(paginationUsers.getContent()).orElseGet(ArrayList::new).stream()
            .map(
                userBasic ->
                    mapper.toUserResponseFromUserBasic(
                        userBasic,
                        userService.getUserLogin(userBasic).isPresent()
                            ? userService.getUserLogin(userBasic).get()
                            : null))
            .collect(Collectors.toList());
    userListResponse.setData(userResponse);
    userListResponse.setTotalPages(paginationUsers.getTotalPages());
    userListResponse.setTotalRecords(paginationUsers.getTotalElements());
    return ResponseEntity.ok(userListResponse);
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_UPDATE)
  public ResponseEntity<UserResponse> addUser(AddUserRequest addUserRequest) {
    UserBasic userBasic = mapper.toUserBasicFromAddUserRequest(addUserRequest);
    userBasic = userService.addUser(userBasic, addUserRequest.getPassword());
    return ResponseEntity.ok(
        mapper.toUserResponseFromUserBasic(
            userBasic, userService.getUserLogin(userBasic).orElse(null)));
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_UPDATE)
  public ResponseEntity<UserResponse> updateUser(UserRequest userRequest) {
    UserBasic userBasic = mapper.toUserBasicFromUserRequest(userRequest);
    userBasic = userService.updateUser(userBasic);
    return ResponseEntity.ok(
        mapper.toUserResponseFromUserBasic(
            userBasic, userService.getUserLogin(userBasic).orElse(null)));
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_UPDATE)
  public ResponseEntity<Void> deleteUsername(UserGetUserByUserNameRequest body) {
    return userService.deleteUser(body.getUserName())
        ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
        : new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_UPDATE)
  public ResponseEntity<UserContactResponse> addUserContact(UserContactRequest userContactRequest) {
    Optional<UserBasic> userBasicOptional = userService.getUser(userContactRequest.getUserName());
    UserContact userContact = mapper.toUserContactFromUserContactRequest(userContactRequest);
    if (userBasicOptional.isPresent()) {
      UserBasic userBasic = userBasicOptional.get();
      userService.addUserContact(userBasic, userContact);
      userService.updateUser(userBasic);
    }
    return ResponseEntity.ok(mapper.fromUserContactToUserContactResponse(userContact));
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_UPDATE)
  public ResponseEntity<UserContactResponse> updateUserContact(
      UserContactRequest userContactRequest) {
    Optional<UserBasic> userBasicOptional = userService.getUser(userContactRequest.getUserName());
    UserContact userContact = mapper.toUserContactFromUserContactRequest(userContactRequest);
    if (userBasicOptional.isPresent()) {
      UserBasic userBasic = userBasicOptional.get();
      userBasic.getUserContacts().stream()
          .filter(
              uc -> uc.getContactId().equals(userContactRequest.getUserContact().getContactId()))
          .forEach(
              uc -> {
                uc.setContactInfo(userContactRequest.getUserContact().getContactInfo());
                uc.setContactType(userContactRequest.getUserContact().getContactType());
                uc.setPrefer(userContactRequest.getUserContact().getPrefer());
              });
      userService.updateUser(userBasic);
    }
    return ResponseEntity.ok(mapper.fromUserContactToUserContactResponse(userContact));
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_UPDATE)
  public ResponseEntity<String> deleteUserContact(UserContactRequest userContactRequest) {
    Optional<UserBasic> userBasicOptional = userService.getUser(userContactRequest.getUserName());
    Optional<UserContact> userContactOptional = Optional.empty();
    if (userBasicOptional.isPresent()) {
      UserBasic userBasic = userBasicOptional.get();
      userContactOptional =
          userBasic.getUserContacts().stream()
              .filter(
                  uc ->
                      uc.getContactId().equals(userContactRequest.getUserContact().getContactId()))
              .findFirst();
      if (userContactOptional.isPresent()) {
        userService.removeUserContact(userBasic, userContactOptional.get());
        userService.updateUser(userBasic);
      }
    }
    // if user sent or contact is not found  or is empty then return a 404 error
    return userBasicOptional.isPresent() && userContactOptional.isPresent()
        ? ResponseEntity.ok(
            "\"Successfully deleted contact id: "
                + userContactRequest.getUserContact().getContactId()
                + " from User: "
                + userContactRequest.getUserName()
                + "\"")
        : new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  @Override
  @PreAuthorize("hasAuthority('PERMIT_SECURITY_UPDATE')")
  public ResponseEntity<String> changePassword(ChangePasswordRequest changePasswordRequest) {
    Optional<UserBasic> userBasicRequest = userService.getUser(changePasswordRequest.getUserName());
    return changePassword(userBasicRequest, changePasswordRequest.getPassword());
  }

  @Override
  @PreAuthorize("hasAuthority('PERMIT_USER_CHANGE_PASSWORD')")
  public ResponseEntity<String> changePassword(MyProfilePasswordRequest changePasswordRequest) {
    Optional<UserBasic> userBasicRequest = userService.getUser();
    return changePassword(userBasicRequest, changePasswordRequest.getNewPassword());
  }

  private ResponseEntity<String> changePassword(
      Optional<UserBasic> userBasicRequest, String password) {
    UserBasic userBasic = null;
    if (userBasicRequest.isPresent()) {
      userBasic = userService.changePassword(userBasicRequest.get(), password);
    }
    return userBasic != null
        ? ResponseEntity.ok(
            ("\"Successfully updated the password for User : " + userBasic.getUsername()) + "\"")
        : new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  @Override
  @PreAuthorize("hasAuthority('PERMIT_USER_UPDATE') or hasAuthority('PERMIT_SECURITY_UPDATE')")
  public ResponseEntity<String> lockUnlock(LockUnlockRequest lockUnlockRequest) {
    Optional<UserBasic> userLockUnlockRequest =
        userService.getUser(lockUnlockRequest.getUserName());
    String responseMessage = "";
    if (userLockUnlockRequest.isPresent()) {
      UserBasic userBasic = userLockUnlockRequest.get();
      // this means if lock is not sent it will default to false which means active and unlock
      // sonar required this for passing
      responseMessage = (Boolean.TRUE.equals(lockUnlockRequest.isLock()) ? "locked" : "unlocked");
      String locked = (Boolean.TRUE.equals(lockUnlockRequest.isLock())) ? "Y" : "N";
      userBasic.setLocked(locked);
      userService.updateUser(userBasic);
    }
    // if user sent is not found  or is empty then return a 404 error
    return userLockUnlockRequest.isPresent()
        ? ResponseEntity.ok(
            "Successfully " + responseMessage + " User : " + lockUnlockRequest.getUserName())
        : new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }

  private static Map<String, String> buildMappings() {
    Field[] fields = UserBasic.class.getDeclaredFields();
    Map<String, String> properties =
        Arrays.asList(fields).stream().collect(Collectors.toMap(Field::getName, Field::getName));
    properties.put("userName", DEFAULT_SORT_BY);
    return properties;
  }

  @Override
  @PreAuthorize(AuthConstants.PERMIT_USER_VIEW)
  public ResponseEntity<List<UserNameByCriteriaResponse>> getUserNamesBySearchCriteria(
      @RequestBody UserNameByCriteriaRequest userNameByCriteriaRequest) {

    List<UserNameByCriteriaResponse> userResponse =
        Optional.ofNullable(userService.getUserBySearchCriteria(userNameByCriteriaRequest))
            .orElseGet(ArrayList::new).stream()
            .map(userBasic -> mapper.toUserNameByCriteriaResponseFromUserBasic(userBasic))
            .collect(Collectors.toList());
    return userResponse.isEmpty()
        ? new ResponseEntity<>(HttpStatus.NOT_FOUND)
        : ResponseEntity.ok(userResponse);
  }
}
