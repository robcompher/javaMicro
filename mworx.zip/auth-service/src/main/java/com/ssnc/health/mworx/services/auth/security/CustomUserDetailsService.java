/*
 * FILE : CustomUserDetailsService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.security;

import com.ssnc.health.mworx.services.auth.exception.UserNotEffectiveException;
import com.ssnc.health.mworx.services.auth.service.UserService;
import java.util.Calendar;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;

/**
 * CustomUserDetailsService is an implementation of Spring's UserDetailsService interface that will
 * retrieve user information from the database.
 *
 * @author dt75546
 */
public class CustomUserDetailsService implements UserDetailsService {

  private static final Logger logger = LogManager.getLogger(CustomUserDetailsService.class);

  @Autowired private UserService userService;

  @Override
  public final UserDetails loadUserByUsername(final String username) {
    logger.debug("loadUserByUsername called.");
    UserDetails user = userService.loadUserByUserName(username);
    if (user == null || StringUtils.isBlank(user.getUsername())) {
      throw new UsernameNotFoundException("User not found in the system.");
    }
    if (user instanceof AppUser
        && (((AppUser) user).getEffDate() == null
            || ((AppUser) user).getEffDate().after(Calendar.getInstance().getTime()))) {
      throw new UserNotEffectiveException("User is not effective yet");
    }

    return user;
  }
}
