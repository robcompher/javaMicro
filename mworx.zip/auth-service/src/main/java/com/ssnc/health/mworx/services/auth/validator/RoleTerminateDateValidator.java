/*
 * FILE : RoleTerminateDateValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.Role;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.stereotype.Component;

@Component
public class RoleTerminateDateValidator implements ConstraintValidator<ValidRuleset, Role> {

  @Override
  public boolean isValid(Role role, ConstraintValidatorContext context) {
    // Custom validation to check whether termination date is after effective date
    // return true if role term date or effective date is null or term date is not before effective
    // date
    return role.getTermDate() == null
        || role.getEffectiveDate() == null
        || !role.getTermDate().isBefore(role.getEffectiveDate());
  }
}
