/*
 * FILE : UserSecRoleValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.SecRole;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

/**
 * Validating the role type, and role name. If UserRequestSecRole object is not null then role type,
 * and role name values are required.
 *
 * @author dt75758
 */
public class UserSecRoleValidator implements ConstraintValidator<ValidRuleset, UserRequest> {

  @Override
  public boolean isValid(UserRequest userRequest, ConstraintValidatorContext context) {

    SecRole secRole = userRequest.getSecRole();
    if (secRole == null) {
      return true;
    }

    return (secRole.getRoleId() != null
        || (StringUtils.isNotEmpty(secRole.getRoleName())
            && StringUtils.isNotEmpty(secRole.getRoleType())));
  }
}
