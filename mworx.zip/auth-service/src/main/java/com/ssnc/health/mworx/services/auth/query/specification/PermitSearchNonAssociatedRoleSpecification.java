/*
FILE : RoleLobPermitSpecification.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.query.specification;

import com.ssnc.health.mworx.services.auth.model.SecPermit;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.JoinType;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.jpa.domain.Specification;

/**
 * PermitSearchNonAssociatedRoleSpecification class to get the criteria builder based on input
 * parameters. Dynamically constructs query based on input and creates a specification.
 *
 * @author dt204819
 */
public class PermitSearchNonAssociatedRoleSpecification {

  private static final String ROLE_LOB_PERMITS = "roleLobPermits";

  private PermitSearchNonAssociatedRoleSpecification() {}

  public static Specification<SecPermit> get(SummaryPermitSearchCriteria permitSearch) {
    return (Root<SecPermit> root, CriteriaQuery<?> query, CriteriaBuilder builder) -> {
      List<Predicate> predicates = new ArrayList<>();

      Join<Object, Object> rlPermitJoin = root.join(ROLE_LOB_PERMITS, JoinType.LEFT);

      rlPermitJoin.on(
          builder.and(
              builder.equal(rlPermitJoin.get("lobId"), permitSearch.getLob().getLobId()),
              builder.equal(rlPermitJoin.get("secRole").get("roleId"), permitSearch.getRoleId()),
              builder.equal(rlPermitJoin.get("active"), "Y")));

      predicates.add(builder.and(builder.isNull(rlPermitJoin.get("linkId"))));

      if (StringUtils.isNotEmpty(permitSearch.getPrimaryPermit())) {

        predicates.add(
            builder.and(
                builder.like(
                    builder.lower(root.get("permitPrimary")),
                    permitSearch.getPrimaryPermit().toLowerCase() + "%")));
      }

      if (StringUtils.isNotEmpty(permitSearch.getSecondaryPermit())) {
        predicates.add(
            builder.and(
                builder.like(
                    builder.lower(root.get("permitSecondary")),
                    permitSearch.getSecondaryPermit().toLowerCase() + "%")));
      }
      query.distinct(true);
      Predicate[] predicatesArray = new Predicate[predicates.size()];
      return builder.and(predicates.toArray(predicatesArray));
    };
  }
}
