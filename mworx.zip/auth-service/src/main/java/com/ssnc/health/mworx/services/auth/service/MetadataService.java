/*
 * FILE : MetadataService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.api.model.LOB;
import java.util.Map;

public interface MetadataService {

  public Long getLOBId(LOB lob);

  public Map<String, Object> getListById(Long id);

  Map<String, Object> getLobInfoById(Long id);
}
