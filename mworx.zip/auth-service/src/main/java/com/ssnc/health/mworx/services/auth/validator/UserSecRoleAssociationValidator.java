/*
 * FILE : UserSecRoleAssociationValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.SecRole;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * If secure role object is not null and if it is not configured in the system then show the
 * validation error message for create or update user.
 *
 * @author dt75758
 */
public class UserSecRoleAssociationValidator
    implements ConstraintValidator<ValidRuleset, UserRequest> {

  @Autowired private SecRoleRepository roleRepository;

  @Override
  public boolean isValid(UserRequest userRequest, ConstraintValidatorContext context) {

    SecRole secRole = userRequest.getSecRole();
    if (secRole == null) {
      return true;
    }
    if (secRole.getRoleId() != null) {
      return roleRepository.existsById(secRole.getRoleId());
    }
    return roleRepository
        .findByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName())
        .isPresent();
  }
}
