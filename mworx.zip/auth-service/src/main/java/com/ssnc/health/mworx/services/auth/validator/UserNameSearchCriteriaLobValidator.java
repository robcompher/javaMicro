/*
 * FILE : UserNameSearchCriteriaLobValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import java.util.Optional;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.reactive.function.client.WebClientResponseException;

public class UserNameSearchCriteriaLobValidator
    implements ConstraintValidator<ValidRuleset, UserNameByCriteriaRequest> {

  @Autowired private MetadataService metadataService;

  public boolean isValid(
      UserNameByCriteriaRequest criteriaRequest, ConstraintValidatorContext context) {

    if (Optional.ofNullable(criteriaRequest.getLob()).isPresent()) {
      LOB lob = criteriaRequest.getLob();
      if (lob.getLobId() == null
          && lob.getLobName() != null
          && (lob.getOrganizationName() != null || lob.getOrganizationId() != null)) {
        try {
          // will call metadata for request that doesn't have an lob id
          // will need the lob name and organization name/id
          // if it return null then an lob id not found
          lob.setLobId(metadataService.getLOBId(lob));
        } catch (WebClientResponseException ex) {
          return false;
        }
      }

      if (lob.getLobId() != null) {
        criteriaRequest.setLob(lob);
        return true;
      }
    }
    return false;
  }
}
