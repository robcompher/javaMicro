/*
 * FILE : UserLoginPredicate.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator.predicates;

import com.ssnc.health.mworx.services.auth.model.UserLogin;
import java.util.function.Predicate;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;

/** @author dt76103 Captures the Business Validations related to UserLogin Entity. */
public class UserLoginPredicate {

  /**
   * returns true when incoming password matches with this userLogin record.
   *
   * @param incomingPassword
   * @param passEncoder
   * @return true
   */
  public static Predicate<UserLogin> passwordInCurrentRecord(
      String incomingPassword, DelegatingPasswordEncoder passEncoder) {
    return userLoginRecord -> passEncoder.matches(incomingPassword, userLoginRecord.getPassword());
  }

  private UserLoginPredicate() {}
}
