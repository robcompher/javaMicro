/*
FILE : UserSpecification.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.query.specification;

import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.BeanWrapperImpl;
import org.springframework.data.jpa.domain.Specification;

/**
 * User Specification class to get the criteria builder based on input parameters.
 *
 * @author dt75758
 */
public class UserSpecification {

  private static final String ROLE_LOB_PERMITS = "roleLobPermits";
  private static final String SEC_PERMIT = "secPermit";
  private static final String SEC_ROLE = "secRole";

  private UserSpecification() {}

  public static Specification<UserBasic> get(boolean loggedInUsers, UserBasic user) {
    return (Root<UserBasic> root, CriteriaQuery<?> query, CriteriaBuilder builder) -> {
      List<Predicate> predicates = new ArrayList<>();

      /**
       * Iterating the string properties and creating the predicate if the value is not null.
       * Example: For username, firstName and lastName properties are search fields then need to
       * write separate predicate for each property.
       */
      for (Field f : UserBasic.class.getDeclaredFields()) {
        if (f.getType() == String.class && !Modifier.isStatic(f.getModifiers())) {
          String value = (String) new BeanWrapperImpl(user).getPropertyValue(f.getName());
          if (StringUtils.isNotBlank(value)) {
            predicates.add(
                builder.and(
                    builder.like(
                        builder.lower(root.get(f.getName())), "%" + value.toLowerCase() + "%")));
          }
        }
      }

      if (loggedInUsers) {
        Join<Object, Object> logins = root.join("userLogins");
        predicates.add(builder.and(builder.isNotNull(logins.get("lastLogin"))));
        predicates.add(builder.and(builder.isNull(logins.get("lastLogout"))));
      }

      query.distinct(true);
      Predicate[] predicatesArray = new Predicate[predicates.size()];
      return builder.and(predicates.toArray(predicatesArray));
    };
  }

  public static Specification<UserBasic> getUserNameByCriteriaRequest(
      UserNameByCriteriaRequest userNameByCriteriaRequest) {
    return (Root<UserBasic> root, CriteriaQuery<?> query, CriteriaBuilder builder) -> {
      List<Predicate> predicates = new ArrayList<>();

      /**
       * Iterating the string properties and creating the predicate if the value is not null.
       * Example: For username, userId and permits properties are search fields then need to write
       * separate predicate for each property.
       */
      if (StringUtils.isNotEmpty(userNameByCriteriaRequest.getUserName())) {
        predicates.add(
            builder.like(
                builder.lower(root.get("username")),
                userNameByCriteriaRequest.getUserName().toLowerCase() + "%"));
      }

      if (Optional.ofNullable(userNameByCriteriaRequest.getUserId()).isPresent()) {
        predicates.add(
            builder.and(builder.equal(root.get("userId"), userNameByCriteriaRequest.getUserId())));
      }

      // lob id
      Join<Object, Object> secRolejoin = root.join(SEC_ROLE);
      Join<Object, Object> rlPermitJoin = secRolejoin.join(ROLE_LOB_PERMITS);
      Join<Object, Object> secPermitJoin = rlPermitJoin.join(SEC_PERMIT);

      if (Optional.ofNullable(userNameByCriteriaRequest.getLob()).isPresent()
          && userNameByCriteriaRequest.getLob().getLobId() != null) {
        predicates.add(
            builder.and(
                builder.equal(
                    rlPermitJoin.get("lobId"), userNameByCriteriaRequest.getLob().getLobId())));
      }

      if ((StringUtils.isNotEmpty(userNameByCriteriaRequest.getPermitPrimary()))
          && (StringUtils.isNotEmpty(userNameByCriteriaRequest.getPermitSecondary()))) {
        predicates.add(
            builder.and(
                builder.like(
                    builder.lower(secPermitJoin.get("permitPrimary")),
                    userNameByCriteriaRequest.getPermitPrimary().toLowerCase() + "%")));

        predicates.add(
            builder.and(
                builder.like(
                    builder.lower(secPermitJoin.get("permitSecondary")),
                    userNameByCriteriaRequest.getPermitSecondary().toLowerCase() + "%")));
      }

      query.distinct(true);
      Predicate[] predicatesArray = new Predicate[predicates.size()];
      return builder.and(predicates.toArray(predicatesArray));
    };
  }
}
