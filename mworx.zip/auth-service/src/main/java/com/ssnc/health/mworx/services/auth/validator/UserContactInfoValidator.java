/*
 * FILE : UserContactInfoValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.UserContact;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import java.util.List;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.reactive.function.client.WebClientResponseException;

/**
 * Validating the contact type exists in metadata.
 *
 * @author dt75758
 */
public class UserContactInfoValidator implements ConstraintValidator<ValidRuleset, UserRequest> {
  @Value("${metadata.category.contactType}")
  String metadataCategoryContactType;

  @Autowired private MetadataService metadataService;

  @Override
  public boolean isValid(UserRequest userRequest, ConstraintValidatorContext context) {

    List<UserContact> userContacts = userRequest.getUserContacts();

    if (CollectionUtils.isEmpty(userContacts)) {
      return true;
    }
    // will call metadata for each item that has a contact type id
    // if it return null or category does not equal contact_type
    // then it is not a correct contact type id and needs to show an error
    try {
      return userRequest.getUserContacts().stream()
          .filter(contact -> contact.getContactType() != null)
          .allMatch(
              contact ->
                  metadataService
                      .getListById(contact.getContactType())
                      .get("category")
                      .toString()
                      .equalsIgnoreCase(metadataCategoryContactType));
    } catch (WebClientResponseException e) {
      return false;
    }
  }
}
