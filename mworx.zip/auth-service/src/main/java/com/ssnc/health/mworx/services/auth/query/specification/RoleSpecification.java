/*
FILE : RoleSpecification.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.query.specification;

import com.ssnc.health.mworx.services.auth.model.SecRole;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Join;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import org.apache.commons.lang.StringUtils;
import org.springframework.data.jpa.domain.Specification;

/**
 * Role Specification class to get the criteria builder based on input parameters. Dynamically
 * constructs query based on input and creates a specification.
 *
 * @author dt70033
 */
public class RoleSpecification {

  private static final String ROLE_LOB_PERMITS = "roleLobPermits";
  private static final String SEC_PERMIT = "secPermit";

  private RoleSpecification() {}

  public static Specification<SecRole> get(SummaryRoleSearchCriteria roleSearch) {
    return (Root<SecRole> root, CriteriaQuery<?> query, CriteriaBuilder builder) -> {

      /**
       * Iterating the string properties and creating the predicate if the value is not null.
       * roletype,rolename,primary and secondary permit along with active flag. To start off
       * roletype and rolename and active are on the SecRole table
       */
      List<Predicate> predicates = rolePredicates(roleSearch, builder, root);

      // lob id is next
      Join<Object, Object> rlPermitJoin = null;
      if (roleSearch.lobId != null) {
        rlPermitJoin = root.join(ROLE_LOB_PERMITS);
        predicates.add(builder.and(builder.equal(rlPermitJoin.get("lobId"), roleSearch.lobId)));
      }

      if ((StringUtils.isNotEmpty(roleSearch.primaryPermit))
          || (StringUtils.isNotEmpty(roleSearch.secondaryPermit))) {
        if (rlPermitJoin == null) {
          rlPermitJoin = root.join(ROLE_LOB_PERMITS);
        }

        // Permit table is next
        Join<Object, Object> lobPermitJoin = rlPermitJoin.join(SEC_PERMIT);

        if (StringUtils.isNotEmpty(roleSearch.getPrimaryPermit())) {
          predicates.add(
              builder.and(
                  builder.like(
                      builder.lower(lobPermitJoin.get("permitPrimary")),
                      roleSearch.getPrimaryPermit().toLowerCase() + "%")));
        }

        if (StringUtils.isNotEmpty(roleSearch.getSecondaryPermit())) {
          predicates.add(
              builder.and(
                  builder.like(
                      builder.lower(lobPermitJoin.get("permitSecondary")),
                      roleSearch.getSecondaryPermit().toLowerCase() + "%")));
        }
      }
      query.distinct(true);
      Predicate[] predicatesArray = new Predicate[predicates.size()];
      return builder.and(predicates.toArray(predicatesArray));
    };
  }

  private static List<Predicate> rolePredicates(
      SummaryRoleSearchCriteria roleSearch, CriteriaBuilder builder, Root<SecRole> root) {
    List<Predicate> predicates = new ArrayList<>();
    if (StringUtils.isNotEmpty(roleSearch.getRoleType())) {
      predicates.add(
          builder.and(
              builder.like(
                  builder.lower(root.get("roleType")),
                  roleSearch.getRoleType().toLowerCase() + "%")));
    }

    if (StringUtils.isNotEmpty(roleSearch.getRoleName())) {
      predicates.add(
          builder.and(
              builder.like(
                  builder.lower(root.get("roleName")),
                  roleSearch.getRoleName().toLowerCase() + "%")));
    }

    if (StringUtils.isNotEmpty(roleSearch.getActive())) {
      predicates.add(builder.and(builder.equal(root.get("active"), roleSearch.getActive())));
    }
    return predicates;
  }
}
