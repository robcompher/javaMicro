/*
 * FILE : CompanyServiceImpl.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.model.SecCompany;
import com.ssnc.health.mworx.services.auth.repository.SecCompanyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class CompanyServiceImpl implements CompanyService {

  @Autowired SecCompanyRepository secCompanyRepository;

  @Override
  public SecCompany updateCompany(SecCompany secCompany) {
    return secCompanyRepository.save(secCompany);
  }

  @Override
  public SecCompany addCompany(SecCompany secCompany) {
    return secCompanyRepository.save(secCompany);
  }
}
