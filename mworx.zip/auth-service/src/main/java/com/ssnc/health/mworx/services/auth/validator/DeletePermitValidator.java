/*
 * FILE : DeletePermitValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 * @author:  dt64106
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.DeleteRolePermitRequest;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.service.RoleService;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DeletePermitValidator
    implements ConstraintValidator<ValidRuleset, DeleteRolePermitRequest> {

  @Autowired RoleService roleService;

  @Override
  public boolean isValid(
      DeleteRolePermitRequest permitRequest, ConstraintValidatorContext context) {

    /*
     * check to make sure linkId is valid
     */
    RoleLobPermit rlp = roleService.findRoleLobPermit(permitRequest.getLinkId());
    if (rlp == null) {
      return false;
    }
    // check to make sure the roleId passed matches
    return rlp.getSecRole().getRoleId().compareTo(permitRequest.getRoleId()) == 0;
  }
}
