/*
 * FILE : RoleRestController.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.resources;

import com.ssnc.health.core.common.utils.PaginationUtil;
import com.ssnc.health.mworx.services.auth.api.RoleApi;
import com.ssnc.health.mworx.services.auth.api.model.ByID;
import com.ssnc.health.mworx.services.auth.api.model.DeleteRolePermitRequest;
import com.ssnc.health.mworx.services.auth.api.model.PermitListSummaryResponse;
import com.ssnc.health.mworx.services.auth.api.model.PermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.api.model.PermitSummaryResponse;
import com.ssnc.health.mworx.services.auth.api.model.Role;
import com.ssnc.health.mworx.services.auth.api.model.RoleRequest;
import com.ssnc.health.mworx.services.auth.api.model.RoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.api.model.SecRoleListResponse;
import com.ssnc.health.mworx.services.auth.constants.AuthConstants.Security;
import com.ssnc.health.mworx.services.auth.mappers.RoleMapper;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import com.ssnc.health.mworx.services.auth.service.RoleService;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.apache.commons.collections.CollectionUtils;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@RestController
public class RoleRestController implements RoleApi {

  private static final String PERMIT_PRIMARY = "permitPrimary";
  private static final String PERMIT_SECONDARY = "permitSecondary";
  @Autowired private RoleService roleService;
  @Autowired private MetadataService metadataService;

  @Autowired private RoleMapper mapper;

  @Override
  @PreAuthorize(
      Security.PERMIT_SECURITY_UPDATE + "and @entitlementService.hasLobAccess(#role.getPermits())")
  public ResponseEntity<Role> addRole(Role role) {
    // if lob name type there and no name update the id fore mapping
    if (!CollectionUtils.isEmpty(role.getPermits())) {
      role.getPermits().stream()
          .filter(permit -> permit.getLob() != null && permit.getLob().getLobId() == null)
          .forEach(permit -> permit.getLob().setLobId(metadataService.getLOBId(permit.getLob())));
    }
    SecRole secRole = mapper.roleToSecRole(role);
    secRole = roleService.addRole(secRole);
    return ResponseEntity.ok(mapper.secRoleToRole(secRole));
  }

  @Override
  @PreAuthorize(Security.PERMIT_SECURITY_VIEW)
  public ResponseEntity<List<Role>> getAllRoles(@Valid RoleRequest body) {
    Boolean includeInactive = body.isIncludeInactive() != null && body.isIncludeInactive();
    List<SecRole> secRoles =
        roleService.getAllRoles(PaginationUtil.getPageable(body.getPagination()), includeInactive);
    List<Role> roleList =
        Optional.ofNullable(secRoles).orElseGet(ArrayList::new).stream()
            .map(secRole -> mapper.secRoleToRole(secRole))
            .collect(Collectors.toList());
    return ResponseEntity.ok(roleList);
  }

  @Override
  @PreAuthorize(Security.PERMIT_SECURITY_VIEW)
  public ResponseEntity<List<com.ssnc.health.mworx.services.auth.api.model.SecRole>>
      getRoleNameAndTypes() {
    List<SecRole> secRoles = roleService.getAllActiveRoles();
    List<com.ssnc.health.mworx.services.auth.api.model.SecRole> roleList =
        Optional.ofNullable(secRoles).orElseGet(ArrayList::new).stream()
            .map(secRole -> mapper.toSecRoleAPIModel(secRole))
            .collect(Collectors.toList());
    return ResponseEntity.ok(roleList);
  }

  @Override
  @PreAuthorize(Security.PERMIT_SECURITY_VIEW)
  public ResponseEntity<Role> getRoleById(ByID id) {
    Optional<SecRole> secRole = roleService.getRoleById(id.getId());
    Role role = null;
    if (secRole.isPresent()) {
      secRole.get().setRoleLobPermits(roleService.getRoleLobPermits(secRole.get()));
      role = mapper.secRoleToRole(secRole.get());
    }
    return role == null ? new ResponseEntity<>(HttpStatus.NOT_FOUND) : ResponseEntity.ok(role);
  }

  @Override
  @PreAuthorize(
      Security.PERMIT_SECURITY_UPDATE + "and @entitlementService.hasLobAccess(#role.getPermits())")
  public ResponseEntity<Role> updateRole(Role role) {
    // if lob name type there and no name update the id fore mapping
    if (!CollectionUtils.isEmpty(role.getPermits())) {
      role.getPermits().stream()
          .filter(permit -> permit.getLob() != null && permit.getLob().getLobId() == null)
          .forEach(permit -> permit.getLob().setLobId(metadataService.getLOBId(permit.getLob())));
    }
    SecRole secRole = mapper.roleToSecRole(role);
    secRole = roleService.updateRole(secRole);
    secRole.setRoleLobPermits(roleService.getRoleLobPermits(secRole));
    return ResponseEntity.ok(Mappers.getMapper(RoleMapper.class).secRoleToRole(secRole));
  }

  @Override
  @PreAuthorize(Security.PERMIT_SECURITY_VIEW)
  public ResponseEntity<SecRoleListResponse> findBySearchCriteria(RoleSearchCriteria inSearch) {
    SummaryRoleSearchCriteria roleSearchCriteria = mapper.roleSearchToSummarySearch(inSearch);
    Pageable pageRequest = PaginationUtil.getPageable(inSearch.getPagination());
    Page<SecRole> summaryRoles = roleService.findRoleByCriteria(roleSearchCriteria, pageRequest);
    SecRoleListResponse secRoleListResponse = new SecRoleListResponse();
    List<com.ssnc.health.mworx.services.auth.api.model.SecRole> roleList =
        Optional.ofNullable(summaryRoles.getContent()).orElseGet(ArrayList::new).stream()
            .map(secRole -> mapper.toSecRoleAPIModel(secRole))
            .collect(Collectors.toList());
    secRoleListResponse.setData(roleList);
    secRoleListResponse.setTotalRecords(summaryRoles.getTotalElements());
    return ResponseEntity.ok(secRoleListResponse);
  }

  @Override
  @PreAuthorize(
      Security.PERMIT_SECURITY_UPDATE
          + "and @entitlementService.hasLobAccess(#deleteRolePermitRequest.getLinkId())")
  public ResponseEntity<Void> deletePermit(DeleteRolePermitRequest deleteRolePermitRequest) {
    roleService.deleteRoleLobPermit(deleteRolePermitRequest.getLinkId());
    return new ResponseEntity<>(HttpStatus.NO_CONTENT);
  }

  @Override
  @PreAuthorize(
      Security.PERMIT_SECURITY_UPDATE + "and @entitlementService.hasLobAccess(#role.getPermits())")
  public ResponseEntity<Role> addPermitsRole(Role role) {

    SecRole secRole = mapper.roleToSecRole(role);
    SecRole retrievedRole = roleService.saveUpdatedPermits(secRole);

    return ResponseEntity.ok(mapper.secRoleToRole(retrievedRole));
  }

  @Override
  @PreAuthorize(
      Security.PERMIT_SECURITY_VIEW
          + "and @entitlementService.hasLobAccess(#permitSearchCriteria.getLob(), #permitSearchCriteria.isExisting())")
  public ResponseEntity<PermitListSummaryResponse> findByPermitSearchCriteria(
      PermitSearchCriteria permitSearchCriteria) {

    boolean existingPermits = permitSearchCriteria.isExisting().booleanValue();
    SummaryPermitSearchCriteria summaryPermitSearchCriteria =
        mapper.permitSearchToSummarySearch(permitSearchCriteria);
    Pageable pageRequest =
        PaginationUtil.getPageable(
            permitSearchCriteria.getPagination(), buildMappings(existingPermits));
    PermitListSummaryResponse permitListSummaryResponse =
        (existingPermits)
            ? roleAssociatedPermits(summaryPermitSearchCriteria, pageRequest)
            : roleNonAssociatedPermits(summaryPermitSearchCriteria, pageRequest);
    return ResponseEntity.ok(permitListSummaryResponse);
  }

  private PermitListSummaryResponse roleAssociatedPermits(
      SummaryPermitSearchCriteria summaryPermitSearchCriteria, Pageable pageRequest) {

    Page<RoleLobPermit> roleAssociatedPermits =
        roleService.findAssociatedPermitsByCriteria(summaryPermitSearchCriteria, pageRequest);
    PermitListSummaryResponse permitListSummaryResponse = new PermitListSummaryResponse();
    List<com.ssnc.health.mworx.services.auth.api.model.PermitSummaryResponse>
        permitSummaryResponseList =
            Optional.ofNullable(roleAssociatedPermits.getContent()).orElseGet(ArrayList::new)
                .stream()
                .map(roleLobPermit -> mapper.roleLobPermitToPermitSummaryResponse(roleLobPermit))
                .collect(Collectors.toList());

    permitListSummaryResponse.setData(permitSummaryResponseList);
    permitListSummaryResponse.setTotalRecords(roleAssociatedPermits.getTotalElements());

    return permitListSummaryResponse;
  }

  private PermitListSummaryResponse roleNonAssociatedPermits(
      SummaryPermitSearchCriteria summaryPermitSearchCriteria, Pageable pageRequest) {

    Page<SecPermit> roleNonAssociatedPermits =
        roleService.findNonAssociatedPermitsByCriteria(summaryPermitSearchCriteria, pageRequest);
    PermitListSummaryResponse permitListSummaryResponse = new PermitListSummaryResponse();
    List<com.ssnc.health.mworx.services.auth.api.model.PermitSummaryResponse>
        permitSummaryResponseList =
            Optional.ofNullable(roleNonAssociatedPermits.getContent()).orElseGet(ArrayList::new)
                .stream()
                .map(secPermit -> mapper.secPermitToPermitSummaryResponse(secPermit))
                .collect(Collectors.toList());

    permitListSummaryResponse.setData(permitSummaryResponseList);
    permitListSummaryResponse.setTotalRecords(roleNonAssociatedPermits.getTotalElements());

    return permitListSummaryResponse;
  }

  private static Map<String, String> buildMappings(boolean existingPermits) {
    Field[] fields = PermitSummaryResponse.class.getDeclaredFields();
    Map<String, String> properties =
        Arrays.asList(fields).stream().collect(Collectors.toMap(Field::getName, Field::getName));

    if (existingPermits) {
      properties.put("id", "secPermit.permitId");
      properties.put(PERMIT_PRIMARY, "secPermit.permitPrimary");
      properties.put(PERMIT_SECONDARY, "secPermit.permitSecondary");
    } else {
      properties.put("id", "permitId");
      properties.put(PERMIT_PRIMARY, PERMIT_PRIMARY);
      properties.put(PERMIT_SECONDARY, PERMIT_SECONDARY);
    }
    return properties;
  }

  @Override
  @PreAuthorize(Security.PERMIT_SECURITY_UPDATE)
  public ResponseEntity<Void> deleteRole(ByID body) {
    return roleService.deleteRoleById(body.getId())
        ? new ResponseEntity<>(HttpStatus.NO_CONTENT)
        : new ResponseEntity<>(HttpStatus.NOT_FOUND);
  }
}
