package com.ssnc.health.mworx.services.auth.config;

import com.ssnc.health.core.common.model.AuditorAwareImpl;
import java.util.Map;
import javax.sql.DataSource;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.orm.jpa.JpaBaseConfiguration;
import org.springframework.boot.autoconfigure.orm.jpa.JpaProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.vendor.AbstractJpaVendorAdapter;
import org.springframework.orm.jpa.vendor.EclipseLinkJpaVendorAdapter;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;

@Configuration
@EnableTransactionManagement
@EnableJpaRepositories({
  "com.ssnc.health.mworx.services.auth.repository",
  "com.ssnc.health.core.common.validation.repository"
})
@EntityScan({
  "com.ssnc.health.mworx.services.auth.model",
  "com.ssnc.health.core.common.validation.model"
})
@EnableJpaAuditing(auditorAwareRef = "auditorAware")
@EnableConfigurationProperties(EclipselinkConfigurationProperties.class)
public class EclipseLinkJPAConfiguration extends JpaBaseConfiguration {

  @Autowired EclipselinkConfigurationProperties eclipselinkProperties;

  protected EclipseLinkJPAConfiguration(
      @Qualifier("user-management-ds") DataSource dataSource,
      JpaProperties properties,
      ObjectProvider<JtaTransactionManager> jtaTransactionManager) {
    super(dataSource, properties, jtaTransactionManager);
  }

  @Override
  protected AbstractJpaVendorAdapter createJpaVendorAdapter() {
    return new EclipseLinkJpaVendorAdapter();
  }

  @Override
  public Map<String, Object> getVendorProperties() {
    return eclipselinkProperties.getEclipselinkJPAConfig();
  }

  @Bean
  public AuditorAware<Long> auditorAware() {
    return new AuditorAwareImpl();
  }
}
