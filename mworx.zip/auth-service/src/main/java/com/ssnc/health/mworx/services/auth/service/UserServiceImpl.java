/*
FILE : UserServiceImpl.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserContact;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.query.specification.UserSpecification;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import com.ssnc.health.mworx.services.auth.repository.UserLoginRepository;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import com.ssnc.health.mworx.services.auth.utils.DateUtils;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

/** Created by dt75546 on 1/23/2020. */
@Service
@RefreshScope
public class UserServiceImpl implements UserService {

  private static final String IN_ADD_USER_BY_USER_NAME = "In add user by user name";

  private static final String IN_LOAD_USER_BY_USER_NAME = "In load user by user name";

  private static final String UPD_USER_CONST = "In update user";

  @Autowired UserBasicRepository userBasicRepository;

  @Autowired UserLoginRepository userLoginRepository;

  @Autowired SecRoleRepository secRoleRepository;

  @Autowired DelegatingPasswordEncoder passwordEncoder;

  @Autowired SecPermitRepository permitRepository;

  @Autowired private MetadataService metadataService;

  @Value("${passwordHistoryLimit}")
  private String passwordHistoryLimit;

  @Value("${passwordExpireDays}")
  private String passwordExpireDays;

  private static final Logger LOG = LogManager.getLogger(UserServiceImpl.class);

  @Override
  public UserDetails loadUserByUserName(final String userName) {
    LOG.info(IN_LOAD_USER_BY_USER_NAME, userName);
    Optional<UserBasic> userBasic = userBasicRepository.findByUsernameIgnoreCase(userName);
    AppUser appUser = new AppUser();
    if (userBasic.isEmpty()) {
      return appUser;
    }
    populateBasicInfo(userBasic, appUser);

    populateLob(userBasic.get().getSecRole().getRoleLobPermits(), appUser);

    // Now set the rest of the lob Information from metadata
    if (appUser.getCurrentLobId() != null) {
      Map<String, Object> mapLob = metadataService.getLobInfoById(appUser.getCurrentLobId());
      appUser.setCurrentLobCategoryName(
          mapLob.containsKey("lobCategoryName") ? mapLob.get("lobCategoryName").toString() : null);
      appUser.setCurrentLobName(
          mapLob.containsKey("lobName") ? mapLob.get("lobName").toString() : null);
      appUser.setCurrentOrganizationName(
          mapLob.containsKey("organizationName")
              ? mapLob.get("organizationName").toString()
              : null);
      appUser.setCurrentOrganizationId(
          mapLob.containsKey("organizationId")
              ? Long.valueOf(mapLob.get("organizationId").toString())
              : null);
    }

    return appUser;
  }

  private void populateBasicInfo(Optional<UserBasic> userBasic, AppUser appUser) {

    if (userBasic.isPresent()) {
      appUser.setUserId(userBasic.get().getUserId());
      appUser.setUsername(userBasic.get().getUsername());
      appUser.setFirstName(userBasic.get().getFirstName());
      appUser.setLastName(userBasic.get().getLastName());

      UserLogin userLogin = getUserLogin(userBasic.get()).orElse(null);
      if (userLogin != null) {
        appUser.setPassword(userLogin.getPassword());
        // Password expire check will not be done if days set is 0 or less.
        if (passwordExpireDays != null && Integer.parseInt(passwordExpireDays) > 0) {
          appUser.setNoOfDaysToPasswordExpire(
              DateUtils.getNoOfDaysToExpire(
                  LocalDateTime.now(),
                  userLogin
                      .getCreated()
                      .toInstant()
                      .atZone(ZoneId.systemDefault())
                      .toLocalDateTime(),
                  Integer.parseInt(passwordExpireDays)));
        }
      }
      boolean isActive = userBasic.get().getActive().equals("Y");
      appUser.setAccountNonExpired(isActive);
      appUser.setAccountNonLocked(
          userBasic.get().getLocked() == null || !userBasic.get().getLocked().equals("Y"));
      appUser.setCredentialsNonExpired(
          userBasic.get().getTermDate() == null
              || userBasic.get().getTermDate().after(Calendar.getInstance().getTime()));

      appUser.setEnabled(isActive);
      appUser.setEffDate(userBasic.get().getEffDate());
      appUser.setRole(Optional.of(userBasic.get().getSecRole()));
    }
  }

  private void populateLob(List<RoleLobPermit> allPermits, AppUser appUser) {

    List<Long> listLob =
        Optional.ofNullable(allPermits).orElseGet(ArrayList::new).stream()
            .filter(
                permit ->
                    (permit.getActive() == null || permit.getActive().equalsIgnoreCase("Y"))
                        && (permit.getSecPermit().getActive() == null
                            || permit.getSecPermit().getActive().equalsIgnoreCase("Y")))
            .map(RoleLobPermit::getLobId)
            .collect(Collectors.toList())
            .stream()
            .filter(Objects::nonNull)
            .distinct()
            .collect(Collectors.toList());
    appUser.setLineOfBusinesses(listLob);
    if (listLob.size() == 1) {
      appUser.setCurrentLobId(listLob.get(0));
    }
    if (appUser.getCurrentLobId() == null && RequestContextHolder.getRequestAttributes() != null) {
      String tmpLobId =
          ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes())
              .getRequest()
              .getParameter("currentLobId");
      if (!StringUtils.isEmpty(tmpLobId)
          && appUser.getLineOfBusinesses().contains(Long.valueOf(tmpLobId))) {
        appUser.setCurrentLobId(Long.valueOf(tmpLobId));
      }
    }
  }

  @Override
  public Optional<UserLogin> getUserLogin(UserBasic userBasic) {
    LOG.info("In get user login {}", userBasic.getUsername());
    List<UserLogin> userLogins = userBasic.getUserLogins();
    if (CollectionUtils.isEmpty(userLogins)) {
      return Optional.empty();
    }
    return Optional.ofNullable(userLogins).orElseGet(ArrayList::new).stream()
        .max(Comparator.comparing(UserLogin::getCreated));
  }

  @Override
  public Page<UserBasic> findUsers(UserBasic userBasic, Pageable pageable, boolean loggedInUsers) {
    return userBasicRepository.findAll(UserSpecification.get(loggedInUsers, userBasic), pageable);
  }

  /**
   * Will get the authenticated user id and return the user basic If not authenticated then a blank
   * UserBasic
   */
  private Long getAuthenticatedUserId() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    Optional<Long> userId = Optional.empty();
    if (authentication instanceof JwtAuthenticationToken) {
      userId =
          Optional.of(((JwtAuthenticationToken) authentication).getToken().getClaim("user_id"));
    }
    return (userId.isPresent()) ? userId.get() : null;
  }

  /**
   * Will get the authenticated user name and return the user basic if not authenticated then a
   * blank UserBasic
   */
  private String getAuthenticatedUserName() {
    Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
    Optional<String> userName = Optional.empty();
    if (authentication instanceof JwtAuthenticationToken) {
      userName = Optional.of(((JwtAuthenticationToken) authentication).getName());
    }
    return (userName.isPresent()) ? userName.get() : null;
  }

  @Override
  @Transactional
  public UserBasic addUser(UserBasic userBasic, String password) {
    LOG.info(IN_ADD_USER_BY_USER_NAME, userBasic.getUsername());
    userBasic.setLocked(StringUtils.equalsIgnoreCase(userBasic.getLocked(), ("Y")) ? "Y" : "N");
    updateTerminateDate(userBasic, userBasic.getLocked());
    Long loggedInId = getAuthenticatedUserId();
    userBasic.setCreateBy(loggedInId);
    userBasic.setCreated(new Date());
    userBasic.setUpdateBy(loggedInId);
    userBasic.setUpdated(new Date());
    UserLogin userLogin = new UserLogin();
    userLogin.setPassword(passwordEncoder.encode(password));
    userLogin.setUserBasic(userBasic);
    userLogin.setCreated(new Date());
    userLogin.setCreateBy(loggedInId);
    userLogin.setUpdateBy(loggedInId);
    userLogin.setUpdated(new Date());
    userBasic.getUserLogins().add(userLogin);
    setSecRole(userBasic);
    setUserContacts(userBasic, Optional.empty());
    userBasic = userBasicRepository.save(userBasic);
    return userBasic;
  }

  private void setSecRole(UserBasic userBasic) {
    SecRole secRole = userBasic.getSecRole();
    // if role id already set then no need to check.  go ahead and save
    if (secRole != null && secRole.getRoleId() == null) {
      Optional<SecRole> existingSecRole =
          secRoleRepository.findByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName());
      if (existingSecRole.isPresent()) {
        userBasic.setSecRole(existingSecRole.get());
        List<UserBasic> userBasics =
            Optional.ofNullable(existingSecRole.get().getUserBasics()).orElseGet(ArrayList::new);
        userBasics.add(userBasic);
        secRole.setUserBasics(userBasics);
      } else {
        userBasic.setSecRole(null);
      }
    }
  }

  @Override
  @Transactional
  public UserBasic changePassword(UserBasic userBasic, String password) {
    LOG.info("In change user by user name {} ", userBasic.getUsername());
    Optional<UserBasic> existingUser = getUser(userBasic.getUsername());
    UserBasic existingUserBasic = null;
    if (existingUser.isPresent()) {
      existingUserBasic = existingUser.get();

      // insert new user login record when passwordHistoryLimit is greater than user
      // login records count.
      if (passwordHistoryLimit != null
          && Integer.parseInt(passwordHistoryLimit) > existingUserBasic.getUserLogins().size()) {
        UserLogin userLogin = constructUserLogin(password);

        // get existingUserLogin and get last logout time and set it to new userlogin.
        Optional<UserLogin> existingUserLogin = getUserLogin(existingUserBasic);
        if (existingUserLogin.isPresent()) {
          userLogin.setLastLogin(existingUserLogin.get().getLastLogin());
          userLogin.setLastLogout(existingUserLogin.get().getLastLogout());
        }
        userLogin.setUserBasic(existingUserBasic);
        existingUserBasic.setUserId(existingUser.get().getUserId());
        existingUserBasic.getUserLogins().add(userLogin);
        existingUserBasic = userBasicRepository.save(existingUserBasic);
      } else {
        UserLogin userLogin =
            existingUserBasic.getUserLogins().stream()
                .min(Comparator.comparing(UserLogin::getCreated))
                .orElse(new UserLogin());
        // Removing old user login record
        existingUserBasic.getUserLogins().remove(userLogin);
        UserLogin newUserLogin = constructUserLogin(password);
        newUserLogin.setUserBasic(existingUserBasic);
        existingUserBasic.setUserId(existingUser.get().getUserId());
        // Adding new user login record
        existingUserBasic.getUserLogins().add(newUserLogin);
        existingUserBasic = userBasicRepository.save(existingUserBasic);
      }
    }
    return existingUserBasic;
  }

  @Override
  @Transactional
  public UserBasic updateUser(UserBasic userBasic) {
    LOG.info(UPD_USER_CONST, userBasic.getUsername());
    Optional<UserBasic> existingUser = getUser(userBasic.getUsername());
    UserBasic updatedUser = null;
    if (existingUser.isPresent()) {
      userBasic.setUserId(existingUser.get().getUserId());
      userBasic.setCreateBy(existingUser.get().getCreateBy());
      userBasic.setCreated(existingUser.get().getCreated());
      userBasic.setUserLogins(existingUser.get().getUserLogins());
      userBasic.setUpdated(new Date());
      userBasic.setUpdateBy(getAuthenticatedUserId());
      if (StringUtils.isEmpty(userBasic.getLocked())) {
        userBasic.setLocked(existingUser.get().getLocked());
      }
      updateTerminateDate(userBasic, userBasic.getLocked());
      setSecRole(userBasic);
      setUserContacts(userBasic, existingUser);
      updatedUser = userBasicRepository.save(userBasic);
    }
    return updatedUser;
  }

  @Override
  public void addUserContact(UserBasic userBasic, UserContact userContact) {
    userBasic.getUserContacts().add(userContact);
    userContact.setUserBasic(userBasic);
  }

  @Override
  public void removeUserContact(UserBasic userBasic, UserContact userContact) {
    userBasic.getUserContacts().remove(userContact);
    userContact.setUserBasic(null);
  }

  private void setUserContacts(UserBasic userBasic, Optional<UserBasic> existingUser) {
    List<UserContact> userContacts = userBasic.getUserContacts();
    if (CollectionUtils.isNotEmpty(userContacts)) {
      setUserbasicToUserContact(userBasic, userContacts);
      mergeUserContacts(userBasic, existingUser);
    }
  }

  private void mergeUserContacts(UserBasic userBasic, Optional<UserBasic> existingUser) {
    List<UserContact> userContacts = userBasic.getUserContacts();
    // Merge with existing User contacts.
    if (existingUser.isPresent()) {
      List<UserContact> existingUserContacts = existingUser.get().getUserContacts();
      // filter only where the id is null to find an existing one.  Otherwise it is correct
      if (CollectionUtils.isNotEmpty(existingUserContacts)) {
        userContacts.stream()
            .filter(userContact -> userContact.getContactId() == null)
            .forEach(
                userContact -> {
                  Optional<UserContact> uc =
                      getExistingUserContact(userContact, existingUserContacts);
                  if (uc.isPresent()) {
                    userContact.setContactId(uc.get().getContactId());
                    userContact.setCreateBy(existingUser.get().getCreateBy());
                    userContact.setCreated(existingUser.get().getCreated());
                  }
                });
      }
    }
  }

  private void setUserbasicToUserContact(UserBasic userBasic, List<UserContact> userContacts) {
    userContacts.stream().forEach(userContact -> userContact.setUserBasic(userBasic));
  }

  private Optional<UserContact> getExistingUserContact(
      UserContact userContact, List<UserContact> existingUserContacts) {
    return existingUserContacts.stream()
        .filter(uc -> userContact.getContactType().equals(uc.getContactType()))
        .findFirst();
  }

  @Override
  @Transactional
  public void updateUserLogin(UserLogin userLogin) {
    userLogin.setUpdated(new Date());
    userLogin.setUpdateBy(getAuthenticatedUserId());
    userLoginRepository.save(userLogin);
  }

  @Override
  public Optional<UserBasic> getUser(String userName) {
    return userBasicRepository.findByUsernameIgnoreCase(userName);
  }

  @Override
  public Optional<UserBasic> getUserById(Long id) {
    return userBasicRepository.findById(id);
  }

  private UserLogin constructUserLogin(String password) {
    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(passwordEncoder.encode(password));
    userLogin.setCreated(new Date());
    return userLogin;
  }

  @Override
  public Optional<UserBasic> getUser() {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    return getUser(auth.getName());
  }

  @Override
  public List<UserBasic> getUserBySearchCriteria(
      UserNameByCriteriaRequest userNameByCriteriaRequest) {

    return userBasicRepository.findAll(
        UserSpecification.getUserNameByCriteriaRequest(userNameByCriteriaRequest));
  }

  @Override
  @Transactional
  public void updateTerminateDate(UserBasic userBasic, String locked) {
    if (StringUtils.equalsIgnoreCase(locked, "Y")) {
      userBasic.setActive("N");
      userBasic.setLocked(locked);
      userBasic.setTermDate(new Date());
    } else {
      userBasic.setActive("Y");
      userBasic.setLocked(locked);
      userBasic.setTermDate(null);
    }
  }

  @Override
  @Transactional
  public List<SecPermit> getAllSecPermits(Optional<Long> lobId) {
    Optional<UserBasic> existingUser = getUser();
    String userName = existingUser.isPresent() ? existingUser.get().getUsername() : null;
    return permitRepository.getAllSecPermits(userName, lobId);
  }

  @Override
  public boolean deleteUser(String userName) {
    Optional<UserBasic> userBasicOptional = getUser(userName);
    if (userBasicOptional.isPresent()) {
      userBasicOptional.get().setActive("N");
      userBasicRepository.save(userBasicOptional.get());
    }
    return userBasicOptional.isPresent();
  }

  @Override
  public boolean isValidLockUnLockUserOperation(String userName, String locked) {
    String loggedInUserName = getAuthenticatedUserName();
    Optional<UserBasic> user = getUser(userName);
    if (user.isEmpty()
        || !StringUtils.equalsIgnoreCase(loggedInUserName, user.get().getUsername())) {
      return true;
    }
    return StringUtils.equalsIgnoreCase(locked, user.get().getLocked());
  }
}
