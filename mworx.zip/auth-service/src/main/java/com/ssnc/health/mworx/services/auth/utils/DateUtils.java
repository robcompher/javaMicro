/*
FILE : DateUtils.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.utils;

import java.time.Duration;
import java.time.LocalDateTime;

public class DateUtils {
  private DateUtils() {}
  /**
   * Calculates the number of days for user to expire the password
   *
   * @param asOfDate.
   * @param passwordCreateDate
   * @param userPasswordExpireDays
   * @return long daysBetween
   */
  public static long getNoOfDaysToExpire(
      LocalDateTime asOfDate, LocalDateTime passwordCreateDate, int userPasswordExpireDays) {
    LocalDateTime expiryDate = passwordCreateDate.plusDays(userPasswordExpireDays);
    return Duration.between(asOfDate, expiryDate).toDays();
  }
}
