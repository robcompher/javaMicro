package com.ssnc.health.mworx.services.auth.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.autoconfigure.liquibase.LiquibaseDataSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/** Created by DT214743 on 1/8/2020. */
@Configuration
public class LiquibaseConfig {

  @Bean
  @LiquibaseDataSource
  public DataSource liquibaseDataSource(@Qualifier("user-management-ds") DataSource dataSource) {
    return dataSource;
  }
}
