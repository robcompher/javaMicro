package com.ssnc.health.mworx.services.auth.config;

import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

@ConfigurationProperties(prefix = "eclipselink-jpa")
@Getter
@Setter
public class EclipselinkConfigurationProperties {
  protected Map<String, Object> properties = new HashMap<>();

  public Map<String, Object> getEclipselinkJPAConfig() {
    return (properties);
  }
}
