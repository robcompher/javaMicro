/*
 * FILE : UserNameSearchCriteriaPermitValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import java.util.Optional;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class UserNameSearchCriteriaPermitValidator
    implements ConstraintValidator<ValidRuleset, UserNameByCriteriaRequest> {

  @Override
  public boolean isValid(
      UserNameByCriteriaRequest searchRequest, ConstraintValidatorContext context) {
    return !(Optional.ofNullable(searchRequest.getPermitPrimary()).isEmpty()
        ^ Optional.ofNullable(searchRequest.getPermitSecondary()).isEmpty());
  }
}
