/*
 * FILE : RoleService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

public interface RoleService {

  List<SecRole> getAllRoles(Pageable pageable, boolean includeInactive);

  Page<SecRole> findRoleByCriteria(SummaryRoleSearchCriteria roleSearchCriteria, Pageable pageable);

  Optional<SecRole> getRoleById(Long id);

  SecRole addRole(SecRole role);

  SecRole updateRole(SecRole role);

  Optional<SecRole> getRoleByRoleTypeAndRoleName(String roleName, String roleType);

  List<RoleLobPermit> getRoleLobPermits(SecRole secRole);

  RoleLobPermit findRoleLobPermit(Long linkId);

  void saveRoleLobPermit(RoleLobPermit roleLobPermit);

  void saveAllRoleLobPermit(List<RoleLobPermit> roleLobPermits);

  void deleteRoleLobPermit(Long linkId);

  SecRole saveUpdatedPermits(SecRole secRole);

  Page<RoleLobPermit> findAssociatedPermitsByCriteria(
      SummaryPermitSearchCriteria permitSearchCriteria, Pageable pageable);

  Page<SecPermit> findNonAssociatedPermitsByCriteria(
      SummaryPermitSearchCriteria permitSearchCriteria, Pageable pageable);

  List<SecRole> getAllActiveRoles();

  boolean verifyDeleteLobPermit(Long linkId);
  /**
   * Delete Role.
   *
   * @param id - id.
   * @return true if there exists Role with the id.
   */
  boolean deleteRoleById(Long id);
}
