package com.ssnc.health.mworx.services.auth.config;

import com.nimbusds.jose.JWSAlgorithm;
import com.nimbusds.jose.jwk.JWKSet;
import com.nimbusds.jose.jwk.KeyUse;
import com.nimbusds.jose.jwk.RSAKey;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import java.security.KeyPair;
import java.security.interfaces.RSAPrivateKey;
import java.security.interfaces.RSAPublicKey;
import java.util.Base64;
import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.keygen.KeyGenerators;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.RsaSigner;
import org.springframework.security.oauth2.common.OAuth2AccessToken;
import org.springframework.security.oauth2.common.exceptions.OAuth2Exception;
import org.springframework.security.oauth2.common.util.JsonParser;
import org.springframework.security.oauth2.common.util.JsonParserFactory;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.OAuth2Authentication;
import org.springframework.security.oauth2.provider.endpoint.FrameworkEndpoint;
import org.springframework.security.oauth2.provider.error.DefaultWebResponseExceptionTranslator;
import org.springframework.security.oauth2.provider.error.WebResponseExceptionTranslator;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.UserAuthenticationConverter;
import org.springframework.security.oauth2.provider.token.store.JwtAccessTokenConverter;
import org.springframework.security.oauth2.provider.token.store.JwtTokenStore;
import org.springframework.security.oauth2.provider.token.store.KeyStoreKeyFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

/** Created by DT214743 on 1/15/2020. */
@RefreshScope
@Configuration
@EnableAuthorizationServer
@EnableConfigurationProperties(JwtKeyStoreProperties.class)
@ConditionalOnProperty(prefix = "security.oauth2.server", name = "enabled", havingValue = "true")
public class JwkAuthServerConfig extends AuthorizationServerConfigurerAdapter {
  static final String VERIFIER_KEY_ID =
      new String(Base64.getEncoder().encode(KeyGenerators.secureRandom(32).generateKey()));

  private final JwtKeyStoreProperties jwtProperties;
  private final AuthenticationManager authenticationManager;
  private final PasswordEncoder passwordEncoder;
  private final UserDetailsService userService;

  @Value("${security.oauth2.client.client-id}")
  private String clientId;

  @Value("${security.oauth2.client.client-secret}")
  private String clientSecret;

  @Value("${jwt.accessTokenValidititySeconds:6000000}") // 10 minutes
  private int accessTokenValiditySeconds;

  @Value(
      "${jwt.authorizedGrantTypes:refresh_token,client_credentials,authorization_code,password,implicit}")
  private String[] authorizedGrantTypes;

  @Value("${jwt.refreshTokenValiditySeconds:43200}") // 1 day
  private int refreshTokenValiditySeconds;

  @Value("${security.oauth2.client.client-redirect-url}")
  private String redirectUrl;

  @Value("${security.oauth2.client.client-resource-ids}")
  private String resourceIds;

  @Value("${security.oauth2.client.client-scopes}")
  private String clientScopes;

  public JwkAuthServerConfig(
      JwtKeyStoreProperties jwtProperties,
      AuthenticationManager authenticationManager,
      PasswordEncoder passwordEncoder,
      UserDetailsService userService) {
    this.jwtProperties = jwtProperties;
    this.authenticationManager = authenticationManager;
    this.passwordEncoder = passwordEncoder;
    this.userService = userService;
  }

  @Override
  public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
    clients
        .inMemory()
        .withClient(clientId)
        .secret(this.passwordEncoder.encode(clientSecret))
        .accessTokenValiditySeconds(accessTokenValiditySeconds)
        .refreshTokenValiditySeconds(refreshTokenValiditySeconds)
        .authorizedGrantTypes(authorizedGrantTypes)
        .scopes(clientScopes)
        .autoApprove(true)
        .redirectUris(redirectUrl)
        .resourceIds(resourceIds);
  }

  @Override
  public void configure(final AuthorizationServerEndpointsConfigurer endpoints) {
    endpoints
        .tokenStore(tokenStore())
        .authenticationManager(authenticationManager)
        .accessTokenConverter(accessTokenConverter())
        .userDetailsService(userService)
        .allowedTokenEndpointRequestMethods(HttpMethod.GET, HttpMethod.POST)
        .exceptionTranslator(exceptionTranslator());
  }

  @Override
  public void configure(AuthorizationServerSecurityConfigurer oauthServer) throws Exception {
    oauthServer
        .realm("oauth2-mworx")
        .passwordEncoder(this.passwordEncoder)
        .tokenKeyAccess("permitAll()")
        .checkTokenAccess("isAuthenticated()")
        .allowFormAuthenticationForClients();
  }

  @Bean
  public TokenStore tokenStore() {
    return new JwtTokenStore(accessTokenConverter());
  }

  @Bean
  public JwtAccessTokenConverter accessTokenConverter() {
    return new JwkAccessTokenConverter(Collections.singletonMap("kid", VERIFIER_KEY_ID), keyPair());
  }

  @Bean
  public WebResponseExceptionTranslator<OAuth2Exception> exceptionTranslator() {
    return new DefaultWebResponseExceptionTranslator() {
      @Override
      public ResponseEntity<OAuth2Exception> translate(Exception e) throws Exception {
        ResponseEntity<OAuth2Exception> responseEntity = super.translate(e);
        OAuth2Exception body = responseEntity.getBody();
        HttpStatus statusCode = responseEntity.getStatusCode();
        if (body != null) {
          body.addAdditionalInformation(
              "timestamp",
              DateFormatUtils.ISO_8601_EXTENDED_DATETIME_FORMAT.format(System.currentTimeMillis()));
          body.addAdditionalInformation("status", statusCode.name());
          body.addAdditionalInformation("message", body.getMessage());
          body.addAdditionalInformation(
              "debugMessage", body.getOAuth2ErrorCode() + ", " + body.getMessage());
        }
        HttpHeaders headers = new HttpHeaders();
        headers.setAll(responseEntity.getHeaders().toSingleValueMap());
        // do something with header or response
        return new ResponseEntity<>(body, headers, statusCode);
      }
    };
  }

  @Bean
  public JWKSet jwkSet() {
    RSAKey.Builder builder =
        new RSAKey.Builder((RSAPublicKey) keyPair().getPublic())
            .keyUse(KeyUse.SIGNATURE)
            .algorithm(JWSAlgorithm.RS256)
            .keyID(VERIFIER_KEY_ID);
    return new JWKSet(builder.build());
  }

  @Bean
  public KeyPair keyPair() {
    KeyStoreKeyFactory keyStoreKeyFactory =
        new KeyStoreKeyFactory(
            jwtProperties.getKeyStore(), jwtProperties.getKeyStorePassword().toCharArray());
    return keyStoreKeyFactory.getKeyPair(
        jwtProperties.getKeyPairAlias(), jwtProperties.getKeyPairPassword().toCharArray());
  }
}

@ConfigurationProperties("security.jwt")
@NoArgsConstructor
@Getter
@Setter
class JwtKeyStoreProperties {
  private Resource keyStore;
  private String keyStorePassword;
  private String keyPairAlias;
  private String keyPairPassword;
}

class JwkAccessTokenConverter extends JwtAccessTokenConverter {
  private Map<String, String> customHeaders = new HashMap<>();
  private JsonParser objectMapper = JsonParserFactory.create();
  final RsaSigner signer;

  public JwkAccessTokenConverter(Map<String, String> customHeaders, KeyPair keyPair) {
    super();
    super.setKeyPair(keyPair);
    this.signer = new RsaSigner((RSAPrivateKey) keyPair.getPrivate());
    this.customHeaders = customHeaders;
  }

  @SuppressWarnings("unchecked")
  @Override
  protected String encode(OAuth2AccessToken accessToken, OAuth2Authentication authentication) {
    String content;
    try {
      Map<String, Object> tokenAsMap =
          (Map<String, Object>)
              getAccessTokenConverter().convertAccessToken(accessToken, authentication);
      tokenAsMap.put("sub", tokenAsMap.get(UserAuthenticationConverter.USERNAME));
      tokenAsMap.put("user_id", ((AppUser) authentication.getPrincipal()).getUserId());
      tokenAsMap.put("currentLobId", ((AppUser) authentication.getPrincipal()).getCurrentLobId());
      tokenAsMap.put(
          "currentLobName", ((AppUser) authentication.getPrincipal()).getCurrentLobName());
      tokenAsMap.put(
          "currentLobCategoryName",
          ((AppUser) authentication.getPrincipal()).getCurrentLobCategoryName());
      tokenAsMap.put(
          "currentOrganizationName",
          ((AppUser) authentication.getPrincipal()).getCurrentOrganizationName());
      tokenAsMap.put(
          "currentOrganizationId",
          ((AppUser) authentication.getPrincipal()).getCurrentOrganizationId());
      content = this.objectMapper.formatMap(tokenAsMap);
    } catch (Exception ex) {
      throw new IllegalStateException("Cannot convert access token to JSON", ex);
    }
    return JwtHelper.encode(content, this.signer, this.customHeaders).getEncoded();
  }
}

@FrameworkEndpoint
@RestController
class JWKSetResource {

  @Autowired private JWKSet jwkSet;

  @GetMapping(value = "/oauth/keys", produces = "application/json; charset=UTF-8")
  public String keys() {
    return this.jwkSet.toString();
  }
}
