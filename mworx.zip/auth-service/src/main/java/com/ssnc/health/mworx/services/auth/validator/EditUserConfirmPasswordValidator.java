/*
 * FILE : EditUserConfirmPasswordValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */

package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.ChangePasswordRequest;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang3.StringUtils;

public class EditUserConfirmPasswordValidator extends BaseAuthValidator
    implements ConstraintValidator<ValidRuleset, ChangePasswordRequest> {

  /** Validates confirm password, if exists, matches with the new password. */
  @Override
  public boolean isValid(
      ChangePasswordRequest changePasswordRequest, ConstraintValidatorContext context) {
    return StringUtils.isNotEmpty(changePasswordRequest.getConfirmPassword())
        && StringUtils.isNotEmpty(changePasswordRequest.getPassword())
        && changePasswordRequest.getPassword().equals(changePasswordRequest.getConfirmPassword());
  }
}
