/*
 * FILE : PermitRestController.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.resources;

import com.ssnc.health.mworx.services.auth.api.PermitApi;
import com.ssnc.health.mworx.services.auth.api.model.ByID;
import com.ssnc.health.mworx.services.auth.api.model.Permit;
import com.ssnc.health.mworx.services.auth.api.model.PermitRequest;
import com.ssnc.health.mworx.services.auth.constants.AuthConstants.Security;
import com.ssnc.health.mworx.services.auth.mappers.RoleMapper;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.service.PermitService;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import javax.validation.Valid;
import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.context.annotation.ScopedProxyMode;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RestController;

@Scope(proxyMode = ScopedProxyMode.TARGET_CLASS)
@RestController
public class PermitRestController implements PermitApi {

  private RoleMapper mapper = Mappers.getMapper(RoleMapper.class);
  @Autowired private PermitService permitService;

  @Override
  @PreAuthorize(Security.PERMIT_SECURITY_VIEW)
  public ResponseEntity<List<Permit>> getAllPermits(@Valid PermitRequest body) {
    // default value is false unless set to true
    Boolean includeInactive = body.isIncludeInactive() != null && body.isIncludeInactive();
    List<SecPermit> permits = permitService.getAllPermits(includeInactive);

    List<Permit> permitList =
        Optional.ofNullable(permits).orElseGet(ArrayList::new).stream()
            .map(secPermit -> mapper.secPermitToPermit(secPermit))
            .collect(Collectors.toList());
    return ResponseEntity.ok(permitList);
  }

  @Override
  @PreAuthorize(Security.PERMIT_SECURITY_VIEW)
  public ResponseEntity<Permit> getPermitById(ByID id) {
    Optional<SecPermit> secPermit = permitService.getPermitById(id.getId());
    Permit permit = null;
    if (secPermit.isPresent()) {
      permit = mapper.secPermitToPermit(secPermit.get());
    }
    return permit == null ? new ResponseEntity<>(HttpStatus.NOT_FOUND) : ResponseEntity.ok(permit);
  }
}
