/*
 * FILE : RoleMapper.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.mappers;

import com.ssnc.health.core.common.utils.DateMapper;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.api.model.Permit;
import com.ssnc.health.mworx.services.auth.api.model.PermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.api.model.PermitSummaryResponse;
import com.ssnc.health.mworx.services.auth.api.model.Role;
import com.ssnc.health.mworx.services.auth.api.model.RoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.service.RoleService;
import java.util.Optional;
import org.mapstruct.AfterMapping;
import org.mapstruct.InheritInverseConfiguration;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.MappingTarget;
import org.mapstruct.Mappings;
import org.springframework.beans.factory.annotation.Autowired;

@Mapper(
    imports = {DateMapper.class},
    componentModel = "spring")
public abstract class RoleMapper {
  @Autowired private RoleService roleService;

  @Mappings({
    @Mapping(target = "roleLobPermits", source = "permits"),
    @Mapping(
        target = "effDate",
        expression = "java(new DateMapper().asDate(role.getEffectiveDate()))"),
    @Mapping(target = "termDate", expression = "java(new DateMapper().asDate(role.getTermDate()))")
  })
  public abstract SecRole roleToSecRole(Role role);

  @InheritInverseConfiguration
  @Mappings({
    @Mapping(
        target = "effectiveDate",
        expression = "java(new DateMapper().asLocalDate(secRole.getEffDate()))"),
    @Mapping(
        target = "termDate",
        expression = "java(new DateMapper().asLocalDate(secRole.getTermDate()))")
  })
  public abstract Role secRoleToRole(SecRole secRole);

  @Mapping(target = "permitId", source = "id")
  public abstract SecPermit permitToSecPermit(Permit permit);

  @Mapping(target = "id", source = "permitId")
  public abstract Permit secPermitToPermit(SecPermit secPermit);

  @Mapping(target = "secPermit", source = "permit")
  @Mapping(target = "lobId", source = "permit.lob.lobId")
  public abstract RoleLobPermit permitToRoleLobPermit(Permit permit);

  public Permit roleLobPermitToPermit(RoleLobPermit roleLobPermit) {
    Permit permit = secPermitToPermit(roleLobPermit.getSecPermit());
    if (roleLobPermit.getLobId() != null) {
      LOB lob = new LOB();
      lob.setLobId(roleLobPermit.getLobId());
      permit.setLob(lob);
    }
    return permit;
  }

  @Mappings({
    @Mapping(
        target = "effectiveDate",
        expression = "java(new DateMapper().asLocalDate(secRole.getEffDate()))"),
    @Mapping(
        target = "termDate",
        expression = "java(new DateMapper().asLocalDate(secRole.getTermDate()))")
  })
  public abstract com.ssnc.health.mworx.services.auth.api.model.SecRole toSecRoleAPIModel(
      SecRole secRole);

  public abstract SummaryRoleSearchCriteria roleSearchToSummarySearch(
      RoleSearchCriteria roleSearch);

  @AfterMapping
  public void mapRoleAndPermitIDToDTO(@MappingTarget SecRole secRole, Role role) {
    // find by roleId if present otherwise find by name/type
    Optional<SecRole> existingRole =
        secRole.getRoleId() == null
            ? roleService.getRoleByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName())
            : roleService.getRoleById(secRole.getRoleId());
    if (existingRole.isPresent()) {
      secRole.setRoleId(existingRole.get().getRoleId());
    }
  }

  public abstract SummaryPermitSearchCriteria permitSearchToSummarySearch(
      PermitSearchCriteria permitSearch);

  @Mappings({
    @Mapping(target = "permitSecondary", source = "roleLobPermit.secPermit.permitSecondary"),
    @Mapping(target = "permitPrimary", source = "roleLobPermit.secPermit.permitPrimary"),
    @Mapping(target = "description", source = "roleLobPermit.secPermit.description"),
    @Mapping(target = "id", source = "roleLobPermit.secPermit.permitId")
  })
  public abstract PermitSummaryResponse roleLobPermitToPermitSummaryResponse(
      RoleLobPermit roleLobPermit);

  @Mappings({
    @Mapping(target = "permitSecondary", source = "secPermit.permitSecondary"),
    @Mapping(target = "permitPrimary", source = "secPermit.permitPrimary"),
    @Mapping(target = "id", source = "secPermit.permitId")
  })
  public abstract PermitSummaryResponse secPermitToPermitSummaryResponse(SecPermit secPermit);
}
