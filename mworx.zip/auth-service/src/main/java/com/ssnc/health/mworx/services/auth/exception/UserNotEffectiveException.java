package com.ssnc.health.mworx.services.auth.exception;

import org.springframework.security.core.AuthenticationException;

public class UserNotEffectiveException extends AuthenticationException {
  private static final long serialVersionUID = -2L;

  public UserNotEffectiveException(String msg) {
    super(msg);
  }
}
