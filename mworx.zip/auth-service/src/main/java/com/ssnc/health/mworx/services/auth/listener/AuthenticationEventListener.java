/*
FILE : AuthenticationEventListener.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.listener;

import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import com.ssnc.health.mworx.services.auth.service.UserService;
import java.util.Date;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.context.config.annotation.RefreshScope;
import org.springframework.context.event.EventListener;
import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.stereotype.Component;

@Component
@RefreshScope
public class AuthenticationEventListener {

  @Autowired UserService userService;

  @Value("${maxFailedAttempts}")
  private String maxFailedAttempts;

  @EventListener
  public void authSuccessEventListener(AuthenticationSuccessEvent authorizedEvent) {
    if (authorizedEvent.getAuthentication().getPrincipal() instanceof AppUser) {
      AppUser appUser = (AppUser) authorizedEvent.getAuthentication().getPrincipal();
      Optional<UserBasic> userBasic = userService.getUser(appUser.getUsername());
      Optional<UserLogin> activeUserLogin =
          userService.getUserLogin(userBasic.isPresent() ? userBasic.get() : new UserBasic());
      if (activeUserLogin.isPresent()) {
        activeUserLogin.get().setFailureAttempts(0);
        activeUserLogin.get().setLastLogin(new Date());
        activeUserLogin.get().setLastLogout(null);
        userService.updateUserLogin(activeUserLogin.get());
      }
    }
  }

  @EventListener
  public void authFailedEventListener(
      AbstractAuthenticationFailureEvent oAuth2AuthenticationFailureEvent) {
    final String username =
        (String) oAuth2AuthenticationFailureEvent.getAuthentication().getPrincipal();
    UserBasic userBasic = userService.getUser(username).orElse(new UserBasic());
    Integer maxPasswordAttemptsAllowed;
    Optional<UserLogin> activeUserLogin = userService.getUserLogin(userBasic);
    if (activeUserLogin.isPresent()) {
      UserLogin userLogin = activeUserLogin.get();
      Integer failureAttempts =
          userLogin.getFailureAttempts() != null ? userLogin.getFailureAttempts() : 0;
      userLogin.setFailureAttempts(failureAttempts + 1);
      userService.updateUserLogin(userLogin);
      try {
        maxPasswordAttemptsAllowed = Integer.parseInt(maxFailedAttempts);
      } catch (NumberFormatException e) {
        maxPasswordAttemptsAllowed = 3;
      }
      if (maxPasswordAttemptsAllowed > 0 && failureAttempts + 1 >= maxPasswordAttemptsAllowed) {
        userBasic.setLocked("Y");
        userService.updateUser(userBasic);
      }
    }
  }
}
