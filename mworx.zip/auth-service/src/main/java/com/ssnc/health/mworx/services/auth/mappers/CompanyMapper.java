/*
 * FILE : CompanyMapper.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.mappers;

import com.ssnc.health.mworx.services.auth.api.model.Company;
import com.ssnc.health.mworx.services.auth.model.SecCompany;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;
import org.mapstruct.ReportingPolicy;

@Mapper(unmappedTargetPolicy = ReportingPolicy.IGNORE)
public interface CompanyMapper {

  @Mappings({
    @Mapping(target = "company", source = "companyName"),
    @Mapping(target = "companyId", source = "id")
  })
  public abstract SecCompany modelToDomain(Company company);

  @Mappings({
    @Mapping(target = "companyName", source = "company"),
    @Mapping(target = "id", source = "companyId")
  })
  public abstract Company domainToModel(SecCompany secCompany);
}
