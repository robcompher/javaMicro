/*
FILE : SummaryRoleSearchCriteria.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.query.specification;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * RoleSearchCriteria to be used in the role service for fetching SecRole objects
 *
 * @author dt70033
 */
@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
public class SummaryRoleSearchCriteria {
  String roleType;
  String roleName;
  String primaryPermit;
  String secondaryPermit;
  Long lobId;
  String active;
}
