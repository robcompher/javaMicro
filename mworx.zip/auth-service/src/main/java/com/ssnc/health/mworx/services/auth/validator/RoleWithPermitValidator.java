/*
 * FILE : RoleWithPermitValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.Permit;
import com.ssnc.health.mworx.services.auth.api.model.Role;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import java.util.List;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.CollectionUtils;

/**
 * Custom Validator to check if valid permits are passed while creating / updating a role
 *
 * @author dt75546
 */
public class RoleWithPermitValidator implements ConstraintValidator<ValidRuleset, Role> {

  @Autowired private SecPermitRepository permitRepository;

  @Override
  public boolean isValid(Role role, ConstraintValidatorContext context) {

    List<Permit> permits = role.getPermits();
    if (CollectionUtils.isEmpty(permits)) {
      return true;
    }

    return permits.stream()
        .allMatch(
            permit ->
                permit.getId() != null
                    ? permitRepository.findById(permit.getId()).isPresent()
                    : permitRepository
                        .findByPermitPrimaryAndPermitSecondary(
                            permit.getPermitPrimary(), permit.getPermitSecondary())
                        .isPresent());
  }
}
