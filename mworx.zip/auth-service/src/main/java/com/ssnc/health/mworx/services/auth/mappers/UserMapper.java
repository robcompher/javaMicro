/*
 * FILE : UserMapper.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.mappers;

import com.ssnc.health.core.common.utils.DateMapper;
import com.ssnc.health.mworx.services.auth.api.model.AddUserRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserContactRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserContactResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserSearchCriteria;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserContact;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

@Mapper(
    imports = {DateMapper.class},
    componentModel = "spring")
public interface UserMapper {

  @Mapping(target = "username", source = "userName")
  @Mapping(
      target = "effDate",
      expression = "java(new DateMapper().asDate(addUserRequest.getEffDate()))")
  @Mapping(
      target = "birthDate",
      expression = "java(new DateMapper().asDate(addUserRequest.getBirthDate()))")
  @Mapping(
      target = "termDate",
      expression = "java(new DateMapper().asDate(addUserRequest.getTermDate()))")
  public abstract UserBasic toUserBasicFromAddUserRequest(AddUserRequest addUserRequest);

  @Mapping(target = "username", source = "userName")
  @Mapping(
      target = "effDate",
      expression = "java(new DateMapper().asDate(userRequest.getEffDate()))")
  @Mapping(
      target = "birthDate",
      expression = "java(new DateMapper().asDate(userRequest.getBirthDate()))")
  @Mapping(
      target = "termDate",
      expression = "java(new DateMapper().asDate(userRequest.getTermDate()))")
  public abstract UserBasic toUserBasicFromUserRequest(UserRequest userRequest);

  @Mapping(target = "userName", source = "userBasic.username")
  @Mapping(target = "userId", source = "userBasic.userId")
  @Mapping(
      target = "effDate",
      expression = "java(new DateMapper().asLocalDate(userBasic.getEffDate()))")
  @Mapping(
      target = "birthDate",
      expression = "java(new DateMapper().asLocalDate(userBasic.getBirthDate()))")
  @Mapping(
      target = "termDate",
      expression = "java(new DateMapper().asLocalDate(userBasic.getTermDate()))")
  public abstract UserResponse toUserResponseFromUserBasic(
      UserBasic userBasic, UserLogin userLogin);

  @Mapping(target = "username", source = "userName")
  public abstract UserBasic toUserBasic(UserSearchCriteria userSearchCriteria);

  @Mapping(target = "userName", source = "username")
  public abstract UserNameByCriteriaResponse toUserNameByCriteriaResponseFromUserBasic(
      UserBasic userBasic);

  @Mapping(target = "contactId", source = "userContact.contactId")
  @Mapping(target = "contactInfo", source = "userContact.contactInfo")
  @Mapping(target = "contactType", source = "userContact.contactType")
  @Mapping(target = "prefer", source = "userContact.prefer")
  public abstract UserContact toUserContactFromUserContactRequest(
      UserContactRequest userContactRequest);

  public abstract UserContactResponse fromUserContactToUserContactResponse(UserContact userContact);
}
