/*
 * FILE : AppUser.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.security;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import lombok.Getter;
import lombok.Setter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

@Getter
@Setter
public class AppUser implements UserDetails {
  private static final long serialVersionUID = 2502125793935205325L;

  private Long userId;
  private String username;
  private String password;
  private boolean accountNonExpired;
  private boolean accountNonLocked;
  private boolean credentialsNonExpired;
  private boolean enabled;
  private transient Optional<SecRole> role;
  private long noOfDaysToPasswordExpire;
  private String firstName;
  private String lastName;
  private List<Long> lineOfBusinesses;
  private Long currentLobId;
  private String currentOrganizationName;
  private String currentLobCategoryName;
  private String currentLobName;
  private Long currentOrganizationId;
  private Date effDate;

  private static final String PERMIT_DEFINITION = "PERMIT_%s_%s";

  @Override
  public Collection<? extends GrantedAuthority> getAuthorities() {

    List<GrantedAuthority> authorities = new ArrayList<>();
    // Password expired for this User. Only Change Password Permit is set.
    if (getNoOfDaysToPasswordExpire() < 0) {
      SimpleGrantedAuthority changePasswordAuthority =
          new SimpleGrantedAuthority(String.format(PERMIT_DEFINITION, "USER", "CHANGE_PASSWORD"));
      authorities.add(changePasswordAuthority);
      changePasswordAuthority =
          new SimpleGrantedAuthority(String.format(PERMIT_DEFINITION, "METADATA_LOB", "VIEW"));
      authorities.add(changePasswordAuthority);

      return authorities;
    }

    if (role.isPresent()) {
      SecRole securityRole = role.get();
      authorities.add(
          new SimpleGrantedAuthority(
              String.format("ROLE_%s_%s", securityRole.getRoleType(), securityRole.getRoleName())));
      if (currentLobId == null) {
        SimpleGrantedAuthority changePasswordAuthority =
            new SimpleGrantedAuthority(String.format(PERMIT_DEFINITION, "METADATA_LOB", "VIEW"));
        authorities.add(changePasswordAuthority);
      }

      List<RoleLobPermit> roleLobPermits = securityRole.getRoleLobPermits();
      Optional.ofNullable(roleLobPermits).orElseGet(ArrayList::new).stream()
          .filter(
              permit ->
                  (permit.getLobId() == null || permit.getLobId().equals(getCurrentLobId()))
                      && (permit.getActive() == null || permit.getActive().equalsIgnoreCase("Y"))
                      && (permit.getSecPermit().getActive() == null
                          || permit.getSecPermit().getActive().equalsIgnoreCase("Y")))
          .map(
              p ->
                  new SimpleGrantedAuthority(
                      String.format(
                          PERMIT_DEFINITION,
                          p.getSecPermit().getPermitPrimary(),
                          p.getSecPermit().getPermitSecondary())))
          .forEach(authorities::add);
    }
    return authorities;
  }
}
