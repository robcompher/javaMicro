/*
 * FILE : PermitServiceImpl.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import java.util.List;
import java.util.Optional;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PermitServiceImpl implements PermitService {

  private static final String IN_GET_PERMIT_BY_ID = "In Get permit by id";
  private static final String WITHIN_GET_ALL_PERMITS = "Within getAllPermits";
  @Autowired SecPermitRepository permitRepository;
  private static final Logger LOG = LogManager.getLogger(PermitServiceImpl.class);

  @Override
  public List<SecPermit> getAllPermits(Boolean includeInactive) {
    LOG.info(WITHIN_GET_ALL_PERMITS);
    if (Boolean.TRUE.equals(includeInactive)) {
      return permitRepository.findAll();
    } else {
      return permitRepository.getAllActivePermits();
    }
  }

  @Override
  public Optional<SecPermit> getPermitById(Long id) {
    LOG.info(IN_GET_PERMIT_BY_ID, id);
    return permitRepository.findById(id);
  }
}
