/*
FILE : UserService.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserContact;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.core.userdetails.UserDetails;

/** Created by dt75546 on 1/23/2020. */
public interface UserService {

  /**
   * returns a user object with security information based on the username.
   *
   * @param userName String representing the username
   * @return User object containing data. or null if the user is not found.
   */
  UserDetails loadUserByUserName(final String userName);

  /**
   * Returns all eligible users based on user search criteria like first name, last name, user name,
   * loggedInUsers and pageable object.
   *
   * @param userBasic
   * @param pageable
   * @param loggedInUsers
   * @return Page object with total record count, page count and users.
   */
  Page<UserBasic> findUsers(UserBasic userBasic, Pageable pageable, boolean loggedInUsers);

  UserBasic addUser(UserBasic userBasic, String password);

  /**
   * Change password will create the new userlogin records based on passwordhistorylimit
   *
   * @param userBasic
   * @param password
   * @return
   */
  UserBasic changePassword(UserBasic userBasic, String password);

  UserBasic updateUser(UserBasic userBasic);

  void addUserContact(UserBasic userBasic, UserContact userContact);

  void removeUserContact(UserBasic userBasic, UserContact userContact);

  Optional<UserBasic> getUser(String userName);

  Optional<UserBasic> getUserById(Long id);

  void updateUserLogin(com.ssnc.health.mworx.services.auth.model.UserLogin useLogin);

  Optional<UserLogin> getUserLogin(UserBasic userBasic);

  /**
   * Get the logged User from SercurityContextHolder
   *
   * @return UserBasic Logged in User
   */
  Optional<UserBasic> getUser();

  /** Get user info based on search criteria */
  List<UserBasic> getUserBySearchCriteria(UserNameByCriteriaRequest userNameByCriteriaRequest);

  /** Update terminate date based on user account locked/unlocked */
  public void updateTerminateDate(UserBasic userBasic, String locked);

  /** Get all permits based on username and lobId */
  List<SecPermit> getAllSecPermits(Optional<Long> lobId);

  /**
   * Delete User.
   *
   * @param userName - User userName.
   * @return true if there exists User with userName.
   */
  boolean deleteUser(String userName);

  boolean isValidLockUnLockUserOperation(String userName, String locked);
}
