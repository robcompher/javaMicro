/*
 * FILE : ChangePasswordValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */

package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.MyProfilePasswordRequest;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.security.core.context.SecurityContextHolder;

public class MyProfilePasswordHistoryValidator extends BaseAuthValidator
    implements ConstraintValidator<ValidRuleset, MyProfilePasswordRequest> {

  /** Validate not to select a password from password history. */
  @Override
  public boolean isValid(
      MyProfilePasswordRequest changePasswordRequest, ConstraintValidatorContext context) {

    return isPasswordNotInHistory(
        SecurityContextHolder.getContext().getAuthentication().getName(),
        changePasswordRequest.getNewPassword());
  }
}
