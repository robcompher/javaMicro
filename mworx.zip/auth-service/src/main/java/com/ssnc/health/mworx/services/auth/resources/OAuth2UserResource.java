/*
 * FILE : OAuth2UserResource.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.resources;

import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import com.ssnc.health.mworx.services.auth.service.UserService;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

/** Created by DT214743 on 1/14/2020. */
@RestController
@Hidden
public class OAuth2UserResource {

  @Autowired private UserService userService;

  @Operation(
      summary = "userinfo",
      description = "Return user information along with autorities",
      tags = {"user"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Returns authenticated user information",
            content =
                @Content(
                    schema = @Schema(name = "UserInfo", implementation = UserInfoResponse.class),
                    examples = {
                      @ExampleObject(
                          value =
                              "{\"sub\": \"username\", \"firstName\": \"first name\", \"lastName\": \"last name\", \"authorities\": [{\"authority\": \"ROLE_Admin\"}, {\"authority\": \"PERMIT_MEMBER_ADD\"}]}")
                    }))
      })
  @GetMapping(value = "/oauth/userinfo", produces = "application/json; charset=UTF-8")
  @ResponseBody
  public UserInfoResponse userInfo(Authentication auth) {
    if (auth != null) {
      UserInfoResponse response = new UserInfoResponse();
      response.setSub(auth.getName());

      if (!(auth instanceof AnonymousAuthenticationToken)) {
        AppUser appUser = (AppUser) userService.loadUserByUserName(auth.getName());
        if (appUser != null) {
          response.setFirstName(appUser.getFirstName());
          response.setLastName(appUser.getLastName());
          response.setNoOfDaysToPasswordExpire(appUser.getNoOfDaysToPasswordExpire());
          response.setLineOfBusinesses(appUser.getLineOfBusinesses());
        }
        response.setCurrentLobId(
            (((Jwt) ((JwtAuthenticationToken) auth).getPrincipal()).getClaim("currentLobId")));
        response.setCurrentLobName(
            (((Jwt) ((JwtAuthenticationToken) auth).getPrincipal()).getClaim("currentLobName")));
        response.setCurrentLobCategoryName(
            (((Jwt) ((JwtAuthenticationToken) auth).getPrincipal())
                .getClaim("currentLobCategoryName")));
        response.setCurrentOrganizationName(
            (((Jwt) ((JwtAuthenticationToken) auth).getPrincipal())
                .getClaim("currentOrganizationName")));
        response.setCurrentOrganizationId(
            (((Jwt) ((JwtAuthenticationToken) auth).getPrincipal())
                .getClaim("currentOrganizationId")));
        response.setAuthorities(auth.getAuthorities());
      }
      return response;
    }
    return null;
  }

  @Operation(
      summary = "userlogout",
      description = "Log out action",
      tags = {"user"})
  @ApiResponses(
      value = {
        @ApiResponse(
            responseCode = "200",
            description = "Log out action",
            content =
                @Content(
                    schema = @Schema(name = "UserInfo", implementation = UserInfoResponse.class),
                    examples = {
                      @ExampleObject(
                          value =
                              "{\"sub\": \"username\", \"firstName\": \"first name\", \"lastName\": \"last name\", \"authorities\": [{\"authority\": \"ROLE_Admin\"}, {\"authority\": \"PERMIT_MEMBER_ADD\"}]}")
                    }))
      })
  @PostMapping(value = "/oauth/logout", produces = "application/json; charset=UTF-8")
  @ResponseBody
  public void logout() {
    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
    if (!(auth instanceof AnonymousAuthenticationToken) && auth instanceof JwtAuthenticationToken) {
      Optional<UserBasic> userBasic = userService.getUser();
      Optional<UserLogin> activeUserLogin =
          userService.getUserLogin(userBasic.isPresent() ? userBasic.get() : new UserBasic());
      if (activeUserLogin.isPresent()) {
        activeUserLogin.get().setLastLogout(new Date());
        userService.updateUserLogin(activeUserLogin.get());
      }
    }
  }

  @Getter
  @Setter
  @NoArgsConstructor
  class UserInfoResponse {
    private String sub;
    private String firstName;
    private String lastName;
    private long noOfDaysToPasswordExpire;
    List<Long> lineOfBusinesses;
    Long currentLobId;
    String currentLobName;
    String currentLobCategoryName;
    String currentOrganizationName;
    Long currentOrganizationId;
    private Collection<? extends GrantedAuthority> authorities;
  }
}
