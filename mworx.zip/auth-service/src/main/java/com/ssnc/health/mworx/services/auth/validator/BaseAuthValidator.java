/*
 * FILE : BaseAuthValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */

package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.service.UserService;
import com.ssnc.health.mworx.services.auth.validator.predicates.UserLoginPredicate;
import java.util.Optional;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.stereotype.Component;

/**
 * Implements Password History Validation.
 *
 * @author dt76103
 */
@Component
public abstract class BaseAuthValidator {

  @Autowired private DelegatingPasswordEncoder passwordEncoder;
  @Autowired private UserService userService;

  /**
   * Validate not to use a password from password history.
   *
   * @param incomingUserName
   * @param incomingPassword
   * @return true when validation is successful
   */
  protected boolean isPasswordNotInHistory(String incomingUserName, String incomingPassword) {
    Optional<UserBasic> existingUser = userService.getUser(incomingUserName);
    return existingUser.isPresent()
        && existingUser.get().getUserLogins().stream()
            .noneMatch(
                UserLoginPredicate.passwordInCurrentRecord(incomingPassword, passwordEncoder));
  }

  /**
   * Validates current password, if exists, matches with the active password
   *
   * @param currentPassword
   * @return boolean true no currentPassword in the request or it matches the active password
   */
  protected boolean isCurrentPasswordValid(String currentPassword) {

    Optional<UserBasic> existingUser = userService.getUser();
    if (existingUser.isPresent()) {
      UserLogin userLogin = userService.getUserLogin(existingUser.get()).orElse(null);
      return (userLogin != null
          && StringUtils.isNotEmpty(userLogin.getPassword())
          && passwordEncoder.matches(currentPassword, userLogin.getPassword()));
    }
    return false;
  }
}
