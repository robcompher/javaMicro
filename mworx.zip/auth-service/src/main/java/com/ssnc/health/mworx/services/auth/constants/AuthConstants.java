/*
 * FILE : AuthConstants.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.constants;
/**
 * Declaring Constants which is used across Auth Services.
 *
 * @author dt224133
 */
public final class AuthConstants {

  public static final String PERMIT_USER_UPDATE = "hasAuthority('PERMIT_USER_UPDATE')";
  public static final String PERMIT_USER_VIEW = "hasAuthority('PERMIT_USER_VIEW')";
  public static final String ACTIVE_YES = "Y";
  public static final String SECURITY_PERMIT = "SECURITY";
  public static final String UPDATE_PERMIT = "UPDATE";
  public static final String USER_PERMIT = "USER";

  public final class Security {

    private Security() {}

    public static final String PERMIT_SECURITY_VIEW = "hasAuthority('PERMIT_SECURITY_VIEW')";
    public static final String PERMIT_SECURITY_UPDATE = "hasAuthority('PERMIT_SECURITY_UPDATE')";
  }
}
