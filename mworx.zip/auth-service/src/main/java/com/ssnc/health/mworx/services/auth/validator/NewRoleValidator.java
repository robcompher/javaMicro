/*
 * FILE : NewRoleValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.Role;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class NewRoleValidator implements ConstraintValidator<ValidRuleset, Role> {

  @Autowired private SecRoleRepository roleRepository;

  @Override
  public boolean isValid(Role role, ConstraintValidatorContext context) {

    // check if there exists role with same role type and role name in repository

    return !roleRepository
        .findByRoleTypeAndRoleName(role.getRoleType(), role.getRoleName())
        .isPresent();
  }
}
