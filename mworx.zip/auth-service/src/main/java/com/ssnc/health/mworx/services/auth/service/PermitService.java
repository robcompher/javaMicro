/*
 * FILE : PermitService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.model.SecPermit;
import java.util.List;
import java.util.Optional;

public interface PermitService {

  List<SecPermit> getAllPermits(Boolean includeInactive);

  Optional<SecPermit> getPermitById(Long id);
}
