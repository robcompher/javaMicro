/*
 * FILE : GenderIDValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.reactive.function.client.WebClientResponseException;

public class GenderIDValidator implements ConstraintValidator<ValidRuleset, UserRequest> {

  @Autowired private MetadataService metadataService;

  @Value("${metadata.category.gender}")
  String metaDataCategoryGender;

  @Override
  public boolean isValid(UserRequest userRequest, ConstraintValidatorContext context) {

    // will call metadata to verify that the gender id passed is a valid gender id in metadata
    try {
      Object category = metadataService.getListById(userRequest.getGender()).get("category");
      return category != null && category.toString().equalsIgnoreCase(metaDataCategoryGender);
    } catch (WebClientResponseException e) {
      return false;
    }
  }
}
