/*
 * FILE : SameUserContactTypeValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.UserContact;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.collections.CollectionUtils;

/**
 * Validating that when adding or updating a user you are not trying to create/update contacts with
 * the same contact type.
 *
 * @author rcompher
 */
public class SameUserContactTypeValidator
    implements ConstraintValidator<ValidRuleset, UserRequest> {

  @Override
  public boolean isValid(UserRequest userRequest, ConstraintValidatorContext context) {

    List<UserContact> userContacts = userRequest.getUserContacts();

    if (CollectionUtils.isEmpty(userContacts)) {
      return true;
    }
    // list of contact types
    List<Long> contactTypes =
        userContacts.stream().map(UserContact::getContactType).collect(Collectors.toList());
    // Creating a hash set if the size is different then know there are duplicates
    Set<Long> setContactTypes = new HashSet<>(contactTypes);
    return contactTypes.size() == setContactTypes.size();
  }
}
