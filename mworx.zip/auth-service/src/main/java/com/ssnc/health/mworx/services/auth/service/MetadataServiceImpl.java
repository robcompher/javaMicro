/*
 * FILE : MetadataServiceImpl.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import java.util.HashMap;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.BodyInserters;
import org.springframework.web.reactive.function.client.WebClient;

@Service
public class MetadataServiceImpl implements MetadataService {

  @Autowired WebClient webClient;

  @Value("${metadata.endpoint.LOBbyByNameAndOrg}")
  String metaDataEndpointNameAndOrg;

  @Value("${metadata.endpoint.LOBById}")
  String metaDataEndpointLobId;

  @Value("${metadata.endpoint.listLibById}")
  String metaDataEndpointListLibById;

  @SuppressWarnings("unchecked")
  @Override
  /** Will call metadata end points and return the Long ID from the response */
  public Long getLOBId(LOB lob) {
    Map<String, Object> requestMap = new ObjectMapper().convertValue(lob, Map.class);
    return Long.parseLong(
        callMetadata(metaDataEndpointNameAndOrg, requestMap).get("id").toString());
  }

  @Override
  /** Will call metadata listById end point and return the list item from the response */
  public Map<String, Object> getListById(Long id) {
    Map<String, Object> requestMap = new HashMap<>();
    requestMap.put("id", id);
    return callMetadata(metaDataEndpointListLibById, requestMap);
  }

  @Override
  /**
   * Will call metadata listById end point and return the lob information Will throw an exception if
   * invalid
   */
  public Map<String, Object> getLobInfoById(Long id) {
    Map<String, Object> requestMap = new HashMap<>();
    requestMap.put("id", id);
    return callMetadata(metaDataEndpointLobId, requestMap);
  }

  /**
   * Will call url passed and return the response object All metadata requests should call this
   * method
   *
   * @param url
   * @param body
   * @return response object
   */
  @SuppressWarnings("unchecked")
  private Map<String, Object> callMetadata(String url, Map<String, Object> body) {
    Map<String, Object> responseMap = new HashMap<>();
    responseMap =
        webClient
            .post()
            .uri(url)
            .body(BodyInserters.fromValue(body))
            .retrieve()
            .bodyToMono(responseMap.getClass())
            .block();
    return responseMap;
  }
}
