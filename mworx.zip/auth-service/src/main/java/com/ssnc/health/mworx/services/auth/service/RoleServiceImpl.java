/*
 * FILE : RoleServiceImpl.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.service;

import com.ssnc.health.mworx.services.auth.model.LnkSecPermit;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.PermitSearchNonAssociatedRoleSpecification;
import com.ssnc.health.mworx.services.auth.query.specification.RoleLobPermitSpecification;
import com.ssnc.health.mworx.services.auth.query.specification.RoleSpecification;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.repository.RoleLobPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class RoleServiceImpl implements RoleService {

  private static final String WITHIN_SAVE_UPDATE_ROLE = "Within save update role ";

  private static final String WITHIN_UPDATE_ROLE = "Within updateRole";

  private static final String IN_GET_ALL_ROLES = "In getAllRoles";

  @Autowired SecRoleRepository secRoleRepository;

  @Autowired SecPermitRepository permitRepository;
  @Autowired RoleLobPermitRepository roleLobPermitRepository;
  private static final Logger LOG = LogManager.getLogger(RoleServiceImpl.class);

  @Override
  public List<SecRole> getAllRoles(Pageable pageable, boolean includeInactive) {
    LOG.info(IN_GET_ALL_ROLES);
    if (includeInactive) {
      Page<SecRole> secRoles = secRoleRepository.findAll(pageable);
      return getSecRolesWithActiveRoleLobPermits(secRoles.getContent());
    } else {
      return getSecRolesWithActiveRoleLobPermits(secRoleRepository.getAllActiveRoles(pageable));
    }
  }

  @Override
  public Optional<SecRole> getRoleById(Long id) {
    return secRoleRepository.findById(id);
  }

  @Override
  public Optional<SecRole> getRoleByRoleTypeAndRoleName(String roleType, String roleName) {
    return secRoleRepository.findByRoleTypeAndRoleName(roleType, roleName);
  }

  @Override
  public List<RoleLobPermit> getRoleLobPermits(SecRole secRole) {

    return secRole.getRoleLobPermits().stream()
        .filter(roleLobPermit -> ("Y").equalsIgnoreCase(roleLobPermit.getActive()))
        .collect(Collectors.toList());
  }

  @Override
  /**
   * This will look to see if there is another existing permit that prevent it from deleting due to
   * implicit permissions Example: Role has AGE_UPDATE and AGE_VIEW access for AGE_UPDATE to work
   * AGE_VIEW has been designated as a required permission that is needed If I try to delete
   * AGE_VIEW it will return false since AGE_UPDATE is there You will have to delete AGE_UPDATE
   * first and then AGE_VIEW The reason why we can't automatically delete the parent group is
   * because it could have multiple items For example: AGE_UPDATE requires AGE_VIEW META_GROUP_VIEW
   * requires AGE_VIEW If I try remove AGE_VIEW it will return false because tied to both of them.
   * The application will not know if the user really wants to delete AGE_VIEW or delete either
   * AGE_UPDATE or META_GROUP_VIEW Ideally eventually the error message should return. Can't delete
   * because AGE_UPDATE and META_GROUP_VIEW are still there
   */
  public boolean verifyDeleteLobPermit(Long linkId) {
    RoleLobPermit roleLobPermit = findRoleLobPermit(linkId);
    // if invalid roleLobPermit return true Purpose is to find other permits not to
    // see if exists
    if (roleLobPermit == null) {
      return true;
    }
    List<LnkSecPermit> implicitPermits =
        roleLobPermit.getSecPermit().getLnkSecPermitsForImplicitPermitId();
    // if no linked permits return true
    if (CollectionUtils.isEmpty(implicitPermits)) {
      return true;
    }
    List<Long> implicits =
        implicitPermits.stream()
            .map(mapper -> mapper.getSecPermitByPermitId().getPermitId())
            .collect(Collectors.toList());
    // if any permit id's are already present for that lob id/role id then return
    // false
    return permitRepository
        .getActiveSecPermitsByRoleAndLOB(
            roleLobPermit.getSecRole().getRoleId(), roleLobPermit.getLobId())
        .stream()
        .noneMatch(secPermit -> implicits.contains(secPermit.getPermitId()));
  }

  @Override
  public RoleLobPermit findRoleLobPermit(Long linkId) {
    return roleLobPermitRepository.findById(linkId).orElse(null);
  }

  @Override
  public void deleteRoleLobPermit(Long linkId) {
    RoleLobPermit roleLobPermit = findRoleLobPermit(linkId);
    roleLobPermit.setActive("N");
    saveRoleLobPermit(roleLobPermit);
  }

  @Override
  public void saveRoleLobPermit(RoleLobPermit roleLobPermit) {
    roleLobPermitRepository.save(roleLobPermit);
  }

  @Override
  public void saveAllRoleLobPermit(List<RoleLobPermit> roleLobPermits) {
    if (CollectionUtils.isNotEmpty(roleLobPermits)) {
      roleLobPermitRepository.saveAll(roleLobPermits);
    }
  }

  @Override
  @Transactional
  public SecRole addRole(SecRole secRole) {
    getPermits(secRole);
    if (CollectionUtils.isNotEmpty(secRole.getRoleLobPermits())) {
      secRole.getRoleLobPermits().addAll(getImplicitPermissions(secRole, secRole));
      removeDuplicatePermits(secRole);
    }
    return secRoleRepository.save(secRole);
  }

  @Override
  public SecRole updateRole(SecRole secRole) {
    LOG.info(WITHIN_UPDATE_ROLE);
    SecRole returnRole = secRole;
    // get the role entity object from the database based on the roleType and
    // roleName
    Optional<SecRole> existingRole =
        secRole.getRoleId() == null
            ? getRoleByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName())
            : getRoleById(secRole.getRoleId());
    // set all existing permit roles as inactive. New ones be added in buildRole
    // only if
    // incoming permits are there
    if (existingRole.isPresent()) {
      returnRole = existingRole.get();
      // when the GUI just updates the roles and we want to let the existing permits
      // remain.
      if (CollectionUtils.isNotEmpty(secRole.getRoleLobPermits())) {
        getPermits(secRole);
        secRole.getRoleLobPermits().addAll(getImplicitPermissions(secRole, secRole));
        removeDuplicatePermits(secRole);
        if (CollectionUtils.isNotEmpty(returnRole.getRoleLobPermits())) {
          returnRole.getRoleLobPermits().stream()
              .forEach(roleLobPemit -> roleLobPemit.setActive("N"));
        }
      }
      buildRole(returnRole, secRole);
      return secRoleRepository.save(returnRole);
    }
    return returnRole;
  }

  // copy the data from one role to the other
  private void buildRole(SecRole existingRole, SecRole secRole) {
    existingRole.setRoleName(secRole.getRoleName());
    existingRole.setRoleType(secRole.getRoleType());
    existingRole.setDescription(secRole.getDescription());
    existingRole.setActive(secRole.getActive());
    existingRole.setEffDate(secRole.getEffDate());
    existingRole.setTermDate(secRole.getTermDate());
    existingRole.setDbRole(secRole.getDbRole());
    existingRole.setLegacySystemId(secRole.getLegacySystemId());
    existingRole.setAdditionalData(secRole.getAdditionalData());
    if (CollectionUtils.isNotEmpty(secRole.getRoleLobPermits())) {
      secRole.getRoleLobPermits().stream()
          .forEach(roleLobPermit -> roleLobPermit.setSecRole(existingRole));
      existingRole.getRoleLobPermits().addAll(secRole.getRoleLobPermits());
    }
  }

  private List<SecPermit> getPermits(SecRole secRole) {
    List<SecPermit> permits = new ArrayList<>();
    if (CollectionUtils.isNotEmpty(secRole.getRoleLobPermits())) {
      List<RoleLobPermit> oldList = secRole.getRoleLobPermits();
      Collections.copy(secRole.getRoleLobPermits(), oldList);
      secRole.setRoleLobPermits(new ArrayList<>());
      for (RoleLobPermit roleLobPermit : oldList) {
        // if id is there use it, otherwise use primary/secondary
        Optional<SecPermit> existingPermit =
            roleLobPermit.getSecPermit().getPermitId() != null
                ? permitRepository.findById(roleLobPermit.getSecPermit().getPermitId())
                : permitRepository.findByPermitPrimaryAndPermitSecondary(
                    roleLobPermit.getSecPermit().getPermitPrimary(),
                    roleLobPermit.getSecPermit().getPermitSecondary());
        if (existingPermit.isPresent()) {
          SecPermit permit = existingPermit.get();
          RoleLobPermit roleLobPermitNew = new RoleLobPermit();
          roleLobPermitNew.setSecRole(secRole);
          roleLobPermitNew.setSecPermit(permit);
          roleLobPermitNew.setActive("Y");
          roleLobPermitNew.setLobId(roleLobPermit.getLobId());
          secRole.getRoleLobPermits().add(roleLobPermitNew);
          roleLobPermitNew.setSecRole(secRole);
          permits.add(permit);
        }
      }
    }
    return permits;
  }

  private List<SecRole> getSecRolesWithActiveRoleLobPermits(List<SecRole> secRoleList) {
    List<SecRole> secRoles = new ArrayList<>();
    Iterator<SecRole> iterator = secRoleList.iterator();
    while (iterator.hasNext()) {
      SecRole secRole = iterator.next();
      secRole.setRoleLobPermits(getRoleLobPermits(secRole));
      secRoles.add(secRole);
    }
    return secRoles;
  }

  @Override
  public Page<SecRole> findRoleByCriteria(
      SummaryRoleSearchCriteria roleSearchCriteria, Pageable pageable) {
    return secRoleRepository.findAll(RoleSpecification.get(roleSearchCriteria), pageable);
  }

  private void removeDuplicatePermits(SecRole secRole) {
    // discard duplicate items sent
    Set<String> permitsAlreadyThere = new HashSet<>();
    secRole
        .getRoleLobPermits()
        .removeIf(
            rlp ->
                !permitsAlreadyThere.add(
                    rlp.getLobId()
                        + " "
                        + rlp.getSecRole().getRoleName()
                        + " "
                        + rlp.getSecRole().getRoleType()
                        + " "
                        + rlp.getSecPermit().getPermitPrimary()
                        + " "
                        + rlp.getSecPermit().getPermitSecondary()));
  }

  private List<RoleLobPermit> getImplicitPermissions(SecRole secRole, SecRole existingRole) {
    List<RoleLobPermit> lstImplicitPermitsToAdd = new ArrayList<>();
    if (!CollectionUtils.isEmpty(secRole.getRoleLobPermits())) {
      secRole.getRoleLobPermits().stream()
          .forEach(
              rlp -> {
                rlp.setSecRole(existingRole);
                // find by permit id if present otherwise find by primary/secondary
                rlp.setSecPermit(
                    rlp.getSecPermit().getPermitId() != null
                        ? permitRepository.findById(rlp.getSecPermit().getPermitId()).orElse(null)
                        : permitRepository
                            .findByPermitPrimaryAndPermitSecondary(
                                rlp.getSecPermit().getPermitPrimary(),
                                rlp.getSecPermit().getPermitSecondary())
                            .orElse(null));
                rlp.setActive("Y");
                // add implicit permits
                if (!CollectionUtils.isEmpty(rlp.getSecPermit().getLnkSecPermitsForPermitId())) {
                  lstImplicitPermitsToAdd.addAll(
                      rlp.getSecPermit().getLnkSecPermitsForPermitId().stream()
                          .map(
                              permit -> {
                                RoleLobPermit newrlp = new RoleLobPermit();
                                newrlp.setLobId(rlp.getLobId());
                                newrlp.setActive("Y");
                                newrlp.setSecPermit(permit.getSecPermitByImplicitPermitId());
                                newrlp.setSecRole(rlp.getSecRole());
                                return newrlp;
                              })
                          .collect(Collectors.toList()));
                }
              });
    }
    return lstImplicitPermitsToAdd;
  }

  @Override
  public SecRole saveUpdatedPermits(SecRole secRole) {
    LOG.info(WITHIN_SAVE_UPDATE_ROLE, secRole.getRoleName());
    Optional<SecRole> existingRole =
        secRole.getRoleId() == null
            ? getRoleByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName())
            : getRoleById(secRole.getRoleId());

    if (existingRole.isPresent()) {
      // variable will store all the implicit permits that needs to be added
      // duplicated records will removed at the end

      secRole.getRoleLobPermits().addAll(getImplicitPermissions(secRole, existingRole.get()));
      // discard duplicate items sent
      removeDuplicatePermits(secRole);

      // if permit already exists then remove (exists based off active, lobid, and
      // permitId
      final List<RoleLobPermit> lstExistingPerimt = getRoleLobPermits(existingRole.get());
      secRole.setRoleLobPermits(
          secRole.getRoleLobPermits().stream()
              .filter(
                  permit ->
                      lstExistingPerimt.stream()
                          .noneMatch(
                              permit2 ->
                                  StringUtils.equals(permit.getActive(), permit2.getActive())
                                      && permit.getLobId().compareTo(permit2.getLobId()) == 0
                                      && permit
                                              .getSecPermit()
                                              .getPermitId()
                                              .compareTo(permit2.getSecPermit().getPermitId())
                                          == 0))
              .collect(Collectors.toList()));
      // save just the permits
      saveAllRoleLobPermit(secRole.getRoleLobPermits());
      // Update the SecRole with existing Permits
      secRole.getRoleLobPermits().addAll(lstExistingPerimt);
    }
    return secRole;
  }

  @Override
  public Page<RoleLobPermit> findAssociatedPermitsByCriteria(
      SummaryPermitSearchCriteria permitSearchCriteria, Pageable pageable) {
    return roleLobPermitRepository.findAll(
        RoleLobPermitSpecification.get(permitSearchCriteria), pageable);
  }

  @Override
  public Page<SecPermit> findNonAssociatedPermitsByCriteria(
      SummaryPermitSearchCriteria permitSearchCriteria, Pageable pageable) {
    return permitRepository.findAll(
        PermitSearchNonAssociatedRoleSpecification.get(permitSearchCriteria), pageable);
  }

  @Override
  public List<SecRole> getAllActiveRoles() {
    return secRoleRepository.getAllActiveRoles();
  }

  @Override
  public boolean deleteRoleById(Long Id) {
    Optional<SecRole> secRole = secRoleRepository.findById(Id);
    if (secRole.isPresent()) {
      secRole.get().setActive("N");
      secRoleRepository.save(secRole.get());
    }
    return secRole.isPresent();
  }
}
