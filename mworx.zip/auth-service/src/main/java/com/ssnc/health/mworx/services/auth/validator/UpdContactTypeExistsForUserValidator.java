/*
 * FILE : UpdContactTypeExistsForUserValidator.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.validator;

import com.ssnc.health.core.common.validation.validator.ValidRuleset;
import com.ssnc.health.mworx.services.auth.api.model.UserContactRequest;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserContact;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import java.util.Optional;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * Validating the contact type already exists for user.
 *
 * <p>Used by updateUserContact ruleset, userContact.contactType field_name.
 *
 * @author dt64028
 */
public class UpdContactTypeExistsForUserValidator
    implements ConstraintValidator<ValidRuleset, UserContactRequest> {

  @Autowired private UserBasicRepository userBasicRepository;

  @Override
  public boolean isValid(
      UserContactRequest userContactRequest, ConstraintValidatorContext context) {
    if (StringUtils.isBlank(userContactRequest.getUserName())) {
      return true;
    }
    Optional<UserBasic> userBasic =
        userBasicRepository.findByUsernameIgnoreCase(userContactRequest.getUserName());
    // if user doesn't exist, then no need to validate contact types because another validation
    // is checking user existing.
    if (!userBasic.isPresent()) {
      return true;
    }
    Optional<UserContact> userContactOptional =
        userBasic.get().getUserContacts().stream()
            .filter(
                uc ->
                    uc.getContactType()
                        .equals(userContactRequest.getUserContact().getContactType()))
            .findFirst();
    return !(userContactOptional.isPresent()
        && userContactRequest.getUserContact().getContactId() != null
        && !userContactOptional
            .get()
            .getContactId()
            .equals(userContactRequest.getUserContact().getContactId()));
  }
}
