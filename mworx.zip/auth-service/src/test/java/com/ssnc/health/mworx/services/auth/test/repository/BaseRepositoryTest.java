/*
 * FILE : BaseResourceTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.AuthServiceApplication;
import com.ssnc.health.mworx.services.auth.test.config.TestConfiguration;
import com.ssnc.health.services.test.common.EmbeddedDatabaseTest;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@EmbeddedDatabaseTest(
    classes = {AuthServiceApplication.class, TestConfiguration.class},
    beanName = "user-management-ds")
public class BaseRepositoryTest {
  @Test
  void test() {
    Assertions.assertNotNull(this);
  }
}
