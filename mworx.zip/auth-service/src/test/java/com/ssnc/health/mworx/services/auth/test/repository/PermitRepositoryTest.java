package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.model.LnkSecPermit;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.repository.RoleLobPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This is to test PermitRepository Class
 *
 * @author DT224621
 */
public class PermitRepositoryTest extends BaseRepositoryTest {
  @Autowired private SecPermitRepository permitRepository;
  @Autowired private UserBasicRepository userBasicRepository;
  @Autowired private SecRoleRepository roleRepository;
  @Autowired private RoleLobPermitRepository roleLobPermitRepository;
  public static final String PERMIT_PRIMARY = "Super Role";
  public static final String PERMIT_SECONDARY = "Super Role";
  public static final String PERMIT_SUB_PRIMARY = "SUB Role";
  public static final String PERMIT_SUB_SECONDARY = "SUB Role";
  public static final String STRING_VALUE = "DummyVal";

  @Test
  public void testAll() {

    // inserting data into db
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    permit.setCreateBy(1L);
    permit.setCreated(new Date());
    permit.setDescription(STRING_VALUE);
    permit.setLegacySystemId(STRING_VALUE);
    permit.setPermitAdditional(STRING_VALUE);
    permit.setReadOnly("Y");
    permit.setUpdateBy(1L);
    permit.setUpdated(new Date());
    permit = permitRepository.save(permit);
    permit.setRoleLobPermits(new ArrayList<>());
    RoleLobPermit role = new RoleLobPermit();
    role.setActive("Y");
    role.setSecPermit(permit);

    SecRole secRole = new SecRole();
    secRole.setRoleName(STRING_VALUE);
    secRole.setRoleType(STRING_VALUE);
    secRole.setEffDate(new Date());
    role.setSecRole(secRole);
    permit.getRoleLobPermits().add(role);
    permit = permitRepository.save(permit);
    Assertions.assertNotNull(permit.getRoleLobPermits());
    permit.getRoleLobPermits().remove(permit.getRoleLobPermits().get(0));
    permit = permitRepository.save(permit);
    Assertions.assertTrue(permit.getRoleLobPermits().isEmpty());
    // testFindByPermitPrimaryAndPermitSecondary

    Optional<SecPermit> permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);
    Assertions.assertTrue(permitResult.isPresent(), "Repository result should be present");
    Assertions.assertTrue(
        permitRepository.count() > 1, "Repository result count should be greater than one ");
    Assertions.assertEquals(PERMIT_PRIMARY, permitResult.get().getPermitPrimary());
    Assertions.assertEquals(PERMIT_SECONDARY, permitResult.get().getPermitSecondary());
    Assertions.assertEquals(STRING_VALUE, permitResult.get().getDescription());
    Assertions.assertEquals(STRING_VALUE, permitResult.get().getLegacySystemId());
    Assertions.assertEquals(STRING_VALUE, permitResult.get().getPermitAdditional());
    Assertions.assertEquals("Y", permitResult.get().getReadOnly());
    Assertions.assertNotNull(permitResult.get().getCreateBy());
    Assertions.assertNotNull(permitResult.get().getCreated());
    Assertions.assertNotNull(permitResult.get().getUpdateBy());
    Assertions.assertNotNull(permitResult.get().getUpdated());
    // testgetAllActivePermits
    List<SecPermit> permitResultList = permitRepository.getAllActivePermits();
    Assertions.assertNotNull(permitResultList);
    // at least one entry should be present in repository
    Assertions.assertTrue(
        permitResultList.size() > 1, "Result List size should be greater than one ");
  }

  @Test
  public void testAllSecPermits() {
    UserBasic userBasic = new UserBasic();
    userBasic.setUsername("authUser");
    userBasic.setFirstName("authUser");
    userBasic.setLastName("authUser");
    userBasic.setPrefix("auth");
    userBasic.setActive("Y");
    userBasic.setLocked("N");

    SecPermit permit = new SecPermit();
    permit.setPermitPrimary("Security");
    permit.setPermitSecondary("View");
    permit.setActive("Y");
    permit.setCreateBy(1L);
    permit.setCreated(new Date());
    permit.setDescription(STRING_VALUE);
    permit.setLegacySystemId(STRING_VALUE);
    permit.setPermitAdditional(STRING_VALUE);
    permit.setReadOnly("Y");
    permit.setUpdateBy(1L);
    permit.setUpdated(new Date());
    permit.setPermitId(1L);
    permit.setRoleLobPermits(new ArrayList<>());

    SecRole secRole = new SecRole();
    secRole.setRoleName("AuthRole");
    secRole.setRoleType("AuthType");
    secRole.setEffDate(new Date());
    secRole.setRoleId(1L);
    SecRole role2 = roleRepository.save(secRole);
    userBasic.setSecRole(role2);
    userBasicRepository.save(userBasic);
    SecPermit permit2 = permitRepository.save(permit);

    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setLinkId(1L);
    lobPermit.setLobId(1L);
    lobPermit.setActive("Y");
    lobPermit.setSecPermit(permit2);
    lobPermit.setSecRole(role2);
    ArrayList<RoleLobPermit> lstROP = new ArrayList<>();
    lstROP.add(lobPermit);
    secRole.setRoleLobPermits(lstROP);
    permit.setRoleLobPermits(lstROP);
    roleRepository.save(secRole);
    permitRepository.save(permit);

    List<SecPermit> permitResultList =
        permitRepository.getAllSecPermits("authUser", Optional.of(1L));
    Assertions.assertNotNull(permitResultList);
    Assertions.assertTrue(permitResultList.size() > 0);
    Assertions.assertEquals("Security", permitResultList.get(0).getPermitPrimary());
    List<SecPermit> permitNoUserResultList =
        permitRepository.getAllSecPermits("NoUser", Optional.of(1L));
    Assertions.assertFalse(permitNoUserResultList.size() > 0);
  }

  @Test
  public void testLinkSecPermit() {
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("Y");
    permit.setCreateBy(1L);
    permit.setCreated(new Date());
    permit.setDescription(STRING_VALUE);
    permit.setLegacySystemId(STRING_VALUE);
    permit.setPermitAdditional(STRING_VALUE);
    permit.setReadOnly("Y");
    permit.setUpdateBy(1L);
    permit.setUpdated(new Date());
    permit = permitRepository.save(permit);

    SecPermit subPermit = new SecPermit();
    subPermit.setPermitPrimary(PERMIT_SUB_PRIMARY);
    subPermit.setPermitSecondary(PERMIT_SUB_SECONDARY);
    subPermit.setActive("Y");
    subPermit.setCreateBy(1L);
    subPermit.setCreated(new Date());
    subPermit.setDescription(STRING_VALUE);
    subPermit.setLegacySystemId(STRING_VALUE);
    subPermit.setPermitAdditional(STRING_VALUE);
    subPermit.setReadOnly("Y");
    subPermit.setUpdateBy(1L);
    subPermit.setUpdated(new Date());
    subPermit = permitRepository.save(subPermit);

    LnkSecPermit lnkSecPermit = new LnkSecPermit();
    lnkSecPermit.setSecPermitByImplicitPermitId(subPermit);
    lnkSecPermit.setSecPermitByPermitId(permit);
    lnkSecPermit.setUpdateBy(1L);
    lnkSecPermit.setUpdated(new Date());
    lnkSecPermit.setCreateBy(1L);
    lnkSecPermit.setCreated(new Date());
    permit.setLnkSecPermitsForPermitId(new ArrayList<>());

    permit.getLnkSecPermitsForPermitId().add(lnkSecPermit);
    permit = permitRepository.save(permit);
    lnkSecPermit.setLnksecpermitId(1L);
    SecPermit permitSearch =
        permitRepository.findById(permit.getPermitId()).orElse(new SecPermit());
    Assertions.assertNotNull(permitSearch.getPermitId());
    Assertions.assertEquals(1, permitSearch.getLnkSecPermitsForPermitId().size());
    Assertions.assertNotNull(
        permitSearch.getLnkSecPermitsForPermitId().get(0).getSecPermitByPermitId());
    Assertions.assertEquals(
        permit.getPermitPrimary(),
        permitSearch
            .getLnkSecPermitsForPermitId()
            .get(0)
            .getSecPermitByPermitId()
            .getPermitPrimary());
    Assertions.assertEquals(
        subPermit.getPermitPrimary(),
        permitSearch
            .getLnkSecPermitsForPermitId()
            .get(0)
            .getSecPermitByImplicitPermitId()
            .getPermitPrimary());
    Assertions.assertNotNull(permitSearch.getLnkSecPermitsForImplicitPermitId());
    permitSearch
        .getLnkSecPermitsForPermitId()
        .remove(permitSearch.getLnkSecPermitsForPermitId().get(0));
    permit.setLnkSecPermitsForImplicitPermitId(new ArrayList<>());
    permit.getLnkSecPermitsForImplicitPermitId().add(lnkSecPermit);
    permit.getLnkSecPermitsForImplicitPermitId().remove(lnkSecPermit);
    Assertions.assertEquals(permitSearch.getActive(), permit.getActive());
  }

  @Test
  public void testGettingImplicitPermissionsByRole() {
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("Y");
    permit.setCreateBy(1L);
    permit.setCreated(new Date());
    permit.setDescription(STRING_VALUE);
    permit.setLegacySystemId(STRING_VALUE);
    permit.setPermitAdditional(STRING_VALUE);
    permit.setReadOnly("Y");
    permit.setUpdateBy(1L);
    permit.setUpdated(new Date());
    permit = permitRepository.save(permit);

    SecPermit subPermit = new SecPermit();
    subPermit.setPermitPrimary(PERMIT_SUB_PRIMARY);
    subPermit.setPermitSecondary(PERMIT_SUB_SECONDARY);
    subPermit.setActive("Y");
    subPermit.setCreateBy(1L);
    subPermit.setCreated(new Date());
    subPermit.setDescription(STRING_VALUE);
    subPermit.setLegacySystemId(STRING_VALUE);
    subPermit.setPermitAdditional(STRING_VALUE);
    subPermit.setReadOnly("Y");
    subPermit.setUpdateBy(1L);
    subPermit.setUpdated(new Date());
    subPermit = permitRepository.save(subPermit);

    LnkSecPermit lnkSecPermit = new LnkSecPermit();
    lnkSecPermit.setSecPermitByImplicitPermitId(subPermit);
    lnkSecPermit.setSecPermitByPermitId(permit);
    lnkSecPermit.setUpdateBy(1L);
    lnkSecPermit.setUpdated(new Date());
    lnkSecPermit.setCreateBy(1L);
    lnkSecPermit.setCreated(new Date());
    permit.setLnkSecPermitsForPermitId(new ArrayList<>());

    permit.getLnkSecPermitsForPermitId().add(lnkSecPermit);
    permit = permitRepository.save(permit);

    SecRole secRole = new SecRole();
    secRole.setRoleName(STRING_VALUE);
    secRole.setRoleType(STRING_VALUE);
    secRole.setEffDate(new Date());
    secRole = roleRepository.save(secRole);
    RoleLobPermit role = new RoleLobPermit();
    role.setActive("Y");
    role.setSecPermit(permit);
    role.setLobId(1L);
    role.setSecRole(secRole);
    roleLobPermitRepository.save(role);
    RoleLobPermit role2 = new RoleLobPermit();
    role2.setActive("Y");
    role2.setSecPermit(subPermit);
    role2.setLobId(1L);
    role2.setSecRole(secRole);

    roleLobPermitRepository.save(role2);
    Assertions.assertEquals(
        2, permitRepository.getActiveSecPermitsByRoleAndLOB(secRole.getRoleId(), 1L).size());
    // make sure collections are empty if sending invalid data
    Assertions.assertEquals(
        0, permitRepository.getActiveSecPermitsByRoleAndLOB(secRole.getRoleId() + 1L, 1L).size());
    Assertions.assertEquals(
        0, permitRepository.getActiveSecPermitsByRoleAndLOB(secRole.getRoleId(), 2L).size());
    Assertions.assertEquals(
        0, permitRepository.getActiveSecPermitsByRoleAndLOB(secRole.getRoleId() + 1L, 2L).size());
  }
}
