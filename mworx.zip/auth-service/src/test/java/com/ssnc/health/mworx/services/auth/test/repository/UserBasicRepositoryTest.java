/*
 * FILE : UserBasicRepositoryTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserContact;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.query.specification.UserSpecification;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;

/**
 * This is to test change password repository
 *
 * @author dt213321
 */
public class UserBasicRepositoryTest extends BaseRepositoryTest {

  @Autowired private UserBasicRepository userBasicRepository;

  @Autowired private DelegatingPasswordEncoder passwordEncoder;

  @Autowired private SecRoleRepository roleRepository;
  @Autowired private SecPermitRepository permitRepository;

  public static final String ROLE_NAME = "New Role";
  public static final String ROLE_TYPE = "Super Duper";
  public static final String PERMIT_PRIMARY = "Super Role";
  public static final String PERMIT_SECONDARY = "Super Role";

  private static final String MIDDLE_NAME_NEW = "middle name new";
  private static final String userName = "testUser";
  private static final String prefix = "Ms.";
  private static final String suffix = "awesome";
  private static final Long gender = 1L;
  private static final Date date = new Date();
  private static final String activeYes = "Y";
  private static final String lockedNo = "N";
  private static final Integer id = 10;
  private static final Long lobId = 1L;
  private String password = "t3stP@ssword";

  @Test
  public void testAll() {
    UserBasic userBasic = buildUserBasic();

    // Test data insertion
    userBasicRepository.save(userBasic);
    Optional<UserBasic> result =
        userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername());
    Assertions.assertNotNull(result);

    userBasic = result.get();
    Assertions.assertEquals(userName, userBasic.getUsername());
    Assertions.assertEquals(prefix, userBasic.getPrefix());
    Assertions.assertEquals(userName, userBasic.getFirstName());
    Assertions.assertEquals(userName, userBasic.getMiddleName());
    Assertions.assertEquals(userName, userBasic.getLastName());
    Assertions.assertEquals(suffix, userBasic.getSuffix());
    Assertions.assertEquals(gender, userBasic.getGender());
    Assertions.assertEquals(date, userBasic.getEffDate());
    Assertions.assertEquals(activeYes, userBasic.getActive());
    Assertions.assertEquals(lockedNo, userBasic.getLocked());
    Assertions.assertEquals(userName, userBasic.getAdditionalData());
    Assertions.assertEquals(date, userBasic.getBirthDate());
    Assertions.assertEquals(Integer.valueOf(id).toString(), userBasic.getInternalId());
    Assertions.assertEquals(Integer.valueOf(id).toString(), userBasic.getLegacySystemId());
    Assertions.assertEquals(userName, userBasic.getDescription());
    Assertions.assertEquals(id, userBasic.getManagerId());
    Assertions.assertEquals(userName, userBasic.getTitle());
    Assertions.assertEquals(1, userBasic.getUserLogins().size());
    Assertions.assertEquals(date, userBasic.getUserLogins().get(0).getLastLogin());
    Assertions.assertNotNull(userBasic.getUserLogins().get(0).getUpdateBy());
    Assertions.assertNotNull(userBasic.getUserLogins().get(0).getUpdated());
    Assertions.assertNotNull(userBasic.getUserLogins().get(0).getUserBasic());

    // retrieved pw doesn't match given means encoded

    Assertions.assertNotEquals(userBasic.getUserLogins().get(0).getPassword(), password);
    Assertions.assertEquals(ROLE_NAME, userBasic.getSecRole().getRoleName());
    Assertions.assertEquals(1, userBasic.getUserContacts().size());

    // Verifying user basic object update.
    userBasic.setMiddleName(MIDDLE_NAME_NEW);
    userBasic.getUserContacts().addAll(getUserContactsForUpdate());
    userBasic.getUserContacts().get(1).setUserBasic(userBasic);
    userBasic = userBasicRepository.save(userBasic);
    Assertions.assertEquals(ROLE_NAME, userBasic.getSecRole().getRoleName());
    Assertions.assertEquals(MIDDLE_NAME_NEW, userBasic.getMiddleName());
    Assertions.assertEquals(2, userBasic.getUserContacts().size());
    Assertions.assertNotNull(userBasic.getUserContacts().get(1).getUserBasic());
    Assertions.assertNotNull(userBasic.getUserContacts().get(1).getAdditionalData());
    // test removing add works
    UserContact uc = userBasic.getUserContacts().get(1);
    userBasic.getUserContacts().remove(uc);
    Assertions.assertEquals(1, userBasic.getUserContacts().size());
    userBasic.getUserContacts().add(uc);
    Assertions.assertEquals(2, userBasic.getUserContacts().size());
    UserLogin ul = userBasic.getUserLogins().get(0);
    userBasic.getUserLogins().remove(ul);
    Assertions.assertEquals(0, userBasic.getUserLogins().size());
    userBasic.getUserLogins().add(ul);
    Assertions.assertEquals(1, userBasic.getUserLogins().size());
  }

  /**
   * Just test lock and unlock saves to database with Y and N Also test active Y or N is being saved
   */
  @Test
  public void testLockUnlock() {
    UserBasic userBasic = buildUserBasic();

    // Test data insertion
    userBasicRepository.save(userBasic);
    Optional<UserBasic> result =
        userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername());
    Assertions.assertNotNull(result);
    userBasic.setLocked("Y");
    userBasic.setActive("N");
    UserBasic userBasicResult = userBasicRepository.save(userBasic);
    Assertions.assertEquals("Y", userBasicResult.getLocked());
    Assertions.assertEquals("N", userBasicResult.getActive());
    userBasic.setLocked("N");
    userBasic.setActive("Y");
    userBasicResult = userBasicRepository.save(userBasic);
    Assertions.assertEquals("N", userBasicResult.getLocked());
    Assertions.assertEquals("Y", userBasicResult.getActive());
  }

  private UserBasic buildUserBasic() {

    UserBasic userBasic = new UserBasic();
    userBasic.setUsername(userName);
    userBasic.setPrefix(prefix);
    userBasic.setFirstName(userName);
    userBasic.setMiddleName(userName);
    userBasic.setLastName(userName);
    userBasic.setSuffix(suffix);
    userBasic.setGender(gender);
    userBasic.setEffDate(date);
    userBasic.setActive(activeYes);
    userBasic.setLocked(lockedNo);
    userBasic.setAdditionalData(userName);
    userBasic.setBirthDate(date);
    userBasic.setInternalId(Integer.valueOf(id).toString());
    userBasic.setLegacySystemId(Integer.valueOf(id).toString());
    userBasic.setDescription(userName);
    userBasic.setManagerId(id);
    userBasic.setTitle(userName);

    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(passwordEncoder.encode(password));
    userLogin.setCreated(date);
    userLogin.setUpdated(date);
    userLogin.setUpdateBy(1L);
    userLogin.setCreateBy(1L);
    userLogin.setLastLogin(date);
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    // Setting SecRole and userContacts.
    userBasic.setSecRole(getSecRole());
    userBasic.setUserContacts(getUserContacts());
    return userBasic;
  }

  private List<UserContact> getUserContacts() {
    List<UserContact> list = new ArrayList<>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info 1");
    userContact.setContactType(1L);
    list.add(userContact);
    return list;
  }

  private List<UserContact> getUserContactsForUpdate() {
    List<UserContact> list = new ArrayList<>();
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo("Contact info 2");
    userContact2.setContactType(2L);
    userContact2.setAdditionalData("data");
    list.add(userContact2);
    return list;
  }

  private SecRole getSecRole() {

    // inserting data into permit table
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    permitRepository.save(permit);
    Optional<SecPermit> permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);
    Assertions.assertTrue(permitResult.isPresent(), "Repository result should be present");
    SecRole role = new SecRole();
    role.setRoleName(ROLE_NAME);
    role.setRoleType(ROLE_TYPE);
    role.setEffDate(Calendar.getInstance().getTime());
    role.setEffDate(new Date());
    role = roleRepository.save(role);
    // associate permits to role
    RoleLobPermit rop = new RoleLobPermit();
    rop.setLobId(lobId);
    rop.setSecPermit(permitResult.get());
    rop.setSecRole(role);
    ArrayList<RoleLobPermit> lstROP = new ArrayList<>();
    lstROP.add(rop);
    role.setRoleLobPermits(lstROP);
    return roleRepository.save(role);
  }

  private UserNameByCriteriaRequest createUserNameByCriteriaRequest(
      Long id, String userName, String permitPrimary, String permitSecondary, LOB lob) {
    UserNameByCriteriaRequest criteriaRequest = new UserNameByCriteriaRequest();
    criteriaRequest.setUserId(id);
    criteriaRequest.setUserName(userName);
    criteriaRequest.setPermitPrimary(permitPrimary);
    criteriaRequest.setPermitSecondary(permitSecondary);
    criteriaRequest.setLob(lob);
    return criteriaRequest;
  }

  @Test
  @DisplayName("UserBasic SearchCriteria With All Attributes")
  void testUserSpecificatioSearch() {
    UserBasic userBasic = buildUserBasic();
    userBasic = userBasicRepository.save(userBasic);
    LOB lob = new LOB();
    lob.setLobId(lobId);
    UserNameByCriteriaRequest criteriaRequest =
        createUserNameByCriteriaRequest(
            userBasic.getUserId(), userName, PERMIT_PRIMARY, PERMIT_SECONDARY, lob);
    List<UserBasic> list =
        userBasicRepository.findAll(
            UserSpecification.getUserNameByCriteriaRequest(criteriaRequest));
    assertNotNull(list);
    assertEquals(1, list.size());
  }

  @Test
  @DisplayName("UserBasic SearchCriteria test like userName")
  void testUserSpecificatioUserNameLikeSearch() {
    UserBasic userBasic = buildUserBasic();
    userBasic = userBasicRepository.save(userBasic);
    LOB lob = new LOB();
    lob.setLobId(lobId);
    UserNameByCriteriaRequest criteriaRequest =
        createUserNameByCriteriaRequest(null, userName, null, null, lob);
    List<UserBasic> list =
        userBasicRepository.findAll(
            UserSpecification.getUserNameByCriteriaRequest(criteriaRequest));
    assertNotNull(list);
    assertEquals(1, list.size());
  }

  @Test
  @DisplayName("UserBasic SearchCriteria Builder Permit Like Search")
  void testUserSpecificatioPermitLikeSearch() {
    UserBasic userBasic = buildUserBasic();
    userBasic = userBasicRepository.save(userBasic);
    LOB lob = new LOB();
    lob.setLobId(lobId);
    UserNameByCriteriaRequest criteriaRequest =
        createUserNameByCriteriaRequest(
            userBasic.getUserId(), null, PERMIT_PRIMARY, PERMIT_SECONDARY, lob);
    List<UserBasic> list =
        userBasicRepository.findAll(
            UserSpecification.getUserNameByCriteriaRequest(criteriaRequest));
    assertNotNull(list);
    assertEquals(1, list.size());
  }

  @Test
  @DisplayName("UserBasic SearchCriteria Builder with No Match")
  void testUserSpecificatioPermitNoMatch() {
    UserBasic userBasic = buildUserBasic();
    userBasic = userBasicRepository.save(userBasic);
    LOB lob = new LOB();
    lob.setLobId(lobId);
    UserNameByCriteriaRequest criteriaRequest =
        createUserNameByCriteriaRequest(1L, "nouser", PERMIT_PRIMARY, PERMIT_SECONDARY, null);
    List<UserBasic> list =
        userBasicRepository.findAll(
            UserSpecification.getUserNameByCriteriaRequest(criteriaRequest));
    assertNotNull(list);
    assertEquals(0, list.size());
  }
}
