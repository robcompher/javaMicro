package com.ssnc.health.mworx.services.auth.test.utis;

import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import java.util.Date;

public class TestUtils {

  public static UserBasic buildUserBasic() {
    UserBasic userBasic = new UserBasic();
    userBasic.setUsername("testUser");
    userBasic.setFirstName("testUser");
    userBasic.setLastName("testUser");
    userBasic.setPrefix("testPrefix");
    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(String.format("{noop}%s", "testPassword"));
    userLogin.setCreated(new Date());
    userLogin.setUpdated(new Date());
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    return userBasic;
  }
}
