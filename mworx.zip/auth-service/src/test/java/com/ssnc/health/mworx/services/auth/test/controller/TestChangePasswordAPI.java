/*
FILE : TestChangePasswordAPI.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.mockito.Mockito.when;

import com.ssnc.health.core.common.error.ApiError;
import com.ssnc.health.mworx.services.auth.api.model.ChangePasswordRequest;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import com.ssnc.health.mworx.services.auth.service.UserService;
import com.ssnc.health.mworx.services.auth.test.utis.TestUtils;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "5000")
class TestChangePasswordAPI extends BaseResourceTest {

  private static String confirmPswdMsg =
      "The confirm password is blank or does not match with new  password.";

  @Autowired private WebTestClient webTestClient;

  @MockBean private UserService mockUserService;

  @MockBean private UserBasicRepository userBasicRepository;
  @MockBean private SecRoleRepository secRoleRepository;

  /** An user updates password if new and confirmPassword are the same. */
  @Test
  public void updatePassword() {
    UserBasic userBasic = TestUtils.buildUserBasic();
    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class)))
        .thenReturn(Optional.of(TestUtils.buildUserBasic()));

    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("testPassword0!");
    changePasswordRequest.setConfirmPassword("testPassword0!");

    EntityExchangeResult<String> userBasicResult =
        webTestClient
            .post()
            .uri("/api/user/changePassword")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertNotNull(userBasicResult);
    Assertions.assertEquals(
        "\"Successfully updated the password for User : "
            + changePasswordRequest.getUserName()
            + "\"",
        userBasicResult.getResponseBody());
  }

  @Test
  public void updatePasswordInvalidInput() {
    UserBasic userBasic = TestUtils.buildUserBasic();
    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class)))
        .thenReturn(Optional.of(TestUtils.buildUserBasic()));

    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("testPassword0!");
    changePasswordRequest.setConfirmPassword("testPassword@123");

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user/changePassword")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError);
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getField().equals("confirmPassword")));
  }

  /**
   * User gets invalid input errors when misses confirm password
   *
   * @throws Exception
   */
  @Test
  public void changePasswordInvalidInput() throws Exception {

    UserBasic userBasic = TestUtils.buildUserBasic();

    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));

    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("testPassword0!");
    changePasswordRequest.setConfirmPassword("");

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user/changePassword")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError);
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getField().equals("confirmPassword")));
  }

  /** User can not update password if new and confirmPassword are not the same. */
  @Test
  public void changePasswordNoMatchPasswords() {
    UserBasic userBasic = TestUtils.buildUserBasic();

    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));

    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("testPassword0!");
    changePasswordRequest.setConfirmPassword("NottheSame@123");

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user/changePassword")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError);
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getField().equals("confirmPassword")));

    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(
                apiValidtionError -> apiValidtionError.getMessage().endsWith(confirmPswdMsg)));
  }
}
