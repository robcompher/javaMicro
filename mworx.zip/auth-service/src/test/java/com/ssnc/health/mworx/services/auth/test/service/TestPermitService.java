/*
 * FILE : TestPermitService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.service;

import static org.mockito.Mockito.*;

import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.service.PermitServiceImpl;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

/**
 * This test case is used test the PermitService.
 *
 * @author dt224133
 */
public class TestPermitService {

  @InjectMocks private PermitServiceImpl permitService;
  @Mock private SecPermitRepository mockSecPermitRepository;

  List<SecPermit> permits = null;

  @BeforeEach
  public void init() {

    MockitoAnnotations.initMocks(this);

    permits = new ArrayList<>();
    SecPermit secPermit1 = new SecPermit();
    secPermit1.setPermitId(100L);
    secPermit1.setPermitPrimary("SECURITY");
    secPermit1.setPermitSecondary("VIEW");
    secPermit1.setDescription("Security View");
    secPermit1.setActive("Y");
    secPermit1.setCreated(new Date());
    permits.add(secPermit1);

    SecPermit secPermit2 = new SecPermit();
    secPermit2.setPermitId(101L);
    secPermit2.setPermitPrimary("SECURITY");
    secPermit2.setPermitSecondary("UPDATE");
    secPermit2.setDescription("Security Update");
    secPermit2.setActive("Y");
    secPermit2.setCreated(new Date());
    permits.add(secPermit2);

    SecPermit secPermit3 = new SecPermit();
    secPermit3.setPermitId(102L);
    secPermit3.setPermitPrimary("RECON");
    secPermit3.setPermitSecondary("VIEW");
    secPermit3.setDescription("RECON VIEW");
    secPermit3.setActive("Y");
    secPermit3.setCreated(new Date());
    permits.add(secPermit3);
  }

  @Test
  public void test() {
    // getAll Active Permits
    when(mockSecPermitRepository.getAllActivePermits()).thenReturn(permits);
    when(mockSecPermitRepository.findAll()).thenReturn(permits);
    List<SecPermit> permitList = permitService.getAllPermits(true);
    Assertions.assertNotNull(permitList);
    Assertions.assertTrue(permitList.size() > 0);

    // getAll Inactive Permits
    permitList = permitService.getAllPermits(false);
    verify(mockSecPermitRepository).getAllActivePermits();

    // getPermitById
    when(mockSecPermitRepository.findById(100L)).thenReturn(Optional.of(permits.get(0)));
    Optional<SecPermit> optionalSecPermit = permitService.getPermitById(100L);
    Assertions.assertNotNull(optionalSecPermit);
    Assertions.assertEquals(optionalSecPermit.get(), permits.get(0));
  }
}
