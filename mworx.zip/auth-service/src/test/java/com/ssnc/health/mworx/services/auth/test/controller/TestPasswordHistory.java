/*
FILE : TestPasswordHistory.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.mockito.Mockito.when;

import com.ssnc.health.core.common.error.ApiError;
import com.ssnc.health.core.common.error.ApiValidationError;
import com.ssnc.health.mworx.services.auth.api.model.ChangePasswordRequest;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.service.UserService;
import java.util.Date;
import java.util.Optional;
import java.util.function.Predicate;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "5000")
class TestPasswordHistory extends BaseResourceTest {
  @Autowired private WebTestClient webTestClient;

  @MockBean private UserService mockUserService;

  private static String VALIDATION_ERROR_MESSAGE =
      "New password does not meet the length, complexity, or history requirements.";

  private static final String CHANGE_PASSWORD_URI = "/api/user/changePassword";
  private static final String USER_NAME = "testUser";

  @Autowired private DelegatingPasswordEncoder passwordEncoder;

  public static Predicate<ApiValidationError> validateErrorMessage() {
    return validationRecord -> validationRecord.getMessage().contains(VALIDATION_ERROR_MESSAGE);
  }

  @Test
  public void testChangePasswordInHistory() throws Exception {
    // Build and save the user.
    UserBasic userBasic = buildUserBasic();
    UserLogin userLogin = buildUserLogin("TestP@ssw0rd123");
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    // Get a user with proper privileges
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    Assertions.assertNotNull(userBasic);
    Assertions.assertEquals(1, userBasic.getUserLogins().size());
    Assertions.assertTrue(
        passwordEncoder.matches("TestP@ssw0rd123", userBasic.getUserLogins().get(0).getPassword()));

    // Try to use the password from the history record
    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName(USER_NAME);
    changePasswordRequest.setConfirmPassword("TestP@ssw0rd123");
    changePasswordRequest.setPassword("TestP@ssw0rd123");

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(apiError.getResponseBody());
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream().anyMatch(validateErrorMessage()));

    // Set Another password
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName(USER_NAME);
    changePasswordRequest.setPassword("TestP@ssw0rd1234");
    changePasswordRequest.setConfirmPassword("TestP@ssw0rd1234");

    EntityExchangeResult<String> userResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertNotNull(userResult);
    Assertions.assertEquals(
        "\"Successfully updated the password for User : "
            + changePasswordRequest.getUserName()
            + "\"",
        userResult.getResponseBody());
    // Persist to userBasic object
    userLogin = buildUserLogin("TestP@ssw0rd1234");
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    Assertions.assertNotNull(userBasic);
    Assertions.assertEquals(2, userBasic.getUserLogins().size());
    Assertions.assertTrue(
        passwordEncoder.matches(
            "TestP@ssw0rd1234", userBasic.getUserLogins().get(1).getPassword()));

    // Try to use the password from the history record
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName(USER_NAME);
    changePasswordRequest.setPassword("TestP@ssw0rd123");

    apiError =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(apiError.getResponseBody());
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream().anyMatch(validateErrorMessage()));
  }

  private UserBasic buildUserBasic() {

    UserBasic userBasic = new UserBasic();
    userBasic.setUsername(USER_NAME);
    userBasic.setFirstName(USER_NAME);
    userBasic.setLastName(USER_NAME);
    userBasic.setPrefix("testPrefix");

    return userBasic;
  }

  private UserLogin buildUserLogin(String password) {
    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    Assertions.assertNotNull(passwordEncoder);
    userLogin.setPassword(passwordEncoder.encode(password));
    userLogin.setCreated(new Date());
    userLogin.setUpdated(new Date());
    return userLogin;
  }
}
