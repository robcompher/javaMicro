/*
FILE : DateUtilsTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */

package com.ssnc.health.mworx.services.auth.utils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.ZoneId;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class DateUtilsTest {

  /**
   * The expiry date is 04/30/2020 11:00:00 AM Today is 04/28/2020 04:00:00 PM Only one day to
   * remaining
   *
   * @throws ParseException
   */
  @Test
  public void testExpiredOneDay() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/28/2020 11:00:00 AM";
    String today = "04/28/2020 04:00:00 PM ";
    int configDays = 2; // expires at 04/30/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);

    Assertions.assertEquals(1, days);
  }

  @Test
  /**
   * The expiry date is 04/30/2020 11:00:00 AM Today is 04/28/2020 04:00:00 PM Exactly 2 day to
   * remaining
   *
   * @throws ParseException
   */
  public void testExpiredTwoDays() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/28/2020 11:00:00 AM";
    String today = "04/28/2020 11:00:00 AM";
    int configDays = 2; // To get Expiry as 04/30/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);

    Assertions.assertEquals(2, days);
  }

  // Expired Date : 4/28/2020 11:00 AM
  // 1 or more days will be calculated --> 4/27 11:00 am or before
  // zero days calculation --> 4/27 11:01 AM to 4/29 10:59 AM.
  // -1 day or more will be calculated --> 4/29 11:00 am to rest of the upcoming days (Password
  // expired)

  @Test
  /**
   * 1 or more days will be calculated --> 4/27 11:00 am or before *
   *
   * @throws ParseException
   */
  public void testNotExpiredOneDayEnds() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/26/2020 11:00:00 AM";
    String today = "04/27/2020 11:00:00 AM";
    int configDays = 2; // To get Expiry as 04/28/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);
    Assertions.assertEquals(1, days);
  }

  @Test
  /**
   * zero days calculation --> 4/27 11:01 AM to 4/29 10:59 AM.
   *
   * @throws ParseException
   */
  public void testNotExpiredZeroDayStart() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/26/2020 11:00:00 AM";
    String today = "04/27/2020 11:01:00 AM ";
    int configDays = 2; // To get Expiry as 04/28/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);
    Assertions.assertEquals(0, days);
  }

  @Test
  /**
   * zero days calculation --> 4/27 11:01 AM to 4/29 10:59 AM.
   *
   * @throws ParseException
   */
  public void testExpiredWithZeroDayEnds() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/26/2020 11:00:00 AM";
    String today = "04/29/2020 10:59:00 AM";
    int configDays = 2; // To get Expiry as 04/29/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);
    // Password will be expired at 12:00 am
    Assertions.assertEquals(0, days);
  }

  /**
   * The expiry date is 04/28/2020 11:00:00 AM and configDays is 2. Today is 04/28/2020 11:00:00 AM
   * Exactly 0 day to remaining means password expired
   *
   * @throws ParseException
   */
  @Test
  public void testExpiredExactTime() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/26/2020 11:00:00 AM";
    String today = "04/28/2020 11:00:00 AM";
    int configDays = 2; // To get Expiry as 04/28/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);
    // Password will be expired at 11:00 am
    Assertions.assertEquals(0, days);
  }

  @Test
  /**
   * The expiry date is 04/28/2020 11:00:00 AM Today is 04/29/2020 11:00:00 AM -1 day starts meaning
   * password expired
   *
   * @throws ParseException
   */
  public void testExpiredWithOneDayStarts() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/26/2020 11:00:00 AM";
    String today = "05/01/2020 11:00:00 AM";
    int configDays = 2; // To get Expiry as 04/29/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);
    // Password will be expired at 11:00 am
    Assertions.assertEquals(-3, days);
  }

  @Test
  /**
   * The expiry date is 04/28/2020 11:00:00 AM Today is 04/29/2020 11:00:00 AM -1 day starts meaning
   * password expired
   *
   * @throws ParseException
   */
  public void testExpiredWithMorethanOneDay() throws ParseException {

    DateFormat df = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss aa");

    String createDateStr = "04/26/2020 11:00:00 AM";
    String today = "04/30/2020 12:00:00 AM";
    int configDays = 2; // To get Expiry as 04/29/2020 11:00:00 AM

    LocalDateTime createDate =
        df.parse(createDateStr).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    LocalDateTime toDay =
        df.parse(today).toInstant().atZone(ZoneId.systemDefault()).toLocalDateTime();
    long days = DateUtils.getNoOfDaysToExpire(toDay, createDate, configDays);
    // Password will be expired at 11:00 am
    Assertions.assertEquals(-1, days);
  }
}
