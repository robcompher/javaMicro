/*
 * FILE : TestMetadataService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */ package com.ssnc.health.mworx.services.auth.test.service;

import com.ssnc.health.mworx.services.auth.AuthServiceApplication;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.service.MetadataServiceImpl;
import java.util.HashMap;
import java.util.Map;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@SpringBootTest(classes = AuthServiceApplication.class)
public class TestMetadataService {

  @Autowired @InjectMocks MetadataServiceImpl metadataService;

  @Mock private WebClient client;

  @Mock WebClient.RequestBodyUriSpec requestBodyUriSpec;

  @SuppressWarnings("rawtypes")
  @Mock
  WebClient.RequestHeadersSpec requestHeadersSpec;

  @Mock WebClient.RequestBodySpec requestBodySpec;

  @Mock WebClient.ResponseSpec responseSpec;

  public static final String ORGANIZATION_NAME = "org";
  public static final String LOB_NAME = "lobName";
  public static final String LOB_CATEGORY = "lobCat";
  public static final String ORG_ID = "10";

  @SuppressWarnings("unchecked")
  @BeforeEach
  void setup() {
    MockitoAnnotations.initMocks(this);
    Mockito.when(client.post()).thenReturn(requestBodyUriSpec);
    Mockito.when(requestBodyUriSpec.uri(Mockito.nullable(String.class)))
        .thenReturn(requestBodySpec);
    Mockito.when(requestBodySpec.header(Mockito.any(), Mockito.any())).thenReturn(requestBodySpec);

    Mockito.when(requestHeadersSpec.header(Mockito.any(), Mockito.any()))
        .thenReturn(requestHeadersSpec);

    Mockito.when(requestBodySpec.accept(Mockito.any())).thenReturn(requestBodySpec);
    Mockito.when(requestBodySpec.body(Mockito.any())).thenReturn(requestHeadersSpec);
    Mockito.when(requestBodySpec.bodyValue(Mockito.any())).thenReturn(requestHeadersSpec);
    Mockito.when(requestHeadersSpec.retrieve()).thenReturn(responseSpec);
  }

  @Test
  public void testMetadataService() {
    Map<String, String> responseMap = new HashMap<>();
    responseMap.put("id", "1");
    Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<Map<String, String>>>notNull()))
        .thenReturn(Mono.just(responseMap));
    LOB lob1 = new LOB();
    lob1.setLobId(1L);
    LOB lob2 = new LOB();
    lob2.setLobId(2L);
    lob2.setLobName("TEST LOB NAME");
    lob2.setOrganizationName("TEST ORG NAME");
    lob2.setOrganizationId(1L);
    Assertions.assertTrue(metadataService.getLOBId(lob1).equals(1L));
    Assertions.assertTrue(metadataService.getLOBId(lob2).equals(1L));
  }

  @Test
  void testMetadataServicelobId() {
    Map<String, String> responseMap = new HashMap<>();
    responseMap.put("lobName", LOB_NAME);
    responseMap.put("lobCategoryName", LOB_CATEGORY);
    responseMap.put("organizationName", ORGANIZATION_NAME);
    responseMap.put("organizationId", ORG_ID);
    Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<Map<String, String>>>notNull()))
        .thenReturn(Mono.just(responseMap));
    Assertions.assertEquals(LOB_NAME, metadataService.getLobInfoById(1L).get("lobName"));
  }

  @Test
  public void testMetadataServiceGenderValid() {
    Map<String, String> responseMap = new HashMap<>();
    responseMap.put("category", "gender");
    Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<Map<String, String>>>notNull()))
        .thenReturn(Mono.just(responseMap));

    Assertions.assertTrue(
        metadataService.getListById(1L).get("category").toString().equalsIgnoreCase("gender"));
  }

  @Test
  public void testMetadataServiceGenderInValid() {
    Map<String, String> responseMap = new HashMap<>();
    responseMap.put("category", "gender33");
    Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<Map<String, String>>>notNull()))
        .thenReturn(Mono.just(responseMap));

    Assertions.assertFalse(
        metadataService.getListById(1L).get("category").toString().equalsIgnoreCase("gender"));
  }

  @Test
  public void testMetadataServiceContactTypeValid() {
    Map<String, String> responseMap = new HashMap<>();
    responseMap.put("category", "contact_type");
    Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<Map<String, String>>>notNull()))
        .thenReturn(Mono.just(responseMap));
    Assertions.assertTrue(
        metadataService
            .getListById(1L)
            .get("category")
            .toString()
            .equalsIgnoreCase("contact_type"));
  }

  @Test
  public void testMetadataServiceContactTypeInValid() {
    Map<String, String> responseMap = new HashMap<>();
    responseMap.put("category", "contact_type12");
    Mockito.when(responseSpec.bodyToMono(ArgumentMatchers.<Class<Map<String, String>>>notNull()))
        .thenReturn(Mono.just(responseMap));
    Assertions.assertFalse(
        metadataService
            .getListById(1L)
            .get("category")
            .toString()
            .equalsIgnoreCase("contact_type"));
  }
}
