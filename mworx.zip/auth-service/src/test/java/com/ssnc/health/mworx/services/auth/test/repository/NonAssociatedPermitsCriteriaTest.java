/*
 * FILE : RoleRepositoryCriteriaTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.PermitSearchNonAssociatedRoleSpecification;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.repository.RoleLobPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

/**
 * This is to test NonAssociatedPermitsCriteriaTest class. It is used for testing that the summary
 * permits that gets called by the UI as part of findByPermitSearchCriteria gets tested with various
 * combinations of the query primary and secondary permit,LOB,roleId where as LOB and permits are
 * optional. combinations with pagination
 *
 * @author dt204819
 */
public class NonAssociatedPermitsCriteriaTest extends BaseRepositoryTest {

  @Autowired private SecRoleRepository roleRepository;
  @Autowired private SecPermitRepository permitRepository;
  @Autowired private RoleLobPermitRepository roleLobPermitRepository;

  public static final String ROLE_NAME_DBA = "DBA Role";
  public static final String ROLE_TYPE_DBA = "Admin";
  public static final String ROLE_NAME_SUPP = "Support Role";
  public static final String ROLE_TYPE_SUPP = "Support";

  public static final String PERMIT_PRIMARY_DBA = "DBA";
  public static final String PERMIT_SECONDARY_DBA = "Add";
  public static final String PERMIT_PRIMARY_SUPP = "Support";
  public static final String PERMIT_SECONDARY_SUPP = "View";
  public static final String PERMIT_DESC = "Permit Description";
  public static final String LEGACY_SYSID = "123456";
  public static final String ACTIVE = "Y";
  public static final String NON_ACTIVE = "Y";

  private PageRequest pageable = PageRequest.of(0, 5, Sort.DEFAULT_DIRECTION, "permitId");

  @BeforeEach
  public void testAssocitePermitsCriteriaQuery() {

    SecRole secAdminRole = new SecRole();
    secAdminRole.setActive(ACTIVE);
    secAdminRole.setRoleName(ROLE_NAME_DBA);
    secAdminRole.setRoleType(ROLE_TYPE_DBA);
    secAdminRole.setEffDate(new Date());
    secAdminRole.setRoleId(1L);
    roleRepository.save(secAdminRole);
    for (int randomPermit = 1; randomPermit <= 10; randomPermit++) {
      RoleLobPermit rlp = new RoleLobPermit();
      rlp.setActive(ACTIVE);
      rlp.setSecRole(secAdminRole);
      rlp.setLobId(1L);
      SecPermit permit = new SecPermit();
      permit.setPermitPrimary(PERMIT_PRIMARY_DBA + randomPermit);
      permit.setPermitSecondary(PERMIT_SECONDARY_DBA + randomPermit);
      permit.setActive(ACTIVE);
      permit.setDescription(PERMIT_DESC);

      rlp.setSecPermit(permit);
      permit.setRoleLobPermits(new ArrayList<>());
      permit.getRoleLobPermits().add(rlp);
      permitRepository.save(permit);
      roleLobPermitRepository.save(rlp);
    }
    SecRole secSystemRole = new SecRole();
    secSystemRole.setActive(ACTIVE);
    secSystemRole.setRoleName(ROLE_NAME_SUPP);
    secSystemRole.setRoleType(ROLE_TYPE_SUPP);
    secSystemRole.setEffDate(new Date());
    secSystemRole.setRoleId(2L);
    roleRepository.save(secSystemRole);
    for (int randomPermit = 11; randomPermit <= 20; randomPermit++) {
      RoleLobPermit rlp = new RoleLobPermit();
      rlp.setActive(ACTIVE);
      rlp.setLobId(2L);
      rlp.setSecRole(secSystemRole);
      SecPermit permit = new SecPermit();
      permit.setPermitPrimary(PERMIT_PRIMARY_SUPP + randomPermit);
      permit.setPermitSecondary(PERMIT_SECONDARY_SUPP + randomPermit);
      permit.setActive(ACTIVE);
      permit.setDescription(PERMIT_DESC);

      rlp.setSecPermit(permit);
      permit.setRoleLobPermits(new ArrayList<>());
      permit.getRoleLobPermits().add(rlp);
      permitRepository.save(permit);
      roleLobPermitRepository.save(rlp);
    }
  }

  @Test
  public void testRoleIdEqualCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<SecPermit> pageSecPermit =
        permitRepository.findAll(
            PermitSearchNonAssociatedRoleSpecification.get(
                new SummaryPermitSearchCriteria(
                    PERMIT_PRIMARY_DBA, PERMIT_SECONDARY_DBA, 2L, lob, false)),
            pageable);
    Assertions.assertNotNull(pageSecPermit);
    Assertions.assertEquals(10, pageSecPermit.getTotalElements());
  }

  @Test
  public void testLobIdEqualCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<SecPermit> pageSecPermit =
        permitRepository.findAll(
            PermitSearchNonAssociatedRoleSpecification.get(
                new SummaryPermitSearchCriteria(
                    PERMIT_PRIMARY_SUPP, PERMIT_SECONDARY_SUPP, 1L, lob, false)),
            pageable);
    Assertions.assertNotNull(pageSecPermit);
    Assertions.assertEquals(10, pageSecPermit.getTotalElements());
  }

  @Test
  public void testPrimaryPermitsCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<SecPermit> pageSecPermit =
        permitRepository.findAll(
            PermitSearchNonAssociatedRoleSpecification.get(
                new SummaryPermitSearchCriteria(PERMIT_PRIMARY_DBA, "", 2L, lob, false)),
            pageable);
    Assertions.assertNotNull(pageSecPermit);
    Assertions.assertEquals(10, pageSecPermit.getTotalElements());
  }

  @Test
  public void testSecondaryPermitsCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<SecPermit> pageSecPermit =
        permitRepository.findAll(
            PermitSearchNonAssociatedRoleSpecification.get(
                new SummaryPermitSearchCriteria("", PERMIT_SECONDARY_DBA, 2L, lob, false)),
            pageable);
    Assertions.assertNotNull(pageSecPermit);
    Assertions.assertEquals(10, pageSecPermit.getTotalElements());
  }

  @Test
  public void testAllCriteriaMixed() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<SecPermit> pageSecPermit =
        permitRepository.findAll(
            PermitSearchNonAssociatedRoleSpecification.get(
                new SummaryPermitSearchCriteria(
                    mixedCase(PERMIT_PRIMARY_DBA + 2),
                    mixedCase(PERMIT_SECONDARY_DBA + 2),
                    2L,
                    lob,
                    false)),
            pageable);
    Assertions.assertNotNull(pageSecPermit);
    Assertions.assertEquals(1, pageSecPermit.getTotalElements());
  }

  @Test
  public void testAllPermitsCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<SecPermit> pageSecPermit =
        permitRepository.findAll(
            PermitSearchNonAssociatedRoleSpecification.get(
                new SummaryPermitSearchCriteria(
                    PERMIT_PRIMARY_SUPP + 1, PERMIT_SECONDARY_SUPP + 1, 1L, lob, false)),
            pageable);
    Assertions.assertNotNull(pageSecPermit);
    Assertions.assertEquals(9, pageSecPermit.getTotalElements());
  }

  private static String mixedCase(String str) {
    return IntStream.range(0, str.length())
        .mapToObj(i -> i % 2 == 0 ? Character.toUpperCase(str.charAt(i)) : str.charAt(i))
        .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
        .toString();
  }
}
