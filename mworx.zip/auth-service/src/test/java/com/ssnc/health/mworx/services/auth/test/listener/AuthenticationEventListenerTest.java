/*
FILE : AuthenticationEventListenerTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.listener;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

import com.ssnc.health.mworx.services.auth.listener.AuthenticationEventListener;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import com.ssnc.health.mworx.services.auth.service.UserServiceImpl;
import java.util.Date;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.*;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.event.AbstractAuthenticationFailureEvent;
import org.springframework.security.authentication.event.AuthenticationFailureBadCredentialsEvent;
import org.springframework.security.authentication.event.AuthenticationSuccessEvent;
import org.springframework.security.core.Authentication;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(MockitoExtension.class)
@ContextConfiguration
@DisplayName("Authentication Event Listener test cases")
public class AuthenticationEventListenerTest {

  @InjectMocks AuthenticationEventListener eventListener;

  @Mock UserServiceImpl userServiceMock;

  @Mock Authentication authMock;

  @Mock Authentication successAuthMock;

  @Mock UserBasic userBasic;

  @Mock UserLogin userLogin;

  @Mock AppUser appUser;

  String username;
  String error;
  AbstractAuthenticationFailureEvent failureEvent;
  AuthenticationSuccessEvent successEvent;

  @BeforeEach
  public void setUp() throws Exception {
    username = "user";
    error = "exception message";

    userBasic = new UserBasic();
    userBasic.setUsername(username);
    userBasic.setLocked("N");
    userLogin = new UserLogin();
    // set last logout to make sure when it it succeeds login it it sets it back to null
    userLogin.setLastLogout(new Date());
    userLogin.setFailureAttempts(0);
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    appUser = new AppUser();
    appUser.setUsername(username);

    failureEvent =
        new AuthenticationFailureBadCredentialsEvent(authMock, new BadCredentialsException(error));
    successEvent = new AuthenticationSuccessEvent(successAuthMock);
  }

  @Test
  @DisplayName("Active user login is not present")
  public void testAuthFailedEventListenerNoActiveUserLoginPresent() {

    UserLogin nonActiveUser = mock(UserLogin.class);
    nonActiveUser = null;
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.ofNullable(nonActiveUser));
    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(authMock.getPrincipal()).thenReturn(username);

    eventListener.authFailedEventListener(failureEvent);

    verify(userServiceMock, never()).updateUserLogin(any(UserLogin.class));
    verify(userServiceMock, never()).updateUser(any(UserBasic.class));
  }

  @Test
  @DisplayName("User is locked for too many failed login attempts")
  public void testAuthFailedEventListenerUserLocked() {

    // to test UserLogin.getFailureAttempts being null
    userLogin.setFailureAttempts(null);

    ReflectionTestUtils.setField(eventListener, "maxFailedAttempts", "1");

    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.of(userLogin));
    when(authMock.getPrincipal()).thenReturn(username);

    eventListener.authFailedEventListener(failureEvent);

    assertEquals("Y", userBasic.getLocked());
    verify(userServiceMock).updateUser(any(UserBasic.class));
  }

  @Test
  @DisplayName("User is not locked due to not reaching maximum failed login attempts")
  public void testAuthFailedEventListenerUserNotLocked() {

    ReflectionTestUtils.setField(eventListener, "maxFailedAttempts", "2");

    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.of(userLogin));
    when(authMock.getPrincipal()).thenReturn(username);

    eventListener.authFailedEventListener(failureEvent);

    assertEquals("N", userBasic.getLocked());
    verify(userServiceMock, never()).updateUser(any(UserBasic.class));
  }

  @Test
  @DisplayName("User is not locked due to maximum failed login attempts property being zero")
  public void testAuthFailedEventListenerUserNotLockedWhenPropertyZero() {

    ReflectionTestUtils.setField(eventListener, "maxFailedAttempts", "0");

    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.of(userLogin));
    when(authMock.getPrincipal()).thenReturn(username);

    eventListener.authFailedEventListener(failureEvent);

    assertEquals("N", userBasic.getLocked());
    verify(userServiceMock, never()).updateUser(any(UserBasic.class));
  }

  @Test
  @DisplayName("Maximum failed login attempts defaults to 3 due to No property")
  public void testAuthFailedEventListenerNoProperty() {

    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.of(userLogin));
    when(authMock.getPrincipal()).thenReturn(username);

    eventListener.authFailedEventListener(failureEvent);

    assertEquals("N", userBasic.getLocked());
    verify(userServiceMock, never()).updateUser(any(UserBasic.class));
  }

  @Test
  @DisplayName("Maximum failed login attempts defaults to 3 due to property having alphanumeric")
  public void testAuthFailedEventListenerAlphanumericProperty() {

    ReflectionTestUtils.setField(eventListener, "maxFailedAttempts", "abc123");

    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.of(userLogin));
    when(authMock.getPrincipal()).thenReturn(username);

    eventListener.authFailedEventListener(failureEvent);

    assertEquals("N", userBasic.getLocked());
    verify(userServiceMock, never()).updateUser(any(UserBasic.class));
  }

  @Test
  @DisplayName("Maximum failed login attempts defaults to 3 due to property being null")
  public void testAuthFailedEventListenerNullProperty() {

    ReflectionTestUtils.setField(eventListener, "maxFailedAttempts", null);

    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.of(userLogin));
    when(authMock.getPrincipal()).thenReturn(username);

    eventListener.authFailedEventListener(failureEvent);

    assertEquals("N", userBasic.getLocked());
    verify(userServiceMock, never()).updateUser(any(UserBasic.class));
  }

  @Test
  @DisplayName("AppUser is not present during successful event")
  public void testAuthSuccessEventListenerNoAppUserPresent() {

    AppUser nonActiveAppUser = mock(AppUser.class);
    nonActiveAppUser = null;
    when(successAuthMock.getPrincipal()).thenReturn(Optional.ofNullable(nonActiveAppUser));

    eventListener.authSuccessEventListener(successEvent);

    verify(userServiceMock, never()).updateUserLogin(any(UserLogin.class));
  }

  @Test
  @DisplayName("Active user login is not present during successful event")
  public void testAuthSuccessEventListenerNoActiveUserLoginPresent() {

    UserLogin nonActiveUser = mock(UserLogin.class);
    nonActiveUser = null;

    when(successAuthMock.getPrincipal()).thenReturn(appUser);
    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.ofNullable(nonActiveUser));

    eventListener.authSuccessEventListener(successEvent);

    verify(userServiceMock, never()).updateUserLogin(any(UserLogin.class));
  }

  @Test
  @DisplayName(
      "User successful login resets failure attempts, updates last login and calls service")
  public void testAuthSuccessEventListenerUserUpdated() {

    when(userServiceMock.getUser(username)).thenReturn(Optional.of(userBasic));
    when(userServiceMock.getUserLogin(userBasic)).thenReturn(Optional.of(userLogin));
    when(successAuthMock.getPrincipal()).thenReturn(appUser);

    userLogin.setFailureAttempts(1);

    eventListener.authSuccessEventListener(successEvent);

    assertEquals((Integer) 0, userLogin.getFailureAttempts());
    assertNotNull(userLogin.getLastLogin());
    // this should be null as it was successful login
    assertNull(userLogin.getLastLogout());
    verify(userServiceMock).updateUserLogin(any(UserLogin.class));
  }
}
