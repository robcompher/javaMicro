/*
FILE : UserServiceMockTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertNull;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserContact;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import com.ssnc.health.mworx.services.auth.repository.UserLoginRepository;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import com.ssnc.health.mworx.services.auth.service.MetadataServiceImpl;
import com.ssnc.health.mworx.services.auth.service.UserServiceImpl;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.util.ReflectionTestUtils;

@ExtendWith(SpringExtension.class)
@ContextConfiguration
public class UserServiceMockTest {

  @InjectMocks private UserServiceImpl userService;

  @Mock private UserBasicRepository userBasicRepositoryMock;

  @Mock private DelegatingPasswordEncoder passwordEncoder;
  @Mock private UserLoginRepository userLoginRepositoryMock;

  @Mock private SecRoleRepository roleRepository;
  @Mock private SecPermitRepository mockSecPermitRepository;
  @Mock MetadataServiceImpl mockMetadataService;

  public static final String ROLE_NAME = "New Role";
  public static final String ROLE_TYPE = "Super Duper";
  public static final String PERMIT_PRIMARY = "Super Role";
  public static final String PERMIT_SECONDARY = "Super Role";
  public static final String ORGANIZATION_NAME = "org";
  public static final String LOB_NAME = "lobName";
  public static final String LOB_CATEGORY = "lobCat";
  public static final Long ORG_ID = 10L;

  private static final String USERNAME = "testUser";
  private static final String PREFIX = "Ms.";
  private static final String SUFIX = "awesome";
  private static final Long GENDER = 1L;
  private static final Date date = new Date();
  private static final String activeYes = "Y";
  private static final String lockedNo = "N";
  private static final Integer id = 10;
  private String password = "t3stP@ssword";
  private static final String LOCKED_YES = "Y";

  @BeforeEach
  public void init() {

    MockitoAnnotations.initMocks(this);
    ReflectionTestUtils.setField(userService, "passwordHistoryLimit", "3");
    ReflectionTestUtils.setField(userService, "passwordExpireDays", "3");
  }

  @Test
  public void testChangePassword() {
    UserBasic userBasic = buildUserBasic();
    when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class))).thenReturn(userBasic);
    when(userBasicRepositoryMock.findByUsernameIgnoreCase("testUser"))
        .thenReturn(java.util.Optional.of(userBasic));

    UserBasic userBasic1 = userService.changePassword(userBasic, "TestP@ssword2");
    Assertions.assertNotNull(userBasic1);
    Assertions.assertEquals(2, userBasic1.getUserLogins().size());
    when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class))).thenReturn(userBasic1);
    when(userBasicRepositoryMock.findByUsernameIgnoreCase("testUser"))
        .thenReturn(java.util.Optional.of(userBasic1));

    UserBasic userBasic2 = userService.changePassword(userBasic, "TestP@ssword3");
    Assertions.assertNotNull(userBasic2);
    Assertions.assertEquals(3, userBasic2.getUserLogins().size());
    when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class))).thenReturn(userBasic2);
    when(userBasicRepositoryMock.findByUsernameIgnoreCase("testUser"))
        .thenReturn(java.util.Optional.of(userBasic2));
    UserBasic userBasic3 = userService.changePassword(userBasic, "TestP@ssword4");
    Assertions.assertNotNull(userBasic3);
    Assertions.assertEquals(3, userBasic3.getUserLogins().size());
  }

  /**
   * Will test adding new contacts during update as well as updating contacts during update Have to
   * create user for the test which is a copy from another test
   */
  @Test
  public void testUpdateUserWithAddingNewContact() {
    UserBasic userBasic = buildUser();

    // Mocking repository calls.
    SecRole secRole = userBasic.getSecRole();
    when(roleRepository.findByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName()))
        .thenReturn(java.util.Optional.of(secRole));

    Mockito.when(userBasicRepositoryMock.getOne(userBasic.getUserId())).thenReturn(userBasic);

    Mockito.when(userBasicRepositoryMock.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    // make sure we return back the userbasic that was sent
    // NOTE at this time the ID's are not being set and setting them afteword
    Mockito.when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class)))
        .thenAnswer(
            new Answer<UserBasic>() {
              public UserBasic answer(InvocationOnMock invocation) {
                return invocation.getArgument(0);
              }
            });

    UserBasic result = userService.addUser(userBasic, "TestP@ssword4");
    Assertions.assertNotNull(result);
    Assertions.assertEquals(userBasic.getUsername(), result.getUsername());
    Assertions.assertEquals(lockedNo, userBasic.getLocked());
    Assertions.assertNull(userBasic.getTermDate());
    userBasic = result;
    userBasic.getUserContacts().get(0).setContactId(1L);
    // add a different contact. and make sure the result has both of them
    UserBasic userBasic2 = buildUser();
    userBasic2.setUserContacts(getUserContacts2());
    result = userService.updateUser(userBasic2);
    Assertions.assertEquals(lockedNo, result.getLocked());
    Assertions.assertNull(result.getTermDate());
    // returns whatever we sent and deleted the which are not part of the request.
    Assertions.assertEquals(1, result.getUserContacts().size());
    userBasic.setUserContacts(result.getUserContacts());
    userBasic.getUserContacts().get(0).setContactId(1L);
    // now update an existing one and make sure we still only get 2
    userBasic2 = buildUser();
    userBasic2.setUserContacts(getUserContacts2());
    userBasic2.getUserContacts().get(0).setContactInfo("ABC");
    userBasic2.setLocked(LOCKED_YES);
    result = userService.updateUser(userBasic2);
    Assertions.assertEquals(LOCKED_YES, result.getLocked());
    Assertions.assertNotNull(result.getTermDate());
    Assertions.assertEquals(1, result.getUserContacts().size());
    // now test without sending any contacts on update  then it should delete all contacts.
    userBasic2 = buildUser();
    List<UserContact> blankList = new ArrayList<>();
    userBasic2.setUserContacts(blankList);
    result = userService.updateUser(userBasic2);
    Assertions.assertTrue(result.getUserContacts().isEmpty());
    // now assume no contacts in system.  make sure can still create a new one
    userBasic.setUserContacts(new ArrayList<>());
    userBasic2 = buildUser();
    userBasic2.setUserContacts(getUserContacts2());
    result = userService.updateUser(userBasic2);
    Assertions.assertEquals(1, result.getUserContacts().size());
  }

  @Test
  public void testDeleteUsernameUserExists() {
    UserBasic userBasic = buildUser();

    Mockito.when(userBasicRepositoryMock.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    Mockito.when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class))).thenReturn(userBasic);

    boolean result = userService.deleteUser(userBasic.getUsername());
    Assertions.assertEquals(true, result);
  }

  @Test
  public void testDeleteUsernameUserDoesNotExist() {
    UserBasic userBasic = buildUser();

    Mockito.when(userBasicRepositoryMock.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.empty());

    boolean result = userService.deleteUser(userBasic.getUsername());
    Assertions.assertEquals(false, result);
  }

  @Test
  public void testUserServices() {
    UserBasic userBasic = buildUser();
    List<UserBasic> list = new ArrayList<>();
    list.add(userBasic);

    // Mocking repository calls.
    SecRole secRole = userBasic.getSecRole();
    when(roleRepository.findByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName()))
        .thenReturn(java.util.Optional.of(secRole));

    Mockito.when(userBasicRepositoryMock.getOne(userBasic.getUserId())).thenReturn(userBasic);

    Mockito.when(userBasicRepositoryMock.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));

    Mockito.when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class))).thenReturn(userBasic);

    Mockito.when(userBasicRepositoryMock.findAll(Example.of(userBasic))).thenReturn(list);

    Mockito.when(userBasicRepositoryMock.findAll(Mockito.any(Pageable.class)))
        .thenReturn(new PageImpl<UserBasic>(list));

    UserBasic result = userService.addUser(userBasic, "TestP@ssword4");
    Assertions.assertNotNull(result);
    Assertions.assertEquals(userBasic.getUsername(), result.getUsername());

    userBasic.setMiddleName("new middle name");
    userBasic.getUserContacts().get(0).setContactId(1L);
    Mockito.when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class))).thenReturn(userBasic);
    result = userService.updateUser(userBasic);
    Assertions.assertNotNull(result);
    Assertions.assertEquals(userBasic.getUsername(), result.getUsername());
    Assertions.assertEquals(userBasic.getMiddleName(), result.getMiddleName());
    Assertions.assertEquals(1, userBasic.getUserContacts().size());

    Optional<UserBasic> result1 = userService.getUser(userBasic.getUsername());
    Assertions.assertTrue(result1.isPresent());
    Assertions.assertEquals(userBasic.getUsername(), result1.get().getUsername());
  }

  private UserBasic buildUser() {

    UserBasic userBasic = new UserBasic();
    userBasic.setUsername(USERNAME);
    userBasic.setPrefix(PREFIX);
    userBasic.setFirstName(USERNAME);
    userBasic.setMiddleName(USERNAME);
    userBasic.setLastName(USERNAME);
    userBasic.setSuffix(SUFIX);
    userBasic.setGender(GENDER);
    userBasic.setEffDate(date);
    userBasic.setActive(activeYes);
    userBasic.setLocked(lockedNo);
    userBasic.setAdditionalData(USERNAME);
    userBasic.setBirthDate(date);
    userBasic.setInternalId(Integer.valueOf(id).toString());
    userBasic.setLegacySystemId(Integer.valueOf(id).toString());
    userBasic.setDescription(USERNAME);
    userBasic.setManagerId(id);
    userBasic.setTitle(USERNAME);

    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(passwordEncoder.encode(password));
    userLogin.setCreated(date);
    userLogin.setUpdated(date);
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    // Setting SecRole and userContacts.
    userBasic.setSecRole(getSecRole());
    userBasic.setUserContacts(getUserContacts());
    return userBasic;
  }

  private List<UserContact> getUserContacts() {
    List<UserContact> list = new ArrayList<>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info 1");
    userContact.setContactType(1L);
    list.add(userContact);
    return list;
  }

  private List<UserContact> getUserContacts2() {
    List<UserContact> list = new ArrayList<>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info 2");
    userContact.setContactType(2L);
    list.add(userContact);
    return list;
  }

  private SecRole getSecRole() {
    SecRole role = new SecRole();
    role.setRoleName(ROLE_NAME);
    role.setRoleType(ROLE_TYPE);
    role.setEffDate(Calendar.getInstance().getTime());

    // inserting data into permit table
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    return role;
  }

  @Test
  public void testLoadUserByUserName() {
    UserBasic userBasic = buildUserBasic();
    Optional<UserBasic> userBasicOptional = Optional.of(userBasic);
    when(userBasicRepositoryMock.findByUsernameIgnoreCase(any(String.class)))
        .thenReturn(userBasicOptional);

    Map<String, Object> responseMap = new HashMap<>();
    Map<String, Object> responseMapBlank = new HashMap<>();
    responseMap.put("lobName", LOB_NAME);
    responseMap.put("lobCategoryName", LOB_CATEGORY);
    responseMap.put("organizationName", ORGANIZATION_NAME);
    responseMap.put("organizationId", ORG_ID);
    when(mockMetadataService.getLobInfoById(1L)).thenReturn(responseMap);
    when(mockMetadataService.getLobInfoById(2L)).thenReturn(responseMapBlank);
    AppUser userDetail = (AppUser) userService.loadUserByUserName(userBasic.getUsername());
    performAssertions(userDetail);
    Assertions.assertEquals("testUser", userDetail.getUsername());
    verify(userBasicRepositoryMock).findByUsernameIgnoreCase(any(String.class));
    // change permit and make sure permit has LOB
    RoleLobPermit rPermit = new RoleLobPermit();
    rPermit.setSecRole(userBasic.getSecRole());
    rPermit.setActive("Y");
    rPermit.setLobId(1L);
    SecPermit permit = new SecPermit();
    permit.setActive("Y");
    rPermit.setSecPermit(permit);
    userBasic.getSecRole().getRoleLobPermits().add(rPermit);
    AppUser user = (AppUser) userService.loadUserByUserName(userBasic.getUsername());
    Assertions.assertNotNull(userDetail);
    Assertions.assertEquals(1L, user.getCurrentLobId().longValue());
    Assertions.assertEquals(LOB_NAME, user.getCurrentLobName());
    Assertions.assertEquals(ORGANIZATION_NAME, user.getCurrentOrganizationName());
    Assertions.assertEquals(LOB_CATEGORY, user.getCurrentLobCategoryName());
    Assertions.assertEquals(ORG_ID, user.getCurrentOrganizationId());
    rPermit.setLobId(2L);
    user = (AppUser) userService.loadUserByUserName(userBasic.getUsername());

    Assertions.assertNotNull(user);

    Assertions.assertNull(user.getCurrentLobName());
    Assertions.assertNull(user.getCurrentOrganizationName());
    Assertions.assertNull(user.getCurrentLobCategoryName());

    Assertions.assertEquals(2L, user.getCurrentLobId().longValue());
    rPermit.setActive(null);
    rPermit.getSecPermit().setActive(null);
    user = (AppUser) userService.loadUserByUserName(userBasic.getUsername());
    Assertions.assertNotNull(user);

    Assertions.assertNull(user.getCurrentLobName());
    Assertions.assertNull(user.getCurrentOrganizationName());
    Assertions.assertNull(user.getCurrentLobCategoryName());
    Assertions.assertEquals(2L, user.getCurrentLobId().longValue());
    rPermit.setActive("N");
    rPermit.getSecPermit().setActive("Y");
    user = (AppUser) userService.loadUserByUserName(userBasic.getUsername());
    performAssertions(user);

    rPermit.setActive("Y");
    rPermit.getSecPermit().setActive("N");
    user = (AppUser) userService.loadUserByUserName(userBasic.getUsername());
    performAssertions(user);
  }

  private void performAssertions(AppUser user) {
    Assertions.assertNotNull(user);
    Assertions.assertNull(user.getCurrentLobId());
    Assertions.assertNull(user.getCurrentLobName());
    Assertions.assertNull(user.getCurrentOrganizationName());
    Assertions.assertNull(user.getCurrentLobCategoryName());
  }

  @SuppressWarnings("unchecked")
  @Test
  public void testFindUsers() {

    List<UserBasic> users = new ArrayList<>();
    UserBasic userBasic1 = buildUserBasic();
    UserBasic userBasic2 = buildUserBasic();
    users.add(userBasic1);
    userBasic2.setUsername("root");
    users.add(userBasic2);
    Page<UserBasic> pagedResponse = new PageImpl<UserBasic>(users);

    PageRequest pageable = PageRequest.of(0, 10);
    when(userBasicRepositoryMock.findAll(any(Specification.class), any(Pageable.class)))
        .thenReturn(pagedResponse);

    Page<UserBasic> userList = userService.findUsers(new UserBasic(), pageable, true);
    Assertions.assertNotNull(userList);
    Assertions.assertEquals(2, userList.getSize());
    Assertions.assertEquals("root", userList.getContent().get(1).getUsername());
    verify(userBasicRepositoryMock).findAll(any(Specification.class), any(Pageable.class));
  }

  @Test
  @DisplayName("User Login successfully updated")
  public void testUpdateUserLogin() {
    UserBasic userBasic = buildUserBasic();
    UserLogin userLogin = userBasic.getUserLogins().get(0);
    when(userLoginRepositoryMock.save(userLogin)).thenReturn(userLogin);
    userService.updateUserLogin(userLogin);

    when(userLoginRepositoryMock.findById(1L)).thenReturn(java.util.Optional.of(userLogin));
    java.util.Optional<UserLogin> foundUserLogin = userLoginRepositoryMock.findById(1L);

    Assertions.assertNotNull(foundUserLogin);
    Assertions.assertEquals(date, foundUserLogin.get().getLastLogin());
    Assertions.assertEquals(Long.valueOf(1), foundUserLogin.get().getUserloginId());

    verify(userLoginRepositoryMock).save(any(UserLogin.class));
  }

  @Test
  @DisplayName("UserBasic is updated in database without a user login")
  public void testUpdateUserExistingWithoutUserLoginID() {
    SecurityContext context = mock(SecurityContext.class);
    Map jwtClaims = new HashMap<>();
    jwtClaims.put("user_id", 1L);
    Map jwtHeaders = new HashMap<>();
    jwtHeaders.put("alg", "none");
    Jwt jwt = new Jwt("password", null, null, jwtHeaders, jwtClaims);
    JwtAuthenticationToken auth = new JwtAuthenticationToken(jwt);
    when(context.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(context);

    Optional<SecRole> optionalSecRole = Optional.empty();
    UserBasic userBasic = buildUserBasic();
    userBasic.getSecRole().setRoleId(null);
    userBasic.getUserLogins().clear();

    when(roleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenReturn(optionalSecRole);
    when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class))).thenReturn(userBasic);
    when(userBasicRepositoryMock.findByUsernameIgnoreCase("testUser"))
        .thenReturn(java.util.Optional.of(userBasic));

    UserBasic userBasic1 = userService.updateUser(userBasic);
    assertNotNull(userBasic1);
    assertNotNull(userBasic1.getUpdated());
    assertEquals(Long.valueOf(1), userBasic1.getUpdateBy());
    verify(userBasicRepositoryMock).save(any(UserBasic.class));
  }

  @Test
  @DisplayName("Locked = Y/N is being saved properly with updateUser")
  public void testLockUnlockuser() {
    UserBasic userBasic = buildUser();

    // Mocking repository calls.
    SecRole secRole = userBasic.getSecRole();
    when(roleRepository.findByRoleTypeAndRoleName(secRole.getRoleType(), secRole.getRoleName()))
        .thenReturn(java.util.Optional.of(secRole));

    Mockito.when(userBasicRepositoryMock.getOne(userBasic.getUserId())).thenReturn(userBasic);

    Mockito.when(userBasicRepositoryMock.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    // make sure we return back the userbasic that was sent
    // NOTE at this time the ID's are not being set and setting them afterword
    Mockito.when(userBasicRepositoryMock.save(Mockito.any(UserBasic.class)))
        .thenAnswer(
            new Answer<UserBasic>() {
              public UserBasic answer(InvocationOnMock invocation) {
                return invocation.getArgument(0);
              }
            });
    // first create a user
    UserBasic result = userService.addUser(userBasic, "TestP@ssword4");
    Assertions.assertNotNull(result);
    Assertions.assertEquals(userBasic.getUsername(), result.getUsername());
    // now update and set to locked and make sure it is loccked
    userBasic.setLocked("Y");
    userBasic.setActive("N");
    result = userService.updateUser(userBasic);
    Assertions.assertEquals("Y", result.getLocked());
    Assertions.assertEquals("N", result.getActive());
    userBasic.setLocked("N");
    userBasic.setActive("Y");
    result = userService.updateUser(userBasic);
    Assertions.assertEquals("N", result.getLocked());
    Assertions.assertEquals("Y", result.getActive());
  }

  @Test
  @DisplayName("UserBasic is not updated in database")
  public void testUpdateUserNotExisting() {
    UserBasic userBasic = new UserBasic();
    userBasic.setUsername("testUser");

    UserBasic userBasic1 = userService.updateUser(userBasic);
    assertNull(userBasic1);
    userBasic1 = userService.updateUser(userBasic);
    assertNull(userBasic1);
  }

  private UserBasic buildUserBasic() {

    SecRole secRole1 = new SecRole();
    secRole1.setRoleId(100L);
    secRole1.setRoleType("Billing");
    secRole1.setRoleName("Product");
    secRole1.setEffDate(new Date());
    secRole1.setCreated(new Date());
    secRole1.setActive("Y");

    UserBasic userBasic = new UserBasic();
    userBasic.setUsername("testUser");
    userBasic.setFirstName("testUser");
    userBasic.setLastName("testUser");
    userBasic.setPrefix("testPrefix");
    userBasic.setActive("Y");
    userBasic.setLocked("N");
    userBasic.setSecRole(secRole1);

    UserLogin userLogin = new UserLogin();
    userLogin.setUserloginId(1L);
    userLogin.setLastLogin(date);
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(passwordEncoder.encode("t3stP@ssword"));
    userLogin.setCreated(date);
    userLogin.setUpdated(date);
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    return userBasic;
  }

  UserNameByCriteriaRequest createValidUserNameByCriteriaRequest() {
    UserNameByCriteriaRequest criteriaRequest = new UserNameByCriteriaRequest();
    criteriaRequest.setUserId(1L);
    criteriaRequest.setUserName("testUser");
    criteriaRequest.setPermitPrimary("AUTH");
    criteriaRequest.setPermitSecondary("VIEW");
    LOB lob = new LOB();
    lob.setLobId(1L);
    lob.setLobName("ABC");
    lob.setOrganizationName("CL");
    criteriaRequest.setLob(lob);
    return criteriaRequest;
  }

  @SuppressWarnings("unchecked")
  @Test
  @DisplayName("Test getUserBySearchCriteria")
  void testGetUserBySearchCriteria() {
    List<UserBasic> users = new ArrayList<>();
    UserBasic userBasic1 = buildUserBasic();
    UserBasic userBasic2 = buildUserBasic();
    users.add(userBasic1);
    userBasic2.setUsername("root");
    users.add(userBasic2);
    when(userBasicRepositoryMock.findAll(Mockito.any(Specification.class))).thenReturn(users);
    List<UserBasic> userList =
        userService.getUserBySearchCriteria(createValidUserNameByCriteriaRequest());
    Assertions.assertNotNull(userList);
    Assertions.assertEquals(2, userList.size());
    Assertions.assertEquals("root", userList.get(1).getUsername());
  }

  @SuppressWarnings("unchecked")
  @Test
  @DisplayName("Test getUserBySearchCriteria returns no users")
  void testGetNoUserBySearchCriteria() {
    when(userBasicRepositoryMock.findAll(Mockito.any(Specification.class))).thenReturn(null);
    List<UserBasic> userList =
        userService.getUserBySearchCriteria(createValidUserNameByCriteriaRequest());
    Assertions.assertNull(userList);
  }

  @Test
  @DisplayName("Test UpdateTerminateDate with LockedUser")
  public void testUpdateTerminateDateWithLock() {
    UserBasic userBasic = buildUserBasic();
    when(userBasicRepositoryMock.save(userBasic)).thenReturn(userBasic);
    when(userBasicRepositoryMock.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    userService.updateTerminateDate(userBasic, "Y");
    Assertions.assertEquals("Y", userBasic.getLocked());
    Assertions.assertEquals("N", userBasic.getActive());
    Assertions.assertNotNull(userBasic.getTermDate());
  }

  @Test
  @DisplayName("Test UpdateTerminateDate with NonLockedUser")
  public void testUpdateTerminateDateWithNoLock() {
    UserBasic userBasic = buildUserBasic();
    when(userBasicRepositoryMock.save(userBasic)).thenReturn(userBasic);
    userService.updateTerminateDate(userBasic, "N");
    Assertions.assertEquals("N", userBasic.getLocked());
    Assertions.assertEquals("Y", userBasic.getActive());
    Assertions.assertNull(userBasic.getTermDate());
  }

  @Test
  public void testValidSecPermits() {
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    List<SecPermit> permitList = new ArrayList<>();
    permitList.add(permit);
    Optional<UserBasic> existingUser = buildUserData();
    String userName = existingUser.isPresent() ? existingUser.get().getUsername() : null;

    SecurityContext context = mock(SecurityContext.class);
    Authentication auth = mock(Authentication.class);
    when(context.getAuthentication()).thenReturn(auth);

    SecurityContextHolder.setContext(context);
    Mockito.when(auth.getName()).thenReturn(userName);
    when(userService.getUser()).thenReturn(existingUser);

    Mockito.when(mockSecPermitRepository.getAllSecPermits(Mockito.any(), Mockito.any()))
        .thenReturn(permitList);
    List<SecPermit> permitResult = userService.getAllSecPermits(Optional.of(1L));
    Assertions.assertNotNull(permitResult);
    Assertions.assertTrue(permitResult.size() > 0);
  }

  @Test
  public void testInvalidSecPermits() {
    SecurityContext context = mock(SecurityContext.class);
    Authentication auth = mock(Authentication.class);
    when(context.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(context);
    Mockito.when(auth.getName()).thenReturn(null);

    Mockito.when(mockSecPermitRepository.getAllSecPermits(Mockito.isNull(), any()))
        .thenReturn(null);

    List<SecPermit> permitNoUserResult = userService.getAllSecPermits(Optional.of(1L));
    Assertions.assertNull(permitNoUserResult);

    Mockito.when(mockSecPermitRepository.getAllSecPermits(Mockito.anyString(), Mockito.isNull()))
        .thenReturn(null);

    List<SecPermit> permitNoLobResult = userService.getAllSecPermits(null);
    Assertions.assertNull(permitNoLobResult);
  }

  private Optional<UserBasic> buildUserData() {
    UserBasic existingUser = buildUserBasic();
    return Optional.of(existingUser);
  }
}
