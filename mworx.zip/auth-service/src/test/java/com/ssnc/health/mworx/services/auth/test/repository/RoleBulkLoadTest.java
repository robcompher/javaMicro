/*
 * FILE : RoleBulkLoadTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This is to test RoleBulkLoadTest class It is used for creating bulk permits and roles. This
 * should be set to @Disabled unless you want to bulk load in pls or test.This has rollback to be
 * false - meaning that it will create entries by default it would create 12 and 13 avail and non
 * avail roles each with 5 permits.
 *
 * @author dt70033
 */
public class RoleBulkLoadTest extends BaseRepositoryTest {
  private static final int NO_NONAVAIL_PERMIT = 2000;
  private static final int NO_AVAIL_PERMIT = 1000;
  @Autowired private SecPermitRepository permitRepository;
  // From this point onwards you have to change
  // change 96 to 97 for eg. and change K to L down.
  public static final String PERMIT_PRIMARY = "Super Permit82";
  public static final String PERMIT_SECONDARY = "Super Permit";
  public static final String PERMIT_SECONDARY_ABBR = "Super P";
  public static final String STRING_VALUE = "RVAL";
  public static final String ROLE_TYPE_MIX_VALUE = "RRoLvAl1";
  public static final String ROLE_TYPE_VALUE = "RROLVAL1";

  @Test
  public void testBulkUpload() {
    // inserting data into db
    // first create primary and secondary permits
    SecPermit permit = getPermit();
    permit = permitRepository.save(permit);

    Optional<SecPermit> permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);

    // then create some links to the role , want it to be more than page size (10 in this test)
    for (int randomRoleNumber = 0; randomRoleNumber <= NO_AVAIL_PERMIT; randomRoleNumber++) {
      permit.setRoleLobPermits(new ArrayList<>());
      RoleLobPermit rlp = getRlpPermit(permit, randomRoleNumber);
      SecRole secRole = rlp.getSecRole();
      secRole.setDescription("Description for " + secRole.getRoleName() + secRole.getRoleType());
      for (int k = 0; k <= 4; k++) {
        permit.getRoleLobPermits().add(rlp);
        permit = permitRepository.save(permit);
        permit = getPermit();
        permit.setPermitPrimary(PERMIT_PRIMARY + randomRoleNumber + k);
        permit = permitRepository.save(permit);
        permit.setRoleLobPermits(new ArrayList<>());
        rlp = getRlpPermit(permit, randomRoleNumber);
        rlp.setSecRole(secRole);
      }
    }

    for (int randomRoleNumber = NO_AVAIL_PERMIT + 1;
        randomRoleNumber <= NO_NONAVAIL_PERMIT;
        randomRoleNumber++) {
      permit.setRoleLobPermits(new ArrayList<>());
      RoleLobPermit rlp = getRlpPermit(permit, randomRoleNumber);
      SecRole secRole = rlp.getSecRole();
      secRole.setActive("N");
      secRole.setDescription("Description for " + secRole.getRoleName() + secRole.getRoleType());
      for (int k = 0; k <= 4; k++) {
        permit.getRoleLobPermits().add(rlp);
        permit = permitRepository.save(permit);
        permit = getPermit();
        permit.setPermitPrimary(PERMIT_PRIMARY + randomRoleNumber + k);
        permit = permitRepository.save(permit);
        permit.setRoleLobPermits(new ArrayList<>());
        rlp = getRlpPermit(permit, randomRoleNumber);
        rlp.setSecRole(secRole);
      }
    }
  }

  private RoleLobPermit getRlpPermit(SecPermit permit, int randomRoleNumber) {
    RoleLobPermit rlp = new RoleLobPermit();
    rlp.setActive("Y");
    rlp.setSecPermit(permit);
    SecRole secRole = new SecRole();
    secRole.setActive("Y");
    secRole.setRoleName(STRING_VALUE + randomRoleNumber);
    secRole.setRoleType(ROLE_TYPE_VALUE + randomRoleNumber);
    secRole.setEffDate(new Date());
    rlp.setSecRole(secRole);
    return rlp;
  }

  private SecPermit getPermit() {
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    permit.setCreateBy(1L);
    permit.setCreated(new Date());
    permit.setDescription(STRING_VALUE);
    permit.setLegacySystemId(STRING_VALUE);
    permit.setPermitAdditional(STRING_VALUE);
    permit.setReadOnly("Y");
    permit.setUpdateBy(1L);
    permit.setUpdated(new Date());
    return permit;
  }
}
