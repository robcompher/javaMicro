/*
 * FILE : CustomAuthenticationEntryPointTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.errors;

import static org.junit.jupiter.api.Assertions.*;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ssnc.health.mworx.services.auth.errors.CustomAuthenticationEntryPoint;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
class CustomAuthenticationEntryPointTest {

  private CustomAuthenticationEntryPoint authenticationEntryPoint;

  @BeforeEach
  void setUp() throws Exception {
    authenticationEntryPoint = new CustomAuthenticationEntryPoint(new ObjectMapper());
  }

  @Test
  void testCommence() throws IOException, ServletException {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    AuthenticationException ex = new AuthenticationCredentialsNotFoundException("");

    authenticationEntryPoint.commence(request, response, ex);

    assertEquals(HttpServletResponse.SC_UNAUTHORIZED, response.getStatus());
  }
}
