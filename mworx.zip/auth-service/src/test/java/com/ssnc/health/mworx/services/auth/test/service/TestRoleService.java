/*
 * FILE : TestRoleService.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */

package com.ssnc.health.mworx.services.auth.test.service;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ssnc.health.mworx.services.auth.AuthServiceApplication;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.model.LnkSecPermit;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.repository.RoleLobPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.service.RoleServiceImpl;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.reactive.function.client.WebClient;

/**
 * This test case is used test the RoleService.
 *
 * @author dt224133
 */
@SpringBootTest(classes = AuthServiceApplication.class)
@ActiveProfiles("test")
public class TestRoleService {

  @InjectMocks private RoleServiceImpl roleService;
  @Mock private SecRoleRepository mockSecRoleRepository;
  @Mock private SecPermitRepository mockPermitRepository;
  @Mock private RoleLobPermitRepository mockRoleLobPermitRepository;

  private static final String PERMIT_PRIMARY = "SECURITY";
  private static final String PERMIT_SECONDARY = "View";
  public static final String PERMIT_PRIMARY_ADM = "Admin";
  public static final String PERMIT_SECONDARY_ADM = "Add";
  private static final String ACTIVE = "Y";
  List<SecRole> roles = null;
  List<SecPermit> permits = null;
  List<RoleLobPermit> lobPermits = null;
  PageRequest pageable = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, "linkId");

  @Autowired WebClient webClient;

  @BeforeEach
  public void init() {
    MockitoAnnotations.initMocks(this);
    roles = new ArrayList<>();
    permits = new ArrayList<>();
    SecRole secRole1 = new SecRole();
    secRole1.setRoleId(100L);
    secRole1.setRoleType("Billing");
    secRole1.setRoleName("Product");
    secRole1.setEffDate(new Date());
    secRole1.setCreated(new Date());
    secRole1.setActive("Y");
    roles.add(secRole1);

    SecRole secRole2 = new SecRole();
    secRole2.setRoleId(101L);
    secRole2.setRoleType("Product");
    secRole2.setRoleName("plan");
    secRole2.setEffDate(new Date());
    secRole2.setCreated(new Date());
    secRole2.setActive("Y");
    roles.add(secRole2);

    SecRole secRole3 = new SecRole();
    secRole3.setRoleId(102L);
    secRole3.setRoleType("Billing");
    secRole3.setRoleName("Product");
    secRole3.setEffDate(new Date());
    secRole3.setCreated(new Date());
    secRole3.setActive("Y");
    roles.add(secRole3);

    SecPermit secPermit1 = new SecPermit();
    secPermit1.setPermitId(200L);
    secPermit1.setPermitPrimary("PERMIT1");
    secPermit1.setPermitSecondary("SEC1");
    secPermit1.setActive("Y");
    permits.add(secPermit1);
    SecPermit secPermit2 = new SecPermit();
    secPermit2.setPermitId(201L);
    secPermit2.setPermitPrimary("PERMIT2");
    secPermit2.setPermitSecondary("SEC2");
    secPermit2.setActive("Y");
    permits.add(secPermit2);
  }

  @Test
  public void test() {

    SecRole secRole = new SecRole();
    secRole.setRoleId(104L);
    secRole.setRoleType("Billing");
    secRole.setRoleName("Product");
    secRole.setEffDate(new Date());
    secRole.setCreated(new Date());
    secRole.setActive("Y");

    // add or update Role
    when(mockSecRoleRepository.save(any(SecRole.class))).thenReturn(secRole);

    SecRole addOrUpdateRole = roleService.addRole(secRole);
    Assertions.assertNotNull(addOrUpdateRole);
    Assertions.assertEquals(secRole, addOrUpdateRole);
    Assertions.assertEquals(secRole.getActive(), addOrUpdateRole.getActive());

    // get all Roles
    PageRequest pageable = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, "roleName");
    when(mockSecRoleRepository.getAllActiveRoles(any(Pageable.class))).thenReturn(roles);
    when(mockSecRoleRepository.findAll(any(Pageable.class)))
        .thenAnswer(
            new Answer<Page<SecRole>>() {
              public Page<SecRole> answer(InvocationOnMock invocation) {
                Page<SecRole> page =
                    new PageImpl<SecRole>(Collections.singletonList(secRole), pageable, 1);
                return page;
              }
            });

    List<SecRole> roleList = roleService.getAllRoles(pageable, true);
    Assertions.assertNotNull(roleList);
    Assertions.assertTrue(roleList.size() == 1);
    roleList = roleService.getAllRoles(pageable, false);
    Assertions.assertNotNull(roleList);
    Assertions.assertTrue(roleList.size() == 3);

    // get RoleById
    when(mockSecRoleRepository.findById(102L)).thenReturn(Optional.of(roles.get(2)));
    Optional<SecRole> optionalSecRole = roleService.getRoleById(102L);
    Assertions.assertNotNull(optionalSecRole);
    Assertions.assertEquals(optionalSecRole.get(), roles.get(2));
  }

  @Test
  public void testGetRoleByRoleTypeAndRoleName() {
    when(mockSecRoleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenReturn(Optional.of(roles.get(1)));
    Optional<SecRole> optionalSecRole = roleService.getRoleByRoleTypeAndRoleName("Product", "plan");
    Assertions.assertNotNull(optionalSecRole);
    Assertions.assertEquals(optionalSecRole.get(), roles.get(1));
    verify(mockSecRoleRepository).findByRoleTypeAndRoleName(any(String.class), any(String.class));
  }

  @Test
  public void testUpdateRole() {
    SecRole secRole = roles.get(1);
    secRole.setActive("N");
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("VIEW");
    lobPermit.setSecPermit(secPermit);
    secRole.getRoleLobPermits().add(lobPermit);
    Optional<SecPermit> optionalSecPermit = Optional.of(secPermit);

    when(mockSecRoleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenReturn(Optional.of(secRole));
    when(mockSecRoleRepository.save(any(SecRole.class))).thenReturn(roles.get(1));
    when(mockPermitRepository.findByPermitPrimaryAndPermitSecondary(
            any(String.class), any(String.class)))
        .thenReturn(optionalSecPermit);
    when(mockSecRoleRepository.findById(101L)).thenReturn(Optional.of(secRole));

    SecRole updatedSecRole = roleService.updateRole(secRole);
    Assertions.assertNotNull(updatedSecRole);
    Assertions.assertEquals("N", secRole.getActive());
    verify(mockSecRoleRepository).save(any(SecRole.class));
  }

  @Test
  public void testSearchCriteria() {
    SecRole secRole = roles.get(1);
    secRole.setActive("N");
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("VIEW");
    lobPermit.setSecPermit(secPermit);
    secRole.getRoleLobPermits().add(lobPermit);
    Optional<SecPermit> optionalSecPermit = Optional.of(secPermit);
    PageRequest pageable = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, "roleType");
    when(mockSecRoleRepository.findAll(any(Specification.class), any((Pageable.class))))
        .thenAnswer(
            new Answer<Page<SecRole>>() {
              public Page<SecRole> answer(InvocationOnMock invocation) {
                Page<SecRole> page =
                    new PageImpl<SecRole>(Collections.singletonList(secRole), pageable, 1);
                return page;
              }
            });
    when(mockSecRoleRepository.save(any(SecRole.class))).thenReturn(roles.get(1));
    when(mockPermitRepository.findByPermitPrimaryAndPermitSecondary(
            any(String.class), any(String.class)))
        .thenReturn(optionalSecPermit);

    SummaryRoleSearchCriteria roleSearchCriteria = new SummaryRoleSearchCriteria();
    roleSearchCriteria.setRoleType("RT");
    String activeFlag = "Y";
    Page<SecRole> secRole1 = roleService.findRoleByCriteria(roleSearchCriteria, pageable);
    Assertions.assertNotNull(secRole1);
  }

  @Test
  public void testCreateRoleWithLOB() {

    SecRole secRole = roles.get(0);
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    lobPermit.setLobId(1L);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("VIEW");
    lobPermit.setSecPermit(secPermit);
    secRole.getRoleLobPermits().add(lobPermit);
    Optional<SecPermit> optionalSecPermit = Optional.of(secPermit);
    when(mockSecRoleRepository.save(any(SecRole.class))).thenReturn(roles.get(0));
    when(mockPermitRepository.findByPermitPrimaryAndPermitSecondary(
            any(String.class), any(String.class)))
        .thenReturn(optionalSecPermit);
    SecRole secRole2 = roleService.addRole(secRole);
    Assertions.assertTrue(secRole2.getRoleLobPermits().size() > 0);
    Assertions.assertTrue(secRole2.getRoleLobPermits().get(0).getLobId().equals(1L));
  }

  @Test
  public void testPermitSearchCriteriaWithLOB() {

    List<RoleLobPermit> lobPermits = buildRoleLobPermit();
    RoleLobPermit lobPermit = lobPermits.get(0);

    SummaryPermitSearchCriteria permitSearchCriteria = new SummaryPermitSearchCriteria();
    permitSearchCriteria.setPrimaryPermit(PERMIT_PRIMARY);
    permitSearchCriteria.setSecondaryPermit(PERMIT_SECONDARY);
    permitSearchCriteria.setRoleId(100L);
    LOB lob = new LOB();
    lob.setLobId(1L);
    permitSearchCriteria.setLob(lob);

    when(mockRoleLobPermitRepository.save(any(RoleLobPermit.class))).thenReturn(lobPermit);
    when(mockRoleLobPermitRepository.findAll(any(Specification.class), any((Pageable.class))))
        .thenAnswer(
            new Answer<Page<RoleLobPermit>>() {
              public Page<RoleLobPermit> answer(InvocationOnMock invocation) {
                Page<RoleLobPermit> page =
                    new PageImpl<RoleLobPermit>(Collections.singletonList(lobPermit), pageable, 1);
                return page;
              }
            });
    Page<RoleLobPermit> roleLobPermits =
        roleService.findAssociatedPermitsByCriteria(permitSearchCriteria, pageable);
    Assertions.assertNotNull(roleLobPermits);
    Assertions.assertNotNull(roleLobPermits.getContent().get(0).getLobId());
  }

  @Test
  public void testPermitSearchCriteriaWithNoLOB() {

    List<RoleLobPermit> lobPermits = buildRoleLobPermit();
    RoleLobPermit lobPermit = lobPermits.get(1);

    SummaryPermitSearchCriteria permitSearchCriteria = new SummaryPermitSearchCriteria();
    permitSearchCriteria.setPrimaryPermit(PERMIT_PRIMARY_ADM);
    permitSearchCriteria.setSecondaryPermit(PERMIT_SECONDARY_ADM);
    permitSearchCriteria.setRoleId(101L);

    when(mockRoleLobPermitRepository.save(any(RoleLobPermit.class))).thenReturn(lobPermit);
    when(mockRoleLobPermitRepository.findAll(any(Specification.class), any((Pageable.class))))
        .thenAnswer(
            new Answer<Page<RoleLobPermit>>() {
              public Page<RoleLobPermit> answer(InvocationOnMock invocation) {
                Page<RoleLobPermit> page =
                    new PageImpl<RoleLobPermit>(Collections.singletonList(lobPermit), pageable, 1);
                return page;
              }
            });
    when(mockRoleLobPermitRepository.save(any(RoleLobPermit.class))).thenReturn(lobPermit);
    Page<RoleLobPermit> roleLobPermits =
        roleService.findAssociatedPermitsByCriteria(permitSearchCriteria, pageable);
    Assertions.assertNull(roleLobPermits.getContent().get(0).getLobId());
  }

  private List<RoleLobPermit> buildRoleLobPermit() {
    lobPermits = new ArrayList<>();
    SecRole secRole4 = roles.get(0);
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setLinkId(1L);
    lobPermit.setLobId(1L);
    lobPermit.setActive(ACTIVE);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitPrimary(PERMIT_PRIMARY);
    secPermit.setPermitSecondary(PERMIT_SECONDARY);
    lobPermit.setSecPermit(secPermit);
    lobPermit.setSecRole(secRole4);
    secRole4.getRoleLobPermits().add(lobPermit);
    lobPermits.add(lobPermit);

    SecRole secRole5 = roles.get(1);
    RoleLobPermit lobPermit1 = new RoleLobPermit();
    lobPermit.setLinkId(10L);
    lobPermit.setActive(ACTIVE);
    SecPermit secPermit1 = new SecPermit();
    secPermit.setPermitPrimary(PERMIT_PRIMARY_ADM);
    secPermit.setPermitSecondary(PERMIT_SECONDARY_ADM);
    lobPermit.setSecPermit(secPermit1);
    lobPermit.setSecRole(secRole5);
    secRole5.getRoleLobPermits().add(lobPermit1);
    lobPermits.add(lobPermit1);
    return lobPermits;
  }

  @Test
  public void testFindRolePermitById() {
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    lobPermit.setLinkId(4L);
    lobPermit.setLobId(1L);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    lobPermit.setSecPermit(secPermit);
    SecRole role = new SecRole();
    role.setRoleId(3L);
    lobPermit.setSecRole(role);
    Optional<RoleLobPermit> rlp = Optional.of(lobPermit);
    when(mockRoleLobPermitRepository.findById(4L)).thenReturn(rlp);
    when(mockRoleLobPermitRepository.findById(5L)).thenReturn(Optional.empty());
    RoleLobPermit rlp3 = roleService.findRoleLobPermit(lobPermit.getLinkId());
    Assertions.assertEquals(rlp3.getActive(), lobPermit.getActive());
    Assertions.assertTrue(rlp3.getLobId().compareTo(lobPermit.getLobId()) == 0);
    Assertions.assertTrue(
        rlp3.getSecPermit().getPermitId().compareTo(lobPermit.getSecPermit().getPermitId()) == 0);
    Assertions.assertTrue(
        rlp3.getSecRole().getRoleId().compareTo(lobPermit.getSecRole().getRoleId()) == 0);
    // now try invalid  should return null
    RoleLobPermit rlp4 = roleService.findRoleLobPermit(5L);
    Assertions.assertNull(rlp4);
  }

  @Test
  public void testDeleteRolePermit() {
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    lobPermit.setLinkId(4L);
    lobPermit.setLobId(1L);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    lobPermit.setSecPermit(secPermit);
    SecRole role = new SecRole();
    role.setRoleId(3L);
    lobPermit.setSecRole(role);
    Optional<RoleLobPermit> rlp = Optional.of(lobPermit);
    when(mockRoleLobPermitRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<RoleLobPermit>>() {
              public Optional<RoleLobPermit> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                if (value.compareTo(4L) == 0) {
                  lobPermit.setActive("N");
                  return rlp;
                } else {
                  return Optional.empty();
                }
              }
            });
    roleService.deleteRoleLobPermit(4L);
    Assertions.assertEquals("N", roleService.findRoleLobPermit(4L).getActive());
  }

  @Test
  public void verifyDeleteLobPermitMethod() {
    SecRole role = new SecRole();
    role.setRoleId(1L);
    RoleLobPermit lobPermitWithSubPermit = new RoleLobPermit();
    lobPermitWithSubPermit.setActive("Y");
    lobPermitWithSubPermit.setLinkId(4L);
    lobPermitWithSubPermit.setLobId(1L);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitId(1L);
    lobPermitWithSubPermit.setSecPermit(secPermit);
    lobPermitWithSubPermit.setSecRole(role);
    SecPermit secPermit2 = new SecPermit();
    secPermit2.setPermitId(2L);
    RoleLobPermit lobPermitWithNoSubPermit = new RoleLobPermit();

    lobPermitWithNoSubPermit.setActive("Y");
    lobPermitWithNoSubPermit.setLinkId(5L);
    lobPermitWithNoSubPermit.setLobId(1L);
    lobPermitWithNoSubPermit.setSecPermit(secPermit2);
    lobPermitWithNoSubPermit.setSecRole(role);
    LnkSecPermit lnk = new LnkSecPermit();
    lnk.setSecPermitByImplicitPermitId(secPermit2);
    lnk.setSecPermitByPermitId(secPermit);
    secPermit.setLnkSecPermitsForPermitId(new ArrayList<>());
    secPermit.setLnkSecPermitsForImplicitPermitId(new ArrayList<>());
    secPermit.getLnkSecPermitsForPermitId().add(lnk);
    secPermit2.setLnkSecPermitsForPermitId(new ArrayList<>());
    secPermit2.setLnkSecPermitsForImplicitPermitId(new ArrayList<>());
    secPermit2.getLnkSecPermitsForImplicitPermitId().add(lnk);
    // mocks
    when(mockRoleLobPermitRepository.findById(4L)).thenReturn(Optional.of(lobPermitWithSubPermit));
    when(mockRoleLobPermitRepository.findById(5L))
        .thenReturn(Optional.of(lobPermitWithNoSubPermit));
    when(mockRoleLobPermitRepository.findById(6L)).thenReturn(Optional.empty());

    when(mockPermitRepository.getActiveSecPermitsByRoleAndLOB(any(Long.class), any(Long.class)))
        .thenAnswer(
            new Answer<List<SecPermit>>() {
              public List<SecPermit> answer(InvocationOnMock invocation) {
                List<SecPermit> lst = new ArrayList<>();
                Long roleId = (Long) invocation.getArguments()[0];
                Long lobId = (Long) invocation.getArguments()[1];
                if (roleId.longValue() == 1L && lobId.longValue() == 1L) {
                  lst.add(secPermit);
                  lst.add(secPermit2);
                }
                return lst;
              }
            });
    Assertions.assertTrue(roleService.verifyDeleteLobPermit(4L));
    Assertions.assertFalse(roleService.verifyDeleteLobPermit(5L));
    Assertions.assertTrue(roleService.verifyDeleteLobPermit(6L));
  }

  @Test
  public void testUpdatingPermits() {
    when(mockPermitRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecPermit>>() {
              public Optional<SecPermit> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                return permits.stream()
                    .filter(permit -> value.compareTo(permit.getPermitId()) == 0)
                    .findFirst();
              }
            });
    when(mockPermitRepository.findByPermitPrimaryAndPermitSecondary(
            any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecPermit>>() {
              public Optional<SecPermit> answer(InvocationOnMock invocation) {
                String primary = (String) invocation.getArguments()[0];
                String secondary = (String) invocation.getArguments()[1];
                return permits.stream()
                    .filter(
                        permit ->
                            primary.equalsIgnoreCase(permit.getPermitPrimary())
                                && secondary.equalsIgnoreCase(permit.getPermitSecondary()))
                    .findFirst();
              }
            });
    when(mockRoleLobPermitRepository.save(any(RoleLobPermit.class))).thenReturn(null);
    when(mockSecRoleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                String roleType = (String) invocation.getArguments()[0];
                String roleName = (String) invocation.getArguments()[1];
                return roles.stream()
                    .filter(
                        role ->
                            roleType.equalsIgnoreCase(role.getRoleType())
                                && roleName.equalsIgnoreCase(role.getRoleName()))
                    .findFirst();
              }
            });
    when(mockSecRoleRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                return roles.stream()
                    .filter(role -> value != null && value.compareTo(role.getRoleId()) == 0)
                    .findFirst();
              }
            });
    // input  saving two permits with ids
    SecRole inputRole = new SecRole();
    inputRole.setRoleId(roles.get(0).getRoleId());
    inputRole.setRoleName(roles.get(0).getRoleName());
    inputRole.setRoleType(roles.get(0).getRoleType());
    SecPermit inputPermit = new SecPermit();
    inputPermit.setPermitId(permits.get(0).getPermitId());
    inputPermit.setPermitPrimary(permits.get(0).getPermitPrimary());
    inputPermit.setPermitSecondary(permits.get(0).getPermitSecondary());
    inputRole.setRoleLobPermits(new ArrayList<>());
    RoleLobPermit rlp = new RoleLobPermit();
    rlp.setLobId(5L);
    rlp.setSecPermit(inputPermit);
    rlp.setSecRole(inputRole);
    inputRole.getRoleLobPermits().add(rlp);
    roleService.saveUpdatedPermits(inputRole);
    Assertions.assertEquals(1, inputRole.getRoleLobPermits().size());
    // now ad that permit to the role already there.  Shouldn't save anything
    roles.get(0).setRoleLobPermits(new ArrayList<>());
    roles.get(0).getRoleLobPermits().add(rlp);
    roleService.saveUpdatedPermits(inputRole);
    Assertions.assertEquals(1, inputRole.getRoleLobPermits().size());
    // now add to a different LOB
    RoleLobPermit rlp2 = new RoleLobPermit();
    rlp2.setLobId(4L);
    rlp2.setSecPermit(inputPermit);
    rlp2.setSecRole(inputRole);
    inputRole.getRoleLobPermits().add(rlp2);
    inputRole = roleService.saveUpdatedPermits(inputRole);
    Assertions.assertEquals(2, inputRole.getRoleLobPermits().size());
    // duplicate  should only save 1
    RoleLobPermit rlp3 = new RoleLobPermit();
    rlp3.setLobId(4L);
    rlp3.setSecPermit(inputPermit);
    rlp3.setSecRole(inputRole);
    inputRole.getRoleLobPermits().add(rlp3);
    inputRole = roleService.saveUpdatedPermits(inputRole);
    Assertions.assertEquals(2, inputRole.getRoleLobPermits().size());
    // remove id and use name/type  should do same thing
    rlp2.getSecPermit().setPermitId(permits.get(0).getPermitId());
    inputRole.setRoleId(null);
    roleService.saveUpdatedPermits(inputRole);
    Assertions.assertEquals(2, inputRole.getRoleLobPermits().size());

    // database now have a different one.  Should make 2 with different lob
    RoleLobPermit rlp4 = new RoleLobPermit();
    rlp4.setLobId(5L);
    rlp4.setSecPermit(permits.get(1));
    rlp4.setSecRole(inputRole);
    rlp4.setActive("N");
    roles.get(0).setRoleLobPermits(new ArrayList<>());
    roles.get(0).getRoleLobPermits().add(rlp4);
    inputRole = roleService.saveUpdatedPermits(inputRole);
    inputRole.getRoleLobPermits().clear();
    inputRole.getRoleLobPermits().add(rlp);
    inputRole.getRoleLobPermits().add(rlp2);
    inputRole.getRoleLobPermits().add(rlp3);
    inputRole = roleService.saveUpdatedPermits(inputRole);
    Assertions.assertEquals(2, inputRole.getRoleLobPermits().size());
  }

  @Test
  public void testNonAssocitedPermitsService() {

    List<RoleLobPermit> lobPermits = buildRoleLobPermit();
    RoleLobPermit lobPermit = lobPermits.get(0);
    SecPermit permit = permits.get(0);

    SummaryPermitSearchCriteria permitSearchCriteria = new SummaryPermitSearchCriteria();
    permitSearchCriteria.setPrimaryPermit(PERMIT_PRIMARY);
    permitSearchCriteria.setSecondaryPermit(PERMIT_SECONDARY);
    permitSearchCriteria.setRoleId(100L);
    LOB lob = new LOB();
    lob.setLobId(1L);
    permitSearchCriteria.setLob(lob);

    when(mockRoleLobPermitRepository.save(any(RoleLobPermit.class))).thenReturn(lobPermit);
    when(mockPermitRepository.save(any(SecPermit.class))).thenReturn(permit);
    when(mockPermitRepository.findAll(any(Specification.class), any((Pageable.class))))
        .thenAnswer(
            new Answer<Page<SecPermit>>() {
              public Page<SecPermit> answer(InvocationOnMock invocation) {
                Page<SecPermit> page =
                    new PageImpl<SecPermit>(Collections.singletonList(permit), pageable, 10);
                return page;
              }
            });
    Page<SecPermit> secPermits =
        roleService.findNonAssociatedPermitsByCriteria(permitSearchCriteria, pageable);
    Assertions.assertNotNull(secPermits);
    Assertions.assertEquals(10, secPermits.getTotalElements());
    Assertions.assertEquals("PERMIT1", secPermits.getContent().get(0).getPermitPrimary());
    Assertions.assertEquals("SEC1", secPermits.getContent().get(0).getPermitSecondary());
  }

  @Test
  public void testUpdatePermitsWithImplicitPermits() {
    SecPermit implicitpermit = new SecPermit();
    implicitpermit.setActive("Y");
    implicitpermit.setPermitId(88L);
    implicitpermit.setPermitPrimary("IMPLICIT");
    implicitpermit.setPermitSecondary("IMPLICIT");

    when(mockPermitRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecPermit>>() {
              public Optional<SecPermit> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                Optional<SecPermit> finalPermit =
                    permits.stream()
                        .filter(permit -> value.compareTo(permit.getPermitId()) == 0)
                        .findFirst();
                if (finalPermit.isPresent()) {
                  finalPermit.get().setLnkSecPermitsForPermitId(new ArrayList<>());
                  LnkSecPermit lnkSecPermit = new LnkSecPermit();
                  lnkSecPermit.setSecPermitByPermitId(finalPermit.get());
                  lnkSecPermit.setSecPermitByImplicitPermitId(implicitpermit);
                  finalPermit.get().getLnkSecPermitsForPermitId().add(lnkSecPermit);
                }
                return finalPermit;
              }
            });
    when(mockPermitRepository.findByPermitPrimaryAndPermitSecondary(
            any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecPermit>>() {
              public Optional<SecPermit> answer(InvocationOnMock invocation) {
                String primary = (String) invocation.getArguments()[0];
                String secondary = (String) invocation.getArguments()[1];

                Optional<SecPermit> finalPermit =
                    permits.stream()
                        .filter(
                            permit ->
                                primary.equalsIgnoreCase(permit.getPermitPrimary())
                                    && secondary.equalsIgnoreCase(permit.getPermitSecondary()))
                        .findFirst();
                if (finalPermit.isPresent()) {
                  finalPermit.get().setLnkSecPermitsForPermitId(new ArrayList<>());
                  LnkSecPermit lnkSecPermit = new LnkSecPermit();
                  lnkSecPermit.setSecPermitByPermitId(finalPermit.get());
                  lnkSecPermit.setSecPermitByImplicitPermitId(implicitpermit);
                  finalPermit.get().getLnkSecPermitsForPermitId().add(lnkSecPermit);
                }
                return finalPermit;
              }
            });
    when(mockRoleLobPermitRepository.save(any(RoleLobPermit.class))).thenReturn(null);
    when(mockSecRoleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                String roleType = (String) invocation.getArguments()[0];
                String roleName = (String) invocation.getArguments()[1];
                return roles.stream()
                    .filter(
                        role ->
                            roleType.equalsIgnoreCase(role.getRoleType())
                                && roleName.equalsIgnoreCase(role.getRoleName()))
                    .findFirst();
              }
            });
    when(mockSecRoleRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                return roles.stream()
                    .filter(role -> value != null && value.compareTo(role.getRoleId()) == 0)
                    .findFirst();
              }
            });
    // input  saving permit  shoud get implicit permit
    SecRole inputRole = new SecRole();
    inputRole.setRoleId(roles.get(0).getRoleId());
    inputRole.setRoleName(roles.get(0).getRoleName());
    inputRole.setRoleType(roles.get(0).getRoleType());
    SecPermit inputPermit = new SecPermit();
    inputPermit.setPermitId(permits.get(0).getPermitId());
    inputPermit.setPermitPrimary(permits.get(0).getPermitPrimary());
    inputPermit.setPermitSecondary(permits.get(0).getPermitSecondary());
    inputRole.setRoleLobPermits(new ArrayList<>());
    RoleLobPermit rlp = new RoleLobPermit();
    rlp.setLobId(5L);
    rlp.setSecPermit(inputPermit);
    rlp.setSecRole(inputRole);
    inputRole.getRoleLobPermits().add(rlp);
    roleService.saveUpdatedPermits(inputRole);
    Assertions.assertEquals(2, inputRole.getRoleLobPermits().size());
    Assertions.assertTrue(
        inputRole.getRoleLobPermits().stream()
            .filter(rlp2 -> rlp2.getSecPermit().getPermitPrimary().equalsIgnoreCase("IMPLICIT"))
            .findAny()
            .isPresent());
    // make sure add does same thing
    inputRole.getRoleLobPermits().clear();
    inputRole.getRoleLobPermits().add(rlp);
    roleService.addRole(inputRole);
    Assertions.assertEquals(2, inputRole.getRoleLobPermits().size());
    // make sure update role does same thing
    inputRole.getRoleLobPermits().clear();
    inputRole.getRoleLobPermits().add(rlp);
  }

  @Test
  public void addRoleWithoutPermits() {
    SecRole secRole = new SecRole();
    secRole.setRoleId(104L);
    secRole.setRoleType("Billing");
    secRole.setRoleName("Product");
    secRole.setEffDate(new Date());
    secRole.setCreated(new Date());
    secRole.setActive("Y");
    secRole.setRoleLobPermits(null);

    // add or update Role
    when(mockSecRoleRepository.save(any(SecRole.class))).thenReturn(secRole);

    SecRole addOrUpdateRole = roleService.addRole(secRole);
    Assertions.assertEquals(addOrUpdateRole.getActive(), secRole.getActive());
  }
}
