/*
FILE : AppUserTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.security;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.MockitoAnnotations;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@ActiveProfiles("test")
class AppUserTest {

  private AppUser appUser;
  private SecRole secRole;
  private SecPermit secPermit;
  private RoleLobPermit roleLobPermit;
  private List<RoleLobPermit> roleLobPermitList;
  private Optional<SecRole> optionalSecRole;
  private List<GrantedAuthority> authorityList;

  private static final String VALUE = "VALUE";
  MockHttpServletRequest request = new MockHttpServletRequest();

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
    RequestContextHolder.setRequestAttributes(new ServletRequestAttributes(request));

    appUser = new AppUser();
    secRole = new SecRole();
    SecPermit secPermit = new SecPermit();
    roleLobPermit = new RoleLobPermit();
    List<Long> lobIds = new ArrayList<>();
    lobIds.add(1L);
    lobIds.add(2L);
    secPermit.setPermitId(2L);
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("UPDATE");
    secPermit.setActive("Y");
    secRole.setRoleId(1L);
    secRole.setRoleType("System Admin");
    secRole.setRoleName("Security");
    secRole.setActive("Y");
    roleLobPermit.setLinkId(2L);
    roleLobPermit.setLobId(lobIds.get(0));
    roleLobPermit.setSecRole(secRole);
    roleLobPermit.setSecPermit(secPermit);
    roleLobPermitList = new ArrayList<>();
    roleLobPermitList.add(roleLobPermit);
    secRole.setRoleLobPermits(roleLobPermitList);
    optionalSecRole = Optional.of(secRole);
    appUser.setRole(optionalSecRole);
    appUser.setCurrentLobId(lobIds.get(0));
    appUser.setLineOfBusinesses(lobIds);
    authorityList = new ArrayList<>();
  }

  @Test
  void testPermitsWithLOB() {
    secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("UPDATE");
    RoleLobPermit roleLobPermit = new RoleLobPermit();
    roleLobPermit.setLinkId(5L);
    roleLobPermit.setLobId(null);
    roleLobPermit.setSecRole(secRole);
    roleLobPermit.setSecPermit(secPermit);
    secRole.getRoleLobPermits().add(roleLobPermit);
    // current LOB is 1  should be 3 (2 permits and 1 role) since picking up null
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(3, authorityList.size());
    // make one inactive..one  same number
    secPermit = new SecPermit();
    secPermit.setPermitId(3L);
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("VIEW");
    secPermit.setActive("N");
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(3, authorityList.size());

    roleLobPermit = new RoleLobPermit();
    roleLobPermit.setLinkId(5L);
    roleLobPermit.setLobId(1L);
    roleLobPermit.setSecRole(secRole);
    roleLobPermit.setSecPermit(secPermit);
    secRole.getRoleLobPermits().add(roleLobPermit);
    // set it to 2  should be one the one for permit
    appUser.setCurrentLobId(2L);
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(2, authorityList.size());
    // add a permit for 2 should now be still one  the new one
    roleLobPermit = new RoleLobPermit();
    roleLobPermit.setLinkId(6L);
    roleLobPermit.setLobId(2L);
    roleLobPermit.setSecRole(secRole);
    roleLobPermit.setSecPermit(secPermit);
    secRole.getRoleLobPermits().add(roleLobPermit);
    appUser.setCurrentLobId(2L);
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(2, authorityList.size());
    // send one not int he list of available  should be one
    appUser.setCurrentLobId(3L);
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();
    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(2, authorityList.size());
    // if current lob is null just return the 3
    appUser.setCurrentLobId(1L);

    // check to make sure the lobID gets set fro the request
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();
    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(3, authorityList.size());
    request.setParameter("currentLobId", "1");
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();
    Assertions.assertTrue(appUser.getCurrentLobId().equals(1L));
    request.removeParameter("currentLobId");
    appUser.setCurrentLobId(null);
    request.setParameter("currentLobId", "88");
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();
    Assertions.assertNull(appUser.getCurrentLobId());
  }

  @Test
  void testRoleLobPermitActive() {
    secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("UPDATE");
    RoleLobPermit roleLobPermit = new RoleLobPermit();
    roleLobPermit.setLinkId(5L);
    roleLobPermit.setLobId(null);
    roleLobPermit.setSecRole(secRole);
    roleLobPermit.setSecPermit(secPermit);
    roleLobPermit.setActive("Y");
    secRole.getRoleLobPermits().add(roleLobPermit);
    // current LOB is 1  should be 3 (2 permits and 1 role) since picking up RoleLobPermit active
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(3, authorityList.size());

    secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("UPDATE");
    roleLobPermit = new RoleLobPermit();
    roleLobPermit.setLinkId(5L);
    roleLobPermit.setLobId(null);
    roleLobPermit.setSecRole(secRole);
    roleLobPermit.setSecPermit(secPermit);
    roleLobPermit.setActive("N");
    secRole.getRoleLobPermits().add(roleLobPermit);
    // make RoleLobPermit inactive, should be same number
    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(3, authorityList.size());
  }

  @Test
  void testGetAuthoritiesRolePresent() {

    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
  }

  @Test
  void testGetAuthoritiesRoleNotPresent() {

    appUser.setRole(optionalSecRole.empty());
    appUser.setNoOfDaysToPasswordExpire(10);

    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(0, authorityList.size());
  }

  @Test
  void testUserPasswordExpired() {

    appUser.setRole(optionalSecRole.empty());
    appUser.setNoOfDaysToPasswordExpire(0);

    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(0, authorityList.size());
  }

  @Test
  void testUserPasswordExpiredNegDays() {

    appUser.setRole(optionalSecRole.empty());
    appUser.setNoOfDaysToPasswordExpire(-1);

    authorityList = (List<GrantedAuthority>) appUser.getAuthorities();

    Assertions.assertNotNull(authorityList);
    Assertions.assertEquals(2, authorityList.size());

    Assertions.assertNotNull(authorityList.get(0).getAuthority());
    Assertions.assertEquals("PERMIT_USER_CHANGE_PASSWORD", authorityList.get(0).getAuthority());
    Assertions.assertNotNull(authorityList.get(1).getAuthority());
    Assertions.assertEquals("PERMIT_METADATA_LOB_VIEW", authorityList.get(1).getAuthority());
  }

  @Test
  void testGetSet() {
    appUser.setAccountNonExpired(true);
    appUser.setAccountNonLocked(true);
    appUser.setCredentialsNonExpired(true);
    appUser.setCurrentLobId(1L);
    appUser.setEnabled(true);
    appUser.setFirstName(VALUE);
    appUser.setLastName(VALUE);
    appUser.setLineOfBusinesses(null);
    appUser.setNoOfDaysToPasswordExpire(1L);
    appUser.setPassword(VALUE);
    appUser.setRole(null);
    appUser.setUserId(1L);
    appUser.setUsername(VALUE);
    Assertions.assertTrue(appUser.isAccountNonExpired());
    Assertions.assertTrue(appUser.isAccountNonLocked());
    Assertions.assertTrue(appUser.isCredentialsNonExpired());
    Assertions.assertTrue(appUser.isEnabled());
    Assertions.assertEquals(VALUE, appUser.getFirstName());
    Assertions.assertEquals(VALUE, appUser.getLastName());
    Assertions.assertEquals(VALUE, appUser.getPassword());
    Assertions.assertEquals(VALUE, appUser.getUsername());
    Assertions.assertTrue(appUser.getCurrentLobId().equals(1L));
    Assertions.assertTrue(appUser.getUserId().equals(1L));
  }
}
