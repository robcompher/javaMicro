/*
 * FILE : RoleRepositoryCriteriaTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.RoleSpecification;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

/**
 * This is to test RoleRepositoryCriteriaTest class It is used for testing that the summary roles
 * that gets called by the UI as part of findSearchCriteria gets tested with various combinations of
 * the query . roletype,rolename,primary and secondary permit along with active flag are the
 * combinations with/without pagination
 *
 * @author dt70033
 */
public class RoleRepositoryCriteriaTest extends BaseRepositoryTest {

  @Autowired private SecRoleRepository roleRepository;
  @Autowired private SecPermitRepository permitRepository;
  public static final String ROLE_NAME = "New Role1";
  public static final String ROLE_TYPE = "Super Duper1";
  public static long ROLE_ID = 23;
  public static final String PERMIT_PRIMARY = "Super Permit";
  public static final String PERMIT_SECONDARY = "Super Permit";
  public static final String PERMIT_SECONDARY_ABBR = "Super P";
  public static final String STRING_VALUE = "VAL";
  public static final String ROLE_TYPE_MIX_VALUE = "RoLvAl";
  public static final String ROLE_TYPE_VALUE = "ROLVAL";
  private PageRequest pageable = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, "roleType");
  private Page<SecRole> pageSecRole = null;
  private Long lobId = null;

  @BeforeEach
  public void testRoleCriteriaQuery() {
    // inserting data into db
    // first create primary and secondary permits
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    permit.setCreateBy(1L);
    permit.setCreated(new Date());
    permit.setDescription(STRING_VALUE);
    permit.setLegacySystemId(STRING_VALUE);
    permit.setPermitAdditional(STRING_VALUE);
    permit.setReadOnly("Y");
    permit.setUpdateBy(1L);
    permit.setUpdated(new Date());
    permit = permitRepository.save(permit);

    Optional<SecPermit> permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);

    // then create some links to the role , want it to be more than page size (10 in this test)
    for (int randomRoleNumber = 0; randomRoleNumber <= 12; randomRoleNumber++) {
      permit.setRoleLobPermits(new ArrayList<>());
      RoleLobPermit rlp = new RoleLobPermit();
      rlp.setActive("Y");
      rlp.setSecPermit(permit);
      SecRole secRole = new SecRole();
      secRole.setActive("Y");
      secRole.setRoleName(STRING_VALUE + randomRoleNumber);
      secRole.setRoleType(ROLE_TYPE_VALUE + randomRoleNumber);
      secRole.setEffDate(new Date());
      rlp.setSecRole(secRole);
      permit.getRoleLobPermits().add(rlp);
      permit = permitRepository.save(permit);
    }

    for (int randomRoleNumber = 13; randomRoleNumber <= 25; randomRoleNumber++) {
      permit.setRoleLobPermits(new ArrayList<>());
      RoleLobPermit rlp = new RoleLobPermit();
      rlp.setActive("Y");
      rlp.setSecPermit(permit);
      SecRole secRole = new SecRole();
      secRole.setActive("N");
      secRole.setRoleName(STRING_VALUE + randomRoleNumber);
      secRole.setRoleType(ROLE_TYPE_VALUE + randomRoleNumber);
      secRole.setEffDate(new Date());
      rlp.setSecRole(secRole);
      permit.getRoleLobPermits().add(rlp);
      permit = permitRepository.save(permit);
    }

    permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);
  }

  @Test
  public void testRoleTypeEqualCriteria() {
    Long lobId = null;
    Page<SecRole> pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    ROLE_TYPE_VALUE + 0, null, null, null, (Long) lobId, "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testRoleTypeIgnoreCaseCriteria() {
    Long lobId = null;
    Page<SecRole> pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    ROLE_TYPE_MIX_VALUE + 0, null, null, null, (Long) lobId, "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testLikeRoleTypeCriteria() {
    Long lobId = null;

    pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    ROLE_TYPE_VALUE, null, null, null, (Long) lobId, "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testSpecificRoleTypeAndNameCriteria() {
    Long lobId = null;

    pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    ROLE_TYPE_VALUE + 0, STRING_VALUE + 0, null, null, (Long) lobId, "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testAllCriteriaMixed() {
    Long lobId = null;
    pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    mixedCase(ROLE_TYPE_VALUE + 0),
                    mixedCase(STRING_VALUE + 0),
                    mixedCase(PERMIT_PRIMARY),
                    mixedCase(PERMIT_SECONDARY),
                    (Long) lobId,
                    "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testAllCriteria() {
    Long lobId = null;

    pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    ROLE_TYPE_VALUE + 0,
                    STRING_VALUE + 0,
                    PERMIT_PRIMARY,
                    PERMIT_SECONDARY,
                    (Long) lobId,
                    "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testPermitsCriteria() {

    pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    null, null, PERMIT_PRIMARY, PERMIT_SECONDARY, (Long) lobId, "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testSecondaryPermitCriteria() {
    pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    null, null, null, PERMIT_SECONDARY, (Long) lobId, "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testSecondaryPermitLikeCriteria() {
    pageSecRole =
        roleRepository.findAll(
            RoleSpecification.get(
                new SummaryRoleSearchCriteria(
                    null, null, null, PERMIT_SECONDARY_ABBR, (Long) lobId, "Y")),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  private static String mixedCase(String str) {
    return IntStream.range(0, str.length())
        .mapToObj(i -> i % 2 == 0 ? Character.toUpperCase(str.charAt(i)) : str.charAt(i))
        .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
        .toString();
  }
}
