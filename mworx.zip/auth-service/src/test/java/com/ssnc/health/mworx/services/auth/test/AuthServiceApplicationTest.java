package com.ssnc.health.mworx.services.auth.test;

import com.ssnc.health.mworx.services.auth.test.config.TestConfiguration;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(classes = TestConfiguration.class)
public class AuthServiceApplicationTest {

  @Test
  void contextLoads() {
    Assertions.assertTrue(true);
  }
}
