/*
 * FILE : TestUserAPI.java COPYRIGHT: The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health are proprietary in nature and as such are confidential. Any
 * unauthorized use or disclosure of such information may result in civil liabilities. Copyright (C)
 * 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

import com.ssnc.health.core.common.error.ApiError;
import com.ssnc.health.mworx.services.auth.api.model.AddUserRequest;
import com.ssnc.health.mworx.services.auth.api.model.ByID;
import com.ssnc.health.mworx.services.auth.api.model.ChangePasswordRequest;
import com.ssnc.health.mworx.services.auth.api.model.SecRole;
import com.ssnc.health.mworx.services.auth.api.model.UserContact;
import com.ssnc.health.mworx.services.auth.api.model.UserContactRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserResponse;
import com.ssnc.health.mworx.services.auth.mappers.UserMapper;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import com.ssnc.health.mworx.services.auth.service.UserService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mapstruct.factory.Mappers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "5000")
class TestUserAPI extends BaseResourceTest {
  @Autowired private WebTestClient webTestClient;

  @MockBean private UserService mockUserService;

  @MockBean private MetadataService mockMetadataService;

  @MockBean private UserBasicRepository mockUserBasicRepository;

  private UserMapper mapper = Mappers.getMapper(UserMapper.class);

  private static final String CHANGE_PASSWORD_URI = "/api/user/changePassword";
  private static final String ADD_USER_API = "/api/user";
  private static final String UPDATE_USER_API = "/api/user/updateUser";
  private static final String GET_USER_ID_API = "/api/user/getUserById";
  private static final String USER_CONTACT_API = "/api/user/userContact";
  private static final String USER_CONTACT_DELETE_API = "/api/user/userContact/delete";
  private static final String CONTACT_TYPE_INVALID = "User contact type is invalid";
  private static final String CONTACT_TYPE_REQUIRED = "User contact type is required";
  private static final String CONTACT_TYPE_EXISTS = "User contact type already exists for user";
  private static final String CONTACT_TYPE_EXISTS_OTHER =
      "User contact type already exists for user under a different contact id";
  private static final String USER_NAME_INVALID = "User name is invalid";
  private static final String USER_NAME_REQUIRED = "User name is required";
  private static final String CONTACT_ID_INVALID = "Contact id does not exist for user";

  public static final String ROLE_NAME = "Security";
  public static final String ROLE_TYPE = "System Admin";
  public static final String PERMIT_PRIMARY = "Super Role";
  public static final String PERMIT_SECONDARY = "Super Role";

  @BeforeEach
  public void initMock() {
    Map<String, Object> requestMap1 = new HashMap<>();
    requestMap1.put("id", 1L);
    requestMap1.put("category", "contactType");
    when(mockMetadataService.getListById(1L)).thenReturn(requestMap1);
    Map<String, Object> requestMap2 = new HashMap<>();
    requestMap2.put("id", 2L);
    requestMap2.put("category", "contactType");
    when(mockMetadataService.getListById(2L)).thenReturn(requestMap2);
    Map<String, Object> requestMap3 = new HashMap<>();
    requestMap3.put("id", 3L);
    requestMap3.put("category", "gender");
    when(mockMetadataService.getListById(3L)).thenReturn(requestMap3);
  }

  @Test
  public void testWebClientResponseException() throws Exception {
    UserBasic userBasic = buildUserBasic();
    UserContactRequest userContactRequest = getUserContactRequest();
    userContactRequest.getUserContact().setContactType(4L);
    when(mockUserBasicRepository.findByUsernameIgnoreCase(Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic));
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.updateUser(userBasic)).thenReturn(null);
    when(mockMetadataService.getListById(4L)).thenThrow(WebClientResponseException.class);

    EntityExchangeResult<ApiError> userContactError =
        webTestClient
            .post()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(
        CONTACT_TYPE_INVALID,
        userContactError.getResponseBody().getSubErrors().get(0).getMessage());
  }

  @Test
  public void testAddUserContactAPI() throws Exception {
    UserBasic userBasic = buildUserBasic();
    UserContactRequest userContactRequest = getUserContactRequest();
    when(mockUserBasicRepository.findByUsernameIgnoreCase(Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic));
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.updateUser(userBasic)).thenReturn(null);

    // test successful user contact added
    webTestClient
        .post()
        .uri(USER_CONTACT_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(userContactRequest), UserContactRequest.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(UserContact.class)
        .returnResult();

    // test invalid contact type
    userContactRequest.getUserContact().setContactType(3L);

    EntityExchangeResult<ApiError> userContactError =
        webTestClient
            .post()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(
        CONTACT_TYPE_INVALID,
        userContactError.getResponseBody().getSubErrors().get(0).getMessage());

    // test contact type already exists for user
    userContactRequest.getUserContact().setContactType(1L);
    userBasic.getUserContacts().add(mapper.toUserContactFromUserContactRequest(userContactRequest));

    userContactError =
        webTestClient
            .post()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(
        CONTACT_TYPE_EXISTS, userContactError.getResponseBody().getSubErrors().get(0).getMessage());

    // test user name is required validation.
    userContactRequest.setUserName(null);
    when(mockUserService.getUser(Mockito.any())).thenReturn(Optional.empty());
    userContactError =
        webTestClient
            .post()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(1, userContactError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        USER_NAME_REQUIRED, userContactError.getResponseBody().getSubErrors().get(0).getMessage());
    // Validating empty string in the user name
    userContactRequest.setUserName("  ");
    userContactError =
        webTestClient
            .post()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(1, userContactError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        USER_NAME_REQUIRED, userContactError.getResponseBody().getSubErrors().get(0).getMessage());

    // test user name is invalid validation.
    when(mockUserBasicRepository.findByUsernameIgnoreCase(Mockito.any(String.class)))
        .thenReturn(Optional.empty());
    userContactRequest.setUserName("invalid");
    when(mockUserService.getUser("invalid")).thenReturn(Optional.empty());
    userContactError =
        webTestClient
            .post()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(1, userContactError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        USER_NAME_INVALID, userContactError.getResponseBody().getSubErrors().get(0).getMessage());
  }

  @Test
  public void testUpdateUserContactAPI() throws Exception {
    UserBasic userBasic = buildUserBasic();
    UserContactRequest userContactRequest = getUserContactRequest();
    userContactRequest.getUserContact().setContactId(1L);
    userBasic.getUserContacts().add(mapper.toUserContactFromUserContactRequest(userContactRequest));
    userContactRequest.getUserContact().setContactInfo("MABPERSON");
    when(mockUserBasicRepository.findByUsernameIgnoreCase(Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic));
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.updateUser(userBasic)).thenReturn(null);

    // test successful user contact updated
    webTestClient
        .put()
        .uri(USER_CONTACT_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(userContactRequest), UserContactRequest.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(UserContact.class)
        .returnResult();

    // test invalid contact id for user
    userBasic.getUserContacts().get(0).setContactId(2L);
    userBasic.getUserContacts().get(0).setContactType(2L);

    EntityExchangeResult<ApiError> userContactError =
        webTestClient
            .put()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(
        CONTACT_ID_INVALID, userContactError.getResponseBody().getSubErrors().get(0).getMessage());

    // test contact type already exists for user under another number
    userContactRequest.getUserContact().setContactType(null);
    userContactError =
        webTestClient
            .put()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(1, userContactError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        CONTACT_TYPE_REQUIRED,
        userContactError.getResponseBody().getSubErrors().get(0).getMessage());

    userBasic.getUserContacts().add(mapper.toUserContactFromUserContactRequest(userContactRequest));
    userContactRequest.getUserContact().setContactType(2L);
    userContactError =
        webTestClient
            .put()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(
        CONTACT_TYPE_EXISTS_OTHER,
        userContactError.getResponseBody().getSubErrors().get(0).getMessage());

    // test user name is required validation.
    userContactRequest.setUserName(null);
    when(mockUserService.getUser(Mockito.any())).thenReturn(Optional.empty());
    userContactError =
        webTestClient
            .put()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(1, userContactError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        USER_NAME_REQUIRED, userContactError.getResponseBody().getSubErrors().get(0).getMessage());
    // Validating empty string in the user name
    userContactRequest.setUserName("  ");
    userContactError =
        webTestClient
            .put()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(1, userContactError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        USER_NAME_REQUIRED, userContactError.getResponseBody().getSubErrors().get(0).getMessage());

    // test user name is invalid validation.
    when(mockUserBasicRepository.findByUsernameIgnoreCase(Mockito.any(String.class)))
        .thenReturn(Optional.empty());
    userContactRequest.setUserName("invalid");
    when(mockUserService.getUser("invalid")).thenReturn(Optional.empty());
    userContactError =
        webTestClient
            .put()
            .uri(USER_CONTACT_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userContactRequest), UserContactRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userContactError);
    Assertions.assertEquals(1, userContactError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        USER_NAME_INVALID, userContactError.getResponseBody().getSubErrors().get(0).getMessage());
  }

  @Test
  public void testDeleteUserContactAPI() throws Exception {
    UserBasic userBasic = buildUserBasic();
    UserContactRequest userContactRequest = getUserContactRequest();
    userContactRequest.getUserContact().setContactId(1L);
    userBasic.getUserContacts().add(mapper.toUserContactFromUserContactRequest(userContactRequest));
    when(mockUserBasicRepository.findByUsernameIgnoreCase(Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic));
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.updateUser(userBasic)).thenReturn(null);

    // test successful user contact deleted
    webTestClient
        .put()
        .uri(USER_CONTACT_DELETE_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(userContactRequest), UserContactRequest.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .returnResult();
  }

  /**
   * Test the change password API call with valid password
   *
   * @throws Exception
   */
  @Test
  public void testChangePasswordAPI() throws Exception {
    UserBasic userBasic = buildUserBasic();
    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("TestP@ssw0rd");
    changePasswordRequest.setConfirmPassword("TestP@ssw0rd");

    EntityExchangeResult<String> userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();

    Assertions.assertNotNull(userBasic);
    Assertions.assertEquals(1, userBasic.getUserLogins().size());
    Assertions.assertEquals(
        "\"Successfully updated the password for User : "
            + changePasswordRequest.getUserName()
            + "\"",
        userBasicResult.getResponseBody());
  }

  /**
   * Test the change password API call with invalid passwords
   *
   * <p>1. No special characters 2. No numbers 3. No capitalization 4. Fewer than 8 characters 5.
   * More than 30 characters 6. Containing spaces 7. Containing invalid special character
   *
   * @throws Exception
   */
  @Test
  public void testChangePasswordAPIInvalidPassword() throws Exception {
    UserBasic userBasic = buildUserBasic();
    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    // Try with no special characters
    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("estPssw0rd");

    EntityExchangeResult<ApiError> userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userBasicResult);

    // Try with no numeric characters
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("estPssw@rd");

    userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userBasicResult);

    // Try with no capitalization
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("testp@ssw0rd");

    userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userBasicResult);

    // Try with less than 8 characters (7)
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("ttp@0rd");

    userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userBasicResult);

    // Try with more than 30 characters (31)
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("TestP@ss87508750875jhfjkyfdlju!");

    userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userBasicResult);

    // Try with password that contains spaces
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword(" TestP@ssw0rd");

    userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(userBasicResult);

    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("Test P@ssw0rd");

    userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userBasicResult);

    // Try with invalid special character
    changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("/TestP@ssw0rd;");

    userBasicResult =
        webTestClient
            .post()
            .uri(CHANGE_PASSWORD_URI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(userBasicResult);
  }

  @Test
  public void testMiddleNameValidation() throws Exception {
    // create new user with no middle name
    UserBasic userBasic = buildUserBasic();
    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    AddUserRequest addUserRequest = getAddUserRequest();

    // if result is OK, user was added
    webTestClient
        .post()
        .uri(ADD_USER_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(addUserRequest), AddUserRequest.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .returnResult();

    // create a new user with middle name
    addUserRequest.setMiddleName("middlename");
    addUserRequest.setUserName("testUser2@a.com");

    // if result is OK, user was added
    webTestClient
        .post()
        .uri(ADD_USER_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(addUserRequest), AddUserRequest.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .returnResult();

    // attempt to create a new user with an invalid middle name (containing spaces)
    addUserRequest.setMiddleName("   ");
    addUserRequest.setUserName("testUser3");

    EntityExchangeResult<ApiError> addUserBasicBadResult =
        webTestClient
            .post()
            .uri(ADD_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    assertNotNull(addUserBasicBadResult);

    // attempt to create a new user with an invalid middle name (over 30 chars)
    addUserRequest.setMiddleName("iamabadmiddlenamesodontaddmeever");
    addUserRequest.setUserName("testUser3");

    addUserBasicBadResult =
        webTestClient
            .post()
            .uri(ADD_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    // attempt updating existing with bad middle name, testUser2 should be there
    UserRequest userRequest = getUserRequest();
    userRequest.setMiddleName("     ");

    EntityExchangeResult<ApiError> updateUserBasicBadResult =
        webTestClient
            .put()
            .uri(UPDATE_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    assertNotNull(updateUserBasicBadResult);

    userRequest.setMiddleName("iamabadmiddlenamesodontaddmeever");

    updateUserBasicBadResult =
        webTestClient
            .put()
            .uri(UPDATE_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();
  }

  @Test
  public void getUserById() throws Exception {
    // create new user eff date
    UserBasic userBasic = buildUserBasic();
    when(mockUserService.getUserById(Mockito.any(Long.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    ByID byId = new ByID();
    byId.setId(1L);
    EntityExchangeResult<UserResponse> response =
        webTestClient
            .post()
            .uri(GET_USER_ID_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(byId), ByID.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    assertNotNull(response);
  }

  @Test
  public void testTerminationDateValidation() throws Exception {
    // create new user eff date
    UserBasic userBasic = buildUserBasic();
    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    AddUserRequest addUserRequest = getAddUserRequest();

    // if result is OK, user was added
    webTestClient
        .post()
        .uri(ADD_USER_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(addUserRequest), AddUserRequest.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .returnResult();

    addUserRequest.setUserName("testUser2");
    addUserRequest.setTermDate(LocalDate.of(2019, 1, 1));

    // try and add with bad term date
    EntityExchangeResult<ApiError> addUserBasicBadResult =
        webTestClient
            .post()
            .uri(ADD_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    assertNotNull(addUserBasicBadResult);

    UserRequest updateUserRequest = new UserRequest();

    // try and update with bad date
    updateUserRequest.setUserName("testUser1");
    updateUserRequest.setTermDate(LocalDate.of(2019, 1, 1));

    EntityExchangeResult<ApiError> updateUserBasicBadResult =
        webTestClient
            .put()
            .uri(UPDATE_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(updateUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();
    assertNotNull(updateUserBasicBadResult);
  }

  @Test
  public void testBirthDateValidation() throws Exception {
    // create new user eff date
    UserBasic userBasic = buildUserBasic();
    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    AddUserRequest addUserRequest = getAddUserRequest();

    // if result is OK, user was added
    webTestClient
        .post()
        .uri(ADD_USER_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(addUserRequest), AddUserRequest.class)
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody(String.class)
        .returnResult();

    // attempt to update with birth date into the future
    UserRequest updateUserRequest = new UserRequest();
    updateUserRequest.setBirthDate(LocalDate.now().plusMonths(1));

    EntityExchangeResult<ApiError> updateUserBasicBadResult =
        webTestClient
            .put()
            .uri(UPDATE_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(updateUserRequest), UserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    assertNotNull(updateUserBasicBadResult);
    // attempt to add new user with birth date into the future
    addUserRequest.setBirthDate(LocalDate.now().plusMonths(1));

    EntityExchangeResult<ApiError> addUserBasicBadResult =
        webTestClient
            .put()
            .uri(UPDATE_USER_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isEqualTo(HttpStatus.UNPROCESSABLE_ENTITY)
            .expectBody(ApiError.class)
            .returnResult();

    assertNotNull(addUserBasicBadResult);
  }

  private AddUserRequest getAddUserRequest() {
    AddUserRequest addUserRequest = new AddUserRequest();
    addUserRequest.setUserName("testUser1@a.com");
    addUserRequest.setFirstName("testUser1");
    addUserRequest.setLastName("testUser1");
    addUserRequest.setPrefix("testPrefix1");
    addUserRequest.setGender(3L);
    addUserRequest.setEffDate(LocalDate.now());
    addUserRequest.setPassword("PwdWORD@123");
    SecRole secRole = new SecRole();
    secRole.setRoleName(ROLE_NAME);
    secRole.setRoleType(ROLE_TYPE);
    addUserRequest.setSecRole(secRole);
    List<UserContact> userContacts = new ArrayList<UserContact>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info1 for User");
    userContact.setContactType(1L);
    userContacts.add(userContact);
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo("Contact info2 for User");
    userContact2.setContactType(2L);
    userContacts.add(userContact2);
    addUserRequest.setUserContacts(userContacts);
    return addUserRequest;
  }

  private UserRequest getUserRequest() {
    UserRequest userRequest = new UserRequest();
    userRequest.setUserName("testUser2@a.com");
    userRequest.setFirstName("testUser1");
    userRequest.setLastName("testUser1");
    userRequest.setPrefix("testPrefix1");
    userRequest.setGender(3L);
    userRequest.setEffDate(LocalDate.now());
    com.ssnc.health.mworx.services.auth.api.model.SecRole secRole =
        new com.ssnc.health.mworx.services.auth.api.model.SecRole();
    secRole.setRoleName(ROLE_NAME);
    secRole.setRoleType(ROLE_TYPE);
    userRequest.setSecRole(secRole);
    List<UserContact> userContacts = new ArrayList<UserContact>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info1 for User");
    userContact.setContactType(1L);
    userContacts.add(userContact);
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo("Contact info2 for User");
    userContact2.setContactType(2L);
    userContacts.add(userContact2);
    userRequest.setUserContacts(userContacts);
    return userRequest;
  }

  private UserContactRequest getUserContactRequest() {
    UserContactRequest userContactRequest = new UserContactRequest();
    userContactRequest.setUserName("testUser");
    UserContact userContact = new UserContact();
    userContact.setContactInfo("MABUSER1");
    userContact.setContactType(1L);
    userContact.setPrefer("1");
    userContactRequest.setUserContact(userContact);
    return userContactRequest;
  }

  private UserBasic buildUserBasic() {

    UserBasic userBasic = new UserBasic();
    userBasic.setUsername("testUser");
    userBasic.setFirstName("testUser");
    userBasic.setLastName("testUser");
    userBasic.setPrefix("testPrefix");

    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(String.format("{noop}%s", "testPassword"));
    userLogin.setCreated(new Date());
    userLogin.setUpdated(new Date());
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    return userBasic;
  }
}
