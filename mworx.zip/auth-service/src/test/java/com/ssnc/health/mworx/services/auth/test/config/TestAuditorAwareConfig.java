/*
 * FILE : TestAuditorAwareConfig.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2019- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.config;

import com.ssnc.health.services.test.common.AuditorAwareImpl;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.domain.AuditorAware;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@EnableJpaRepositories("com.ssnc.health.mworx.services.auth.repository")
@EntityScan("com.ssnc.health.mworx.services.auth.model")
@EnableTransactionManagement
public class TestAuditorAwareConfig {
  @Bean
  public AuditorAware<Long> auditorAware() {
    return new AuditorAwareImpl();
  }
}
