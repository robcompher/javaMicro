/*
 * FILE : RoleRepositoryCriteriaTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.RoleLobPermitSpecification;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.repository.RoleLobPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.stream.IntStream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

/**
 * This is to test RoleLobPermitRepositoryCriteria class. It is used for testing that the summary
 * permits that gets called by the UI as part of findByPermitSearchCriteria gets tested with various
 * combinations of the query primary and secondary permit,LOB,roleId where as LOB and permits are
 * optional. combinations with pagination
 *
 * @author dt204819
 */
public class RoleLobPermitRepositoryCriteriaTest extends BaseRepositoryTest {

  @Autowired private SecPermitRepository permitRepository;
  @Autowired private RoleLobPermitRepository roleLobPermitRepository;
  @Autowired private SecRoleRepository roleRepository;

  public static final String ROLE_NAME_ADM = "Admin Role";
  public static final String ROLE_TYPE_ADM = "Admin";
  public static final String ROLE_NAME_SYS = "System Role";
  public static final String ROLE_TYPE_SYS = "System";

  public static final String PERMIT_PRIMARY_ADM = "Admin";
  public static final String PERMIT_SECONDARY_ADM = "Add";
  public static final String PERMIT_PRIMARY_SYS = "System";
  public static final String PERMIT_SECONDARY_SYS = "View";
  public static final String PERMIT_DESC = "Permit Description";
  public static final String LEGACY_SYSID = "123456";
  public static final String ACTIVE = "Y";

  private PageRequest pageable = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, "linkId");

  @BeforeEach
  public void testRoleLobPermitCriteriaQuery() {

    SecRole secAdminRole = new SecRole();
    secAdminRole.setActive(ACTIVE);
    secAdminRole.setRoleName(ROLE_NAME_ADM);
    secAdminRole.setRoleType(ROLE_TYPE_ADM);
    secAdminRole.setEffDate(new Date());
    secAdminRole.setRoleId(1L);
    roleRepository.save(secAdminRole);

    for (int randomPermit = 1; randomPermit <= 10; randomPermit++) {
      RoleLobPermit rlp = new RoleLobPermit();
      rlp.setActive(ACTIVE);
      rlp.setSecRole(secAdminRole);
      SecPermit permit = new SecPermit();
      permit.setPermitPrimary(PERMIT_PRIMARY_ADM + randomPermit);
      permit.setPermitSecondary(PERMIT_SECONDARY_ADM + randomPermit);
      permit.setActive(ACTIVE);
      permit.setDescription(PERMIT_DESC);
      permit.setLegacySystemId(LEGACY_SYSID);
      permitRepository.save(permit);
      rlp.setSecPermit(permit);
      permit.setRoleLobPermits(new ArrayList<>());
      permit.getRoleLobPermits().add(rlp);

      roleLobPermitRepository.save(rlp);
    }
    SecRole secSystemRole = new SecRole();
    secSystemRole.setActive(ACTIVE);
    secSystemRole.setRoleName(ROLE_NAME_SYS);
    secSystemRole.setRoleType(ROLE_TYPE_SYS);
    secSystemRole.setEffDate(new Date());
    secSystemRole.setRoleId(2L);
    roleRepository.save(secSystemRole);

    for (int randomPermit = 11; randomPermit <= 20; randomPermit++) {
      RoleLobPermit rlp = new RoleLobPermit();
      rlp.setActive(ACTIVE);
      rlp.setLobId(1L);
      rlp.setSecRole(secSystemRole);
      SecPermit permit = new SecPermit();
      permit.setPermitPrimary(PERMIT_PRIMARY_SYS + randomPermit);
      permit.setPermitSecondary(PERMIT_SECONDARY_SYS + randomPermit);
      permit.setActive(ACTIVE);
      permit.setDescription(PERMIT_DESC);
      permit.setLegacySystemId(LEGACY_SYSID);
      permitRepository.save(permit);
      rlp.setSecPermit(permit);
      permit.setRoleLobPermits(new ArrayList<>());
      permit.getRoleLobPermits().add(rlp);

      roleLobPermitRepository.save(rlp);
    }
  }

  @Test
  public void testRoleIdEqualCriteria() {
    Page<RoleLobPermit> pageSecRole =
        roleLobPermitRepository.findAll(
            RoleLobPermitSpecification.get(
                new SummaryPermitSearchCriteria(
                    PERMIT_PRIMARY_ADM, PERMIT_SECONDARY_ADM, 1L, null, true)),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testLobIdEqualCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<RoleLobPermit> pageSecRole =
        roleLobPermitRepository.findAll(
            RoleLobPermitSpecification.get(
                new SummaryPermitSearchCriteria(
                    PERMIT_PRIMARY_SYS, PERMIT_SECONDARY_SYS, 2L, lob, true)),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testNoPermitsCriteria() {
    Page<RoleLobPermit> pageSecRole =
        roleLobPermitRepository.findAll(
            RoleLobPermitSpecification.get(
                new SummaryPermitSearchCriteria(null, null, 1L, null, true)),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testPrimaryPermitsCriteria() {
    Page<RoleLobPermit> pageSecRole =
        roleLobPermitRepository.findAll(
            RoleLobPermitSpecification.get(
                new SummaryPermitSearchCriteria(PERMIT_PRIMARY_ADM, null, 1L, null, true)),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testSecondaryPermitsCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<RoleLobPermit> pageSecRole =
        roleLobPermitRepository.findAll(
            RoleLobPermitSpecification.get(
                new SummaryPermitSearchCriteria(null, PERMIT_SECONDARY_SYS, 2L, lob, true)),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(10, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testAllCriteriaMixed() {
    Page<RoleLobPermit> pageSecRole =
        roleLobPermitRepository.findAll(
            RoleLobPermitSpecification.get(
                new SummaryPermitSearchCriteria(
                    mixedCase(PERMIT_PRIMARY_ADM + 2),
                    mixedCase(PERMIT_SECONDARY_ADM + 2),
                    1L,
                    null,
                    true)),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());
  }

  @Test
  public void testAllPermitsCriteria() {
    LOB lob = new LOB();
    lob.setLobId(1L);
    Page<RoleLobPermit> pageSecRole =
        roleLobPermitRepository.findAll(
            RoleLobPermitSpecification.get(
                new SummaryPermitSearchCriteria(
                    PERMIT_PRIMARY_SYS + 1, PERMIT_SECONDARY_SYS + 1, 2L, lob, true)),
            pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(9, pageSecRole.getNumberOfElements());
  }

  private static String mixedCase(String str) {
    return IntStream.range(0, str.length())
        .mapToObj(i -> i % 2 == 0 ? Character.toUpperCase(str.charAt(i)) : str.charAt(i))
        .collect(StringBuilder::new, StringBuilder::appendCodePoint, StringBuilder::append)
        .toString();
  }
}
