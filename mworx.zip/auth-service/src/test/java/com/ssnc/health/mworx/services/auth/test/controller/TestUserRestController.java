/*
FILE : TestUserRestController.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.ssnc.health.core.common.error.ApiError;
import com.ssnc.health.core.common.model.Pagination;
import com.ssnc.health.core.common.utils.DateMapper;
import com.ssnc.health.mworx.services.auth.api.model.AddUserRequest;
import com.ssnc.health.mworx.services.auth.api.model.ChangePasswordRequest;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.api.model.LockUnlockRequest;
import com.ssnc.health.mworx.services.auth.api.model.SecRole;
import com.ssnc.health.mworx.services.auth.api.model.UserContact;
import com.ssnc.health.mworx.services.auth.api.model.UserGetUserByUserNameRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserListResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserNameByCriteriaResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserRequest;
import com.ssnc.health.mworx.services.auth.api.model.UserResponse;
import com.ssnc.health.mworx.services.auth.api.model.UserSearchCriteria;
import com.ssnc.health.mworx.services.auth.mappers.UserMapper;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import com.ssnc.health.mworx.services.auth.service.RoleService;
import com.ssnc.health.mworx.services.auth.service.UserService;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mapstruct.factory.Mappers;
import org.mockito.ArgumentMatchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "5000")
class TestUserRestController extends BaseResourceTest {
  private static final Long SAMPLE_MF = 123L;
  private static final String VALID_USER1 = "testUser1@gmail.com";
  private static final String INVALID_USER1 = "testUser1";
  private static final String VALID_USER2 = "TESTUser1@gmail.com";
  private static final String INVALID_DATA =
      "sample invalid data testing testing. sample invalid data testing testing sample "
          + "invalid data testing testing sample invalid data testing testing. invalid data testing testing sample invalid data testing testing";
  private static final String GET_USERNAME_SEARCH_API = "/api/user/getUserNamesBySearchCriteria";
  private static final String DELETE_USERNAME_API = "/api/user/delete";
  @Autowired private WebTestClient webTestClient;

  @MockBean private UserService mockUserService;

  @MockBean private UserBasicRepository userBasicRepository;
  @MockBean private SecRoleRepository secRoleRepository;
  @MockBean private RoleService mockSecRoleService;
  @MockBean private MetadataService mockMetadataService;

  private UserMapper mapper = Mappers.getMapper(UserMapper.class);
  DateMapper datemapper = new DateMapper();

  @BeforeEach
  public void setUp() throws Exception {
    Map<String, Object> requestMap1 = new HashMap<>();
    requestMap1.put("id", 1L);
    requestMap1.put("category", "contactType");
    when(mockMetadataService.getListById(1L)).thenReturn(requestMap1);
    Map<String, Object> requestMap2 = new HashMap<>();
    requestMap2.put("id", 2L);
    requestMap2.put("category", "contactType");
    when(mockMetadataService.getListById(2L)).thenReturn(requestMap2);
    Map<String, Object> requestMap3 = new HashMap<>();
    requestMap3.put("id", 3L);
    requestMap3.put("category", "gender");
    when(mockMetadataService.getListById(3L)).thenReturn(requestMap3);
  }

  @BeforeEach
  public void initMock() {
    when(mockMetadataService.getListById(ArgumentMatchers.anyLong())).thenReturn(null);
    Map<String, Object> requestMap1 = new HashMap<>();
    requestMap1.put("id", 1L);
    requestMap1.put("category", "contactType");
    when(mockMetadataService.getListById(1L)).thenReturn(requestMap1);
    Map<String, Object> requestMap2 = new HashMap<>();
    requestMap2.put("id", 2L);
    requestMap2.put("category", "contactType");
    when(mockMetadataService.getListById(2L)).thenReturn(requestMap2);
    Map<String, Object> requestMap3 = new HashMap<>();
    requestMap3.put("id", 3L);
    requestMap3.put("category", "gender");
    when(mockMetadataService.getListById(3L)).thenReturn(requestMap3);
    when(mockMetadataService.getListById(Mockito.eq(4L)))
        .thenThrow(new WebClientResponseException(401, null, null, null, null));
  }

  @Test
  public void testLockUnlockAPILock() {
    UserBasic userBasic = buildUserBasic();
    Optional<UserBasic> optionalUserBasic = Optional.of(userBasic);

    when(mockUserService.getUser(any(String.class))).thenReturn(optionalUserBasic);
    Mockito.when(userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    Mockito.when(userBasicRepository.findByUsernameIgnoreCase("INVALID"))
        .thenReturn(Optional.empty());

    LockUnlockRequest lockUnlockRequest = new LockUnlockRequest();
    lockUnlockRequest.setUserName("testUser");
    lockUnlockRequest.setLock(true);
    EntityExchangeResult<String> lockUnlockResult =
        webTestClient
            .post()
            .uri("/api/user/lockUnlockUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(lockUnlockRequest), LockUnlockRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertNotNull(lockUnlockResult);
    Assertions.assertEquals(
        "Successfully locked User : " + lockUnlockRequest.getUserName(),
        lockUnlockResult.getResponseBody());
  }

  @Test
  public void testDeleteUsernameUserExistsAPI() {
    when(mockUserService.deleteUser(any(String.class))).thenReturn(true);

    UserGetUserByUserNameRequest request = new UserGetUserByUserNameRequest();
    request.setUserName("user");
    webTestClient
        .put()
        .uri(DELETE_USERNAME_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(request), UserGetUserByUserNameRequest.class)
        .exchange()
        .expectStatus()
        .is2xxSuccessful();
  }

  @Test
  public void testDeleteUsernameUserDoesNotExistAPI() {
    when(mockUserService.deleteUser(any(String.class))).thenReturn(false);

    UserGetUserByUserNameRequest request = new UserGetUserByUserNameRequest();
    request.setUserName("user");
    webTestClient
        .put()
        .uri(DELETE_USERNAME_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(request), UserGetUserByUserNameRequest.class)
        .exchange()
        .expectStatus()
        .is4xxClientError();
  }

  @Test
  public void testChangePasswordAPI() throws Exception {
    UserBasic userBasic = buildUserBasic();

    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    ChangePasswordRequest changePasswordRequest = new ChangePasswordRequest();
    changePasswordRequest.setUserName("testUser");
    changePasswordRequest.setPassword("testPassword0!");
    changePasswordRequest.setConfirmPassword("testPassword0!");
    EntityExchangeResult<String> userBasicResult =
        webTestClient
            .post()
            .uri("/api/user/changePassword")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), ChangePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertNotNull(userBasicResult);
    Assertions.assertTrue(
        userBasicResult.getResponseBody().contains("Successfully updated the password for User"));
  }

  /**
   * Will test to verify that user contacts returns the whole list and now just what is sent 1. will
   * create a user 2. will update a user but not send any contacts 3. Should still send the contacts
   * that were saved
   */
  @Test
  public void testAPIreturnAllUserContacts() {
    AddUserRequest addUserRequest = getAddUserRequest();
    UserBasic userBasic = getUserBasic(addUserRequest);
    UserRequest userRequest = getUserRequest();
    // first must add user
    List<UserBasic> list = new ArrayList<>();
    list.add(userBasic);

    // Mocking repository calls.
    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));
    Page<UserBasic> page = new PageImpl<UserBasic>(list);
    when(mockUserService.findUsers(
            Mockito.any(UserBasic.class),
            Mockito.any(PageRequest.class),
            Mockito.any(Boolean.class)))
        .thenReturn(page);

    // Verify add user API call
    EntityExchangeResult<UserResponse> userBasicResult =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    validateUserResponse(userBasicResult);
    // updateUser return the object.
    Mockito.when(userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    when(mockUserService.updateUser(Mockito.any(UserBasic.class))).thenReturn(userBasic);
    // remove the User contacts. Make sure the API still show the 2 contacts
    userRequest.setUserContacts(null);
    userBasicResult =
        webTestClient
            .put()
            .uri("/api/user/updateUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), UserRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    validateUserResponse(userBasicResult);
    Assertions.assertEquals(
        userBasic.getUserContacts().size(),
        userBasicResult.getResponseBody().getUserContacts().size());
    // validate that multiple contacts with same type will fail
    List<UserContact> contacts = new ArrayList<>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info1 for User");
    userContact.setContactType(1L);
    contacts.add(userContact);
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo("Contact info2 for User");
    userContact2.setContactType(1L);
    contacts.add(userContact2);
    userRequest.setUserContacts(contacts);

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .put()
            .uri("/api/user/updateUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), UserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(1, apiError.getResponseBody().getSubErrors().size());
  }

  /**
   * test case to verify User API calls add user, update user, get user by user name and get all
   * users based on pagination request.
   */
  @Test
  public void testUserBasicAPICalls() {
    AddUserRequest addUserRequest = getAddUserRequest();
    UserBasic userBasic = getUserBasic(addUserRequest);
    UserRequest userRequest = getUserRequest();

    // Mocking repository calls.
    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));

    List<UserBasic> list = new ArrayList<>();
    list.add(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));
    Page<UserBasic> page = new PageImpl<UserBasic>(list);
    when(mockUserService.findUsers(
            Mockito.any(UserBasic.class),
            Mockito.any(PageRequest.class),
            Mockito.any(Boolean.class)))
        .thenReturn(page);

    // Verify add user API call
    EntityExchangeResult<UserResponse> userBasicResult =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    validateUserResponse(userBasicResult);

    // Verifying getUserByUserName API call.
    UserGetUserByUserNameRequest request = new UserGetUserByUserNameRequest();
    request.setUserName(userBasic.getUsername());
    userBasicResult =
        webTestClient
            .post()
            .uri("/api/user/getUserByUserName")
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(request), UserGetUserByUserNameRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    validateUserResponse(userBasicResult);

    // updateUser API call
    userBasic.setLastName("new Last name");
    Mockito.when(userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    when(mockUserService.updateUser(Mockito.any(UserBasic.class))).thenReturn(userBasic);
    userBasicResult =
        webTestClient
            .put()
            .uri("/api/user/updateUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), UserRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    validateUserResponse(userBasicResult);
    Assertions.assertEquals("new Last name", userBasicResult.getResponseBody().getLastName());

    // Verifying getUsersList API call.

    Pagination pagination = new Pagination();
    pagination.setPage(0);
    pagination.setPageSize(10);
    pagination.setSortBy("userId");
    pagination.setSortOrder("ASC");

    UserSearchCriteria userSearchCriteria = new UserSearchCriteria();
    userSearchCriteria.setPagination(pagination);
    userSearchCriteria.setUserName("a");
    EntityExchangeResult<UserListResponse> userResponse =
        webTestClient
            .post()
            .uri("/api/user/getUsers")
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(userSearchCriteria), UserSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserListResponse.class)
            .returnResult();

    Assertions.assertEquals(1, userResponse.getResponseBody().getData().size());

    pagination = new Pagination();
    pagination.setPageSize(5);
    userSearchCriteria.setPagination(pagination);
    userSearchCriteria.setFirstName("test");
    userResponse =
        webTestClient
            .post()
            .uri("/api/user/getUsers")
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(userSearchCriteria), UserSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserListResponse.class)
            .returnResult();

    Assertions.assertEquals(1, userResponse.getResponseBody().getData().size());

    // Verifying add user API call required field and custom validations.
    testAddUserValidations(addUserRequest, userBasic);

    // Verifying update user API call required field and custom validations.
    testUpdateUserValidations(userRequest, userBasic);

    // for private method getPageable coverage inside condition
    pagination.setPage(1);
    pagination.setSortBy("userName");
    pagination.setSortOrder("DESC");
    userSearchCriteria.setPagination(pagination);
    userSearchCriteria.setFirstName("test");
    userSearchCriteria.setActive("Y");
    userResponse =
        webTestClient
            .post()
            .uri("/api/user/getUsers")
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(userSearchCriteria), UserSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserListResponse.class)
            .returnResult();

    Assertions.assertEquals(1, userResponse.getResponseBody().getData().size());

    // cover else clause
    UserSearchCriteria nullCriteria = new UserSearchCriteria();

    userResponse =
        webTestClient
            .post()
            .uri("/api/user/getUsers")
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(nullCriteria), UserSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserListResponse.class)
            .returnResult();

    Assertions.assertEquals(1, userResponse.getResponseBody().getData().size());
  }

  @Test
  public void testGetUserByUserNameUserBasicNotPresent() {
    Optional<UserBasic> optionalUserBasic = Optional.empty();

    when(mockUserService.getUser(any(String.class))).thenReturn(optionalUserBasic);
    UserGetUserByUserNameRequest request = new UserGetUserByUserNameRequest();
    request.setUserName("root");
    webTestClient
        .post()
        .uri("/api/user/getUserByUserName")
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(request), UserGetUserByUserNameRequest.class)
        .exchange()
        .expectStatus()
        .is4xxClientError()
        .expectBody(ApiError.class)
        .returnResult();
  }

  private void testUpdateUserValidations(UserRequest userRequest, UserBasic userBasic) {
    /**
     * Validating required fields. username, first name, last name, effective date, roleType, and
     * roleName, contact type, contact info (if contact information is passed)
     */
    UserRequest userRequestForRequiredFieldvalidations = new UserRequest();
    userRequestForRequiredFieldvalidations.setSecRole(new SecRole());
    List<UserContact> contacts = new ArrayList<UserContact>();
    contacts.add(new UserContact());
    userRequestForRequiredFieldvalidations.setUserContacts(contacts);
    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .put()
            .uri("/api/user/updateUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequestForRequiredFieldvalidations), UserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(11, apiError.getResponseBody().getSubErrors().size());

    Mockito.when(userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.empty());

    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.empty());
    /**
     * Validating following rules. 1) User secure role is not configured. 2)User not configured in
     * the system.
     */
    apiError =
        webTestClient
            .put()
            .uri("/api/user/updateUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), UserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(2, apiError.getResponseBody().getSubErrors().size());

    Mockito.when(userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    /**
     * Validating length on first name, last name, middle name, gender, active, description,
     * internalId, legacySystemId, prefix, suffix, title, contact info, contact type (invalid
     * contact type), prefer (if contact information is passed).
     */
    apiError =
        webTestClient
            .put()
            .uri("/api/user/updateUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(getInvalidUserRequest()), UserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(15, apiError.getResponseBody().getSubErrors().size());
  }

  private void testAddUserValidations(AddUserRequest addUserRequest, UserBasic userBasic) {
    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.empty());
    /**
     * Validating following two rules. 1)User secure role is not configured. 2) User already exists
     * with the same user name.
     */
    // Verifying add user API call required field and custom validations.
    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(2, apiError.getResponseBody().getSubErrors().size());

    /**
     * Validating required fields. username, first name, last name, effective date, roleType, and
     * roleName, contact type, contact info (if contact information is passed)
     */
    UserRequest userRequestForRequiredFieldvalidations = new UserRequest();
    userRequestForRequiredFieldvalidations.setSecRole(new SecRole());
    List<UserContact> contacts = new ArrayList<UserContact>();
    contacts.add(new UserContact());
    userRequestForRequiredFieldvalidations.setUserContacts(contacts);

    apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequestForRequiredFieldvalidations), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(10, apiError.getResponseBody().getSubErrors().size());

    // Validating user name to make sure it is case insensitive.
    addUserRequest.setUserName(VALID_USER2);
    apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(1, apiError.getResponseBody().getSubErrors().size());

    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));

    // Validating user name to make sure it is in proper email format.
    addUserRequest.setUserName(INVALID_USER1);
    apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(1, apiError.getResponseBody().getSubErrors().size());

    /**
     * Length validations on user name, first name, last name, middle name, gender, active,
     * description, internalId, legacySystemId, prefix, suffix, title, contact type, contact info,
     * prefer (if contact information is passed).
     */
    AddUserRequest addUserRequestForLen = getInvalidUserRequest();
    addUserRequestForLen.setUserName("u");
    apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequestForLen), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(17, apiError.getResponseBody().getSubErrors().size());
  }

  @Test
  @DisplayName("Locked = Y/N is being saved properly when  calling the lock/unlock API")
  public void testLockUnlockAPI() {
    AddUserRequest addUserRequest = getAddUserRequest();
    UserBasic userBasic = getUserBasic(addUserRequest);

    // Mocking repository calls.
    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));

    List<UserBasic> list = new ArrayList<>();
    list.add(userBasic);

    when(mockUserService.getUser(Mockito.eq(userBasic.getUsername())))
        .thenReturn(Optional.of(userBasic));
    // if username is sent invalid then don't find it
    when(mockUserService.getUser(Mockito.eq("INVALID"))).thenReturn(Optional.empty());

    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.updateUser(Mockito.any(UserBasic.class))).thenReturn(userBasic);
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));
    Page<UserBasic> page = new PageImpl<UserBasic>(list);
    when(mockUserService.findUsers(
            Mockito.any(UserBasic.class),
            Mockito.any(PageRequest.class),
            Mockito.any(Boolean.class)))
        .thenReturn(page);

    // Verify add user API call
    EntityExchangeResult<UserResponse> userBasicResult =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    validateUserResponse(userBasicResult);
    Mockito.when(userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    Mockito.when(userBasicRepository.findByUsernameIgnoreCase("INVALID"))
        .thenReturn(Optional.empty());
    LockUnlockRequest lockrequest = new LockUnlockRequest();
    // Will now be trying to lock and unlock the user
    // verify if no body sent then return a 404 and now some random error
    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user/lockUnlockUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(lockrequest), LockUnlockRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    validateRequiredFieldsForLockUnlockUser(apiError);
    // send an invalid username. Should give validation message.
    lockrequest.setUserName("INVALID");
    apiError =
        webTestClient
            .post()
            .uri("/api/user/lockUnlockUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(lockrequest), LockUnlockRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(1, apiError.getResponseBody().getSubErrors().size());
    Assertions.assertTrue(
        apiError
            .getResponseBody()
            .getSubErrors()
            .get(0)
            .getMessage()
            .contains("User not configured in the system"));
    // validating required fields for lockUnlock request.
    lockrequest.setUserName(null);
    apiError =
        webTestClient
            .post()
            .uri("/api/user/lockUnlockUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(lockrequest), LockUnlockRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    validateRequiredFieldsForLockUnlockUser(apiError);
    // send a valid user but no lock value. Should unlock
    lockrequest.setUserName(userBasic.getUsername());
    EntityExchangeResult<String> returnValue =
        webTestClient
            .post()
            .uri("/api/user/lockUnlockUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.TEXT_PLAIN)
            .body(Mono.just(lockrequest), LockUnlockRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertTrue(returnValue.getResponseBody().contains("Successfully unlocked"));
    // send a valid user but with a lock value of false. Should unlock
    lockrequest.setLock(false);
    returnValue =
        webTestClient
            .post()
            .uri("/api/user/lockUnlockUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.TEXT_PLAIN)
            .body(Mono.just(lockrequest), LockUnlockRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertTrue(returnValue.getResponseBody().contains("Successfully unlocked"));
    // send a valid user but with a lock value of true. Should lock
    lockrequest.setLock(true);
    returnValue =
        webTestClient
            .post()
            .uri("/api/user/lockUnlockUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.TEXT_PLAIN)
            .body(Mono.just(lockrequest), LockUnlockRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertTrue(returnValue.getResponseBody().contains("Successfully locked"));
  }

  @Test
  @DisplayName("Verify can't add a new user which conflicts existing one")
  public void testAdduserAlreadyExists() {
    AddUserRequest addUserRequest = getAddUserRequest();
    UserBasic userBasic = getUserBasic(addUserRequest);
    // Mocking repository calls.
    Mockito.when(userBasicRepository.findByUsernameIgnoreCase(userBasic.getUsername()))
        .thenReturn(Optional.of(userBasic));
    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));
    // Verifying add user API call fails with username alrady exists
    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(1, apiError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        "userName", apiError.getResponseBody().getSubErrors().get(0).getField());
    Assertions.assertEquals(
        "User already exists with the same user name.",
        apiError.getResponseBody().getSubErrors().get(0).getMessage());
    // now try without user contacts
    addUserRequest.setUserContacts(null);

    apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(1, apiError.getResponseBody().getSubErrors().size());
    Assertions.assertEquals(
        "userName", apiError.getResponseBody().getSubErrors().get(0).getField());
    Assertions.assertEquals(
        "User already exists with the same user name.",
        apiError.getResponseBody().getSubErrors().get(0).getMessage());
  }

  private void validateRequiredFieldsForLockUnlockUser(EntityExchangeResult<ApiError> apiError) {
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(2, apiError.getResponseBody().getSubErrors().size());
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors().get(0).getMessage());
  }

  @Test
  @DisplayName("When adding users verify contact information is correct")
  public void testMultipleUserContactScenariosAddUser() {
    AddUserRequest addUserRequest = getAddUserRequest();
    List<com.ssnc.health.mworx.services.auth.api.model.UserContact> contacts = new ArrayList<>();
    addUserRequest.setSecRole(null);
    addUserRequest.setUserContacts(contacts);
    UserBasic userBasic = getUserBasic(addUserRequest);
    // create new user without any contacts. Should be successful
    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    // Verify add user API call
    EntityExchangeResult<UserResponse> userBasicResult =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    Assertions.assertEquals(0, userBasicResult.getResponseBody().getUserContacts().size());
    // create user contacts with the same contact type. Should fail
    contacts = new ArrayList<>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info1 for User");
    userContact.setContactType(1L);
    contacts.add(userContact);
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo("Contact info2 for User");
    userContact2.setContactType(1L);
    contacts.add(userContact2);
    addUserRequest.setUserContacts(contacts);
    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertEquals(1, apiError.getResponseBody().getSubErrors().size());
  }

  @Test
  @DisplayName("When adding users verify invalid gender info fails")
  public void testInvalidGenderAdd() {
    AddUserRequest addUserRequest = getAddUserRequest();
    UserBasic userBasic = getUserBasic(addUserRequest);
    addUserRequest.setGender(2L);
    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));
    checkInvalidGender(addUserRequest);
    // make sure null is as well
    addUserRequest.setGender(null);
    checkInvalidGender(addUserRequest);
    // make sure another gender fails
    addUserRequest.setGender(4L);
    checkInvalidGender(addUserRequest);
  }

  @Test
  @DisplayName("When updating users verify invalid gender info fails")
  public void testInvalidGenderUpdate() {
    UserBasic userBasic = getUserBasic(getAddUserRequest());

    UserRequest userRequest = getUserRequest();
    userRequest.setUserContacts(null);
    userRequest.setGender(2L);
    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));

    checkInvalidGenderUpdate(userRequest);
    // make sure null is as well
    userRequest.setGender(null);
    checkInvalidGenderUpdate(userRequest);
    // make sure another gender fails
    userRequest.setGender(4L);
    checkInvalidGenderUpdate(userRequest);
  }

  private void checkInvalidGender(AddUserRequest adduserRequest) {
    // Verify add user API call throws gender issue
    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(adduserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError
            .getResponseBody()
            .getSubErrors()
            .get(0)
            .getMessage()
            .toUpperCase()
            .contains("GENDER"));
  }

  private void checkInvalidGenderUpdate(UserRequest userRequest) {
    // Verify update user API call throws gender issue
    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .put()
            .uri("/api/user/updateUser")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(userRequest), UserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
  }

  private void validateUserResponse(EntityExchangeResult<UserResponse> userBasicResult) {
    Assertions.assertNotNull(userBasicResult);
    UserResponse response = userBasicResult.getResponseBody();
    Assertions.assertEquals(VALID_USER1, response.getUserName());
    Assertions.assertEquals(SAMPLE_MF, response.getModelFrom());
    SecRole secRole = response.getSecRole();
    Assertions.assertNotNull(secRole);
    Assertions.assertEquals("role name1", secRole.getRoleName());
    Assertions.assertEquals("role type1", secRole.getRoleType());
    List<UserContact> userContacts = response.getUserContacts();
    Assertions.assertNotNull(userContacts);
    Assertions.assertEquals(2, userContacts.size());
  }

  private UserBasic getUserBasic(AddUserRequest addUserRequest) {
    UserBasic userBasic = mapper.toUserBasicFromAddUserRequest(addUserRequest);
    userBasic.setUserId(Long.valueOf(1));
    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(String.format("{noop}%s", "testPassword"));
    userLogin.setCreated(new Date());
    userLogin.setUpdated(new Date());
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    return userBasic;
  }

  private AddUserRequest getAddUserRequest() {
    AddUserRequest addUserRequest = new AddUserRequest();
    addUserRequest.setUserName(VALID_USER1);
    addUserRequest.setFirstName("testUser1");
    addUserRequest.setLastName("testUser1");
    addUserRequest.setPrefix("testPrefix1");
    addUserRequest.setGender(3L);
    addUserRequest.setEffDate(LocalDate.now());
    addUserRequest.setPassword("PwdWORD@123");
    addUserRequest.setModelFrom(SAMPLE_MF);
    SecRole secRole = new SecRole();
    secRole.setRoleName("role name1");
    secRole.setRoleType("role type1");
    addUserRequest.setSecRole(secRole);
    List<UserContact> userContacts = new ArrayList<UserContact>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info1 for User");
    userContact.setContactType(1L);
    userContacts.add(userContact);
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo("Contact info2 for User");
    userContact2.setContactType(2L);
    userContacts.add(userContact2);
    addUserRequest.setUserContacts(userContacts);
    return addUserRequest;
  }

  private UserBasic buildUserBasic() {

    UserBasic userBasic = new UserBasic();
    userBasic.setUsername("testUser");
    userBasic.setFirstName("testUser");
    userBasic.setLastName("testUser");
    userBasic.setPrefix("testPrefix");

    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(String.format("{noop}%s", "testPassword"));
    userLogin.setCreated(new Date());
    userLogin.setUpdated(new Date());
    userLogin.setUserBasic(userBasic);
    userBasic.getUserLogins().add(userLogin);
    return userBasic;
  }

  private UserRequest getUserRequest() {
    UserRequest userRequest = new UserRequest();
    userRequest.setUserName(VALID_USER1);
    userRequest.setFirstName("testUser1");
    userRequest.setLastName("testUser1");
    userRequest.setPrefix("testPrefix1");
    userRequest.setGender(3L);
    userRequest.setModelFrom(SAMPLE_MF);
    userRequest.setEffDate(LocalDate.now());
    SecRole secRole = new SecRole();
    secRole.setRoleName("role name1");
    secRole.setRoleType("role type1");
    userRequest.setSecRole(secRole);
    List<UserContact> userContacts = new ArrayList<UserContact>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info1 for User");
    userContact.setContactType(1L);
    userContact.setPrefer("1");
    userContacts.add(userContact);
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo("Contact info2 for User");
    userContact2.setContactType(2L);
    userContact.setPrefer("2");
    userContacts.add(userContact2);
    userRequest.setUserContacts(userContacts);
    return userRequest;
  }

  private AddUserRequest getInvalidUserRequest() {
    AddUserRequest userRequest = new AddUserRequest();
    userRequest.setUserName(VALID_USER1);
    userRequest.setFirstName("u");
    userRequest.setLastName("f");
    userRequest.setActive("Yes");
    userRequest.setMiddleName(INVALID_DATA);
    userRequest.setGender(null);
    userRequest.setInternalId(INVALID_DATA);
    userRequest.setLegacySystemId(INVALID_DATA);
    userRequest.setPrefix(INVALID_DATA);
    userRequest.setSuffix(INVALID_DATA);
    userRequest.setTitle(INVALID_DATA);
    userRequest.setDescription(INVALID_DATA + INVALID_DATA + INVALID_DATA + INVALID_DATA);
    userRequest.setEffDate(LocalDate.now());
    List<UserContact> userContacts = new ArrayList<UserContact>();
    UserContact userContact = new UserContact();
    userContact.setContactInfo("Contact info1 for User");
    userContact.setContactType(1L);
    userContact.setPrefer("123");
    userContacts.add(userContact);
    UserContact userContact2 = new UserContact();
    userContact2.setContactInfo(INVALID_DATA);
    userContact2.setContactType(3L);
    userContact2.setPrefer("3");
    userContacts.add(userContact2);
    userRequest.setUserContacts(userContacts);
    return userRequest;
  }

  UserNameByCriteriaRequest createValidUserNameByCriteriaRequest() {
    UserNameByCriteriaRequest criteriaRequest = new UserNameByCriteriaRequest();
    criteriaRequest.setUserId(1L);
    criteriaRequest.setUserName("testUser");
    criteriaRequest.setPermitPrimary("AUTH");
    criteriaRequest.setPermitSecondary("VIEW");
    LOB lob = new LOB();
    lob.setLobId(1L);
    lob.setLobName("CL");
    lob.setOrganizationName("ABC");
    criteriaRequest.setLob(lob);
    return criteriaRequest;
  }

  UserNameByCriteriaRequest createInvalidUserNameByCriteriaRequest(
      Long id, String userName, String permitPrimary, String permitSecondary, LOB lob) {
    UserNameByCriteriaRequest criteriaRequest = new UserNameByCriteriaRequest();
    criteriaRequest.setUserId(id);
    criteriaRequest.setUserName(userName);
    criteriaRequest.setPermitPrimary(permitPrimary);
    criteriaRequest.setPermitSecondary(permitSecondary);
    criteriaRequest.setLob(lob);
    return criteriaRequest;
  }

  @Test
  @DisplayName("Successfully return user name details")
  void testGetUserNamesBySearchCriteriaAPI() {
    UserNameByCriteriaRequest nameByCriteriaRequest = createValidUserNameByCriteriaRequest();

    List<UserBasic> responses = new ArrayList<UserBasic>();
    responses.add(buildUserBasic());
    when(mockUserService.getUserBySearchCriteria(Mockito.any(UserNameByCriteriaRequest.class)))
        .thenReturn(responses);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(1L);
    EntityExchangeResult<List<UserNameByCriteriaResponse>> exchangeResult =
        webTestClient
            .post()
            .uri(GET_USERNAME_SEARCH_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(nameByCriteriaRequest), UserNameByCriteriaRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(UserNameByCriteriaResponse.class)
            .returnResult();
    Assertions.assertNotNull(exchangeResult);
  }

  @Test
  @DisplayName("No user can be found for matching criteria")
  void testGetUserNamesReturnsNoUser() {
    UserNameByCriteriaRequest nameByCriteriaRequest = createValidUserNameByCriteriaRequest();

    List<UserBasic> responses = new ArrayList<UserBasic>();
    responses.add(buildUserBasic());
    when(mockUserService.getUserBySearchCriteria(Mockito.any(UserNameByCriteriaRequest.class)))
        .thenReturn(null);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(1L);
    EntityExchangeResult<ApiError> exchangeResult =
        webTestClient
            .post()
            .uri(GET_USERNAME_SEARCH_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(nameByCriteriaRequest), UserNameByCriteriaRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    assertEquals(HttpStatus.NOT_FOUND, exchangeResult.getStatus());
  }

  @Test
  @DisplayName("UserName/UserId Validation Check")
  void testGetUserNamesValidationCheck() {
    UserNameByCriteriaRequest nameByCriteriaRequest =
        createInvalidUserNameByCriteriaRequest(null, null, "VIEW", "SECURITY", null);
    webTestClient
        .post()
        .uri(GET_USERNAME_SEARCH_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(nameByCriteriaRequest), UserNameByCriteriaRequest.class)
        .exchange()
        .expectStatus()
        .is4xxClientError()
        .expectBody(ApiError.class)
        .returnResult();
    // assertEquals(exchangeResult.getStatus(),HttpStatus.UNPROCESSABLE_ENTITY);
  }

  @Test
  @DisplayName("UserSearch Permit Validation Check")
  void testGetUserPermitValidationCheck() {
    UserNameByCriteriaRequest nameByCriteriaRequest =
        createInvalidUserNameByCriteriaRequest(1L, null, "VIEW", null, null);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(null);
    EntityExchangeResult<ApiError> exchangeResult =
        webTestClient
            .post()
            .uri(GET_USERNAME_SEARCH_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(nameByCriteriaRequest), UserNameByCriteriaRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, exchangeResult.getStatus());
  }

  @Test
  @DisplayName("UserSearch Null LOB Validation Check")
  void testGetUserLOBVNullalidationCheck() {
    UserNameByCriteriaRequest nameByCriteriaRequest =
        createInvalidUserNameByCriteriaRequest(null, "root", "VIEW", "SECURITY", null);
    webTestClient
        .post()
        .uri(GET_USERNAME_SEARCH_API)
        .contentType(MediaType.APPLICATION_JSON)
        .accept(MediaType.APPLICATION_JSON)
        .body(Mono.just(nameByCriteriaRequest), UserNameByCriteriaRequest.class)
        .exchange()
        .expectStatus()
        .is4xxClientError()
        .expectBody(ApiError.class)
        .returnResult();
    // assertEquals(exchangeResult.getStatus(),HttpStatus.UNPROCESSABLE_ENTITY);
  }

  @Test
  @DisplayName("UserSearch LOB Validation Check")
  void testGetUserLOBValidationCheck() {
    LOB lob = new LOB();
    lob.setLobName("CL");
    UserNameByCriteriaRequest nameByCriteriaRequest =
        createInvalidUserNameByCriteriaRequest(null, "root", "VIEW", "SECURITY", lob);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(2L);
    EntityExchangeResult<ApiError> exchangeResult =
        webTestClient
            .post()
            .uri(GET_USERNAME_SEARCH_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(nameByCriteriaRequest), UserNameByCriteriaRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, exchangeResult.getStatus());
  }

  @Test
  @DisplayName("UserSearch LOB MetaData Web Client Exception")
  void testGetUserMetadataExceptionCheck() {
    LOB lob = new LOB();
    lob.setLobName("CL");
    lob.setOrganizationName("ABC");
    UserNameByCriteriaRequest nameByCriteriaRequest =
        createInvalidUserNameByCriteriaRequest(null, "root", "VIEW", "SECURITY", lob);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class)))
        .thenThrow(new WebClientResponseException(401, null, null, null, null));
    EntityExchangeResult<ApiError> exchangeResult =
        webTestClient
            .post()
            .uri(GET_USERNAME_SEARCH_API)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(nameByCriteriaRequest), UserNameByCriteriaRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    assertEquals(HttpStatus.UNPROCESSABLE_ENTITY, exchangeResult.getStatus());
  }
  // Verify add user API call for Birthdate validation
  @Test
  @DisplayName("User Birthdate validation for Add user")
  public void testAddUser() {

    // Verify add user API call when birthday is todays date
    AddUserRequest addUserRequest = getAddUserRequest();
    Date date = new Date();
    date.setHours(0);
    date.setMinutes(0);
    date.setSeconds(0);
    addUserRequest.setBirthDate(datemapper.asLocalDate(date));
    UserBasic userBasic = getUserBasic(addUserRequest);

    Mockito.when(
            secRoleRepository.findByRoleTypeAndRoleName(
                Mockito.any(String.class), Mockito.any(String.class)))
        .thenReturn(Optional.of(userBasic.getSecRole()));
    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));
    when(mockUserService.addUser(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    EntityExchangeResult<UserResponse> userBasicResult =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequest), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(UserResponse.class)
            .returnResult();
    Assertions.assertNotNull(userBasicResult);
    Assertions.assertEquals(userBasicResult.getResponseBody().getBirthDate(), LocalDate.now());

    // Verify add user API call when birthday is in future
    AddUserRequest addUserRequestApiError = getAddUserRequest();
    addUserRequestApiError.setEffDate(LocalDate.now().plusDays(1));
    addUserRequestApiError.setBirthDate(LocalDate.now().plusDays(1));

    EntityExchangeResult<ApiError> apiErrorResponse =
        webTestClient
            .post()
            .uri("/api/user")
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(addUserRequestApiError), AddUserRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(apiErrorResponse);
    Assertions.assertEquals(
        "Birthdate cannot be in the future.",
        apiErrorResponse.getResponseBody().getSubErrors().get(0).getMessage());
  }
}
