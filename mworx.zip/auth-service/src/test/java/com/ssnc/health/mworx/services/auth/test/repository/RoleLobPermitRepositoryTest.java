/*
 * FILE : RoleRepositoryCriteriaTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.repository.RoleLobPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import java.util.ArrayList;
import java.util.Date;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

/**
 * This is to test RoleRepositoryCriteriaTest class It is used for testing that the summary roles
 * that gets called by the UI as part of findSearchCriteria gets tested with various combinations of
 * the query . roletype,rolename,primary and secondary permit along with active flag are the
 * combinations with/without pagination
 *
 * @author dt70033
 */
public class RoleLobPermitRepositoryTest extends BaseRepositoryTest {

  @Autowired private SecRoleRepository roleRepository;
  @Autowired private SecPermitRepository permitRepository;
  @Autowired private RoleLobPermitRepository roleLobpermitRepository;
  public static final String ROLE_NAME = "System Role";
  public static final String ROLE_TYPE = "System";
  public static long ROLE_ID = 23;
  public static final String PERMIT_PRIMARY = "Primary Permit";
  public static final String PERMIT_SECONDARY = "Secondary Permit";
  public static final String PERMIT_SECONDARY_ABBR = "Permits for System Role";
  public static final String STRING_VALUE = "VAL";
  public static final String ROLE_TYPE_MIX_VALUE = "RoLvAl";
  public static final String ROLE_TYPE_VALUE = "ROLVAL";
  private PageRequest pageable = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, "roleType");
  private Page<SecRole> pageSecRole = null;
  private Long lobId = null;

  @Test
  public void testRoleCriteriaQuery() {
    // inserting data into db
    // first create primary and secondary permits
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    permit.setCreateBy(1L);
    permit.setCreated(new Date());
    permit.setDescription(STRING_VALUE);
    permit.setLegacySystemId(STRING_VALUE);
    permit.setPermitAdditional(STRING_VALUE);
    permit.setReadOnly("Y");
    permit.setUpdateBy(1L);
    permit.setUpdated(new Date());
    permit.setPermitId(60L);
    permit = permitRepository.save(permit);

    permit.setRoleLobPermits(new ArrayList<>());

    SecRole secRole = new SecRole();
    secRole.setRoleName(ROLE_NAME);
    secRole.setRoleType(ROLE_TYPE);
    secRole.setEffDate(new Date());
    secRole.setRoleId(5L);
    SecRole role2 = roleRepository.save(secRole);
    SecPermit permit2 = permitRepository.save(permit);

    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setLinkId(60L);
    lobPermit.setLobId(6L);
    lobPermit.setActive("Y");
    lobPermit.setSecPermit(permit2);
    lobPermit.setSecRole(role2);
    ArrayList<RoleLobPermit> lstROP = new ArrayList<>();
    lstROP.add(lobPermit);
    secRole.setRoleLobPermits(lstROP);
    permit.setRoleLobPermits(lstROP);
    roleRepository.save(secRole);
    permitRepository.save(permit);
    roleLobpermitRepository.save(lobPermit);
    Optional<RoleLobPermit> result = roleLobpermitRepository.findById(60L);
    Assertions.assertNotNull(result);
  }
}
