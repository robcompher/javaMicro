/*
FILE : UserServicesTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.service;

import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import com.ssnc.health.mworx.services.auth.service.UserServiceImpl;
import com.ssnc.health.mworx.services.auth.test.repository.BaseRepositoryTest;
import java.util.Date;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

public class UserServicesTest extends BaseRepositoryTest {
  @Autowired private UserBasicRepository userRepository;

  @Autowired private UserServiceImpl userService;

  private static final String TEST_USER123 = "TestUser123";
  private static final String TEST_USER = "testUser";
  public static final String ROLE_NAME = "New Role";
  public static final String ROLE_TYPE = "Super Duper";
  public static final String PERMIT_PRIMARY = "Super Role";
  public static final String PERMIT_SECONDARY = "Super Role";

  private static final String PASSWORD1 = "t1stP@ssword";
  private static final String DEFAULT_SORT_BY = "username";

  /**
   * To verify the findUser() call after changing the password for multiple times.
   *
   * <p>In below data, we updated the password for three times and there are three user login
   * records are available for this user and irrespective of user login records it should get only
   * one unique record per user based on search criteria.
   */
  @Test
  void testChangePasswordAndFindUsers() {
    Optional<UserBasic> userBasicOptional = userService.getUser(TEST_USER123);
    if (userBasicOptional.isPresent()) {
      userRepository.delete(userBasicOptional.get());
    }
    UserBasic userBasic = buildUserBasic();
    userBasic.setUsername(TEST_USER123);
    userBasic = userService.addUser(userBasic, PASSWORD1);
    Assertions.assertNotNull(userBasic);
    Assertions.assertEquals(1, userBasic.getUserLogins().size());
    userBasic.getUserLogins().iterator().next().setLastLogin(new Date());
    userBasic = userRepository.save(userBasic);

    userBasic = userService.changePassword(userBasic, "TestP@ssword2");
    Assertions.assertNotNull(userBasic);
    Assertions.assertEquals(2, userBasic.getUserLogins().size());

    userBasic = userService.changePassword(userBasic, "TestP@ssword3");
    Assertions.assertNotNull(userBasic);

    /**
     * For findUsers() call it should get only one unique record per user based on search criteria
     * and irrespective of number of user login records.
     */
    UserBasic userSearch = new UserBasic();
    userSearch.setUsername(userBasic.getUsername());
    PageRequest pageRequest = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, DEFAULT_SORT_BY);
    boolean loggedInUsers = true;
    Page<UserBasic> userResponse = userService.findUsers(userSearch, pageRequest, loggedInUsers);
    Assertions.assertNotNull(userResponse);
    Assertions.assertEquals(1, userResponse.getTotalPages());
    Assertions.assertEquals(1, userResponse.getTotalElements());
    Assertions.assertEquals(1, userResponse.getContent().size());
    Assertions.assertEquals(
        userBasic.getUsername(), userResponse.getContent().get(0).getUsername());

    // User search criteria with active flag
    userSearch.setActive("Y");
    userResponse = userService.findUsers(userSearch, pageRequest, loggedInUsers);
    Assertions.assertNotNull(userResponse);
    Assertions.assertEquals(
        userBasic.getUsername(), userResponse.getContent().get(0).getUsername());

    userSearch.setActive("N");
    userResponse = userService.findUsers(userSearch, pageRequest, loggedInUsers);
    Assertions.assertNotNull(userResponse);
    Assertions.assertEquals(0, userResponse.getTotalPages());
    Assertions.assertEquals(0, userResponse.getTotalElements());

    userBasicOptional = userService.getUser(TEST_USER123);
    // Testing getUserById service
    Optional<UserBasic> userBasic2 = userService.getUserById(200L);
    Assertions.assertTrue(userBasic2.isEmpty());
    userBasic2 = userService.getUserById(userBasicOptional.get().getUserId());
    Assertions.assertFalse(userBasic2.isEmpty());
    Assertions.assertEquals(TEST_USER123, userBasic2.get().getUsername());
    userRepository.delete(userBasicOptional.get());
    userResponse = userService.findUsers(userBasic, pageRequest, loggedInUsers);
    Assertions.assertNotNull(userResponse);
    Assertions.assertEquals(0, userResponse.getTotalPages());
  }

  private UserBasic buildUserBasic() {
    UserBasic userBasic = new UserBasic();
    userBasic.setUsername("testUser");
    userBasic.setFirstName("testUser");
    userBasic.setLastName("testUser");
    return userBasic;
  }

  public void testLoggedInUser() {
    Optional<UserBasic> userBasic = userService.getUser();
    Assertions.assertNotNull(userBasic);
    Assertions.assertNotNull(userBasic.get());
    Assertions.assertNotNull(userBasic.get().getUsername());
    Assertions.assertEquals(TEST_USER, userBasic.get().getUsername());
  }
}
