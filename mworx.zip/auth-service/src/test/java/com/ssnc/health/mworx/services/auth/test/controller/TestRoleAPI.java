/*
 * FILE : TestRoleAPI.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

import com.ssnc.health.core.common.error.ApiError;
import com.ssnc.health.core.common.model.Pagination;
import com.ssnc.health.mworx.services.auth.api.model.ByID;
import com.ssnc.health.mworx.services.auth.api.model.DeleteRolePermitRequest;
import com.ssnc.health.mworx.services.auth.api.model.LOB;
import com.ssnc.health.mworx.services.auth.api.model.Permit;
import com.ssnc.health.mworx.services.auth.api.model.PermitListSummaryResponse;
import com.ssnc.health.mworx.services.auth.api.model.PermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.api.model.Role;
import com.ssnc.health.mworx.services.auth.api.model.RoleRequest;
import com.ssnc.health.mworx.services.auth.api.model.RoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.api.model.SecRoleListResponse;
import com.ssnc.health.mworx.services.auth.mappers.RoleMapper;
import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.RoleLobPermitSpecification;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryPermitSearchCriteria;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.repository.RoleLobPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.service.MetadataService;
import com.ssnc.health.mworx.services.auth.service.RoleService;
import com.ssnc.health.services.devtool.config.filters.DevUserDetails;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.apache.commons.lang.StringUtils;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mapstruct.factory.Mappers;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientResponseException;
import reactor.core.publisher.Mono;

/**
 * This test case is used test the RoleRestController end points.
 *
 * @author dt224133
 */
@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "35000")
class TestRoleAPI extends BaseResourceTest {
  @Autowired private WebTestClient webTestClient;

  @Mock private WebClient webClientMock;
  @Mock WebClient.RequestBodyUriSpec requestBodyUriSpec;

  @MockBean private RoleService mockSecRoleService;

  @MockBean private MetadataService mockMetadataService;

  @MockBean private SecRoleRepository mockSecRoleRepository;

  @MockBean private SecPermitRepository mockPermitRepository;

  @MockBean private RoleLobPermitRepository mockRoleLobPermitRepository;

  @Autowired DevUserDetails userDetails;

  @Mock private RoleLobPermitSpecification mockRoleLobPermitSpecification;
  private static final String ALL_ROLES_URI = "/api/role/getAllRoles";
  private static final String FIND_BY_SUMMARY_ROLES = "/api/role/findBySearchCriteria";
  private static final String FIND_BY_SUMMARY_PERMITS = "/api/role/findByPermitSearchCriteria";
  private static final String ROLE_BY_ID_URI = "/api/role/getRoleById";
  private static final String ADD_OR_UPDATE_ROLE_URI = "/api/role";
  private static final String ROLE_NAME_TYPES_URI = "/api/role/getRoleNameAndTypes";
  private static final String DELETE_ROLE_PERMIT_URI = "/api/role/permit/delete";
  private static final String ADD_ROLE_PERMIT_URI = "/api/role/permit";
  private static final String DELETE_BY_ID_URI = "/api/role/delete";

  public static final String PERMIT_PRIMARY = "System";
  public static final String PERMIT_SECONDARY = "View";

  @Value("${spring.liquibase.parameters.systemLOBID}")
  Long systemLOBID;

  List<SecRole> secRoleList = new ArrayList<>();
  private RoleMapper mapper = Mappers.getMapper(RoleMapper.class);

  @BeforeEach
  public void init() {

    MockitoAnnotations.initMocks(this);
    // mock the meta data calls
    List<RoleLobPermit> roleLobPermitList = new ArrayList<>();
    RoleLobPermit roleLobPermit = new RoleLobPermit();
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitPrimary("SECURITY");
    secPermit.setPermitSecondary("VIEW");
    roleLobPermit.setSecPermit(secPermit);
    roleLobPermitList.add(roleLobPermit);
    secRoleList = new ArrayList<>();

    SecRole secRole1 = new SecRole();
    secRole1.setRoleId(100L);
    secRole1.setRoleType("Billing");
    secRole1.setRoleName("Product");
    secRole1.setEffDate(new Date());
    secRole1.setTermDate(new Date());
    secRole1.setCreated(new Date());
    secRole1.setActive("Y");
    secRole1.setRoleLobPermits(roleLobPermitList);

    secRoleList.add(secRole1);

    SecRole secRole2 = new SecRole();
    secRole2.setRoleId(101L);
    secRole2.setRoleType("TEST");
    secRole2.setRoleName("TEST");
    secRole2.setEffDate(new Date());
    secRole2.setTermDate(new Date());
    secRole2.setCreated(new Date());
    secRole2.setActive("Y");
    secRole2.setRoleLobPermits(roleLobPermitList);

    secRoleList.add(secRole2);

    SecRole secRole3 = new SecRole();
    secRole3.setRoleId(102L);
    secRole3.setRoleType("Billing");
    secRole3.setRoleName("Product");
    secRole3.setEffDate(new Date());
    secRole3.setTermDate(new Date());
    secRole3.setCreated(new Date());
    secRole3.setActive("Y");
    secRole3.setRoleLobPermits(roleLobPermitList);

    secRoleList.add(secRole3);
  }

  @Test
  public void createRoleThrowsErrors() {
    // add Role with invalid lob
    Role inputRole = mapper.secRoleToRole(secRoleList.get(1));
    LOB lob = new LOB();
    lob.setLobId(1L);
    secRoleList.get(1).getRoleLobPermits().get(0).setLobId(lob.getLobId());
    inputRole.getPermits().get(0).setLob(lob);
    userDetails.setCurrentLobId(systemLOBID);
    userDetails.setCurrentLobName("TEST");
    EntityExchangeResult<ApiError> error =
        webTestClient
            .post()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputRole), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());
    // add Role with only name
    inputRole = mapper.secRoleToRole(secRoleList.get(1));
    lob.setLobId(null);
    lob.setLobName("TEST");
    lob.setOrganizationName(null);
    webTestClient
        .post()
        .uri(ADD_OR_UPDATE_ROLE_URI)
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(inputRole), Role.class)
        .exchange()
        .expectStatus()
        .is4xxClientError()
        .expectBody(ApiError.class)
        .returnResult();
    // add Role with only type
    inputRole = mapper.secRoleToRole(secRoleList.get(1));
    lob.setLobId(null);
    lob.setLobName(null);
    lob.setOrganizationName("TEST");
    webTestClient
        .post()
        .uri(ADD_OR_UPDATE_ROLE_URI)
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(inputRole), Role.class)
        .exchange()
        .expectStatus()
        .is4xxClientError()
        .expectBody(ApiError.class)
        .returnResult();
    // add Role with both
    inputRole = mapper.secRoleToRole(secRoleList.get(1));
    lob.setLobId(null);
    lob.setLobName("TEST");
    lob.setOrganizationName("TEST");
    webTestClient
        .post()
        .uri(ADD_OR_UPDATE_ROLE_URI)
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(inputRole), Role.class)
        .exchange()
        .expectStatus()
        .is4xxClientError()
        .expectBody(ApiError.class)
        .returnResult();
  }

  @Test
  public void createRoleValidLOB() {
    // add Role with lob
    Role inputRole = mapper.secRoleToRole(secRoleList.get(1));
    LOB lob = new LOB();
    lob.setLobId(4L);
    secRoleList.get(1).getRoleLobPermits().get(0).setLobId(lob.getLobId());
    inputRole.getPermits().get(0).setLob(lob);
    userDetails.setCurrentLobId(systemLOBID);

    // when(mockMetadataService.getLOBId(any(Long.class), Mockito.isNull(),
    // Mockito.isNull()))
    // .thenReturn(1L);
    // when(mockMetadataService.getLOBId(Mockito.isNull(), any(String.class),
    // any(String.class)))
    // .thenReturn(1L);
    // when(mockMetadataService.getLOBId(Mockito.isNull(), any(String.class),
    // Mockito.isNull()))
    // .thenReturn(1L);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(4L);

    when(mockSecRoleService.addRole(Mockito.any(SecRole.class)))
        .thenAnswer(
            new Answer<SecRole>() {
              public SecRole answer(InvocationOnMock invocation) {
                SecRole map = (SecRole) invocation.getArguments()[0];
                return map;
              }
            });
    EntityExchangeResult<Role> addedRole =
        webTestClient
            .post()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputRole), Role.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(addedRole);
    Assertions.assertTrue(
        addedRole.getResponseBody().getPermits().get(0).getLob().getLobId().equals(4L));
    // now with just name and type. should still work
    inputRole = mapper.secRoleToRole(secRoleList.get(1));
    lob = new LOB();
    lob.setLobId(null);
    lob.setLobName("TEST");
    lob.setOrganizationId(2L);
    inputRole.getPermits().get(0).setLob(lob);
    addedRole =
        webTestClient
            .post()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputRole), Role.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(addedRole);
    Assertions.assertTrue(
        addedRole.getResponseBody().getPermits().get(0).getLob().getLobId().equals(4L));
    // now without any lob should return validation error.
    inputRole = mapper.secRoleToRole(secRoleList.get(1));
    lob = null;
    inputRole.getPermits().get(0).setLob(lob);
    EntityExchangeResult<ApiError> roleError =
        webTestClient
            .post()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputRole), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, roleError.getStatus());
  }

  @Test
  public void test() {
    // getAllRole
    RoleRequest roleRequest = new RoleRequest();
    roleRequest.setIncludeInactive(true);
    Pagination pagination = new Pagination();
    pagination.setPage(0);
    pagination.setPageSize(10);
    pagination.setSortBy("roleType");
    pagination.setSortOrder("ASC");
    roleRequest.setPagination(pagination);

    Mockito.when(mockSecRoleService.getAllRoles(any(PageRequest.class), any(Boolean.class)))
        .thenReturn(secRoleList);

    // includeInactive true
    EntityExchangeResult<List<Role>> roleList =
        webTestClient
            .post()
            .uri(ALL_ROLES_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(roleRequest), RoleRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(Role.class)
            .returnResult();
    Assertions.assertNotNull(roleList);
    Assertions.assertTrue(roleList.getResponseBody().size() == 3);

    /**
     * API call to get the active roles with minimum information like roleName and roleType.
     * Example: For user screen we need to display the roles dropdown, for this scenario dont need
     * to get the complete information of roles.
     */
    Mockito.when(mockSecRoleService.getAllActiveRoles()).thenReturn(secRoleList);
    EntityExchangeResult<List<com.ssnc.health.mworx.services.auth.api.model.SecRole>> activeRoles =
        webTestClient
            .post()
            .uri(ROLE_NAME_TYPES_URI)
            .accept(MediaType.APPLICATION_JSON)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(com.ssnc.health.mworx.services.auth.api.model.SecRole.class)
            .returnResult();
    Assertions.assertNotNull(activeRoles);
    Assertions.assertEquals(3, activeRoles.getResponseBody().size());

    // with includeInactive false
    roleRequest.setIncludeInactive(false);
    EntityExchangeResult<List<Role>> roleList1 =
        webTestClient
            .post()
            .uri(ALL_ROLES_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(roleRequest), RoleRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(Role.class)
            .returnResult();
    Assertions.assertNotNull(roleList1);
    Assertions.assertTrue(roleList1.getResponseBody().size() == 3);

    // with DESC
    pagination.setSortOrder("DESC");
    roleRequest.setIncludeInactive(false);
    EntityExchangeResult<List<Role>> roleList2 =
        webTestClient
            .post()
            .uri(ALL_ROLES_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(roleRequest), RoleRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(Role.class)
            .returnResult();
    Assertions.assertNotNull(roleList2);
    Assertions.assertTrue(roleList2.getResponseBody().size() == 3);

    // with null Pagination
    Pagination nullPagination = new Pagination();
    roleRequest.setPagination(nullPagination);
    EntityExchangeResult<List<Role>> roleList3 =
        webTestClient
            .post()
            .uri(ALL_ROLES_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(roleRequest), RoleRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(Role.class)
            .returnResult();
    Assertions.assertNotNull(roleList3);
    Assertions.assertTrue(roleList3.getResponseBody().size() == 3);

    // getRoleByID
    Mockito.when(mockSecRoleService.getRoleById(Mockito.any(Long.class)))
        .thenReturn(Optional.of(secRoleList.get(0)));
    ByID byID = new ByID();
    byID.setId(100L);

    EntityExchangeResult<Role> role =
        webTestClient
            .post()
            .uri(ROLE_BY_ID_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(byID), ByID.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(role);
    Assertions.assertEquals("Billing", role.getResponseBody().getRoleType());

    // add Role
    Role inputRole = mapper.secRoleToRole(secRoleList.get(1));
    LOB lob = new LOB();
    lob.setLobId(1L);
    secRoleList.get(1).getRoleLobPermits().get(0).setLobId(lob.getLobId());
    inputRole.getPermits().get(0).setLob(lob);
    when(mockSecRoleService.addRole(Mockito.any(SecRole.class))).thenReturn(secRoleList.get(1));
    EntityExchangeResult<Role> addedRole =
        webTestClient
            .post()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputRole), Role.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(addedRole);
    Assertions.assertEquals("TEST", addedRole.getResponseBody().getRoleType());
    userDetails.setCurrentLobName("SYSTEM");
    // update Role
    Role updateRole = mapper.secRoleToRole(secRoleList.get(2));
    secRoleList.get(2).getRoleLobPermits().get(0).setLobId(lob.getLobId());
    updateRole.getPermits().get(0).setLob(lob);
    updateRole.setAdditionalData("additional data");
    secRoleList.get(2).setAdditionalData("additional data");
    when(mockSecRoleService.updateRole(Mockito.any(SecRole.class))).thenReturn(secRoleList.get(2));
    when(mockSecRoleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                return Optional.of(secRoleList.get(2));
              }
            });
    when(mockSecRoleRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                return Optional.of(secRoleList.get(2));
              }
            });
    EntityExchangeResult<Role> updatedRule =
        webTestClient
            .put()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(updateRole), Role.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(updatedRule);
    Assertions.assertEquals("Billing", updatedRule.getResponseBody().getRoleType());
    Assertions.assertEquals("additional data", updatedRule.getResponseBody().getAdditionalData());

    validateRoleTypeAndName(updateRole);
  }

  private void validateRoleTypeAndName(Role updateRole) {
    // For update role API call, modifying the role name or type is invalid.It
    // should return the
    // validation errors.
    updateRole.setRoleType("Billing1");
    EntityExchangeResult<ApiError> roleError =
        webTestClient
            .put()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(updateRole), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(roleError);
    Assertions.assertEquals(1, roleError.getResponseBody().getSubErrors().size());
    Assertions.assertTrue(
        roleError
            .getResponseBody()
            .getSubErrors()
            .get(0)
            .getMessage()
            .contains("Role type should not be modified"));

    updateRole.setRoleType("Billing");
    updateRole.setRoleName("Billing2");
    roleError =
        webTestClient
            .put()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(updateRole), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(roleError);
    Assertions.assertEquals(1, roleError.getResponseBody().getSubErrors().size());
    Assertions.assertTrue(
        roleError
            .getResponseBody()
            .getSubErrors()
            .get(0)
            .getMessage()
            .contains("Role name should not be modified"));
    updateRole.setRoleName("Product");
  }

  @Test
  public void testSearchCriteria() {
    RoleSearchCriteria roleRequest = new RoleSearchCriteria();
    roleRequest.setRoleType("RT");
    Pagination pagination = new Pagination();
    pagination.setPage(1);
    pagination.setPageSize(10);
    pagination.setSortBy("roleType");
    pagination.setSortOrder("ASC");
    roleRequest.setPagination(pagination);
    List<SecRole> list = new ArrayList<>();
    SecRole secRole = new SecRole();
    secRole.setRoleName("rname");
    secRole.setRoleType("rtype");
    list.add(secRole);
    Page<SecRole> page = new PageImpl<SecRole>(list);

    Mockito.when(mockSecRoleService.findRoleByCriteria(any(SummaryRoleSearchCriteria.class), any()))
        .thenReturn(page);

    // includeInactive true
    EntityExchangeResult<SecRoleListResponse> roleList =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_ROLES)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(roleRequest), RoleSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(SecRoleListResponse.class)
            .returnResult();
    Assertions.assertNotNull(roleList);
  }

  @Test
  public void testRoleNoPermits() {
    Role inputRole = mapper.secRoleToRole(secRoleList.get(1));
    inputRole.setPermits(null);
    when(mockSecRoleService.addRole(Mockito.any(SecRole.class)))
        .thenAnswer(
            new Answer<SecRole>() {
              public SecRole answer(InvocationOnMock invocation) {
                SecRole map = (SecRole) invocation.getArguments()[0];
                return map;
              }
            });
    EntityExchangeResult<Role> addedRole =
        webTestClient
            .post()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputRole), Role.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(addedRole);
    Assertions.assertEquals(addedRole.getResponseBody().getRoleName(), inputRole.getRoleName());
  }

  // InValid RoleIdValidation
  @Test
  public void testFindByPermitsRoleIdValidatorTest() {
    PermitSearchCriteria permitSearchCriteria = buildPermitSearchCriteria();
    LOB lob = new LOB();
    lob.setLobId(4L);
    permitSearchCriteria.setLob(lob);
    SecRole secRole = secRoleList.get(1);
    RoleLobPermit lobPermit = secRole.getRoleLobPermits().get(0);
    lobPermit.setLinkId(1L);
    lobPermit.setLobId(4L);
    userDetails.setCurrentLobId(systemLOBID);
    List<RoleLobPermit> list = new ArrayList<>();
    list.add(lobPermit);
    Page<RoleLobPermit> page = new PageImpl<RoleLobPermit>(list);

    Mockito.when(mockRoleLobPermitRepository.save(lobPermit)).thenReturn(lobPermit);
    Mockito.when(mockSecRoleService.findRoleLobPermit(Mockito.anyLong())).thenReturn(lobPermit);
    Mockito.when(mockSecRoleRepository.findById(Mockito.anyLong())).thenReturn(Optional.empty());
    Mockito.when(
            mockSecRoleService.findAssociatedPermitsByCriteria(
                any(SummaryPermitSearchCriteria.class), any()))
        .thenReturn(page);

    EntityExchangeResult<ApiError> error =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_PERMITS)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitSearchCriteria), PermitSearchCriteria.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals("roleId", error.getResponseBody().getSubErrors().get(0).getField());
  }

  // InValid LoBID,when LOBID not found in meta
  @Test
  public void testFindByPermitsLOBValidatorErrorTest() {

    PermitSearchCriteria permitSearchCriteria = buildPermitSearchCriteria();
    LOB lob = new LOB();
    lob.setLobId(404L);
    permitSearchCriteria.setLob(lob);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(null);
    SecRole secRole = secRoleList.get(1);
    RoleLobPermit lobPermit = secRole.getRoleLobPermits().get(0);
    lobPermit.setLinkId(1L);
    List<RoleLobPermit> list = new ArrayList<>();
    list.add(lobPermit);

    EntityExchangeResult<ApiError> error =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_PERMITS)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitSearchCriteria), PermitSearchCriteria.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());
  }

  // Given CurrentLOBName and CurrentLOBId
  @Test
  public void testFindByPermitsLOBValidatorTest() {

    PermitSearchCriteria permitSearchCriteria = buildPermitSearchCriteria();
    LOB lob = new LOB();
    lob.setLobId(4L);
    permitSearchCriteria.setLob(lob);

    SecRole secRole = secRoleList.get(1);
    RoleLobPermit lobPermit = secRole.getRoleLobPermits().get(0);
    lobPermit.setLinkId(1L);
    lobPermit.setLobId(4L);
    List<RoleLobPermit> list = new ArrayList<>();
    list.add(lobPermit);
    Page<RoleLobPermit> page = new PageImpl<RoleLobPermit>(list);

    userDetails.setCurrentLobId(4L);
    userDetails.setCurrentLobName("SYSTEM");

    Mockito.when(mockSecRoleService.getRoleById(101L)).thenReturn(Optional.of(secRole));
    Mockito.when(mockMetadataService.getLOBId(Mockito.any())).thenReturn(4L);
    Mockito.when(
            mockSecRoleService.findAssociatedPermitsByCriteria(
                any(SummaryPermitSearchCriteria.class), any()))
        .thenReturn(page);

    EntityExchangeResult<PermitListSummaryResponse> permitList =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_PERMITS)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitSearchCriteria), PermitSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(PermitListSummaryResponse.class)
            .returnResult();
    Assertions.assertNotNull(permitList);
    Assertions.assertNotNull(permitList.getResponseBody().getData().get(0).getLobId());
  }

  @Test
  public void testFindByPermitsLobAssociation() {

    PermitSearchCriteria permitSearchCriteria = buildPermitSearchCriteria();
    LOB lob = new LOB();
    lob.setLobId(4L);
    permitSearchCriteria.setLob(lob);

    SecRole secRole = secRoleList.get(1);
    RoleLobPermit lobPermit = secRole.getRoleLobPermits().get(0);
    lobPermit.setLinkId(1L);
    lobPermit.setLobId(4L);
    List<RoleLobPermit> list = new ArrayList<>();
    list.add(lobPermit);
    Page<RoleLobPermit> page = new PageImpl<RoleLobPermit>(list);

    userDetails.setCurrentLobId(10L);
    userDetails.setCurrentLobName("SYSTEM1");

    Mockito.when(mockSecRoleRepository.findById(101L)).thenReturn(Optional.of(secRole));
    Mockito.when(mockMetadataService.getLOBId(Mockito.any())).thenReturn(4L);
    Mockito.when(
            mockSecRoleService.findAssociatedPermitsByCriteria(
                any(SummaryPermitSearchCriteria.class), any()))
        .thenReturn(page);

    EntityExchangeResult<ApiError> lobAssociationError =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_PERMITS)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitSearchCriteria), PermitSearchCriteria.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    // Assertions.assertEquals(
    // "lob",
    // lobAssociationError.getResponseBody().getSubErrors().get(0).getField());
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, lobAssociationError.getStatus());
  }

  @Test
  public void testFindByPermitsNoLobAssociation() {

    PermitSearchCriteria permitSearchCriteria = buildPermitSearchCriteria();
    SecRole secRole = secRoleList.get(1);
    RoleLobPermit lobPermit = secRole.getRoleLobPermits().get(0);
    lobPermit.setLinkId(1L);
    lobPermit.setLobId(4L);
    List<RoleLobPermit> list = new ArrayList<>();
    list.add(lobPermit);
    Page<RoleLobPermit> page = new PageImpl<RoleLobPermit>(list);

    Mockito.when(mockSecRoleService.getRoleById(101L)).thenReturn(Optional.of(secRole));
    Mockito.when(mockMetadataService.getLOBId(Mockito.any())).thenReturn(4L);
    Mockito.when(
            mockSecRoleService.findAssociatedPermitsByCriteria(
                any(SummaryPermitSearchCriteria.class), any()))
        .thenReturn(page);

    EntityExchangeResult<PermitListSummaryResponse> permitList =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_PERMITS)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitSearchCriteria), PermitSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(PermitListSummaryResponse.class)
            .returnResult();
    Assertions.assertNotNull(permitList);
    Assertions.assertNotNull(permitList.getResponseBody().getData().get(0).getLobId());
  }

  private PermitSearchCriteria buildPermitSearchCriteria() {
    PermitSearchCriteria permitSearchCriteria = new PermitSearchCriteria();
    permitSearchCriteria.setPrimaryPermit(PERMIT_PRIMARY);
    permitSearchCriteria.setSecondaryPermit(PERMIT_SECONDARY);
    permitSearchCriteria.setRoleId(101L);
    permitSearchCriteria.setExisting(true);
    Pagination pagination = new Pagination();
    pagination.setPage(1);
    pagination.setPageSize(10);
    pagination.setSortBy("linkId");
    pagination.setSortOrder("ASC");
    permitSearchCriteria.setPagination(pagination);
    return permitSearchCriteria;
  }

  @Test
  public void testAddingLobPermitValidations() {
    setUpAddPermitMocks();
    // validate null is working
    Role role = new Role();
    EntityExchangeResult<ApiError> error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getField().equalsIgnoreCase("permits")));
    // invalid role id combination
    role.setRoleId(2L);
    Permit permit = new Permit();
    permit.setId(2L);
    LOB lob = new LOB();
    lob.setLobId(4L);
    role.setPermits(new ArrayList<>());
    permit.setLob(lob);
    role.getPermits().add(permit);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(4L);
    error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(1, error.getResponseBody().getSubErrors().size());
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getMessage().contains("Role ID,")));
    role.setRoleId(null);
    role.setRoleName("TEST2");
    role.setRoleType("TEST2");

    // invalid rolename/type
    error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(1, error.getResponseBody().getSubErrors().size());
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getMessage().contains("Role ID,")));
    // invalid permitId
    role.setRoleId(3L);
    role.getPermits().get(0).setId(3L);
    error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(1, error.getResponseBody().getSubErrors().size());
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getMessage().contains("Permit ID")));
    // invalid permit primary/secondary
    role.getPermits().get(0).setId(null);
    role.getPermits().get(0).setPermitPrimary("P");
    role.getPermits().get(0).setPermitSecondary("S");
    error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(1, error.getResponseBody().getSubErrors().size());
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getMessage().contains("Permit ID")));

    // invalid lob id
    role.getPermits().get(0).setId(2L);
    role.getPermits().get(0).getLob().setLobId(1L);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(1L);
    error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());
    // invalid lob name/type
    role.getPermits().get(0).setId(2L);
    role.getPermits().get(0).getLob().setLobId(null);
    role.getPermits().get(0).getLob().setLobName("L");
    role.getPermits().get(0).getLob().setOrganizationName("L");
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(null);
    error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());
    // lob doesn't match token
    userDetails.setCurrentLobId(2L);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(4L);
    role.getPermits().get(0).getLob().setLobId(1L);
    error =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());
    userDetails.setCurrentLobName("SYSTEM");
    userDetails.setCurrentOrganizationName("Organization");
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(4L);

    when(mockSecRoleService.saveUpdatedPermits(Mockito.any(SecRole.class)))
        .thenAnswer(
            new Answer<SecRole>() {
              public SecRole answer(InvocationOnMock invocation) {
                SecRole map = (SecRole) invocation.getArguments()[0];
                return map;
              }
            });
    // successful
    EntityExchangeResult<Role> result =
        webTestClient
            .post()
            .uri(ADD_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(role), Role.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(result);
    Assertions.assertNotNull(result.getResponseBody());
    Assertions.assertEquals(role.getRoleId(), result.getResponseBody().getRoleId());
  }

  private void setUpAddPermitMocks() {
    // setting up repository mocks
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    lobPermit.setLinkId(4L);
    lobPermit.setLobId(6L);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    secPermit.setPermitPrimary("PRIMARY");
    secPermit.setPermitPrimary("SECONDARY");
    lobPermit.setSecPermit(secPermit);
    SecRole role = new SecRole();
    role.setRoleId(3L);
    role.setRoleName("TEST");
    role.setRoleType("TEST");
    lobPermit.setSecRole(role);
    Optional<RoleLobPermit> rlp = Optional.of(lobPermit);
    when(mockSecRoleService.findRoleLobPermit(4L)).thenReturn(rlp.get());
    when(mockSecRoleService.findRoleLobPermit(5L)).thenReturn(null);
    Mockito.when(mockSecRoleService.getRoleById(Mockito.any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                return value.compareTo(3L) == 0 ? Optional.of(role) : Optional.empty();
              }
            });
    when(mockSecRoleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                String roleType = (String) invocation.getArguments()[0];
                String roleName = (String) invocation.getArguments()[1];
                return roleType.equalsIgnoreCase(role.getRoleType())
                        && roleName.equalsIgnoreCase(role.getRoleName())
                    ? Optional.of(role)
                    : Optional.empty();
              }
            });
    when(mockSecRoleRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                return value.compareTo(3L) == 0 ? Optional.of(role) : Optional.empty();
              }
            });
    when(mockPermitRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecPermit>>() {
              public Optional<SecPermit> answer(InvocationOnMock invocation) {
                Long value = (Long) invocation.getArguments()[0];
                return value.compareTo(2L) == 0 ? Optional.of(secPermit) : Optional.empty();
              }
            });
    when(mockPermitRepository.findByPermitPrimaryAndPermitSecondary(
            any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecPermit>>() {
              public Optional<SecPermit> answer(InvocationOnMock invocation) {
                String primary = (String) invocation.getArguments()[0];
                String secondary = (String) invocation.getArguments()[1];
                return primary.equalsIgnoreCase("PRIMARY")
                        && secondary.equalsIgnoreCase("SECONDARY")
                    ? Optional.of(secPermit)
                    : Optional.empty();
              }
            });
    Mockito.doAnswer(
            invocation -> {
              return null;
            })
        .when(mockSecRoleService)
        .saveUpdatedPermits(any(SecRole.class));

    when(mockMetadataService.getLOBId(Mockito.any(LOB.class)))
        .thenAnswer(
            new Answer<Long>() {
              public Long answer(InvocationOnMock invocation) {
                LOB lob = (LOB) invocation.getArguments()[0];
                if (lob != null && lob.getLobId() != null && lob.getLobId().compareTo(1L) == 0) {
                  return 1L;
                } else if (StringUtils.equalsIgnoreCase("LOBNAME", lob.getLobName())
                    && StringUtils.equalsIgnoreCase("ORGANIZATION", lob.getOrganizationName())) {
                  return 1L;
                }
                throw new WebClientResponseException(401, null, null, null, null);
              }
            });
  }

  @Test
  public void testDeletingRoleLobPermitImplicitPermissionError() {
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    lobPermit.setLinkId(4L);
    lobPermit.setLobId(4L);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    lobPermit.setSecPermit(secPermit);
    SecRole role = new SecRole();
    role.setRoleId(3L);
    role.setRoleName("TEST");
    lobPermit.setSecRole(role);
    Optional<RoleLobPermit> rlp = Optional.of(lobPermit);
    when(mockSecRoleService.findRoleLobPermit(4L)).thenReturn(rlp.get());
    when(mockSecRoleService.verifyDeleteLobPermit(any(Long.class))).thenReturn(false);
    DeleteRolePermitRequest drpr = new DeleteRolePermitRequest();
    drpr.setLinkId(4L);
    drpr.setRoleId(3L);
    EntityExchangeResult<ApiError> error =
        webTestClient
            .post()
            .uri(DELETE_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(drpr), DeleteRolePermitRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getField().equalsIgnoreCase("linkId")));
    Assertions.assertEquals(1, error.getResponseBody().getSubErrors().size());
  }

  @Test
  public void testDeletingRoleLobPermitValidations() {
    // validate null is working
    DeleteRolePermitRequest drpr = new DeleteRolePermitRequest();
    EntityExchangeResult<ApiError> error =
        webTestClient
            .post()
            .uri(DELETE_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(drpr), DeleteRolePermitRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getField().equalsIgnoreCase("linkId")));
    Assertions.assertTrue(
        error.getResponseBody().getSubErrors().stream()
            .anyMatch(subError -> subError.getField().equalsIgnoreCase("roleId")));
    // setting up repository mocks
    RoleLobPermit lobPermit = new RoleLobPermit();
    lobPermit.setActive("Y");
    lobPermit.setLinkId(4L);
    lobPermit.setLobId(4L);
    SecPermit secPermit = new SecPermit();
    secPermit.setPermitId(2L);
    lobPermit.setSecPermit(secPermit);
    SecRole role = new SecRole();
    role.setRoleId(3L);
    role.setRoleName("TEST");
    lobPermit.setSecRole(role);
    Optional<RoleLobPermit> rlp = Optional.of(lobPermit);
    when(mockSecRoleService.findRoleLobPermit(4L)).thenReturn(rlp.get());
    when(mockSecRoleService.findRoleLobPermit(5L)).thenReturn(null);
    when(mockSecRoleService.verifyDeleteLobPermit(any(Long.class))).thenReturn(true);
    // verify if sending an invalid link id it returns error
    drpr.setLinkId(5L);
    drpr.setRoleId(6L);
    error =
        webTestClient
            .post()
            .uri(DELETE_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(drpr), DeleteRolePermitRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(1, error.getResponseBody().getSubErrors().size());
    // if roleid doesn't match
    drpr.setLinkId(4L);
    error =
        webTestClient
            .post()
            .uri(DELETE_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(drpr), DeleteRolePermitRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(1, error.getResponseBody().getSubErrors().size());
    drpr.setRoleId(3L);
    userDetails.setCurrentLobId(99L);
    userDetails.setCurrentLobName("TEST");
    // should fail because currentLobId is different then lob in system
    error =
        webTestClient
            .post()
            .uri(DELETE_ROLE_PERMIT_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(drpr), DeleteRolePermitRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());

    lobPermit.setLobId(1L);
    userDetails.setCurrentLobId(1L);
    userDetails.setCurrentLobName("TEST");
    // now should be successful
    webTestClient
        .post()
        .uri(DELETE_ROLE_PERMIT_URI)
        .accept(MediaType.TEXT_PLAIN)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(drpr), DeleteRolePermitRequest.class)
        .exchange()
        .expectStatus()
        .is2xxSuccessful();

    // now system lob. should be successful
    userDetails.setCurrentLobId(3L);
    userDetails.setCurrentLobName("SYSTEM");
    userDetails.setCurrentOrganizationName("Organization");
    webTestClient
        .post()
        .uri(DELETE_ROLE_PERMIT_URI)
        .accept(MediaType.TEXT_PLAIN)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(drpr), DeleteRolePermitRequest.class)
        .exchange()
        .expectStatus()
        .is2xxSuccessful();
  }

  @Test
  public void testUpdateRoleNoId() {
    userDetails.setCurrentLobId(1L);
    LOB lob = new LOB();
    lob.setLobId(1L);
    Role updateRole = mapper.secRoleToRole(secRoleList.get(2));
    updateRole.setRoleId(null);
    secRoleList.get(2).getRoleLobPermits().get(0).setLobId(lob.getLobId());
    updateRole.getPermits().get(0).setLob(lob);
    updateRole.setAdditionalData("additional data");
    secRoleList.get(2).setAdditionalData("additional data");
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(1L);
    when(mockSecRoleService.updateRole(Mockito.any(SecRole.class))).thenReturn(secRoleList.get(2));
    when(mockSecRoleRepository.findByRoleTypeAndRoleName(any(String.class), any(String.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                return Optional.of(secRoleList.get(2));
              }
            });
    when(mockSecRoleRepository.findById(any(Long.class)))
        .thenAnswer(
            new Answer<Optional<SecRole>>() {
              public Optional<SecRole> answer(InvocationOnMock invocation) {
                return Optional.of(secRoleList.get(2));
              }
            });
    EntityExchangeResult<Role> updatedRule =
        webTestClient
            .put()
            .uri(ADD_OR_UPDATE_ROLE_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(updateRole), Role.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Role.class)
            .returnResult();
    Assertions.assertNotNull(updatedRule);
    Assertions.assertEquals("Billing", updatedRule.getResponseBody().getRoleType());
    Assertions.assertEquals("additional data", updatedRule.getResponseBody().getAdditionalData());
  }

  private PermitSearchCriteria buildSummaryPermitSearchCriteria() {
    PermitSearchCriteria permitSearchCriteria = new PermitSearchCriteria();
    permitSearchCriteria.setPrimaryPermit(PERMIT_PRIMARY);
    permitSearchCriteria.setSecondaryPermit(PERMIT_SECONDARY);
    permitSearchCriteria.setRoleId(101L);
    permitSearchCriteria.setExisting(false);
    Pagination pagination = new Pagination();
    pagination.setPage(1);
    pagination.setPageSize(10);
    pagination.setSortBy("permitId");
    pagination.setSortOrder("ASC");
    permitSearchCriteria.setPagination(pagination);
    return permitSearchCriteria;
  }

  @Test
  public void testFindByNonAssociatedPermits() {

    PermitSearchCriteria permitSearchCriteria = buildSummaryPermitSearchCriteria();
    LOB lob = new LOB();
    lob.setLobId(4L);
    permitSearchCriteria.setLob(lob);

    SecRole secRole = secRoleList.get(1);
    RoleLobPermit lobPermit = secRole.getRoleLobPermits().get(0);
    lobPermit.setLobId(4L);
    List<SecPermit> permitList = new ArrayList<>();
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permitList.add(permit);
    Page<SecPermit> page = new PageImpl<SecPermit>(permitList);
    when(mockMetadataService.getLOBId(Mockito.any(LOB.class))).thenReturn(4L);
    Mockito.when(mockPermitRepository.save(any(SecPermit.class))).thenReturn(permit);
    Mockito.when(mockRoleLobPermitRepository.save(any(RoleLobPermit.class))).thenReturn(lobPermit);
    Mockito.when(mockSecRoleService.getRoleById(101L)).thenReturn(Optional.of(secRole));
    Mockito.when(
            mockSecRoleService.findNonAssociatedPermitsByCriteria(
                any(SummaryPermitSearchCriteria.class), any()))
        .thenReturn(page);

    EntityExchangeResult<PermitListSummaryResponse> permitResultList =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_PERMITS)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitSearchCriteria), PermitSearchCriteria.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(PermitListSummaryResponse.class)
            .returnResult();
    Assertions.assertNotNull(permitResultList);
    Assertions.assertNotNull(permitResultList.getResponseBody());
    Assertions.assertEquals(
        "System", permitResultList.getResponseBody().getData().get(0).getPermitPrimary());
    Assertions.assertEquals(1, permitResultList.getResponseBody().getData().size());
  }

  @Test
  public void testFindByNonAssociatedPermitswithError() {

    PermitSearchCriteria permitSearchCriteria = buildSummaryPermitSearchCriteria();
    LOB lob = new LOB();
    lob.lobId(null);
    permitSearchCriteria.setLob(lob);
    permitSearchCriteria.setExisting(false);
    userDetails.setCurrentLobId(4L);
    userDetails.setCurrentLobName("SYSTEM");
    userDetails.setCurrentOrganizationName("SYSTEM");

    EntityExchangeResult<ApiError> error =
        webTestClient
            .post()
            .uri(FIND_BY_SUMMARY_PERMITS)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitSearchCriteria), PermitSearchCriteria.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertEquals(HttpStatus.UNAUTHORIZED, error.getStatus());
  }

  @Test
  public void testdeleteRoleById() {
    ByID byID = new ByID();
    byID.setId(100L);
    Mockito.when(mockSecRoleService.deleteRoleById(Mockito.any(Long.class))).thenReturn(true);

    webTestClient
        .put()
        .uri(DELETE_BY_ID_URI)
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(byID), ByID.class)
        .exchange()
        .expectStatus()
        .isNoContent()
        .expectBody(Void.class)
        .returnResult();
  }

  @Test
  public void testdeleteRoleByIdDoesNotExist() {
    ByID byID = new ByID();
    byID.setId(12345L);
    Mockito.when(mockSecRoleService.deleteRoleById(Mockito.any(Long.class))).thenReturn(false);

    webTestClient
        .put()
        .uri(DELETE_BY_ID_URI)
        .accept(MediaType.APPLICATION_JSON)
        .contentType(MediaType.APPLICATION_JSON)
        .body(Mono.just(byID), ByID.class)
        .exchange()
        .expectStatus()
        .isNotFound()
        .expectBody(Void.class)
        .returnResult();
  }
}
