/*
FILE : OAuth2UserResourceTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.mockito.Mockito.*;

import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import com.ssnc.health.mworx.services.auth.service.UserServiceImpl;
import com.ssnc.health.mworx.services.auth.test.utis.TestUtils;
import java.util.Optional;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.WebTestClient;

@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "35000")
class OAuth2UserResourceTest extends BaseResourceTest {
  @Autowired WebTestClient webTestClient;

  @MockBean private UserServiceImpl userService;

  @MockBean private SecurityContext context;

  @MockBean private Authentication auth;

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);
  }

  @Test
  void testUserInfo() {

    AppUser appUser = new AppUser();
    appUser.setFirstName("FirstName");
    appUser.setLastName("LastName");
    appUser.setUsername("testUser");
    appUser.setNoOfDaysToPasswordExpire(10);
    appUser.setAccountNonExpired(true);
    appUser.setAccountNonLocked(true);
    when(userService.loadUserByUserName("testUser")).thenReturn((UserDetails) appUser);

    when(context.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(context);

    webTestClient
        .get()
        .uri("/oauth/userinfo")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("$.firstName")
        .isEqualTo("FirstName")
        .jsonPath("$.lastName")
        .isEqualTo("LastName")
        .jsonPath("$.noOfDaysToPasswordExpire")
        .isEqualTo("10");
    verify(userService).loadUserByUserName("testUser");
  }

  @Test
  void testUserLogout() {

    UserBasic userBasic = TestUtils.buildUserBasic();
    when(userService.getUser()).thenReturn(Optional.of(TestUtils.buildUserBasic()));

    when(context.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(context);

    webTestClient.post().uri("/oauth/logout").exchange().expectStatus().isOk();
  }

  @Test
  void testAppUserNull() {

    AppUser appUser = null;
    when(context.getAuthentication()).thenReturn(auth);
    SecurityContextHolder.setContext(context);

    webTestClient
        .get()
        .uri("/oauth/userinfo")
        .exchange()
        .expectStatus()
        .isOk()
        .expectBody()
        .jsonPath("$.firstName")
        .isEmpty()
        .jsonPath("$.lastName")
        .isEmpty()
        .jsonPath("$.noOfDaysToPasswordExpire")
        .isEqualTo("0");
  }

  @Test
  void testUserInfoAuthNull() {

    AppUser appUser = new AppUser();
    appUser.setFirstName("FirstName");
    appUser.setLastName("LastName");
    appUser.setUsername("testUser");
    appUser.setNoOfDaysToPasswordExpire(10);
    when(userService.loadUserByUserName("testUser")).thenReturn((UserDetails) appUser);
    Authentication NullAuth = null;
    when(context.getAuthentication()).thenReturn(NullAuth);
    SecurityContextHolder.setContext(context);

    webTestClient.get().uri("/oauth/userinfo").exchange().expectStatus().isOk().expectBody();
  }
}
