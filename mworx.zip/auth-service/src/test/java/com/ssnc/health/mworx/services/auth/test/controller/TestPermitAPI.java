/*
 * FILE : TestPermitAPI.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.mockito.Mockito.when;

import com.ssnc.health.mworx.services.auth.api.model.ByID;
import com.ssnc.health.mworx.services.auth.api.model.Permit;
import com.ssnc.health.mworx.services.auth.api.model.PermitRequest;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.service.PermitService;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

/**
 * This test case is used test the PermitRestController end points.
 *
 * @author dt224133
 */
@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "5000")
class TestPermitAPI extends BaseResourceTest {

  @Autowired private WebTestClient webTestClient;

  @MockBean private PermitService mockPermitService;

  List<SecPermit> permits = null;
  private static final String ALL_PERMITS_URI = "/api/permit/getAllPermits";
  private static final String PERMIT_BY_ID = "/api/permit/getPermitById";

  @BeforeEach
  public void init() {

    permits = new ArrayList<>();
    SecPermit secPermit1 = new SecPermit();
    secPermit1.setPermitId(100L);
    secPermit1.setPermitPrimary("SECURITY");
    secPermit1.setPermitSecondary("VIEW");
    secPermit1.setDescription("Security View");
    secPermit1.setActive("Y");
    secPermit1.setCreated(new Date());
    permits.add(secPermit1);

    SecPermit secPermit2 = new SecPermit();
    secPermit2.setPermitId(101L);
    secPermit2.setPermitPrimary("SECURITY");
    secPermit2.setPermitSecondary("UPDATE");
    secPermit2.setDescription("Security Update");
    secPermit2.setActive("Y");
    secPermit2.setCreated(new Date());
    permits.add(secPermit2);

    SecPermit secPermit3 = new SecPermit();
    secPermit3.setPermitId(102L);
    secPermit3.setPermitPrimary("RECON");
    secPermit3.setPermitSecondary("VIEW");
    secPermit3.setDescription("RECON VIEW");
    secPermit3.setActive("Y");
    secPermit3.setCreated(new Date());
    permits.add(secPermit3);
  }

  @Test
  public void test() {

    // getAllPermits
    when(mockPermitService.getAllPermits(Mockito.any(Boolean.class))).thenReturn(permits);
    PermitRequest permitRequest = new PermitRequest();
    permitRequest.setIncludeInactive(true);
    EntityExchangeResult<List<Permit>> permitList =
        webTestClient
            .post()
            .uri(ALL_PERMITS_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(permitRequest), PermitRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(Permit.class)
            .returnResult();
    Assertions.assertNotNull(permitList);
    Assertions.assertTrue(permitList.getResponseBody().size() == 3);

    // getPermitByID
    when(mockPermitService.getPermitById(Mockito.any(Long.class)))
        .thenReturn(Optional.of(permits.get(0)));
    ByID byID = new ByID();
    byID.setId(100L);

    EntityExchangeResult<Permit> permit =
        webTestClient
            .post()
            .uri(PERMIT_BY_ID)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(byID), ByID.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Permit.class)
            .returnResult();
    Assertions.assertNotNull(permit);
    Assertions.assertEquals("SECURITY", permit.getResponseBody().getPermitPrimary());
  }
}
