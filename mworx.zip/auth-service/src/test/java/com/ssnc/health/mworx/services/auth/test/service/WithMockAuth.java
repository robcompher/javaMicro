/*
 * FILE : WithMockAuth.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.service;

import java.lang.annotation.*;
import java.lang.annotation.Retention;
import org.springframework.security.test.context.support.WithSecurityContext;
import org.springframework.test.context.ActiveProfiles;

/**
 * Annotation for setting mock authentication. You can specify userId and authorities as comma
 * separated. If no arguments are specified , user id and authorities mentioned in properties wil be
 * considered. This annotation can be specified at class level or method level.
 *
 * @author dt216896
 */
@ActiveProfiles("test")
@Retention(RetentionPolicy.RUNTIME)
@WithSecurityContext(factory = WithMockAuthSecurityContextFactory.class)
public @interface WithMockAuth {
  boolean isAuthenticated() default true;

  String userName() default "default";

  long userId() default 0;

  String authorities() default "";
}
