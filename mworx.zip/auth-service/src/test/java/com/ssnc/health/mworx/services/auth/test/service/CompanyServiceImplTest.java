/*
 * FILE : CompanyServiceImplTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.service;

import static org.mockito.Mockito.*;

import com.ssnc.health.mworx.services.auth.model.SecCompany;
import com.ssnc.health.mworx.services.auth.repository.SecCompanyRepository;
import com.ssnc.health.mworx.services.auth.service.CompanyServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.ContextConfiguration;

@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
@ContextConfiguration
class CompanyServiceImplTest {
  @InjectMocks private CompanyServiceImpl companyServiceMock;
  @Mock private SecCompanyRepository secCompanyRepositoryMock;

  private SecCompany secCompany;

  @BeforeEach
  public void setUp() throws Exception {
    secCompany = new SecCompany();
    secCompany.setActive("Y");
    secCompany.setAddress1("1027 New Street");
    secCompany.setCity("Sometown");
    secCompany.setZip("19222");
  }

  @Test
  void testUpdateCompany() {
    when(secCompanyRepositoryMock.save(any(SecCompany.class))).thenReturn(secCompany);

    SecCompany updatedCompany = companyServiceMock.updateCompany(secCompany);

    Assertions.assertNotNull(updatedCompany);
    Assertions.assertEquals("19222", updatedCompany.getZip());
    verify(secCompanyRepositoryMock).save(any(SecCompany.class));
  }

  @Test
  void testAddCompany() {
    when(secCompanyRepositoryMock.save(any(SecCompany.class))).thenReturn(secCompany);

    SecCompany addedCompany = companyServiceMock.addCompany(secCompany);

    Assertions.assertNotNull(addedCompany);
    Assertions.assertEquals("19222", addedCompany.getZip());
    verify(secCompanyRepositoryMock).save(any(SecCompany.class));
  }
}
