/*
 * FILE : CustomAccessDeniedHandlerTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020- by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.errors;

import static org.mockito.Mockito.*;

import com.ssnc.health.mworx.services.auth.errors.CustomAccessDeniedHandler;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.test.context.ActiveProfiles;

@ActiveProfiles("test")
@ExtendWith(MockitoExtension.class)
class CustomAccessDeniedHandlerTest {

  @Mock private CustomAccessDeniedHandler accessDeniedHandler;

  @BeforeEach
  void setUp() throws Exception {
    accessDeniedHandler = new CustomAccessDeniedHandler();
  }

  @Test
  void testHandle() throws Exception {
    MockHttpServletRequest request = new MockHttpServletRequest();
    MockHttpServletResponse response = new MockHttpServletResponse();
    AccessDeniedException ex = new AccessDeniedException("");

    Assertions.assertThrows(
        AccessDeniedException.class,
        () -> {
          accessDeniedHandler.handle(request, response, ex);
        });
  }
}
