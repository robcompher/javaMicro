/*
 * FILE : WithMockAuthSecurityContextFactory.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs
 * created and maintained by SS&C Health, are proprietary
 * in nature and as such are confidential. Any unauthorized
 * use or disclosure of such information may result in civil
 * liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health.
 * All Rights Reserved.
 *
 */
package com.ssnc.health.mworx.services.auth.test.service;

import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.security.test.context.support.WithSecurityContextFactory;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.util.Assert;

@ActiveProfiles("test")
public class WithMockAuthSecurityContextFactory
    implements WithSecurityContextFactory<WithMockAuth> {

  @Value("${spring.security.user.id}")
  private Long userId;

  @Value("${spring.security.user.authorities}")
  private List<String> authoritiesList;

  @Override
  public SecurityContext createSecurityContext(WithMockAuth mockAuthAnnotation) {
    SecurityContext ctx = SecurityContextHolder.createEmptyContext();
    Map<String, Object> headersMap = new HashMap<>();
    Map<String, Object> claimsMap = new HashMap<>();
    claimsMap.put("ABC", mockAuthAnnotation.userId());
    claimsMap.put("user_id", mockAuthAnnotation.userId());
    claimsMap.put("sub", mockAuthAnnotation.userName());
    headersMap.put("workflow", "workflow");
    List<GrantedAuthority> authorities = new ArrayList<>();
    if (mockAuthAnnotation.authorities().length() == 0) {
      for (String auth : authoritiesList) {
        Assert.isTrue(
            !auth.startsWith("PERMIT_"),
            () -> auth + " cannot start with PERMIT_ (it is automatically added)");
        authorities.add(new SimpleGrantedAuthority("PERMIT_" + auth));
      }
    } else {
      String[] authoritiesArray = mockAuthAnnotation.authorities().split(",");
      for (String auth : authoritiesArray) {
        Assert.isTrue(
            !auth.startsWith("PERMIT_"),
            () -> auth + " cannot start with PERMIT_ (it is automatically added)");
        authorities.add(new SimpleGrantedAuthority("PERMIT_" + auth));
      }
    }
    claimsMap.put("authority", authorities);

    Jwt jwt =
        new Jwt(
            "WorkflowJobToken",
            new Date().toInstant(),
            new Date().toInstant().plus(3, ChronoUnit.HOURS),
            headersMap,
            claimsMap);
    JwtAuthenticationToken token = new JwtAuthenticationToken(jwt, new ArrayList<>());
    ctx.setAuthentication(token);
    SecurityContextHolder.setContext(ctx);
    return ctx;
  }
}
