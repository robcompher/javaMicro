/*
 * FILE : RoleServicesTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health,
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020- by SS&C Health. All Rights Reserved.
 *
 */

package com.ssnc.health.mworx.services.auth.test.service;

import static org.mockito.Mockito.when;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.query.specification.SummaryRoleSearchCriteria;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.service.RoleServiceImpl;
import com.ssnc.health.mworx.services.auth.test.repository.BaseRepositoryTest;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;

/**
 * This test case is used test the RoleService create and update functionality without permits. The
 * GUI creates and updates the roles without any permits and this test makes sure that it doesnt
 * mess up the existing permits when there are no permits sent in.
 *
 * @author dt70033
 */
public class RoleServicesTest extends BaseRepositoryTest {
  @Autowired private SecPermitRepository permitRepository;
  @Mock private SecRoleRepository roleRepository;
  @Autowired RoleServiceImpl roleService;
  @InjectMocks RoleServiceImpl roleServiceImpl;
  List<SecRole> roles = null;
  public static final String ROLE_NAME = "New Role";
  public static final String ROLE_TYPE = "Super Duper";
  public static long ROLE_ID = 28;
  public static final String PERMIT_PRIMARY = "Super Role";
  public static final String PERMIT_SECONDARY = "Super Role";
  private PageRequest pageable = PageRequest.of(0, 10, Sort.DEFAULT_DIRECTION, "roleType");

  @Test
  @WithMockAuth(userName = "default")
  public void testRoleService() {
    create();
    update();
    testGetAllActiveRoles();
  }

  private void create() {
    roles = new ArrayList<>();

    SecRole secRole1 = new SecRole();
    secRole1.setRoleId(100L);
    secRole1.setRoleType("Billing");
    secRole1.setRoleName("Product");
    secRole1.setEffDate(new Date());
    secRole1.setCreated(new Date());
    secRole1.setActive("Y");
    roles.add(secRole1);
    SecRole role2 = roleService.addRole(secRole1);
    Optional<SecRole> role3 = roleService.getRoleById(role2.getRoleId());
    Assertions.assertNotNull(role3.get().getRoleId());

    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("Y");
    permitRepository.save(permit);
    Optional<SecPermit> permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);
    Assertions.assertTrue(permitResult.isPresent(), "Repository result should be present");

    // associate permits to role
    RoleLobPermit rop = new RoleLobPermit();
    rop.setLobId(1L);
    rop.setSecPermit(permitResult.get());
    rop.setSecRole(secRole1);
    ArrayList<RoleLobPermit> lstROP = new ArrayList<>();
    lstROP.add(rop);
    secRole1.setRoleLobPermits(lstROP);
    role2 = roleService.updateRole(secRole1);
  }

  private void update() {
    SecRole role2;
    SummaryRoleSearchCriteria roleSearch = new SummaryRoleSearchCriteria();
    roleSearch.setRoleName("Product");
    Page<SecRole> pageSecRole = roleService.findRoleByCriteria(roleSearch, pageable);
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());
    role2 = pageSecRole.getContent().get(0);
    long size = role2.getRoleLobPermits().size();
    // by this time you should have got all the roles and permits
    // now you want to just change something in the role and verify that
    // it doesnt mess up the permits
    SecRole secRoleForUpdate = new SecRole();
    secRoleForUpdate.setRoleType("Billing");
    secRoleForUpdate.setRoleName("Product");
    secRoleForUpdate.setEffDate(new Date());
    secRoleForUpdate.setCreated(new Date());
    secRoleForUpdate.setActive("Y");
    secRoleForUpdate.setLegacySystemId("LEGSYS1");
    secRoleForUpdate.setRoleLobPermits(null);
    secRoleForUpdate.setRoleId((role2.getRoleId()));

    role2 = roleService.updateRole(secRoleForUpdate);
    role2 = roleService.getRoleById(role2.getRoleId()).get();
    Assertions.assertNotNull(role2.getRoleId());
    // first verify that your updates are in the db.
    Assertions.assertEquals("LEGSYS1", role2.getLegacySystemId());
    pageSecRole = roleService.findRoleByCriteria(roleSearch, pageable);
    // then verify that you are able to see the role lob permits
    Assertions.assertNotNull(pageSecRole);
    Assertions.assertEquals(1, pageSecRole.getNumberOfElements());

    Assertions.assertEquals(
        size,
        pageSecRole.getContent().get(0).getRoleLobPermits().stream()
            .filter(roleLobPermit -> ("Y").equalsIgnoreCase(roleLobPermit.getActive()))
            .collect(Collectors.toList())
            .size());
  }

  private void testGetAllActiveRoles() {

    SecRole secRole = new SecRole();
    secRole.setRoleType("System Admin");
    secRole.setRoleName("Security BPO");
    secRole.setEffDate(new Date());
    secRole.setActive("Y");
    secRole = roleService.addRole(secRole);
    Assertions.assertNotNull(secRole.getRoleId());

    secRole = new SecRole();
    secRole.setRoleType("Admin");
    secRole.setRoleName("Admin dept2");
    secRole.setEffDate(new Date());
    secRole.setActive("Y");
    secRole = roleService.addRole(secRole);
    Assertions.assertNotNull(secRole.getRoleId());

    secRole = new SecRole();
    secRole.setRoleType("System Admin");
    secRole.setRoleName("Security3");
    secRole.setEffDate(new Date());
    secRole.setActive("Y");
    secRole = roleService.addRole(secRole);
    Assertions.assertNotNull(secRole.getRoleId());

    secRole = new SecRole();
    secRole.setRoleType("System Admin");
    secRole.setRoleName("Security2");
    secRole.setEffDate(new Date());
    secRole.setActive("Y");
    secRole = roleService.addRole(secRole);
    Assertions.assertNotNull(secRole.getRoleId());

    secRole = new SecRole();
    secRole.setRoleType("Admin");
    secRole.setRoleName("Admin dept1");
    secRole.setEffDate(new Date());
    secRole.setActive("Y");
    secRole = roleService.addRole(secRole);
    Assertions.assertNotNull(secRole.getRoleId());

    secRole = new SecRole();
    secRole.setRoleType("System Admin");
    secRole.setRoleName("Developer");
    secRole.setEffDate(new Date());
    secRole.setActive("Y");
    secRole = roleService.addRole(secRole);
    Assertions.assertNotNull(secRole.getRoleId());

    List<SecRole> rolesList = roleService.getAllActiveRoles();
    Assertions.assertNotNull(rolesList);
    secRole = rolesList.get(0);
    Assertions.assertEquals("Admin", secRole.getRoleType());
    Assertions.assertEquals("Admin dept1", secRole.getRoleName());

    secRole = rolesList.get(1);
    Assertions.assertEquals("Admin", secRole.getRoleType());
    Assertions.assertEquals("Admin dept2", secRole.getRoleName());

    secRole = rolesList.get(2);
    Assertions.assertEquals("Billing", secRole.getRoleType());
    Assertions.assertEquals("Product", secRole.getRoleName());
  }

  @Test
  public void deleteRoleById() {
    SecRole secRole = getSecRole();
    Mockito.when(roleRepository.save(secRole)).thenReturn(secRole);
    when(roleRepository.findById(200L)).thenReturn(Optional.of(secRole));
    Assertions.assertTrue(roleServiceImpl.deleteRoleById(200L));
  }

  private SecRole getSecRole() {
    SecRole secRole = new SecRole();
    secRole.setRoleType("System Admin");
    secRole.setRoleName("Security BPO");
    secRole.setEffDate(new Date());
    secRole.setActive("N");
    return secRole;
  }
}
