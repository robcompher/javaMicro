/*
FILE : TestMyProfileChangePasswordAPI.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.mockito.Mockito.when;

import com.ssnc.health.core.common.error.ApiError;
import com.ssnc.health.mworx.services.auth.api.model.MyProfilePasswordRequest;
import com.ssnc.health.mworx.services.auth.model.UserBasic;
import com.ssnc.health.mworx.services.auth.model.UserLogin;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import com.ssnc.health.mworx.services.auth.repository.UserBasicRepository;
import com.ssnc.health.mworx.services.auth.service.UserService;
import com.ssnc.health.mworx.services.auth.test.utis.TestUtils;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.security.crypto.password.DelegatingPasswordEncoder;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "5000")
class TestMyProfileChangePasswordAPI extends BaseResourceTest {

  @Autowired private DelegatingPasswordEncoder passwordEncoder;
  private static String MyProfileChangePasswordURI = "/api/user/myprofile/changePassword";
  private static String msg =
      "Password requirements. Min 8 char, min 1 uppercase, min 1 number, min 1 special char.";
  private static String VALIDATION_ERROR_MESSAGE =
      "New password does not meet the length, complexity, or history requirements.";

  @Autowired private WebTestClient webTestClient;

  @MockBean private UserService mockUserService;

  @MockBean private UserBasicRepository userBasicRepository;
  @MockBean private SecRoleRepository secRoleRepository;

  /** User updates password if new and confirmPassword are the same. */
  @Test
  public void updatePassword() {
    UserBasic userBasic = TestUtils.buildUserBasic();
    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));

    // Get LoggedInUser
    when(mockUserService.getUser()).thenReturn(Optional.of(userBasic));

    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    MyProfilePasswordRequest changePasswordRequest = new MyProfilePasswordRequest();
    changePasswordRequest.setNewPassword("testPassword0!");
    changePasswordRequest.setConfirmPassword("testPassword0!");
    changePasswordRequest.setCurrentPassword("testPassword");

    EntityExchangeResult<String> userBasicResult =
        webTestClient
            .post()
            .uri(MyProfileChangePasswordURI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), MyProfilePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertNotNull(userBasicResult);
    Assertions.assertTrue(
        userBasicResult.getResponseBody().contains("Successfully updated the password for User"));
  }

  /**
   * No Current, confirm and new Password
   *
   * @throws Exception
   */
  @Test
  public void changePasswordInvalidInput() throws Exception {

    UserBasic userBasic = TestUtils.buildUserBasic();

    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));

    // Get LoggedInUser
    when(mockUserService.getUser()).thenReturn(Optional.of(userBasic));

    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    MyProfilePasswordRequest changePasswordRequest = new MyProfilePasswordRequest();
    changePasswordRequest.setCurrentPassword("");
    changePasswordRequest.setConfirmPassword("");
    changePasswordRequest.setNewPassword("");

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri(MyProfileChangePasswordURI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), MyProfilePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError);
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getField().equals("newPassword")));
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getField().equals("currentPassword")));
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getField().equals("confirmPassword")));
  }

  /**
   * No Current, confirm and new Password
   *
   * @throws Exception
   */
  @Test
  public void changePasswordInvalidPattern() throws Exception {

    UserBasic userBasic = TestUtils.buildUserBasic();

    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));

    // Get LoggedInUser
    when(mockUserService.getUser()).thenReturn(Optional.of(userBasic));

    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    MyProfilePasswordRequest changePasswordRequest = new MyProfilePasswordRequest();
    changePasswordRequest.setNewPassword("testPassword");
    changePasswordRequest.setConfirmPassword("testPassword");
    changePasswordRequest.setCurrentPassword("testPassword");

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri(MyProfileChangePasswordURI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), MyProfilePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();
    Assertions.assertNotNull(apiError);
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getField().equals("newPassword")));

    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(apiValidtionError -> apiValidtionError.getMessage().equals(msg)));
  }

  @Test
  public void testChangePasswordInHistory() throws Exception {
    UserBasic userBasic = TestUtils.buildUserBasic();
    UserLogin userLogin = buildUserLogin("testPassword@123");
    List<UserLogin> userLogins = new ArrayList<>();
    userLogins.add(userLogin);
    userBasic.setUserLogins(userLogins);
    Assertions.assertNotNull(userBasic);
    Assertions.assertEquals(1, userBasic.getUserLogins().size());
    // Assertions.assertEquals("testPassword@123", userBasic.getUserLogins().get(0).getPassword());

    when(mockUserService.changePassword(Mockito.any(UserBasic.class), Mockito.any(String.class)))
        .thenReturn(userBasic);

    when(mockUserService.getUser(Mockito.any(String.class))).thenReturn(Optional.of(userBasic));

    // Get LoggedInUser
    when(mockUserService.getUser()).thenReturn(Optional.of(userBasic));

    when(mockUserService.getUserLogin(Mockito.any(UserBasic.class)))
        .thenReturn(Optional.of(userBasic.getUserLogins().get(0)));

    // Try to use the password from the history record
    MyProfilePasswordRequest changePasswordRequest = new MyProfilePasswordRequest();
    changePasswordRequest.setNewPassword("testPassword@123");
    changePasswordRequest.setCurrentPassword("testPassword@123");
    changePasswordRequest.setConfirmPassword("testPassword@123");

    EntityExchangeResult<ApiError> apiError =
        webTestClient
            .post()
            .uri(MyProfileChangePasswordURI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), MyProfilePasswordRequest.class)
            .exchange()
            .expectStatus()
            .is4xxClientError()
            .expectBody(ApiError.class)
            .returnResult();

    Assertions.assertNotNull(apiError.getResponseBody());
    Assertions.assertNotNull(apiError.getResponseBody().getSubErrors());
    Assertions.assertTrue(
        apiError.getResponseBody().getSubErrors().stream()
            .anyMatch(
                apiValidtionError ->
                    apiValidtionError.getMessage().equals(VALIDATION_ERROR_MESSAGE)));

    // Set Another password
    changePasswordRequest = new MyProfilePasswordRequest();

    changePasswordRequest.setNewPassword("TestP@ssw0rd1234");
    changePasswordRequest.setCurrentPassword("testPassword@123");
    changePasswordRequest.setConfirmPassword("TestP@ssw0rd1234");

    EntityExchangeResult<String> userResult =
        webTestClient
            .post()
            .uri(MyProfileChangePasswordURI)
            .contentType(MediaType.APPLICATION_JSON)
            .accept(MediaType.APPLICATION_JSON)
            .body(Mono.just(changePasswordRequest), MyProfilePasswordRequest.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(String.class)
            .returnResult();
    Assertions.assertNotNull(userResult);
    Assertions.assertTrue(
        userResult.getResponseBody().contains("Successfully updated the password for User"));
  }

  public UserLogin buildUserLogin(String password) {
    UserLogin userLogin = new UserLogin();
    userLogin.setFailureAttempts(0);
    userLogin.setPassword(passwordEncoder.encode(password));
    userLogin.setCreated(new Date());
    userLogin.setUpdated(new Date());
    return userLogin;
  }
}
