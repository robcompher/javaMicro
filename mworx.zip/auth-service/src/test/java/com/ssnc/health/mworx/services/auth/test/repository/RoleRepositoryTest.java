/*
 * FILE : RoleRepositoryTest.java
 *
 * COPYRIGHT:
 *
 * The computer systems, procedures, data bases and programs created and maintained by SS&C Health
 * are proprietary in nature and as such are confidential. Any unauthorized use or disclosure of
 * such information may result in civil liabilities.
 *
 * Copyright (C) 2020 - by SS&C Health All Rights Reserved.
 */
package com.ssnc.health.mworx.services.auth.test.repository;

import com.ssnc.health.mworx.services.auth.model.RoleLobPermit;
import com.ssnc.health.mworx.services.auth.model.SecPermit;
import com.ssnc.health.mworx.services.auth.model.SecRole;
import com.ssnc.health.mworx.services.auth.repository.SecPermitRepository;
import com.ssnc.health.mworx.services.auth.repository.SecRoleRepository;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;

/**
 * This is to test RoleRepository class
 *
 * @author DT224621
 */
public class RoleRepositoryTest extends BaseRepositoryTest {

  @Autowired private SecRoleRepository roleRepository;
  @Autowired private SecPermitRepository permitRepository;
  public static final String ROLE_NAME = "New Role";
  public static final String ROLE_TYPE = "Super Duper";
  public static long ROLE_ID = 23;
  public static final String PERMIT_PRIMARY = "Super Role";
  public static final String PERMIT_SECONDARY = "Super Role";

  @Test
  public void testAll() {

    // inserting data into role table

    SecRole role = new SecRole();
    role.setRoleId(ROLE_ID);
    role.setRoleName(ROLE_NAME);
    role.setRoleType(ROLE_TYPE);
    role.setEffDate(Calendar.getInstance().getTime());

    // inserting data into permit table
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("N");
    permitRepository.save(permit);
    Optional<SecPermit> permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);
    Assertions.assertTrue(permitResult.isPresent(), "Repository result should be present");

    // associate permits to role

    roleRepository.save(role);

    // testFindByRoleNameAndRoleType
    Optional<SecRole> newRole = roleRepository.findByRoleTypeAndRoleName(ROLE_NAME, ROLE_TYPE);
    Assertions.assertNotNull(newRole);
  }

  // Testing lob related information making sure it works
  @Test
  public void testLOBInformation() {
    SecRole role = new SecRole();
    role.setRoleId(ROLE_ID);
    role.setRoleName(ROLE_NAME);
    role.setRoleType(ROLE_TYPE);
    role.setEffDate(Calendar.getInstance().getTime());

    // inserting data into permit table
    SecPermit permit = new SecPermit();
    permit.setPermitPrimary(PERMIT_PRIMARY);
    permit.setPermitSecondary(PERMIT_SECONDARY);
    permit.setActive("Y");
    permitRepository.save(permit);
    Optional<SecPermit> permitResult =
        permitRepository.findByPermitPrimaryAndPermitSecondary(PERMIT_PRIMARY, PERMIT_SECONDARY);
    Assertions.assertNotNull(permitResult);
    Assertions.assertTrue(permitResult.isPresent(), "Repository result should be present");

    // associate permits to role
    RoleLobPermit rop = new RoleLobPermit();
    rop.setLobId(1L);
    rop.setSecPermit(permitResult.get());
    rop.setSecRole(role);
    ArrayList<RoleLobPermit> lstROP = new ArrayList<>();
    lstROP.add(rop);
    role.setRoleLobPermits(lstROP);
    SecRole role2 = roleRepository.save(role);
    Assertions.assertEquals(1, role2.getRoleLobPermits().size());
    Assertions.assertTrue(role2.getRoleLobPermits().get(0).getLobId().equals(1L));
    // make sure get works
    Optional<SecRole> roleList = roleRepository.findByRoleTypeAndRoleName(ROLE_TYPE, ROLE_NAME);
    Assertions.assertEquals(1, roleList.get().getRoleLobPermits().size());
    Assertions.assertTrue(roleList.get().getRoleLobPermits().get(0).getLobId().equals(1L));
    // set it to null to make sure it still saves
    role2.getRoleLobPermits().get(0).setLobId(null);
    role2 = roleRepository.save(role2);
    Assertions.assertEquals(1, role2.getRoleLobPermits().size());
    Assertions.assertNull(role2.getRoleLobPermits().get(0).getLobId());
    roleList = roleRepository.findByRoleTypeAndRoleName(ROLE_TYPE, ROLE_NAME);
    Assertions.assertEquals(1, roleList.get().getRoleLobPermits().size());
    Assertions.assertNull(roleList.get().getRoleLobPermits().get(0).getLobId());
    // now lets just change some role properties
    Optional<SecRole> roleForUpdate =
        roleRepository.findByRoleTypeAndRoleName(ROLE_TYPE, ROLE_NAME);
    Assertions.assertEquals(1, roleForUpdate.get().getRoleLobPermits().size());
    SecRole roleToBeUpdated = roleForUpdate.get();
    roleToBeUpdated.setLegacySystemId("NEWLEG");
    // set it to null to make sure it still saves
    role2 = roleRepository.save(role2);
    roleForUpdate = roleRepository.findByRoleTypeAndRoleName(ROLE_TYPE, ROLE_NAME);
    role2 = roleForUpdate.get();

    Assertions.assertEquals(1, role2.getRoleLobPermits().size());
    Assertions.assertNull(role2.getRoleLobPermits().get(0).getLobId());
    Assertions.assertEquals("NEWLEG", role2.getLegacySystemId());
    Assertions.assertEquals(1, roleList.get().getRoleLobPermits().size());
    Assertions.assertNull(roleList.get().getRoleLobPermits().get(0).getLobId());
  }
}
