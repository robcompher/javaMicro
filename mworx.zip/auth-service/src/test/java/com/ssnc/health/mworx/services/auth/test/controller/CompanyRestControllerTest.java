/*
FILE : CompanyRestControllerTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.ssnc.health.core.common.model.Pagination;
import com.ssnc.health.mworx.services.auth.api.model.Company;
import com.ssnc.health.mworx.services.auth.mappers.CompanyMapper;
import com.ssnc.health.mworx.services.auth.model.SecCompany;
import com.ssnc.health.mworx.services.auth.repository.SecCompanyRepository;
import com.ssnc.health.mworx.services.auth.service.CompanyService;
import java.util.LinkedList;
import java.util.List;
import java.util.Optional;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.mapstruct.factory.Mappers;
import org.mockito.MockitoAnnotations;
import org.mockito.invocation.InvocationOnMock;
import org.mockito.stubbing.Answer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.reactive.AutoConfigureWebTestClient;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.reactive.server.EntityExchangeResult;
import org.springframework.test.web.reactive.server.WebTestClient;
import reactor.core.publisher.Mono;

@ActiveProfiles("test")
@TestInstance(Lifecycle.PER_CLASS)
@AutoConfigureWebTestClient(timeout = "5000")
class CompanyRestControllerTest extends BaseResourceTest {
  @Autowired private WebTestClient webTestClient;
  @MockBean private CompanyService mockService;

  @MockBean private SecCompanyRepository mockSecCompanyRepository;
  private static final String ALL_COMPANIES_URI = "/api/company/";
  private static final String DELETE_COMPANY_URI = "/api/company/delete";
  private static final String ADD_COMPANY_URI = "/api/company";
  private static final String UPDATE_COMPANY_URI = "/api/company/updateCompany";
  List<SecCompany> secCompanyList = new LinkedList<>();
  private CompanyMapper mapper = Mappers.getMapper(CompanyMapper.class);

  @BeforeEach
  void setUp() {
    MockitoAnnotations.initMocks(this);

    SecCompany company1 = new SecCompany();
    company1.setCompanyId(1L);
    company1.setCompany("company tom");
    company1.setActive("Y");
    company1.setAddress1("1007 Federal St");
    company1.setCity("Lebanon");
    company1.setZip("17042");

    secCompanyList.add(company1);

    SecCompany company2 = new SecCompany();
    company2.setCompanyId(2L);
    company2.setCompany("company beth");
    company2.setActive("Y");
    company2.setAddress1("1027 Federal St");
    company2.setCity("Lebanon");
    company2.setZip("17042");

    secCompanyList.add(company2);

    SecCompany company3 = new SecCompany();
    company3.setCompanyId(3L);
    company3.setCompany("company kim");
    company3.setActive("Y");
    company3.setAddress1("104 New St");
    company3.setCity("Lansdale");
    company3.setZip("19446");

    secCompanyList.add(company3);
  }

  @Test
  void testGetCompanyList() {
    // getCompanyList
    // method tested doesn't really do anything, but created test for coverage
    Pagination pagination = new Pagination();
    pagination.setPage(0);
    pagination.setPageSize(10);
    pagination.setSortBy("companyName");
    pagination.setSortOrder("ASC");

    EntityExchangeResult<List<Company>> companyList =
        webTestClient
            .post()
            .uri(ALL_COMPANIES_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(pagination), Pagination.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBodyList(Company.class)
            .returnResult();
    Assertions.assertNotNull(companyList);
  }

  @Test
  void testDeleteCompany() {
    // delete company
    // method tested doesn't really do anything, but created test for coverage
    Company inputCompany = mapper.domainToModel(secCompanyList.get(0));

    EntityExchangeResult<Company> deletedCompany =
        webTestClient
            .post()
            .uri(DELETE_COMPANY_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputCompany), Company.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Company.class)
            .returnResult();
    Assertions.assertNotNull(deletedCompany);
  }

  @Test
  void testAddCompany() {
    // addCompany
    Company inputCompany = mapper.domainToModel(secCompanyList.get(1));
    when(mockService.addCompany(any(SecCompany.class))).thenReturn(secCompanyList.get(1));
    EntityExchangeResult<Company> addedCompany =
        webTestClient
            .post()
            .uri(ADD_COMPANY_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(inputCompany), Company.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Company.class)
            .returnResult();
    Assertions.assertNotNull(addedCompany);
    Assertions.assertEquals("company beth", addedCompany.getResponseBody().getCompanyName());
    verify(mockService).addCompany(any(SecCompany.class));
  }

  @Test
  void testUpdateCompany() {
    // update Company
    Company updateCompany = mapper.domainToModel(secCompanyList.get(2));
    updateCompany.setContactPerson("some person");
    secCompanyList.get(2).setContactPerson("some person");
    when(mockService.updateCompany(any(SecCompany.class))).thenReturn(secCompanyList.get(2));
    when(mockSecCompanyRepository.findById(any(Integer.class)))
        .thenAnswer(
            new Answer<Optional<SecCompany>>() {
              public Optional<SecCompany> answer(InvocationOnMock invocation) {
                return Optional.of(secCompanyList.get(2));
              }
            });
    EntityExchangeResult<Company> updatedCompany =
        webTestClient
            .put()
            .uri(UPDATE_COMPANY_URI)
            .accept(MediaType.APPLICATION_JSON)
            .contentType(MediaType.APPLICATION_JSON)
            .body(Mono.just(updateCompany), Company.class)
            .exchange()
            .expectStatus()
            .isOk()
            .expectBody(Company.class)
            .returnResult();
    Assertions.assertNotNull(updatedCompany);
    Assertions.assertEquals("19446", updatedCompany.getResponseBody().getZip());
    Assertions.assertEquals("some person", updatedCompany.getResponseBody().getContactPerson());
    verify(mockService).updateCompany(any(SecCompany.class));
  }
}
