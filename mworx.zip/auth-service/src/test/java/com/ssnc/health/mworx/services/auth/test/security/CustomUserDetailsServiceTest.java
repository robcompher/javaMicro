/*
FILE : CustomUserDetailsServiceTest.java
COPYRIGHT:
The computer systems, procedures, data bases and programs
created and maintained by SS&C Health are proprietary
in nature and as such are confidential. Any unauthorized
use or disclosure of such information may result in civil
liabilities.
Copyright (C) 2020 - by SS&C Health
All Rights Reserved. */
package com.ssnc.health.mworx.services.auth.test.security;

import static org.mockito.Mockito.*;

import com.ssnc.health.mworx.services.auth.exception.UserNotEffectiveException;
import com.ssnc.health.mworx.services.auth.security.AppUser;
import com.ssnc.health.mworx.services.auth.security.CustomUserDetailsService;
import com.ssnc.health.mworx.services.auth.service.UserServiceImpl;
import java.util.Calendar;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.*;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(SpringExtension.class)
@ContextConfiguration
class CustomUserDetailsServiceTest {

  @InjectMocks private CustomUserDetailsService userDetailService;

  @Mock private UserServiceImpl userServiceMock;

  private UserDetails newAppUser;

  @Test
  void testLoadUserByUsername() {
    AppUser appUser = new AppUser();

    when(userServiceMock.loadUserByUserName("appuser")).thenReturn((UserDetails) appUser);
    when(userServiceMock.loadUserByUserName("nulluser")).thenReturn((UserDetails) null);

    // test null user
    Assertions.assertThrows(
        UsernameNotFoundException.class,
        () -> {
          newAppUser = userDetailService.loadUserByUsername("nulluser");
        });

    // test blank username
    appUser.setUsername("");
    Assertions.assertThrows(
        UsernameNotFoundException.class,
        () -> {
          newAppUser = userDetailService.loadUserByUsername("appuser");
        });

    // test user returned
    Calendar cl = Calendar.getInstance();
    cl.set(Calendar.DAY_OF_YEAR, cl.get(Calendar.DAY_OF_YEAR) - 1);
    appUser.setUsername("user");
    appUser.setEffDate(cl.getTime());
    newAppUser = userDetailService.loadUserByUsername("appuser");
    Assertions.assertNotNull(newAppUser);
    Assertions.assertEquals("user", newAppUser.getUsername());
    // test if effective date after
    cl.set(Calendar.DAY_OF_YEAR, cl.get(Calendar.DAY_OF_YEAR) + 3);
    appUser.setEffDate(cl.getTime());
    Assertions.assertThrows(
        UserNotEffectiveException.class,
        () -> {
          newAppUser = userDetailService.loadUserByUsername("appuser");
        });
    // for some reson effective date is null
    appUser.setEffDate(null);
    Assertions.assertThrows(
        UserNotEffectiveException.class,
        () -> {
          newAppUser = userDetailService.loadUserByUsername("appuser");
        });
  }
}
