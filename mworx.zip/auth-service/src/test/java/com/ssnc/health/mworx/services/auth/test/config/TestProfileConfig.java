package com.ssnc.health.mworx.services.auth.test.config;

import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.transaction.annotation.EnableTransactionManagement;

/** Created by dt203397 on 2/3/2020. */
@Configuration
@EnableJpaRepositories("com.ssnc.health.mworx.services.auth.repository")
@EntityScan("com.ssnc.health.mworx.services.auth.model")
@EnableTransactionManagement
public class TestProfileConfig {}
